
package mvc_talend.mvc_crash_stage_0_1;

import routines.Numeric;
import routines.DataOperation;
import routines.TalendDataGenerator;
import routines.TalendStringUtil;
import routines.TalendString;
import routines.StringHandling;
import routines.Relational;
import routines.TalendDate;
import routines.Mathematical;
import routines.SQLike;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;

@SuppressWarnings("unused")

/**
 * Job: MVC_Crash_Stage Purpose: <br>
 * Description: <br>
 * 
 * @author chokshi.ra@northeastern.edu
 * @version 8.0.1.20211109_1610
 * @status
 */
public class MVC_Crash_Stage implements TalendJob {
	static {
		System.setProperty("TalendJob.log", "MVC_Crash_Stage.log");
	}

	private static org.apache.logging.log4j.Logger log = org.apache.logging.log4j.LogManager
			.getLogger(MVC_Crash_Stage.class);

	protected static void logIgnoredError(String message, Throwable cause) {
		log.error(message, cause);

	}

	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}

	private final static String defaultCharset = java.nio.charset.Charset.defaultCharset().name();

	private final static String utf8Charset = "UTF-8";

	// contains type for every context property
	public class PropertiesWithType extends java.util.Properties {
		private static final long serialVersionUID = 1L;
		private java.util.Map<String, String> propertyTypes = new java.util.HashMap<>();

		public PropertiesWithType(java.util.Properties properties) {
			super(properties);
		}

		public PropertiesWithType() {
			super();
		}

		public void setContextType(String key, String type) {
			propertyTypes.put(key, type);
		}

		public String getContextType(String key) {
			return propertyTypes.get(key);
		}
	}

	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();

	// create application properties with default
	public class ContextProperties extends PropertiesWithType {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties) {
			super(properties);
		}

		public ContextProperties() {
			super();
		}

		public void synchronizeContext() {

		}

		// if the stored or passed value is "<TALEND_NULL>" string, it mean null
		public String getStringValue(String key) {
			String origin_value = this.getProperty(key);
			if (NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY.equals(origin_value)) {
				return null;
			}
			return origin_value;
		}

	}

	protected ContextProperties context = new ContextProperties(); // will be instanciated by MS.

	public ContextProperties getContext() {
		return this.context;
	}

	private final String jobVersion = "0.1";
	private final String jobName = "MVC_Crash_Stage";
	private final String projectName = "MVC_TALEND";
	public Integer errorCode = null;
	private String currentComponent = "";

	private final java.util.Map<String, Object> globalMap = new java.util.HashMap<String, Object>();
	private final static java.util.Map<String, Object> junitGlobalMap = new java.util.HashMap<String, Object>();

	private final java.util.Map<String, Long> start_Hash = new java.util.HashMap<String, Long>();
	private final java.util.Map<String, Long> end_Hash = new java.util.HashMap<String, Long>();
	private final java.util.Map<String, Boolean> ok_Hash = new java.util.HashMap<String, Boolean>();
	public final java.util.List<String[]> globalBuffer = new java.util.ArrayList<String[]>();

	private final JobStructureCatcherUtils talendJobLog = new JobStructureCatcherUtils(jobName,
			"_5XRbMN16Ee2YsdD2WHnMvg", "0.1");
	private org.talend.job.audit.JobAuditLogger auditLogger_talendJobLog = null;

	private RunStat runStat = new RunStat(talendJobLog, System.getProperty("audit.interval"));

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";

	private final static String KEY_DB_DATASOURCES_RAW = "KEY_DB_DATASOURCES_RAW";

	public void setDataSources(java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources.entrySet()) {
			talendDataSources.put(dataSourceEntry.getKey(),
					new routines.system.TalendDataSource(dataSourceEntry.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}

	public void setDataSourceReferences(List serviceReferences) throws Exception {

		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		java.util.Map<String, javax.sql.DataSource> dataSources = new java.util.HashMap<String, javax.sql.DataSource>();

		for (java.util.Map.Entry<String, javax.sql.DataSource> entry : BundleUtils
				.getServices(serviceReferences, javax.sql.DataSource.class).entrySet()) {
			dataSources.put(entry.getKey(), entry.getValue());
			talendDataSources.put(entry.getKey(), new routines.system.TalendDataSource(entry.getValue()));
		}

		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}

	private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
	private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(new java.io.BufferedOutputStream(baos));

	public String getExceptionStackTrace() {
		if ("failure".equals(this.getStatus())) {
			errorMessagePS.flush();
			return baos.toString();
		}
		return null;
	}

	private Exception exception;

	public Exception getException() {
		if ("failure".equals(this.getStatus())) {
			return this.exception;
		}
		return null;
	}

	private class TalendException extends Exception {

		private static final long serialVersionUID = 1L;

		private java.util.Map<String, Object> globalMap = null;
		private Exception e = null;
		private String currentComponent = null;
		private String virtualComponentName = null;

		public void setVirtualComponentName(String virtualComponentName) {
			this.virtualComponentName = virtualComponentName;
		}

		private TalendException(Exception e, String errorComponent, final java.util.Map<String, Object> globalMap) {
			this.currentComponent = errorComponent;
			this.globalMap = globalMap;
			this.e = e;
		}

		public Exception getException() {
			return this.e;
		}

		public String getCurrentComponent() {
			return this.currentComponent;
		}

		public String getExceptionCauseMessage(Exception e) {
			Throwable cause = e;
			String message = null;
			int i = 10;
			while (null != cause && 0 < i--) {
				message = cause.getMessage();
				if (null == message) {
					cause = cause.getCause();
				} else {
					break;
				}
			}
			if (null == message) {
				message = e.getClass().getName();
			}
			return message;
		}

		@Override
		public void printStackTrace() {
			if (!(e instanceof TalendException || e instanceof TDieException)) {
				if (virtualComponentName != null && currentComponent.indexOf(virtualComponentName + "_") == 0) {
					globalMap.put(virtualComponentName + "_ERROR_MESSAGE", getExceptionCauseMessage(e));
				}
				globalMap.put(currentComponent + "_ERROR_MESSAGE", getExceptionCauseMessage(e));
				System.err.println("Exception in component " + currentComponent + " (" + jobName + ")");
			}
			if (!(e instanceof TDieException)) {
				if (e instanceof TalendException) {
					e.printStackTrace();
				} else {
					e.printStackTrace();
					e.printStackTrace(errorMessagePS);
					MVC_Crash_Stage.this.exception = e;
				}
			}
			if (!(e instanceof TalendException)) {
				try {
					for (java.lang.reflect.Method m : this.getClass().getEnclosingClass().getMethods()) {
						if (m.getName().compareTo(currentComponent + "_error") == 0) {
							m.invoke(MVC_Crash_Stage.this, new Object[] { e, currentComponent, globalMap });
							break;
						}
					}

					if (!(e instanceof TDieException)) {
					}
				} catch (Exception e) {
					this.e.printStackTrace();
				}
			}
		}
	}

	public void tBigQueryInput_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tBigQueryInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMap_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tBigQueryInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBOutput_2_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tBigQueryInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void talendJobLog_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		talendJobLog_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tBigQueryInput_1_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void talendJobLog_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public static class Load_DataStruct implements routines.system.IPersistableRow<Load_DataStruct> {
		final static byte[] commonByteArrayLock_MVC_TALEND_MVC_Crash_Stage = new byte[0];
		static byte[] commonByteArray_MVC_TALEND_MVC_Crash_Stage = new byte[0];

		public String borough;

		public String getBorough() {
			return this.borough;
		}

		public String contributing_factor_vehicle_1;

		public String getContributing_factor_vehicle_1() {
			return this.contributing_factor_vehicle_1;
		}

		public String contributing_factor_vehicle_2;

		public String getContributing_factor_vehicle_2() {
			return this.contributing_factor_vehicle_2;
		}

		public String contributing_factor_vehicle_3;

		public String getContributing_factor_vehicle_3() {
			return this.contributing_factor_vehicle_3;
		}

		public String contributing_factor_vehicle_4;

		public String getContributing_factor_vehicle_4() {
			return this.contributing_factor_vehicle_4;
		}

		public String contributing_factor_vehicle_5;

		public String getContributing_factor_vehicle_5() {
			return this.contributing_factor_vehicle_5;
		}

		public String cross_street_name;

		public String getCross_street_name() {
			return this.cross_street_name;
		}

		public java.util.Date collision_dt;

		public java.util.Date getCollision_dt() {
			return this.collision_dt;
		}

		public Integer collision_hour;

		public Integer getCollision_hour() {
			return this.collision_hour;
		}

		public java.util.Date collision_time;

		public java.util.Date getCollision_time() {
			return this.collision_time;
		}

		public Integer collision_dayoftheweek;

		public Integer getCollision_dayoftheweek() {
			return this.collision_dayoftheweek;
		}

		public Double latitude;

		public Double getLatitude() {
			return this.latitude;
		}

		public Double longitude;

		public Double getLongitude() {
			return this.longitude;
		}

		public String location;

		public String getLocation() {
			return this.location;
		}

		public Integer number_of_cyclist_injured;

		public Integer getNumber_of_cyclist_injured() {
			return this.number_of_cyclist_injured;
		}

		public Integer number_of_cyclist_killed;

		public Integer getNumber_of_cyclist_killed() {
			return this.number_of_cyclist_killed;
		}

		public Integer number_of_motorist_injured;

		public Integer getNumber_of_motorist_injured() {
			return this.number_of_motorist_injured;
		}

		public Integer number_of_motorist_killed;

		public Integer getNumber_of_motorist_killed() {
			return this.number_of_motorist_killed;
		}

		public Integer number_of_pedestrians_injured;

		public Integer getNumber_of_pedestrians_injured() {
			return this.number_of_pedestrians_injured;
		}

		public Integer number_of_pedestrians_killed;

		public Integer getNumber_of_pedestrians_killed() {
			return this.number_of_pedestrians_killed;
		}

		public Integer number_of_persons_injured;

		public Integer getNumber_of_persons_injured() {
			return this.number_of_persons_injured;
		}

		public Integer number_of_persons_killed;

		public Integer getNumber_of_persons_killed() {
			return this.number_of_persons_killed;
		}

		public String off_street_name;

		public String getOff_street_name() {
			return this.off_street_name;
		}

		public String on_street_name;

		public String getOn_street_name() {
			return this.on_street_name;
		}

		public int unique_key;

		public int getUnique_key() {
			return this.unique_key;
		}

		public String vehicle_type_code1;

		public String getVehicle_type_code1() {
			return this.vehicle_type_code1;
		}

		public String vehicle_type_code2;

		public String getVehicle_type_code2() {
			return this.vehicle_type_code2;
		}

		public String vehicle_type_code3;

		public String getVehicle_type_code3() {
			return this.vehicle_type_code3;
		}

		public String vehicle_type_code4;

		public String getVehicle_type_code4() {
			return this.vehicle_type_code4;
		}

		public String vehicle_type_code5;

		public String getVehicle_type_code5() {
			return this.vehicle_type_code5;
		}

		public Integer zip_code;

		public Integer getZip_code() {
			return this.zip_code;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_MVC_Crash_Stage.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_MVC_Crash_Stage.length == 0) {
						commonByteArray_MVC_TALEND_MVC_Crash_Stage = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_MVC_Crash_Stage = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MVC_TALEND_MVC_Crash_Stage, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_MVC_Crash_Stage, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_MVC_Crash_Stage.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_MVC_Crash_Stage.length == 0) {
						commonByteArray_MVC_TALEND_MVC_Crash_Stage = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_MVC_Crash_Stage = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MVC_TALEND_MVC_Crash_Stage, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_MVC_Crash_Stage, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_MVC_Crash_Stage) {

				try {

					int length = 0;

					this.borough = readString(dis);

					this.contributing_factor_vehicle_1 = readString(dis);

					this.contributing_factor_vehicle_2 = readString(dis);

					this.contributing_factor_vehicle_3 = readString(dis);

					this.contributing_factor_vehicle_4 = readString(dis);

					this.contributing_factor_vehicle_5 = readString(dis);

					this.cross_street_name = readString(dis);

					this.collision_dt = readDate(dis);

					this.collision_hour = readInteger(dis);

					this.collision_time = readDate(dis);

					this.collision_dayoftheweek = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.latitude = null;
					} else {
						this.latitude = dis.readDouble();
					}

					length = dis.readByte();
					if (length == -1) {
						this.longitude = null;
					} else {
						this.longitude = dis.readDouble();
					}

					this.location = readString(dis);

					this.number_of_cyclist_injured = readInteger(dis);

					this.number_of_cyclist_killed = readInteger(dis);

					this.number_of_motorist_injured = readInteger(dis);

					this.number_of_motorist_killed = readInteger(dis);

					this.number_of_pedestrians_injured = readInteger(dis);

					this.number_of_pedestrians_killed = readInteger(dis);

					this.number_of_persons_injured = readInteger(dis);

					this.number_of_persons_killed = readInteger(dis);

					this.off_street_name = readString(dis);

					this.on_street_name = readString(dis);

					this.unique_key = dis.readInt();

					this.vehicle_type_code1 = readString(dis);

					this.vehicle_type_code2 = readString(dis);

					this.vehicle_type_code3 = readString(dis);

					this.vehicle_type_code4 = readString(dis);

					this.vehicle_type_code5 = readString(dis);

					this.zip_code = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_MVC_Crash_Stage) {

				try {

					int length = 0;

					this.borough = readString(dis);

					this.contributing_factor_vehicle_1 = readString(dis);

					this.contributing_factor_vehicle_2 = readString(dis);

					this.contributing_factor_vehicle_3 = readString(dis);

					this.contributing_factor_vehicle_4 = readString(dis);

					this.contributing_factor_vehicle_5 = readString(dis);

					this.cross_street_name = readString(dis);

					this.collision_dt = readDate(dis);

					this.collision_hour = readInteger(dis);

					this.collision_time = readDate(dis);

					this.collision_dayoftheweek = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.latitude = null;
					} else {
						this.latitude = dis.readDouble();
					}

					length = dis.readByte();
					if (length == -1) {
						this.longitude = null;
					} else {
						this.longitude = dis.readDouble();
					}

					this.location = readString(dis);

					this.number_of_cyclist_injured = readInteger(dis);

					this.number_of_cyclist_killed = readInteger(dis);

					this.number_of_motorist_injured = readInteger(dis);

					this.number_of_motorist_killed = readInteger(dis);

					this.number_of_pedestrians_injured = readInteger(dis);

					this.number_of_pedestrians_killed = readInteger(dis);

					this.number_of_persons_injured = readInteger(dis);

					this.number_of_persons_killed = readInteger(dis);

					this.off_street_name = readString(dis);

					this.on_street_name = readString(dis);

					this.unique_key = dis.readInt();

					this.vehicle_type_code1 = readString(dis);

					this.vehicle_type_code2 = readString(dis);

					this.vehicle_type_code3 = readString(dis);

					this.vehicle_type_code4 = readString(dis);

					this.vehicle_type_code5 = readString(dis);

					this.zip_code = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.borough, dos);

				// String

				writeString(this.contributing_factor_vehicle_1, dos);

				// String

				writeString(this.contributing_factor_vehicle_2, dos);

				// String

				writeString(this.contributing_factor_vehicle_3, dos);

				// String

				writeString(this.contributing_factor_vehicle_4, dos);

				// String

				writeString(this.contributing_factor_vehicle_5, dos);

				// String

				writeString(this.cross_street_name, dos);

				// java.util.Date

				writeDate(this.collision_dt, dos);

				// Integer

				writeInteger(this.collision_hour, dos);

				// java.util.Date

				writeDate(this.collision_time, dos);

				// Integer

				writeInteger(this.collision_dayoftheweek, dos);

				// Double

				if (this.latitude == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeDouble(this.latitude);
				}

				// Double

				if (this.longitude == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeDouble(this.longitude);
				}

				// String

				writeString(this.location, dos);

				// Integer

				writeInteger(this.number_of_cyclist_injured, dos);

				// Integer

				writeInteger(this.number_of_cyclist_killed, dos);

				// Integer

				writeInteger(this.number_of_motorist_injured, dos);

				// Integer

				writeInteger(this.number_of_motorist_killed, dos);

				// Integer

				writeInteger(this.number_of_pedestrians_injured, dos);

				// Integer

				writeInteger(this.number_of_pedestrians_killed, dos);

				// Integer

				writeInteger(this.number_of_persons_injured, dos);

				// Integer

				writeInteger(this.number_of_persons_killed, dos);

				// String

				writeString(this.off_street_name, dos);

				// String

				writeString(this.on_street_name, dos);

				// int

				dos.writeInt(this.unique_key);

				// String

				writeString(this.vehicle_type_code1, dos);

				// String

				writeString(this.vehicle_type_code2, dos);

				// String

				writeString(this.vehicle_type_code3, dos);

				// String

				writeString(this.vehicle_type_code4, dos);

				// String

				writeString(this.vehicle_type_code5, dos);

				// Integer

				writeInteger(this.zip_code, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.borough, dos);

				// String

				writeString(this.contributing_factor_vehicle_1, dos);

				// String

				writeString(this.contributing_factor_vehicle_2, dos);

				// String

				writeString(this.contributing_factor_vehicle_3, dos);

				// String

				writeString(this.contributing_factor_vehicle_4, dos);

				// String

				writeString(this.contributing_factor_vehicle_5, dos);

				// String

				writeString(this.cross_street_name, dos);

				// java.util.Date

				writeDate(this.collision_dt, dos);

				// Integer

				writeInteger(this.collision_hour, dos);

				// java.util.Date

				writeDate(this.collision_time, dos);

				// Integer

				writeInteger(this.collision_dayoftheweek, dos);

				// Double

				if (this.latitude == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeDouble(this.latitude);
				}

				// Double

				if (this.longitude == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeDouble(this.longitude);
				}

				// String

				writeString(this.location, dos);

				// Integer

				writeInteger(this.number_of_cyclist_injured, dos);

				// Integer

				writeInteger(this.number_of_cyclist_killed, dos);

				// Integer

				writeInteger(this.number_of_motorist_injured, dos);

				// Integer

				writeInteger(this.number_of_motorist_killed, dos);

				// Integer

				writeInteger(this.number_of_pedestrians_injured, dos);

				// Integer

				writeInteger(this.number_of_pedestrians_killed, dos);

				// Integer

				writeInteger(this.number_of_persons_injured, dos);

				// Integer

				writeInteger(this.number_of_persons_killed, dos);

				// String

				writeString(this.off_street_name, dos);

				// String

				writeString(this.on_street_name, dos);

				// int

				dos.writeInt(this.unique_key);

				// String

				writeString(this.vehicle_type_code1, dos);

				// String

				writeString(this.vehicle_type_code2, dos);

				// String

				writeString(this.vehicle_type_code3, dos);

				// String

				writeString(this.vehicle_type_code4, dos);

				// String

				writeString(this.vehicle_type_code5, dos);

				// Integer

				writeInteger(this.zip_code, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("borough=" + borough);
			sb.append(",contributing_factor_vehicle_1=" + contributing_factor_vehicle_1);
			sb.append(",contributing_factor_vehicle_2=" + contributing_factor_vehicle_2);
			sb.append(",contributing_factor_vehicle_3=" + contributing_factor_vehicle_3);
			sb.append(",contributing_factor_vehicle_4=" + contributing_factor_vehicle_4);
			sb.append(",contributing_factor_vehicle_5=" + contributing_factor_vehicle_5);
			sb.append(",cross_street_name=" + cross_street_name);
			sb.append(",collision_dt=" + String.valueOf(collision_dt));
			sb.append(",collision_hour=" + String.valueOf(collision_hour));
			sb.append(",collision_time=" + String.valueOf(collision_time));
			sb.append(",collision_dayoftheweek=" + String.valueOf(collision_dayoftheweek));
			sb.append(",latitude=" + String.valueOf(latitude));
			sb.append(",longitude=" + String.valueOf(longitude));
			sb.append(",location=" + location);
			sb.append(",number_of_cyclist_injured=" + String.valueOf(number_of_cyclist_injured));
			sb.append(",number_of_cyclist_killed=" + String.valueOf(number_of_cyclist_killed));
			sb.append(",number_of_motorist_injured=" + String.valueOf(number_of_motorist_injured));
			sb.append(",number_of_motorist_killed=" + String.valueOf(number_of_motorist_killed));
			sb.append(",number_of_pedestrians_injured=" + String.valueOf(number_of_pedestrians_injured));
			sb.append(",number_of_pedestrians_killed=" + String.valueOf(number_of_pedestrians_killed));
			sb.append(",number_of_persons_injured=" + String.valueOf(number_of_persons_injured));
			sb.append(",number_of_persons_killed=" + String.valueOf(number_of_persons_killed));
			sb.append(",off_street_name=" + off_street_name);
			sb.append(",on_street_name=" + on_street_name);
			sb.append(",unique_key=" + String.valueOf(unique_key));
			sb.append(",vehicle_type_code1=" + vehicle_type_code1);
			sb.append(",vehicle_type_code2=" + vehicle_type_code2);
			sb.append(",vehicle_type_code3=" + vehicle_type_code3);
			sb.append(",vehicle_type_code4=" + vehicle_type_code4);
			sb.append(",vehicle_type_code5=" + vehicle_type_code5);
			sb.append(",zip_code=" + String.valueOf(zip_code));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (borough == null) {
				sb.append("<null>");
			} else {
				sb.append(borough);
			}

			sb.append("|");

			if (contributing_factor_vehicle_1 == null) {
				sb.append("<null>");
			} else {
				sb.append(contributing_factor_vehicle_1);
			}

			sb.append("|");

			if (contributing_factor_vehicle_2 == null) {
				sb.append("<null>");
			} else {
				sb.append(contributing_factor_vehicle_2);
			}

			sb.append("|");

			if (contributing_factor_vehicle_3 == null) {
				sb.append("<null>");
			} else {
				sb.append(contributing_factor_vehicle_3);
			}

			sb.append("|");

			if (contributing_factor_vehicle_4 == null) {
				sb.append("<null>");
			} else {
				sb.append(contributing_factor_vehicle_4);
			}

			sb.append("|");

			if (contributing_factor_vehicle_5 == null) {
				sb.append("<null>");
			} else {
				sb.append(contributing_factor_vehicle_5);
			}

			sb.append("|");

			if (cross_street_name == null) {
				sb.append("<null>");
			} else {
				sb.append(cross_street_name);
			}

			sb.append("|");

			if (collision_dt == null) {
				sb.append("<null>");
			} else {
				sb.append(collision_dt);
			}

			sb.append("|");

			if (collision_hour == null) {
				sb.append("<null>");
			} else {
				sb.append(collision_hour);
			}

			sb.append("|");

			if (collision_time == null) {
				sb.append("<null>");
			} else {
				sb.append(collision_time);
			}

			sb.append("|");

			if (collision_dayoftheweek == null) {
				sb.append("<null>");
			} else {
				sb.append(collision_dayoftheweek);
			}

			sb.append("|");

			if (latitude == null) {
				sb.append("<null>");
			} else {
				sb.append(latitude);
			}

			sb.append("|");

			if (longitude == null) {
				sb.append("<null>");
			} else {
				sb.append(longitude);
			}

			sb.append("|");

			if (location == null) {
				sb.append("<null>");
			} else {
				sb.append(location);
			}

			sb.append("|");

			if (number_of_cyclist_injured == null) {
				sb.append("<null>");
			} else {
				sb.append(number_of_cyclist_injured);
			}

			sb.append("|");

			if (number_of_cyclist_killed == null) {
				sb.append("<null>");
			} else {
				sb.append(number_of_cyclist_killed);
			}

			sb.append("|");

			if (number_of_motorist_injured == null) {
				sb.append("<null>");
			} else {
				sb.append(number_of_motorist_injured);
			}

			sb.append("|");

			if (number_of_motorist_killed == null) {
				sb.append("<null>");
			} else {
				sb.append(number_of_motorist_killed);
			}

			sb.append("|");

			if (number_of_pedestrians_injured == null) {
				sb.append("<null>");
			} else {
				sb.append(number_of_pedestrians_injured);
			}

			sb.append("|");

			if (number_of_pedestrians_killed == null) {
				sb.append("<null>");
			} else {
				sb.append(number_of_pedestrians_killed);
			}

			sb.append("|");

			if (number_of_persons_injured == null) {
				sb.append("<null>");
			} else {
				sb.append(number_of_persons_injured);
			}

			sb.append("|");

			if (number_of_persons_killed == null) {
				sb.append("<null>");
			} else {
				sb.append(number_of_persons_killed);
			}

			sb.append("|");

			if (off_street_name == null) {
				sb.append("<null>");
			} else {
				sb.append(off_street_name);
			}

			sb.append("|");

			if (on_street_name == null) {
				sb.append("<null>");
			} else {
				sb.append(on_street_name);
			}

			sb.append("|");

			sb.append(unique_key);

			sb.append("|");

			if (vehicle_type_code1 == null) {
				sb.append("<null>");
			} else {
				sb.append(vehicle_type_code1);
			}

			sb.append("|");

			if (vehicle_type_code2 == null) {
				sb.append("<null>");
			} else {
				sb.append(vehicle_type_code2);
			}

			sb.append("|");

			if (vehicle_type_code3 == null) {
				sb.append("<null>");
			} else {
				sb.append(vehicle_type_code3);
			}

			sb.append("|");

			if (vehicle_type_code4 == null) {
				sb.append("<null>");
			} else {
				sb.append(vehicle_type_code4);
			}

			sb.append("|");

			if (vehicle_type_code5 == null) {
				sb.append("<null>");
			} else {
				sb.append(vehicle_type_code5);
			}

			sb.append("|");

			if (zip_code == null) {
				sb.append("<null>");
			} else {
				sb.append(zip_code);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(Load_DataStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row1Struct implements routines.system.IPersistableRow<row1Struct> {
		final static byte[] commonByteArrayLock_MVC_TALEND_MVC_Crash_Stage = new byte[0];
		static byte[] commonByteArray_MVC_TALEND_MVC_Crash_Stage = new byte[0];

		public String borough;

		public String getBorough() {
			return this.borough;
		}

		public String contributing_factor_vehicle_1;

		public String getContributing_factor_vehicle_1() {
			return this.contributing_factor_vehicle_1;
		}

		public String contributing_factor_vehicle_2;

		public String getContributing_factor_vehicle_2() {
			return this.contributing_factor_vehicle_2;
		}

		public String contributing_factor_vehicle_3;

		public String getContributing_factor_vehicle_3() {
			return this.contributing_factor_vehicle_3;
		}

		public String contributing_factor_vehicle_4;

		public String getContributing_factor_vehicle_4() {
			return this.contributing_factor_vehicle_4;
		}

		public String contributing_factor_vehicle_5;

		public String getContributing_factor_vehicle_5() {
			return this.contributing_factor_vehicle_5;
		}

		public String cross_street_name;

		public String getCross_street_name() {
			return this.cross_street_name;
		}

		public java.util.Date timestamp;

		public java.util.Date getTimestamp() {
			return this.timestamp;
		}

		public Double latitude;

		public Double getLatitude() {
			return this.latitude;
		}

		public Double longitude;

		public Double getLongitude() {
			return this.longitude;
		}

		public String location;

		public String getLocation() {
			return this.location;
		}

		public Integer number_of_cyclist_injured;

		public Integer getNumber_of_cyclist_injured() {
			return this.number_of_cyclist_injured;
		}

		public Integer number_of_cyclist_killed;

		public Integer getNumber_of_cyclist_killed() {
			return this.number_of_cyclist_killed;
		}

		public Integer number_of_motorist_injured;

		public Integer getNumber_of_motorist_injured() {
			return this.number_of_motorist_injured;
		}

		public Integer number_of_motorist_killed;

		public Integer getNumber_of_motorist_killed() {
			return this.number_of_motorist_killed;
		}

		public Integer number_of_pedestrians_injured;

		public Integer getNumber_of_pedestrians_injured() {
			return this.number_of_pedestrians_injured;
		}

		public Integer number_of_pedestrians_killed;

		public Integer getNumber_of_pedestrians_killed() {
			return this.number_of_pedestrians_killed;
		}

		public Integer number_of_persons_injured;

		public Integer getNumber_of_persons_injured() {
			return this.number_of_persons_injured;
		}

		public Integer number_of_persons_killed;

		public Integer getNumber_of_persons_killed() {
			return this.number_of_persons_killed;
		}

		public String off_street_name;

		public String getOff_street_name() {
			return this.off_street_name;
		}

		public String on_street_name;

		public String getOn_street_name() {
			return this.on_street_name;
		}

		public int unique_key;

		public int getUnique_key() {
			return this.unique_key;
		}

		public String vehicle_type_code1;

		public String getVehicle_type_code1() {
			return this.vehicle_type_code1;
		}

		public String vehicle_type_code2;

		public String getVehicle_type_code2() {
			return this.vehicle_type_code2;
		}

		public String vehicle_type_code3;

		public String getVehicle_type_code3() {
			return this.vehicle_type_code3;
		}

		public String vehicle_type_code4;

		public String getVehicle_type_code4() {
			return this.vehicle_type_code4;
		}

		public String vehicle_type_code5;

		public String getVehicle_type_code5() {
			return this.vehicle_type_code5;
		}

		public Integer zip_code;

		public Integer getZip_code() {
			return this.zip_code;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_MVC_Crash_Stage.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_MVC_Crash_Stage.length == 0) {
						commonByteArray_MVC_TALEND_MVC_Crash_Stage = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_MVC_Crash_Stage = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MVC_TALEND_MVC_Crash_Stage, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_MVC_Crash_Stage, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_MVC_Crash_Stage.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_MVC_Crash_Stage.length == 0) {
						commonByteArray_MVC_TALEND_MVC_Crash_Stage = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_MVC_Crash_Stage = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MVC_TALEND_MVC_Crash_Stage, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_MVC_Crash_Stage, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_MVC_Crash_Stage) {

				try {

					int length = 0;

					this.borough = readString(dis);

					this.contributing_factor_vehicle_1 = readString(dis);

					this.contributing_factor_vehicle_2 = readString(dis);

					this.contributing_factor_vehicle_3 = readString(dis);

					this.contributing_factor_vehicle_4 = readString(dis);

					this.contributing_factor_vehicle_5 = readString(dis);

					this.cross_street_name = readString(dis);

					this.timestamp = readDate(dis);

					length = dis.readByte();
					if (length == -1) {
						this.latitude = null;
					} else {
						this.latitude = dis.readDouble();
					}

					length = dis.readByte();
					if (length == -1) {
						this.longitude = null;
					} else {
						this.longitude = dis.readDouble();
					}

					this.location = readString(dis);

					this.number_of_cyclist_injured = readInteger(dis);

					this.number_of_cyclist_killed = readInteger(dis);

					this.number_of_motorist_injured = readInteger(dis);

					this.number_of_motorist_killed = readInteger(dis);

					this.number_of_pedestrians_injured = readInteger(dis);

					this.number_of_pedestrians_killed = readInteger(dis);

					this.number_of_persons_injured = readInteger(dis);

					this.number_of_persons_killed = readInteger(dis);

					this.off_street_name = readString(dis);

					this.on_street_name = readString(dis);

					this.unique_key = dis.readInt();

					this.vehicle_type_code1 = readString(dis);

					this.vehicle_type_code2 = readString(dis);

					this.vehicle_type_code3 = readString(dis);

					this.vehicle_type_code4 = readString(dis);

					this.vehicle_type_code5 = readString(dis);

					this.zip_code = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_MVC_Crash_Stage) {

				try {

					int length = 0;

					this.borough = readString(dis);

					this.contributing_factor_vehicle_1 = readString(dis);

					this.contributing_factor_vehicle_2 = readString(dis);

					this.contributing_factor_vehicle_3 = readString(dis);

					this.contributing_factor_vehicle_4 = readString(dis);

					this.contributing_factor_vehicle_5 = readString(dis);

					this.cross_street_name = readString(dis);

					this.timestamp = readDate(dis);

					length = dis.readByte();
					if (length == -1) {
						this.latitude = null;
					} else {
						this.latitude = dis.readDouble();
					}

					length = dis.readByte();
					if (length == -1) {
						this.longitude = null;
					} else {
						this.longitude = dis.readDouble();
					}

					this.location = readString(dis);

					this.number_of_cyclist_injured = readInteger(dis);

					this.number_of_cyclist_killed = readInteger(dis);

					this.number_of_motorist_injured = readInteger(dis);

					this.number_of_motorist_killed = readInteger(dis);

					this.number_of_pedestrians_injured = readInteger(dis);

					this.number_of_pedestrians_killed = readInteger(dis);

					this.number_of_persons_injured = readInteger(dis);

					this.number_of_persons_killed = readInteger(dis);

					this.off_street_name = readString(dis);

					this.on_street_name = readString(dis);

					this.unique_key = dis.readInt();

					this.vehicle_type_code1 = readString(dis);

					this.vehicle_type_code2 = readString(dis);

					this.vehicle_type_code3 = readString(dis);

					this.vehicle_type_code4 = readString(dis);

					this.vehicle_type_code5 = readString(dis);

					this.zip_code = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.borough, dos);

				// String

				writeString(this.contributing_factor_vehicle_1, dos);

				// String

				writeString(this.contributing_factor_vehicle_2, dos);

				// String

				writeString(this.contributing_factor_vehicle_3, dos);

				// String

				writeString(this.contributing_factor_vehicle_4, dos);

				// String

				writeString(this.contributing_factor_vehicle_5, dos);

				// String

				writeString(this.cross_street_name, dos);

				// java.util.Date

				writeDate(this.timestamp, dos);

				// Double

				if (this.latitude == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeDouble(this.latitude);
				}

				// Double

				if (this.longitude == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeDouble(this.longitude);
				}

				// String

				writeString(this.location, dos);

				// Integer

				writeInteger(this.number_of_cyclist_injured, dos);

				// Integer

				writeInteger(this.number_of_cyclist_killed, dos);

				// Integer

				writeInteger(this.number_of_motorist_injured, dos);

				// Integer

				writeInteger(this.number_of_motorist_killed, dos);

				// Integer

				writeInteger(this.number_of_pedestrians_injured, dos);

				// Integer

				writeInteger(this.number_of_pedestrians_killed, dos);

				// Integer

				writeInteger(this.number_of_persons_injured, dos);

				// Integer

				writeInteger(this.number_of_persons_killed, dos);

				// String

				writeString(this.off_street_name, dos);

				// String

				writeString(this.on_street_name, dos);

				// int

				dos.writeInt(this.unique_key);

				// String

				writeString(this.vehicle_type_code1, dos);

				// String

				writeString(this.vehicle_type_code2, dos);

				// String

				writeString(this.vehicle_type_code3, dos);

				// String

				writeString(this.vehicle_type_code4, dos);

				// String

				writeString(this.vehicle_type_code5, dos);

				// Integer

				writeInteger(this.zip_code, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.borough, dos);

				// String

				writeString(this.contributing_factor_vehicle_1, dos);

				// String

				writeString(this.contributing_factor_vehicle_2, dos);

				// String

				writeString(this.contributing_factor_vehicle_3, dos);

				// String

				writeString(this.contributing_factor_vehicle_4, dos);

				// String

				writeString(this.contributing_factor_vehicle_5, dos);

				// String

				writeString(this.cross_street_name, dos);

				// java.util.Date

				writeDate(this.timestamp, dos);

				// Double

				if (this.latitude == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeDouble(this.latitude);
				}

				// Double

				if (this.longitude == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeDouble(this.longitude);
				}

				// String

				writeString(this.location, dos);

				// Integer

				writeInteger(this.number_of_cyclist_injured, dos);

				// Integer

				writeInteger(this.number_of_cyclist_killed, dos);

				// Integer

				writeInteger(this.number_of_motorist_injured, dos);

				// Integer

				writeInteger(this.number_of_motorist_killed, dos);

				// Integer

				writeInteger(this.number_of_pedestrians_injured, dos);

				// Integer

				writeInteger(this.number_of_pedestrians_killed, dos);

				// Integer

				writeInteger(this.number_of_persons_injured, dos);

				// Integer

				writeInteger(this.number_of_persons_killed, dos);

				// String

				writeString(this.off_street_name, dos);

				// String

				writeString(this.on_street_name, dos);

				// int

				dos.writeInt(this.unique_key);

				// String

				writeString(this.vehicle_type_code1, dos);

				// String

				writeString(this.vehicle_type_code2, dos);

				// String

				writeString(this.vehicle_type_code3, dos);

				// String

				writeString(this.vehicle_type_code4, dos);

				// String

				writeString(this.vehicle_type_code5, dos);

				// Integer

				writeInteger(this.zip_code, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("borough=" + borough);
			sb.append(",contributing_factor_vehicle_1=" + contributing_factor_vehicle_1);
			sb.append(",contributing_factor_vehicle_2=" + contributing_factor_vehicle_2);
			sb.append(",contributing_factor_vehicle_3=" + contributing_factor_vehicle_3);
			sb.append(",contributing_factor_vehicle_4=" + contributing_factor_vehicle_4);
			sb.append(",contributing_factor_vehicle_5=" + contributing_factor_vehicle_5);
			sb.append(",cross_street_name=" + cross_street_name);
			sb.append(",timestamp=" + String.valueOf(timestamp));
			sb.append(",latitude=" + String.valueOf(latitude));
			sb.append(",longitude=" + String.valueOf(longitude));
			sb.append(",location=" + location);
			sb.append(",number_of_cyclist_injured=" + String.valueOf(number_of_cyclist_injured));
			sb.append(",number_of_cyclist_killed=" + String.valueOf(number_of_cyclist_killed));
			sb.append(",number_of_motorist_injured=" + String.valueOf(number_of_motorist_injured));
			sb.append(",number_of_motorist_killed=" + String.valueOf(number_of_motorist_killed));
			sb.append(",number_of_pedestrians_injured=" + String.valueOf(number_of_pedestrians_injured));
			sb.append(",number_of_pedestrians_killed=" + String.valueOf(number_of_pedestrians_killed));
			sb.append(",number_of_persons_injured=" + String.valueOf(number_of_persons_injured));
			sb.append(",number_of_persons_killed=" + String.valueOf(number_of_persons_killed));
			sb.append(",off_street_name=" + off_street_name);
			sb.append(",on_street_name=" + on_street_name);
			sb.append(",unique_key=" + String.valueOf(unique_key));
			sb.append(",vehicle_type_code1=" + vehicle_type_code1);
			sb.append(",vehicle_type_code2=" + vehicle_type_code2);
			sb.append(",vehicle_type_code3=" + vehicle_type_code3);
			sb.append(",vehicle_type_code4=" + vehicle_type_code4);
			sb.append(",vehicle_type_code5=" + vehicle_type_code5);
			sb.append(",zip_code=" + String.valueOf(zip_code));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (borough == null) {
				sb.append("<null>");
			} else {
				sb.append(borough);
			}

			sb.append("|");

			if (contributing_factor_vehicle_1 == null) {
				sb.append("<null>");
			} else {
				sb.append(contributing_factor_vehicle_1);
			}

			sb.append("|");

			if (contributing_factor_vehicle_2 == null) {
				sb.append("<null>");
			} else {
				sb.append(contributing_factor_vehicle_2);
			}

			sb.append("|");

			if (contributing_factor_vehicle_3 == null) {
				sb.append("<null>");
			} else {
				sb.append(contributing_factor_vehicle_3);
			}

			sb.append("|");

			if (contributing_factor_vehicle_4 == null) {
				sb.append("<null>");
			} else {
				sb.append(contributing_factor_vehicle_4);
			}

			sb.append("|");

			if (contributing_factor_vehicle_5 == null) {
				sb.append("<null>");
			} else {
				sb.append(contributing_factor_vehicle_5);
			}

			sb.append("|");

			if (cross_street_name == null) {
				sb.append("<null>");
			} else {
				sb.append(cross_street_name);
			}

			sb.append("|");

			if (timestamp == null) {
				sb.append("<null>");
			} else {
				sb.append(timestamp);
			}

			sb.append("|");

			if (latitude == null) {
				sb.append("<null>");
			} else {
				sb.append(latitude);
			}

			sb.append("|");

			if (longitude == null) {
				sb.append("<null>");
			} else {
				sb.append(longitude);
			}

			sb.append("|");

			if (location == null) {
				sb.append("<null>");
			} else {
				sb.append(location);
			}

			sb.append("|");

			if (number_of_cyclist_injured == null) {
				sb.append("<null>");
			} else {
				sb.append(number_of_cyclist_injured);
			}

			sb.append("|");

			if (number_of_cyclist_killed == null) {
				sb.append("<null>");
			} else {
				sb.append(number_of_cyclist_killed);
			}

			sb.append("|");

			if (number_of_motorist_injured == null) {
				sb.append("<null>");
			} else {
				sb.append(number_of_motorist_injured);
			}

			sb.append("|");

			if (number_of_motorist_killed == null) {
				sb.append("<null>");
			} else {
				sb.append(number_of_motorist_killed);
			}

			sb.append("|");

			if (number_of_pedestrians_injured == null) {
				sb.append("<null>");
			} else {
				sb.append(number_of_pedestrians_injured);
			}

			sb.append("|");

			if (number_of_pedestrians_killed == null) {
				sb.append("<null>");
			} else {
				sb.append(number_of_pedestrians_killed);
			}

			sb.append("|");

			if (number_of_persons_injured == null) {
				sb.append("<null>");
			} else {
				sb.append(number_of_persons_injured);
			}

			sb.append("|");

			if (number_of_persons_killed == null) {
				sb.append("<null>");
			} else {
				sb.append(number_of_persons_killed);
			}

			sb.append("|");

			if (off_street_name == null) {
				sb.append("<null>");
			} else {
				sb.append(off_street_name);
			}

			sb.append("|");

			if (on_street_name == null) {
				sb.append("<null>");
			} else {
				sb.append(on_street_name);
			}

			sb.append("|");

			sb.append(unique_key);

			sb.append("|");

			if (vehicle_type_code1 == null) {
				sb.append("<null>");
			} else {
				sb.append(vehicle_type_code1);
			}

			sb.append("|");

			if (vehicle_type_code2 == null) {
				sb.append("<null>");
			} else {
				sb.append(vehicle_type_code2);
			}

			sb.append("|");

			if (vehicle_type_code3 == null) {
				sb.append("<null>");
			} else {
				sb.append(vehicle_type_code3);
			}

			sb.append("|");

			if (vehicle_type_code4 == null) {
				sb.append("<null>");
			} else {
				sb.append(vehicle_type_code4);
			}

			sb.append("|");

			if (vehicle_type_code5 == null) {
				sb.append("<null>");
			} else {
				sb.append(vehicle_type_code5);
			}

			sb.append("|");

			if (zip_code == null) {
				sb.append("<null>");
			} else {
				sb.append(zip_code);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row1Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tBigQueryInput_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tBigQueryInput_1_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				row1Struct row1 = new row1Struct();
				Load_DataStruct Load_Data = new Load_DataStruct();

				/**
				 * [tDBOutput_2 begin ] start
				 */

				ok_Hash.put("tDBOutput_2", false);
				start_Hash.put("tDBOutput_2", System.currentTimeMillis());

				currentComponent = "tDBOutput_2";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "Load_Data");

				int tos_count_tDBOutput_2 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBOutput_2 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tDBOutput_2 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tDBOutput_2 = new StringBuilder();
							log4jParamters_tDBOutput_2.append("Parameters:");
							log4jParamters_tDBOutput_2.append("USE_EXISTING_CONNECTION" + " = " + "false");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("DRIVER" + " = " + "JTDS");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("HOST" + " = " + "\"localhost\"");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("PORT" + " = " + "\"1433\"");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("DB_SCHEMA" + " = " + "\"\"");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("DBNAME" + " = " + "\"MVC_Stage\"");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("USER" + " = " + "\"\"");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("PASS" + " = "
									+ String.valueOf(
											"enc:routine.encryption.key.v1:T+v0fVij8/BycBlaN422RTwHVUQ9i2Xw1j0GIg==")
											.substring(0, 4)
									+ "...");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("TABLE" + " = " + "\"MVC_Crash_Stage\"");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("TABLE_ACTION" + " = " + "DROP_IF_EXISTS_AND_CREATE");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("IDENTITY_INSERT" + " = " + "false");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("DATA_ACTION" + " = " + "INSERT");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("SPECIFY_IDENTITY_FIELD" + " = " + "false");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("DIE_ON_ERROR" + " = " + "false");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("PROPERTIES" + " = " + "\"\"");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("COMMIT_EVERY" + " = " + "10000");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("ADD_COLS" + " = " + "[]");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("USE_FIELD_OPTIONS" + " = " + "false");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("IGNORE_DATE_OUTOF_RANGE" + " = " + "false");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("ENABLE_DEBUG_MODE" + " = " + "false");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("SUPPORT_NULL_WHERE" + " = " + "false");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("USE_BATCH_SIZE" + " = " + "true");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("BATCH_SIZE" + " = " + "10000");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("UNIFIED_COMPONENTS" + " = " + "tMSSqlOutput");
							log4jParamters_tDBOutput_2.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tDBOutput_2 - " + (log4jParamters_tDBOutput_2));
						}
					}
					new BytesLimit65535_tDBOutput_2().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tDBOutput_2", "tDBOutput_2", "tMSSqlOutput");
					talendJobLogProcess(globalMap);
				}

				int nb_line_tDBOutput_2 = 0;
				int nb_line_update_tDBOutput_2 = 0;
				int nb_line_inserted_tDBOutput_2 = 0;
				int nb_line_deleted_tDBOutput_2 = 0;
				int nb_line_rejected_tDBOutput_2 = 0;

				int deletedCount_tDBOutput_2 = 0;
				int updatedCount_tDBOutput_2 = 0;
				int insertedCount_tDBOutput_2 = 0;
				int rowsToCommitCount_tDBOutput_2 = 0;
				int rejectedCount_tDBOutput_2 = 0;
				String dbschema_tDBOutput_2 = null;
				String tableName_tDBOutput_2 = null;
				boolean whetherReject_tDBOutput_2 = false;

				java.util.Calendar calendar_tDBOutput_2 = java.util.Calendar.getInstance();
				long year1_tDBOutput_2 = TalendDate.parseDate("yyyy-MM-dd", "0001-01-01").getTime();
				long year2_tDBOutput_2 = TalendDate.parseDate("yyyy-MM-dd", "1753-01-01").getTime();
				long year10000_tDBOutput_2 = TalendDate.parseDate("yyyy-MM-dd HH:mm:ss", "9999-12-31 24:00:00")
						.getTime();
				long date_tDBOutput_2;

				java.util.Calendar calendar_datetimeoffset_tDBOutput_2 = java.util.Calendar
						.getInstance(java.util.TimeZone.getTimeZone("UTC"));

				java.sql.Connection conn_tDBOutput_2 = null;
				String dbUser_tDBOutput_2 = null;
				dbschema_tDBOutput_2 = "";
				String driverClass_tDBOutput_2 = "net.sourceforge.jtds.jdbc.Driver";

				if (log.isDebugEnabled())
					log.debug("tDBOutput_2 - " + ("Driver ClassName: ") + (driverClass_tDBOutput_2) + ("."));
				java.lang.Class.forName(driverClass_tDBOutput_2);
				String port_tDBOutput_2 = "1433";
				String dbname_tDBOutput_2 = "MVC_Stage";
				String url_tDBOutput_2 = "jdbc:jtds:sqlserver://" + "localhost";
				if (!"".equals(port_tDBOutput_2)) {
					url_tDBOutput_2 += ":" + "1433";
				}
				if (!"".equals(dbname_tDBOutput_2)) {
					url_tDBOutput_2 += "//" + "MVC_Stage";

				}
				url_tDBOutput_2 += ";appName=" + projectName + ";" + "";
				dbUser_tDBOutput_2 = "";

				final String decryptedPassword_tDBOutput_2 = routines.system.PasswordEncryptUtil
						.decryptPassword("enc:routine.encryption.key.v1:GJvWuhmEEZefqMXFbDStdvclN9DoK231rFuZ1Q==");

				String dbPwd_tDBOutput_2 = decryptedPassword_tDBOutput_2;
				if (log.isDebugEnabled())
					log.debug("tDBOutput_2 - " + ("Connection attempts to '") + (url_tDBOutput_2)
							+ ("' with the username '") + (dbUser_tDBOutput_2) + ("'."));
				conn_tDBOutput_2 = java.sql.DriverManager.getConnection(url_tDBOutput_2, dbUser_tDBOutput_2,
						dbPwd_tDBOutput_2);
				if (log.isDebugEnabled())
					log.debug("tDBOutput_2 - " + ("Connection to '") + (url_tDBOutput_2) + ("' has succeeded."));

				resourceMap.put("conn_tDBOutput_2", conn_tDBOutput_2);

				conn_tDBOutput_2.setAutoCommit(false);
				int commitEvery_tDBOutput_2 = 10000;
				int commitCounter_tDBOutput_2 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBOutput_2 - " + ("Connection is set auto commit to '")
							+ (conn_tDBOutput_2.getAutoCommit()) + ("'."));
				int batchSize_tDBOutput_2 = 10000;
				int batchSizeCounter_tDBOutput_2 = 0;

				if (dbschema_tDBOutput_2 == null || dbschema_tDBOutput_2.trim().length() == 0) {
					tableName_tDBOutput_2 = "MVC_Crash_Stage";
				} else {
					tableName_tDBOutput_2 = dbschema_tDBOutput_2 + "].[" + "MVC_Crash_Stage";
				}
				int count_tDBOutput_2 = 0;

				boolean whetherExist_tDBOutput_2 = false;
				try (java.sql.Statement isExistStmt_tDBOutput_2 = conn_tDBOutput_2.createStatement()) {
					try {
						isExistStmt_tDBOutput_2.execute("SELECT TOP 1 1 FROM [" + tableName_tDBOutput_2 + "]");
						whetherExist_tDBOutput_2 = true;
					} catch (java.lang.Exception e) {
						globalMap.put("tDBOutput_2_ERROR_MESSAGE", e.getMessage());
						whetherExist_tDBOutput_2 = false;
					}
				}
				if (whetherExist_tDBOutput_2) {
					try (java.sql.Statement stmtDrop_tDBOutput_2 = conn_tDBOutput_2.createStatement()) {
						if (log.isDebugEnabled())
							log.debug("tDBOutput_2 - " + ("Dropping") + (" table '")
									+ ("[" + tableName_tDBOutput_2 + "]") + ("'."));
						stmtDrop_tDBOutput_2.execute("DROP TABLE [" + tableName_tDBOutput_2 + "]");
						if (log.isDebugEnabled())
							log.debug("tDBOutput_2 - " + ("Drop") + (" table '") + ("[" + tableName_tDBOutput_2 + "]")
									+ ("' has succeeded."));
					}
				}
				try (java.sql.Statement stmtCreate_tDBOutput_2 = conn_tDBOutput_2.createStatement()) {
					if (log.isDebugEnabled())
						log.debug("tDBOutput_2 - " + ("Creating") + (" table '") + ("[" + tableName_tDBOutput_2 + "]")
								+ ("'."));
					stmtCreate_tDBOutput_2.execute("CREATE TABLE [" + tableName_tDBOutput_2
							+ "]([borough] STRING(1000,0)  default 'NoValueProvided' ,[contributing_factor_vehicle_1] STRING(1000,0)  default 'NoValueProvided' ,[contributing_factor_vehicle_2] STRING(1000,0)  default 'NoValueProvided' ,[contributing_factor_vehicle_3] STRING(1000,0)  default 'NoValueProvided' ,[contributing_factor_vehicle_4] STRING(1000,0)  default 'NoValueProvided' ,[contributing_factor_vehicle_5] STRING(1000,0)  default 'NoValueProvided' ,[cross_street_name] STRING(1000,0)  default 'NoValueProvided' ,[collision_dt] STRING(1000,0)  ,[collision_hour] INT default -1 ,[collision_time] DATETIME ,[collision_dayoftheweek] INT default -1 ,[latitude] STRING(1000,0)  default -1.0 ,[longitude] STRING(1000,0)  default -1.0 ,[location] STRING(1000,0)  default 'NoValueProvided' ,[number_of_cyclist_injured] STRING(1000,0)  default -1 ,[number_of_cyclist_killed] STRING(1000,0)  default -1 ,[number_of_motorist_injured] STRING(1000,0)  default -1 ,[number_of_motorist_killed] STRING(1000,0)  default -1 ,[number_of_pedestrians_injured] STRING(1000,0)  default -1 ,[number_of_pedestrians_killed] STRING(1000,0)  default -1 ,[number_of_persons_injured] STRING(1000,0)  default -1 ,[number_of_persons_killed] STRING(1000,0)  default -1 ,[off_street_name] STRING(1000,0)  default 'NoValueProvided' ,[on_street_name] STRING(1000,0)  default 'NoValueProvided' ,[unique_key] STRING(1000,0)  default -1  not null ,[vehicle_type_code1] STRING(1000,0)  default 'NoValueProvided' ,[vehicle_type_code2] STRING(1000,0)  default 'NoValueProvided' ,[vehicle_type_code3] STRING(1000,0)  default 'NoValueProvided' ,[vehicle_type_code4] STRING(1000,0)  default 'NoValueProvided' ,[vehicle_type_code5] STRING(1000,0)  default 'NoValueProvided' ,[zip_code] STRING(1000,0)  default -1 )");
					if (log.isDebugEnabled())
						log.debug("tDBOutput_2 - " + ("Create") + (" table '") + ("[" + tableName_tDBOutput_2 + "]")
								+ ("' has succeeded."));
				}
				String insert_tDBOutput_2 = "INSERT INTO [" + tableName_tDBOutput_2
						+ "] ([borough],[contributing_factor_vehicle_1],[contributing_factor_vehicle_2],[contributing_factor_vehicle_3],[contributing_factor_vehicle_4],[contributing_factor_vehicle_5],[cross_street_name],[collision_dt],[collision_hour],[collision_time],[collision_dayoftheweek],[latitude],[longitude],[location],[number_of_cyclist_injured],[number_of_cyclist_killed],[number_of_motorist_injured],[number_of_motorist_killed],[number_of_pedestrians_injured],[number_of_pedestrians_killed],[number_of_persons_injured],[number_of_persons_killed],[off_street_name],[on_street_name],[unique_key],[vehicle_type_code1],[vehicle_type_code2],[vehicle_type_code3],[vehicle_type_code4],[vehicle_type_code5],[zip_code]) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
				java.sql.PreparedStatement pstmt_tDBOutput_2 = conn_tDBOutput_2.prepareStatement(insert_tDBOutput_2);
				resourceMap.put("pstmt_tDBOutput_2", pstmt_tDBOutput_2);

				/**
				 * [tDBOutput_2 begin ] stop
				 */

				/**
				 * [tMap_1 begin ] start
				 */

				ok_Hash.put("tMap_1", false);
				start_Hash.put("tMap_1", System.currentTimeMillis());

				currentComponent = "tMap_1";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "row1");

				int tos_count_tMap_1 = 0;

				if (log.isDebugEnabled())
					log.debug("tMap_1 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tMap_1 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tMap_1 = new StringBuilder();
							log4jParamters_tMap_1.append("Parameters:");
							log4jParamters_tMap_1.append("LINK_STYLE" + " = " + "AUTO");
							log4jParamters_tMap_1.append(" | ");
							log4jParamters_tMap_1.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
							log4jParamters_tMap_1.append(" | ");
							log4jParamters_tMap_1.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
							log4jParamters_tMap_1.append(" | ");
							log4jParamters_tMap_1.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "true");
							log4jParamters_tMap_1.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tMap_1 - " + (log4jParamters_tMap_1));
						}
					}
					new BytesLimit65535_tMap_1().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tMap_1", "tMap_1", "tMap");
					talendJobLogProcess(globalMap);
				}

// ###############################
// # Lookup's keys initialization
				int count_row1_tMap_1 = 0;

// ###############################        

// ###############################
// # Vars initialization
				class Var__tMap_1__Struct {
				}
				Var__tMap_1__Struct Var__tMap_1 = new Var__tMap_1__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_Load_Data_tMap_1 = 0;

				Load_DataStruct Load_Data_tmp = new Load_DataStruct();
// ###############################

				/**
				 * [tMap_1 begin ] stop
				 */

				/**
				 * [tBigQueryInput_1 begin ] start
				 */

				ok_Hash.put("tBigQueryInput_1", false);
				start_Hash.put("tBigQueryInput_1", System.currentTimeMillis());

				currentComponent = "tBigQueryInput_1";

				int tos_count_tBigQueryInput_1 = 0;

				if (log.isDebugEnabled())
					log.debug("tBigQueryInput_1 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tBigQueryInput_1 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tBigQueryInput_1 = new StringBuilder();
							log4jParamters_tBigQueryInput_1.append("Parameters:");
							log4jParamters_tBigQueryInput_1.append("AUTH_MODE" + " = " + "SERVICEACCOUNT");
							log4jParamters_tBigQueryInput_1.append(" | ");
							log4jParamters_tBigQueryInput_1.append("SERVICE_ACCOUNT_CREDENTIALS_FILE" + " = "
									+ "\"C:/Users/rajvi/Downloads/flash-district-384022-b1dc05443e26.json\"");
							log4jParamters_tBigQueryInput_1.append(" | ");
							log4jParamters_tBigQueryInput_1.append("PROJECT_ID" + " = " + "\"flash-district-384022\"");
							log4jParamters_tBigQueryInput_1.append(" | ");
							log4jParamters_tBigQueryInput_1.append("USE_LEGACY_SQL" + " = " + "false");
							log4jParamters_tBigQueryInput_1.append(" | ");
							log4jParamters_tBigQueryInput_1.append("QUERY" + " = "
									+ "\"SELECT * FROM flash-district-384022.MVC_COLLISIONS.MVC_Collision_Stg\"");
							log4jParamters_tBigQueryInput_1.append(" | ");
							log4jParamters_tBigQueryInput_1.append("RESULT_SIZE" + " = " + "AUTO");
							log4jParamters_tBigQueryInput_1.append(" | ");
							log4jParamters_tBigQueryInput_1.append("ADVANCED_SEPARATOR" + " = " + "false");
							log4jParamters_tBigQueryInput_1.append(" | ");
							log4jParamters_tBigQueryInput_1.append("ENCODING" + " = " + "\"ISO-8859-15\"");
							log4jParamters_tBigQueryInput_1.append(" | ");
							log4jParamters_tBigQueryInput_1.append("USE_CUSTOM_TEMPORARY_DATASET" + " = " + "false");
							log4jParamters_tBigQueryInput_1.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tBigQueryInput_1 - " + (log4jParamters_tBigQueryInput_1));
						}
					}
					new BytesLimit65535_tBigQueryInput_1().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tBigQueryInput_1", "tBigQueryInput_1", "tBigQueryInput");
					talendJobLogProcess(globalMap);
				}

				class ServiceAccountBigQueryUtil_tBigQueryInput_1 {
					private com.google.cloud.bigquery.BigQuery bigQuery;
					private boolean useLargeResult;
					private String tempTable;

					public ServiceAccountBigQueryUtil_tBigQueryInput_1() {
						this.useLargeResult = false;
					}

					private com.google.cloud.bigquery.BigQuery buildBigQuery() throws java.io.IOException {
						if (bigQuery != null) {
							return bigQuery;
						}
						com.google.auth.oauth2.GoogleCredentials credentials;
						java.io.File credentialsFile = new java.io.File(
								"C:/Users/rajvi/Downloads/flash-district-384022-b1dc05443e26.json");
						try (java.io.FileInputStream credentialsStream = new java.io.FileInputStream(credentialsFile)) {
							credentials = com.google.auth.oauth2.ServiceAccountCredentials
									.fromStream(credentialsStream);
						}

						com.google.cloud.bigquery.BigQuery result = com.google.cloud.bigquery.BigQueryOptions
								.newBuilder().setCredentials(credentials).setProjectId("flash-district-384022").build()
								.getService();

						return result;
					}

					private com.google.cloud.bigquery.Job buildJob(com.google.cloud.bigquery.BigQuery bigquery,
							com.google.cloud.bigquery.QueryJobConfiguration queryConfiguration,
							com.google.cloud.bigquery.JobId jobId) throws InterruptedException {
						globalMap.put("tBigQueryInput_1_JOBID", jobId.getJob());
						com.google.cloud.bigquery.Job job = bigquery.create(com.google.cloud.bigquery.JobInfo
								.newBuilder(queryConfiguration).setJobId(jobId).build());

						log.info("tBigQueryInput_1 - Sending job " + jobId + " with query: "
								+ "SELECT * FROM flash-district-384022.MVC_COLLISIONS.MVC_Collision_Stg");

						job = job.waitFor();

						if (job == null) {
							String message = "tBigQueryInput_1 - Job no longer exists";
							globalMap.put("tBigQueryInput_1_ERROR_MESSAGE", message);
							throw new RuntimeException(message);
						} else if (job.getStatus().getError() != null) {
							com.google.gson.Gson gsonObject = new com.google.gson.Gson();
							globalMap.put("tBigQueryInput_1_STATISTICS", gsonObject.toJson(job.getStatistics()));
							String message = job.getStatus().getError().toString();
							globalMap.put("tBigQueryInput_1_ERROR_MESSAGE", message);
							throw new RuntimeException(message);
						}

						log.info("tBigQueryInput_1 - Job " + jobId + " finished successfully.");

						return job;
					}

					private com.google.cloud.bigquery.Job executeQuerySmallResult(String query, boolean useLegacySql)
							throws java.io.IOException, InterruptedException {
						bigQuery = buildBigQuery();
						com.google.cloud.bigquery.QueryJobConfiguration queryConfiguration = com.google.cloud.bigquery.QueryJobConfiguration
								.newBuilder(query).setUseLegacySql(useLegacySql).build();
						com.google.cloud.bigquery.JobId jobId = com.google.cloud.bigquery.JobId
								.of("flash-district-384022", java.util.UUID.randomUUID().toString());
						return buildJob(bigQuery, queryConfiguration, jobId);
					}

					private com.google.cloud.bigquery.Job executeQueryLargeResult(String query, boolean useLegacySql)
							throws java.io.IOException, InterruptedException {
						bigQuery = buildBigQuery();

						com.google.cloud.bigquery.QueryJobConfiguration jobConfDryRun = com.google.cloud.bigquery.QueryJobConfiguration
								.newBuilder(query).setUseLegacySql(useLegacySql).setDryRun(true).build();
						com.google.cloud.bigquery.Job jobDryRun = bigQuery
								.create(com.google.cloud.bigquery.JobInfo.of(jobConfDryRun));

						String queryLocation = jobDryRun.getJobId().getLocation();
						String location = queryLocation == null ? "US" : queryLocation;
						String tempDataset = java.util.UUID.randomUUID().toString().replaceAll("-", "")
								+ Integer.toHexString(java.util.concurrent.ThreadLocalRandom.current().nextInt())
								+ Integer.toHexString(java.util.concurrent.ThreadLocalRandom.current().nextInt());

						log.info("tBigQueryInput_1 - query location :" + queryLocation);
						log.info("tBigQueryInput_1 - temporary dataset location :" + location);
						log.info("tBigQueryInput_1 - temporary Dataset name : " + tempDataset);

						com.google.cloud.bigquery.DatasetInfo datasetInfo = com.google.cloud.bigquery.DatasetInfo
								.newBuilder(tempDataset).setLocation(location).build();
						com.google.cloud.bigquery.Dataset dataset = bigQuery.create(datasetInfo);

						tempTable = java.util.UUID.randomUUID().toString().replaceAll("-", "")
								+ Integer.toHexString(java.util.concurrent.ThreadLocalRandom.current().nextInt())
								+ Integer.toHexString(java.util.concurrent.ThreadLocalRandom.current().nextInt());

						log.info("tBigQueryInput_1 - temporary table name : " + tempTable);

						com.google.cloud.bigquery.QueryJobConfiguration queryConfiguration = com.google.cloud.bigquery.QueryJobConfiguration
								.newBuilder(query).setUseLegacySql(useLegacySql).setDryRun(false)
								.setAllowLargeResults(true)
								.setDestinationTable(com.google.cloud.bigquery.TableId.of(tempDataset, tempTable))
								.build();

						com.google.cloud.bigquery.JobId jobId = com.google.cloud.bigquery.JobId.newBuilder()
								.setProject("flash-district-384022").setJob(java.util.UUID.randomUUID().toString())
								.build();

						log.info("tBigQueryInput_1 - job location : " + jobId.getLocation());

						return buildJob(bigQuery, queryConfiguration, jobId);
					}

					public com.google.cloud.bigquery.Job executeQuery(String query, boolean useLegacySql)
							throws Exception {

						com.google.cloud.bigquery.Job job;

						try {
							job = executeQuerySmallResult(query, useLegacySql);
						} catch (com.google.cloud.bigquery.BigQueryException e) {
							job = executeQueryLargeResult(query, useLegacySql);
							useLargeResult = true;
						}

						return job;
					}

					public java.util.List<com.google.cloud.bigquery.Job> getChildJobs(String jobId)
							throws java.io.IOException {
						return java.util.Optional
								.ofNullable(buildBigQuery()
										.listJobs(com.google.cloud.bigquery.BigQuery.JobListOption.parentJobId(jobId)))
								.map(com.google.api.gax.paging.Page::getValues)
								.flatMap(iterable -> java.util.Optional
										.ofNullable(java.util.stream.StreamSupport.stream(iterable.spliterator(), false)
												.collect(java.util.stream.Collectors.toList())))
								.orElse(java.util.Collections.emptyList());
					}

					public void cleanup() throws Exception {
						if (useLargeResult) {

							com.google.cloud.bigquery.DatasetId datasetId = com.google.cloud.bigquery.DatasetId
									.of("flash-district-384022", "temp_dataset");
							bigQuery.delete(datasetId,
									com.google.cloud.bigquery.BigQuery.DatasetDeleteOption.deleteContents());

						}
					}

				}

				log.info("tBigQueryInput_1 - query "
						+ "SELECT * FROM flash-district-384022.MVC_COLLISIONS.MVC_Collision_Stg");

				ServiceAccountBigQueryUtil_tBigQueryInput_1 serviceAccountBigQueryUtil_tBigQueryInput_1 = new ServiceAccountBigQueryUtil_tBigQueryInput_1();

				try {
					com.google.cloud.bigquery.Job job_tBigQueryInput_1 = serviceAccountBigQueryUtil_tBigQueryInput_1
							.executeQuery("SELECT * FROM flash-district-384022.MVC_COLLISIONS.MVC_Collision_Stg",
									false);
					log.info("tBigQueryInput_1 - Retrieving records from dataset.");

					com.google.gson.Gson gsonObject_tBigQueryInput_1 = new com.google.gson.Gson();
					globalMap.put("tBigQueryInput_1_STATISTICS",
							gsonObject_tBigQueryInput_1.toJson(job_tBigQueryInput_1.getStatistics()));
					long nb_line_tBigQueryInput_1 = 0;
					java.util.List<String> child_statistics_tBigQueryInput_1 = null;
					java.util.List<com.google.cloud.bigquery.Job> childJobs_tBigQueryInput_1;
					if (job_tBigQueryInput_1.getStatistics().getNumChildJobs() != null) {
						childJobs_tBigQueryInput_1 = serviceAccountBigQueryUtil_tBigQueryInput_1
								.getChildJobs(job_tBigQueryInput_1.getJobId().getJob());
						java.util.Collections.reverse(childJobs_tBigQueryInput_1);
						child_statistics_tBigQueryInput_1 = new java.util.ArrayList<>();
					} else {
						childJobs_tBigQueryInput_1 = java.util.Collections.singletonList(job_tBigQueryInput_1);
					}
					for (com.google.cloud.bigquery.Job job_iterable_tBigQueryInput_1 : childJobs_tBigQueryInput_1) {
						if (child_statistics_tBigQueryInput_1 != null) {
							child_statistics_tBigQueryInput_1.add(
									gsonObject_tBigQueryInput_1.toJson(job_iterable_tBigQueryInput_1.getStatistics()));
						}
						if (job_iterable_tBigQueryInput_1.getStatus().getError() != null) {
							globalMap.put("tBigQueryInput_1_ERROR_MESSAGE",
									job_iterable_tBigQueryInput_1.getStatus().getError().toString());
							String message_tBigQueryInput_1 = "tBigQueryInput_1 - "
									+ job_iterable_tBigQueryInput_1.getStatus().getError().toString();
							log.error(message_tBigQueryInput_1);
							continue;
						}

						com.google.cloud.bigquery.TableResult result_tBigQueryInput_1 = job_iterable_tBigQueryInput_1
								.getQueryResults();
						// Dynamic start

						// Dynamic end

						for (com.google.cloud.bigquery.FieldValueList field_tBigQueryInput_1 : result_tBigQueryInput_1
								.iterateAll()) {
							Object value_tBigQueryInput_1;
							nb_line_tBigQueryInput_1++;

							int fieldsCount_tBigQueryInput_1 = field_tBigQueryInput_1.size();
							int column_index_tBigQueryInput_1 = 0;

							column_index_tBigQueryInput_1 = 0;

							if (fieldsCount_tBigQueryInput_1 <= column_index_tBigQueryInput_1) {
								row1.borough = null;
							} else {

								value_tBigQueryInput_1 = field_tBigQueryInput_1.get(column_index_tBigQueryInput_1)
										.getValue();

								if (com.google.api.client.util.Data.isNull(value_tBigQueryInput_1))
									value_tBigQueryInput_1 = null;

								if (value_tBigQueryInput_1 != null) {

									row1.borough = value_tBigQueryInput_1.toString();

								} else {
									row1.borough = "NoValueProvided";
								}
							}

							column_index_tBigQueryInput_1 = 1;

							if (fieldsCount_tBigQueryInput_1 <= column_index_tBigQueryInput_1) {
								row1.contributing_factor_vehicle_1 = null;
							} else {

								value_tBigQueryInput_1 = field_tBigQueryInput_1.get(column_index_tBigQueryInput_1)
										.getValue();

								if (com.google.api.client.util.Data.isNull(value_tBigQueryInput_1))
									value_tBigQueryInput_1 = null;

								if (value_tBigQueryInput_1 != null) {

									row1.contributing_factor_vehicle_1 = value_tBigQueryInput_1.toString();

								} else {
									row1.contributing_factor_vehicle_1 = "NoValueProvided";
								}
							}

							column_index_tBigQueryInput_1 = 2;

							if (fieldsCount_tBigQueryInput_1 <= column_index_tBigQueryInput_1) {
								row1.contributing_factor_vehicle_2 = null;
							} else {

								value_tBigQueryInput_1 = field_tBigQueryInput_1.get(column_index_tBigQueryInput_1)
										.getValue();

								if (com.google.api.client.util.Data.isNull(value_tBigQueryInput_1))
									value_tBigQueryInput_1 = null;

								if (value_tBigQueryInput_1 != null) {

									row1.contributing_factor_vehicle_2 = value_tBigQueryInput_1.toString();

								} else {
									row1.contributing_factor_vehicle_2 = "NoValueProvided";
								}
							}

							column_index_tBigQueryInput_1 = 3;

							if (fieldsCount_tBigQueryInput_1 <= column_index_tBigQueryInput_1) {
								row1.contributing_factor_vehicle_3 = null;
							} else {

								value_tBigQueryInput_1 = field_tBigQueryInput_1.get(column_index_tBigQueryInput_1)
										.getValue();

								if (com.google.api.client.util.Data.isNull(value_tBigQueryInput_1))
									value_tBigQueryInput_1 = null;

								if (value_tBigQueryInput_1 != null) {

									row1.contributing_factor_vehicle_3 = value_tBigQueryInput_1.toString();

								} else {
									row1.contributing_factor_vehicle_3 = "NoValueProvided";
								}
							}

							column_index_tBigQueryInput_1 = 4;

							if (fieldsCount_tBigQueryInput_1 <= column_index_tBigQueryInput_1) {
								row1.contributing_factor_vehicle_4 = null;
							} else {

								value_tBigQueryInput_1 = field_tBigQueryInput_1.get(column_index_tBigQueryInput_1)
										.getValue();

								if (com.google.api.client.util.Data.isNull(value_tBigQueryInput_1))
									value_tBigQueryInput_1 = null;

								if (value_tBigQueryInput_1 != null) {

									row1.contributing_factor_vehicle_4 = value_tBigQueryInput_1.toString();

								} else {
									row1.contributing_factor_vehicle_4 = "NoValueProvided";
								}
							}

							column_index_tBigQueryInput_1 = 5;

							if (fieldsCount_tBigQueryInput_1 <= column_index_tBigQueryInput_1) {
								row1.contributing_factor_vehicle_5 = null;
							} else {

								value_tBigQueryInput_1 = field_tBigQueryInput_1.get(column_index_tBigQueryInput_1)
										.getValue();

								if (com.google.api.client.util.Data.isNull(value_tBigQueryInput_1))
									value_tBigQueryInput_1 = null;

								if (value_tBigQueryInput_1 != null) {

									row1.contributing_factor_vehicle_5 = value_tBigQueryInput_1.toString();

								} else {
									row1.contributing_factor_vehicle_5 = "NoValueProvided";
								}
							}

							column_index_tBigQueryInput_1 = 6;

							if (fieldsCount_tBigQueryInput_1 <= column_index_tBigQueryInput_1) {
								row1.cross_street_name = null;
							} else {

								value_tBigQueryInput_1 = field_tBigQueryInput_1.get(column_index_tBigQueryInput_1)
										.getValue();

								if (com.google.api.client.util.Data.isNull(value_tBigQueryInput_1))
									value_tBigQueryInput_1 = null;

								if (value_tBigQueryInput_1 != null) {

									row1.cross_street_name = value_tBigQueryInput_1.toString();

								} else {
									row1.cross_street_name = "NoValueProvided";
								}
							}

							column_index_tBigQueryInput_1 = 7;

							if (fieldsCount_tBigQueryInput_1 <= column_index_tBigQueryInput_1) {
								row1.timestamp = null;
							} else {

								value_tBigQueryInput_1 = field_tBigQueryInput_1.get(column_index_tBigQueryInput_1)
										.getValue();

								if (com.google.api.client.util.Data.isNull(value_tBigQueryInput_1))
									value_tBigQueryInput_1 = null;

								if (value_tBigQueryInput_1 != null) {

									if (value_tBigQueryInput_1.toString().contains("-")) {
										String sValue_tBigQueryInput_1 = value_tBigQueryInput_1.toString();
										if (sValue_tBigQueryInput_1.matches(".*\\.\\d{6}")) {
											// microseconds must be ignored
											sValue_tBigQueryInput_1 = sValue_tBigQueryInput_1.substring(0,
													sValue_tBigQueryInput_1.length() - 3);
										}
										row1.timestamp = ParserUtils.parseTo_Date(sValue_tBigQueryInput_1,
												"yyyy-MM-dd'T'HH:mm:ss");
									} else {
										row1.timestamp = ParserUtils.parseTo_Date(value_tBigQueryInput_1.toString());
									}

								} else {
									row1.timestamp = null;
								}
							}

							column_index_tBigQueryInput_1 = 8;

							if (fieldsCount_tBigQueryInput_1 <= column_index_tBigQueryInput_1) {
								row1.latitude = null;
							} else {

								value_tBigQueryInput_1 = field_tBigQueryInput_1.get(column_index_tBigQueryInput_1)
										.getValue();

								if (com.google.api.client.util.Data.isNull(value_tBigQueryInput_1))
									value_tBigQueryInput_1 = null;

								if (value_tBigQueryInput_1 != null) {

									row1.latitude = ParserUtils.parseTo_Double(value_tBigQueryInput_1.toString());

								} else {
									row1.latitude = -1.0;
								}
							}

							column_index_tBigQueryInput_1 = 9;

							if (fieldsCount_tBigQueryInput_1 <= column_index_tBigQueryInput_1) {
								row1.longitude = null;
							} else {

								value_tBigQueryInput_1 = field_tBigQueryInput_1.get(column_index_tBigQueryInput_1)
										.getValue();

								if (com.google.api.client.util.Data.isNull(value_tBigQueryInput_1))
									value_tBigQueryInput_1 = null;

								if (value_tBigQueryInput_1 != null) {

									row1.longitude = ParserUtils.parseTo_Double(value_tBigQueryInput_1.toString());

								} else {
									row1.longitude = -1.0;
								}
							}

							column_index_tBigQueryInput_1 = 10;

							if (fieldsCount_tBigQueryInput_1 <= column_index_tBigQueryInput_1) {
								row1.location = null;
							} else {

								value_tBigQueryInput_1 = field_tBigQueryInput_1.get(column_index_tBigQueryInput_1)
										.getValue();

								if (com.google.api.client.util.Data.isNull(value_tBigQueryInput_1))
									value_tBigQueryInput_1 = null;

								if (value_tBigQueryInput_1 != null) {

									row1.location = value_tBigQueryInput_1.toString();

								} else {
									row1.location = "NoValueProvided";
								}
							}

							column_index_tBigQueryInput_1 = 11;

							if (fieldsCount_tBigQueryInput_1 <= column_index_tBigQueryInput_1) {
								row1.number_of_cyclist_injured = null;
							} else {

								value_tBigQueryInput_1 = field_tBigQueryInput_1.get(column_index_tBigQueryInput_1)
										.getValue();

								if (com.google.api.client.util.Data.isNull(value_tBigQueryInput_1))
									value_tBigQueryInput_1 = null;

								if (value_tBigQueryInput_1 != null) {

									row1.number_of_cyclist_injured = ParserUtils
											.parseTo_Integer(value_tBigQueryInput_1.toString());

								} else {
									row1.number_of_cyclist_injured = -1;
								}
							}

							column_index_tBigQueryInput_1 = 12;

							if (fieldsCount_tBigQueryInput_1 <= column_index_tBigQueryInput_1) {
								row1.number_of_cyclist_killed = null;
							} else {

								value_tBigQueryInput_1 = field_tBigQueryInput_1.get(column_index_tBigQueryInput_1)
										.getValue();

								if (com.google.api.client.util.Data.isNull(value_tBigQueryInput_1))
									value_tBigQueryInput_1 = null;

								if (value_tBigQueryInput_1 != null) {

									row1.number_of_cyclist_killed = ParserUtils
											.parseTo_Integer(value_tBigQueryInput_1.toString());

								} else {
									row1.number_of_cyclist_killed = -1;
								}
							}

							column_index_tBigQueryInput_1 = 13;

							if (fieldsCount_tBigQueryInput_1 <= column_index_tBigQueryInput_1) {
								row1.number_of_motorist_injured = null;
							} else {

								value_tBigQueryInput_1 = field_tBigQueryInput_1.get(column_index_tBigQueryInput_1)
										.getValue();

								if (com.google.api.client.util.Data.isNull(value_tBigQueryInput_1))
									value_tBigQueryInput_1 = null;

								if (value_tBigQueryInput_1 != null) {

									row1.number_of_motorist_injured = ParserUtils
											.parseTo_Integer(value_tBigQueryInput_1.toString());

								} else {
									row1.number_of_motorist_injured = -1;
								}
							}

							column_index_tBigQueryInput_1 = 14;

							if (fieldsCount_tBigQueryInput_1 <= column_index_tBigQueryInput_1) {
								row1.number_of_motorist_killed = null;
							} else {

								value_tBigQueryInput_1 = field_tBigQueryInput_1.get(column_index_tBigQueryInput_1)
										.getValue();

								if (com.google.api.client.util.Data.isNull(value_tBigQueryInput_1))
									value_tBigQueryInput_1 = null;

								if (value_tBigQueryInput_1 != null) {

									row1.number_of_motorist_killed = ParserUtils
											.parseTo_Integer(value_tBigQueryInput_1.toString());

								} else {
									row1.number_of_motorist_killed = -1;
								}
							}

							column_index_tBigQueryInput_1 = 15;

							if (fieldsCount_tBigQueryInput_1 <= column_index_tBigQueryInput_1) {
								row1.number_of_pedestrians_injured = null;
							} else {

								value_tBigQueryInput_1 = field_tBigQueryInput_1.get(column_index_tBigQueryInput_1)
										.getValue();

								if (com.google.api.client.util.Data.isNull(value_tBigQueryInput_1))
									value_tBigQueryInput_1 = null;

								if (value_tBigQueryInput_1 != null) {

									row1.number_of_pedestrians_injured = ParserUtils
											.parseTo_Integer(value_tBigQueryInput_1.toString());

								} else {
									row1.number_of_pedestrians_injured = -1;
								}
							}

							column_index_tBigQueryInput_1 = 16;

							if (fieldsCount_tBigQueryInput_1 <= column_index_tBigQueryInput_1) {
								row1.number_of_pedestrians_killed = null;
							} else {

								value_tBigQueryInput_1 = field_tBigQueryInput_1.get(column_index_tBigQueryInput_1)
										.getValue();

								if (com.google.api.client.util.Data.isNull(value_tBigQueryInput_1))
									value_tBigQueryInput_1 = null;

								if (value_tBigQueryInput_1 != null) {

									row1.number_of_pedestrians_killed = ParserUtils
											.parseTo_Integer(value_tBigQueryInput_1.toString());

								} else {
									row1.number_of_pedestrians_killed = -1;
								}
							}

							column_index_tBigQueryInput_1 = 17;

							if (fieldsCount_tBigQueryInput_1 <= column_index_tBigQueryInput_1) {
								row1.number_of_persons_injured = null;
							} else {

								value_tBigQueryInput_1 = field_tBigQueryInput_1.get(column_index_tBigQueryInput_1)
										.getValue();

								if (com.google.api.client.util.Data.isNull(value_tBigQueryInput_1))
									value_tBigQueryInput_1 = null;

								if (value_tBigQueryInput_1 != null) {

									row1.number_of_persons_injured = ParserUtils
											.parseTo_Integer(value_tBigQueryInput_1.toString());

								} else {
									row1.number_of_persons_injured = -1;
								}
							}

							column_index_tBigQueryInput_1 = 18;

							if (fieldsCount_tBigQueryInput_1 <= column_index_tBigQueryInput_1) {
								row1.number_of_persons_killed = null;
							} else {

								value_tBigQueryInput_1 = field_tBigQueryInput_1.get(column_index_tBigQueryInput_1)
										.getValue();

								if (com.google.api.client.util.Data.isNull(value_tBigQueryInput_1))
									value_tBigQueryInput_1 = null;

								if (value_tBigQueryInput_1 != null) {

									row1.number_of_persons_killed = ParserUtils
											.parseTo_Integer(value_tBigQueryInput_1.toString());

								} else {
									row1.number_of_persons_killed = -1;
								}
							}

							column_index_tBigQueryInput_1 = 19;

							if (fieldsCount_tBigQueryInput_1 <= column_index_tBigQueryInput_1) {
								row1.off_street_name = null;
							} else {

								value_tBigQueryInput_1 = field_tBigQueryInput_1.get(column_index_tBigQueryInput_1)
										.getValue();

								if (com.google.api.client.util.Data.isNull(value_tBigQueryInput_1))
									value_tBigQueryInput_1 = null;

								if (value_tBigQueryInput_1 != null) {

									row1.off_street_name = value_tBigQueryInput_1.toString();

								} else {
									row1.off_street_name = "NoValueProvided";
								}
							}

							column_index_tBigQueryInput_1 = 20;

							if (fieldsCount_tBigQueryInput_1 <= column_index_tBigQueryInput_1) {
								row1.on_street_name = null;
							} else {

								value_tBigQueryInput_1 = field_tBigQueryInput_1.get(column_index_tBigQueryInput_1)
										.getValue();

								if (com.google.api.client.util.Data.isNull(value_tBigQueryInput_1))
									value_tBigQueryInput_1 = null;

								if (value_tBigQueryInput_1 != null) {

									row1.on_street_name = value_tBigQueryInput_1.toString();

								} else {
									row1.on_street_name = "NoValueProvided";
								}
							}

							column_index_tBigQueryInput_1 = 21;

							if (fieldsCount_tBigQueryInput_1 <= column_index_tBigQueryInput_1) {
								row1.unique_key = 0;
							} else {

								value_tBigQueryInput_1 = field_tBigQueryInput_1.get(column_index_tBigQueryInput_1)
										.getValue();

								if (com.google.api.client.util.Data.isNull(value_tBigQueryInput_1))
									value_tBigQueryInput_1 = null;

								if (value_tBigQueryInput_1 != null) {

									row1.unique_key = ParserUtils.parseTo_int(value_tBigQueryInput_1.toString());

								} else {
									row1.unique_key = -1;
								}
							}

							column_index_tBigQueryInput_1 = 22;

							if (fieldsCount_tBigQueryInput_1 <= column_index_tBigQueryInput_1) {
								row1.vehicle_type_code1 = null;
							} else {

								value_tBigQueryInput_1 = field_tBigQueryInput_1.get(column_index_tBigQueryInput_1)
										.getValue();

								if (com.google.api.client.util.Data.isNull(value_tBigQueryInput_1))
									value_tBigQueryInput_1 = null;

								if (value_tBigQueryInput_1 != null) {

									row1.vehicle_type_code1 = value_tBigQueryInput_1.toString();

								} else {
									row1.vehicle_type_code1 = "NoValueProvided";
								}
							}

							column_index_tBigQueryInput_1 = 23;

							if (fieldsCount_tBigQueryInput_1 <= column_index_tBigQueryInput_1) {
								row1.vehicle_type_code2 = null;
							} else {

								value_tBigQueryInput_1 = field_tBigQueryInput_1.get(column_index_tBigQueryInput_1)
										.getValue();

								if (com.google.api.client.util.Data.isNull(value_tBigQueryInput_1))
									value_tBigQueryInput_1 = null;

								if (value_tBigQueryInput_1 != null) {

									row1.vehicle_type_code2 = value_tBigQueryInput_1.toString();

								} else {
									row1.vehicle_type_code2 = "NoValueProvided";
								}
							}

							column_index_tBigQueryInput_1 = 24;

							if (fieldsCount_tBigQueryInput_1 <= column_index_tBigQueryInput_1) {
								row1.vehicle_type_code3 = null;
							} else {

								value_tBigQueryInput_1 = field_tBigQueryInput_1.get(column_index_tBigQueryInput_1)
										.getValue();

								if (com.google.api.client.util.Data.isNull(value_tBigQueryInput_1))
									value_tBigQueryInput_1 = null;

								if (value_tBigQueryInput_1 != null) {

									row1.vehicle_type_code3 = value_tBigQueryInput_1.toString();

								} else {
									row1.vehicle_type_code3 = "NoValueProvided";
								}
							}

							column_index_tBigQueryInput_1 = 25;

							if (fieldsCount_tBigQueryInput_1 <= column_index_tBigQueryInput_1) {
								row1.vehicle_type_code4 = null;
							} else {

								value_tBigQueryInput_1 = field_tBigQueryInput_1.get(column_index_tBigQueryInput_1)
										.getValue();

								if (com.google.api.client.util.Data.isNull(value_tBigQueryInput_1))
									value_tBigQueryInput_1 = null;

								if (value_tBigQueryInput_1 != null) {

									row1.vehicle_type_code4 = value_tBigQueryInput_1.toString();

								} else {
									row1.vehicle_type_code4 = "NoValueProvided";
								}
							}

							column_index_tBigQueryInput_1 = 26;

							if (fieldsCount_tBigQueryInput_1 <= column_index_tBigQueryInput_1) {
								row1.vehicle_type_code5 = null;
							} else {

								value_tBigQueryInput_1 = field_tBigQueryInput_1.get(column_index_tBigQueryInput_1)
										.getValue();

								if (com.google.api.client.util.Data.isNull(value_tBigQueryInput_1))
									value_tBigQueryInput_1 = null;

								if (value_tBigQueryInput_1 != null) {

									row1.vehicle_type_code5 = value_tBigQueryInput_1.toString();

								} else {
									row1.vehicle_type_code5 = "NoValueProvided";
								}
							}

							column_index_tBigQueryInput_1 = 27;

							if (fieldsCount_tBigQueryInput_1 <= column_index_tBigQueryInput_1) {
								row1.zip_code = null;
							} else {

								value_tBigQueryInput_1 = field_tBigQueryInput_1.get(column_index_tBigQueryInput_1)
										.getValue();

								if (com.google.api.client.util.Data.isNull(value_tBigQueryInput_1))
									value_tBigQueryInput_1 = null;

								if (value_tBigQueryInput_1 != null) {

									row1.zip_code = ParserUtils.parseTo_Integer(value_tBigQueryInput_1.toString());

								} else {
									row1.zip_code = -1;
								}
							}

							log.debug("tBigQueryInput_1 - Retrieving the record " + (nb_line_tBigQueryInput_1) + ".");

							/**
							 * [tBigQueryInput_1 begin ] stop
							 */

							/**
							 * [tBigQueryInput_1 main ] start
							 */

							currentComponent = "tBigQueryInput_1";

							tos_count_tBigQueryInput_1++;

							/**
							 * [tBigQueryInput_1 main ] stop
							 */

							/**
							 * [tBigQueryInput_1 process_data_begin ] start
							 */

							currentComponent = "tBigQueryInput_1";

							/**
							 * [tBigQueryInput_1 process_data_begin ] stop
							 */

							/**
							 * [tMap_1 main ] start
							 */

							currentComponent = "tMap_1";

							if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

									, "row1", "tBigQueryInput_1", "tBigQueryInput_1", "tBigQueryInput", "tMap_1",
									"tMap_1", "tMap"

							)) {
								talendJobLogProcess(globalMap);
							}

							if (log.isTraceEnabled()) {
								log.trace("row1 - " + (row1 == null ? "" : row1.toLogString()));
							}

							boolean hasCasePrimitiveKeyWithNull_tMap_1 = false;

							// ###############################
							// # Input tables (lookups)
							boolean rejectedInnerJoin_tMap_1 = false;
							boolean mainRowRejected_tMap_1 = false;

							// ###############################
							{ // start of Var scope

								// ###############################
								// # Vars tables

								Var__tMap_1__Struct Var = Var__tMap_1;// ###############################
								// ###############################
								// # Output tables

								Load_Data = null;

// # Output table : 'Load_Data'
								count_Load_Data_tMap_1++;

								Load_Data_tmp.borough = row1.borough;
								Load_Data_tmp.contributing_factor_vehicle_1 = row1.contributing_factor_vehicle_1;
								Load_Data_tmp.contributing_factor_vehicle_2 = row1.contributing_factor_vehicle_2;
								Load_Data_tmp.contributing_factor_vehicle_3 = row1.contributing_factor_vehicle_3;
								Load_Data_tmp.contributing_factor_vehicle_4 = row1.contributing_factor_vehicle_4;
								Load_Data_tmp.contributing_factor_vehicle_5 = row1.contributing_factor_vehicle_5;
								Load_Data_tmp.cross_street_name = row1.cross_street_name;
								Load_Data_tmp.collision_dt = row1.timestamp;
								Load_Data_tmp.collision_hour = routines.TalendDate.getPartOfDate("HOUR",
										row1.timestamp);
								Load_Data_tmp.collision_time = row1.timestamp;
								Load_Data_tmp.collision_dayoftheweek = (routines.TalendDate.getPartOfDate("DAY_OF_WEEK",
										row1.timestamp));
								Load_Data_tmp.latitude = row1.latitude;
								Load_Data_tmp.longitude = row1.longitude;
								Load_Data_tmp.location = row1.location;
								Load_Data_tmp.number_of_cyclist_injured = row1.number_of_cyclist_injured;
								Load_Data_tmp.number_of_cyclist_killed = row1.number_of_cyclist_killed;
								Load_Data_tmp.number_of_motorist_injured = row1.number_of_motorist_injured;
								Load_Data_tmp.number_of_motorist_killed = row1.number_of_motorist_killed;
								Load_Data_tmp.number_of_pedestrians_injured = row1.number_of_pedestrians_injured;
								Load_Data_tmp.number_of_pedestrians_killed = row1.number_of_pedestrians_killed;
								Load_Data_tmp.number_of_persons_injured = row1.number_of_persons_injured;
								Load_Data_tmp.number_of_persons_killed = row1.number_of_persons_killed;
								Load_Data_tmp.off_street_name = row1.off_street_name;
								Load_Data_tmp.on_street_name = row1.on_street_name;
								Load_Data_tmp.unique_key = row1.unique_key;
								Load_Data_tmp.vehicle_type_code1 = row1.vehicle_type_code1;
								Load_Data_tmp.vehicle_type_code2 = row1.vehicle_type_code2;
								Load_Data_tmp.vehicle_type_code3 = row1.vehicle_type_code3;
								Load_Data_tmp.vehicle_type_code4 = row1.vehicle_type_code4;
								Load_Data_tmp.vehicle_type_code5 = row1.vehicle_type_code5;
								Load_Data_tmp.zip_code = row1.zip_code;
								Load_Data = Load_Data_tmp;
								log.debug("tMap_1 - Outputting the record " + count_Load_Data_tMap_1
										+ " of the output table 'Load_Data'.");

// ###############################

							} // end of Var scope

							rejectedInnerJoin_tMap_1 = false;

							tos_count_tMap_1++;

							/**
							 * [tMap_1 main ] stop
							 */

							/**
							 * [tMap_1 process_data_begin ] start
							 */

							currentComponent = "tMap_1";

							/**
							 * [tMap_1 process_data_begin ] stop
							 */
// Start of branch "Load_Data"
							if (Load_Data != null) {

								/**
								 * [tDBOutput_2 main ] start
								 */

								currentComponent = "tDBOutput_2";

								if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

										, "Load_Data", "tMap_1", "tMap_1", "tMap", "tDBOutput_2", "tDBOutput_2",
										"tMSSqlOutput"

								)) {
									talendJobLogProcess(globalMap);
								}

								if (log.isTraceEnabled()) {
									log.trace("Load_Data - " + (Load_Data == null ? "" : Load_Data.toLogString()));
								}

								whetherReject_tDBOutput_2 = false;
								if (Load_Data.borough == null) {
									pstmt_tDBOutput_2.setNull(1, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_2.setString(1, Load_Data.borough);
								}

								if (Load_Data.contributing_factor_vehicle_1 == null) {
									pstmt_tDBOutput_2.setNull(2, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_2.setString(2, Load_Data.contributing_factor_vehicle_1);
								}

								if (Load_Data.contributing_factor_vehicle_2 == null) {
									pstmt_tDBOutput_2.setNull(3, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_2.setString(3, Load_Data.contributing_factor_vehicle_2);
								}

								if (Load_Data.contributing_factor_vehicle_3 == null) {
									pstmt_tDBOutput_2.setNull(4, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_2.setString(4, Load_Data.contributing_factor_vehicle_3);
								}

								if (Load_Data.contributing_factor_vehicle_4 == null) {
									pstmt_tDBOutput_2.setNull(5, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_2.setString(5, Load_Data.contributing_factor_vehicle_4);
								}

								if (Load_Data.contributing_factor_vehicle_5 == null) {
									pstmt_tDBOutput_2.setNull(6, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_2.setString(6, Load_Data.contributing_factor_vehicle_5);
								}

								if (Load_Data.cross_street_name == null) {
									pstmt_tDBOutput_2.setNull(7, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_2.setString(7, Load_Data.cross_street_name);
								}

								if (Load_Data.collision_dt != null) {
									pstmt_tDBOutput_2.setTimestamp(8,
											new java.sql.Timestamp(Load_Data.collision_dt.getTime()));
								} else {
									pstmt_tDBOutput_2.setNull(8, java.sql.Types.TIMESTAMP);
								}

								if (Load_Data.collision_hour == null) {
									pstmt_tDBOutput_2.setNull(9, java.sql.Types.INTEGER);
								} else {
									pstmt_tDBOutput_2.setInt(9, Load_Data.collision_hour);
								}

								if (Load_Data.collision_time != null) {
									pstmt_tDBOutput_2.setTimestamp(10,
											new java.sql.Timestamp(Load_Data.collision_time.getTime()));
								} else {
									pstmt_tDBOutput_2.setNull(10, java.sql.Types.TIMESTAMP);
								}

								if (Load_Data.collision_dayoftheweek == null) {
									pstmt_tDBOutput_2.setNull(11, java.sql.Types.INTEGER);
								} else {
									pstmt_tDBOutput_2.setInt(11, Load_Data.collision_dayoftheweek);
								}

								if (Load_Data.latitude == null) {
									pstmt_tDBOutput_2.setNull(12, java.sql.Types.DOUBLE);
								} else {
									pstmt_tDBOutput_2.setDouble(12, Load_Data.latitude);
								}

								if (Load_Data.longitude == null) {
									pstmt_tDBOutput_2.setNull(13, java.sql.Types.DOUBLE);
								} else {
									pstmt_tDBOutput_2.setDouble(13, Load_Data.longitude);
								}

								if (Load_Data.location == null) {
									pstmt_tDBOutput_2.setNull(14, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_2.setString(14, Load_Data.location);
								}

								if (Load_Data.number_of_cyclist_injured == null) {
									pstmt_tDBOutput_2.setNull(15, java.sql.Types.INTEGER);
								} else {
									pstmt_tDBOutput_2.setInt(15, Load_Data.number_of_cyclist_injured);
								}

								if (Load_Data.number_of_cyclist_killed == null) {
									pstmt_tDBOutput_2.setNull(16, java.sql.Types.INTEGER);
								} else {
									pstmt_tDBOutput_2.setInt(16, Load_Data.number_of_cyclist_killed);
								}

								if (Load_Data.number_of_motorist_injured == null) {
									pstmt_tDBOutput_2.setNull(17, java.sql.Types.INTEGER);
								} else {
									pstmt_tDBOutput_2.setInt(17, Load_Data.number_of_motorist_injured);
								}

								if (Load_Data.number_of_motorist_killed == null) {
									pstmt_tDBOutput_2.setNull(18, java.sql.Types.INTEGER);
								} else {
									pstmt_tDBOutput_2.setInt(18, Load_Data.number_of_motorist_killed);
								}

								if (Load_Data.number_of_pedestrians_injured == null) {
									pstmt_tDBOutput_2.setNull(19, java.sql.Types.INTEGER);
								} else {
									pstmt_tDBOutput_2.setInt(19, Load_Data.number_of_pedestrians_injured);
								}

								if (Load_Data.number_of_pedestrians_killed == null) {
									pstmt_tDBOutput_2.setNull(20, java.sql.Types.INTEGER);
								} else {
									pstmt_tDBOutput_2.setInt(20, Load_Data.number_of_pedestrians_killed);
								}

								if (Load_Data.number_of_persons_injured == null) {
									pstmt_tDBOutput_2.setNull(21, java.sql.Types.INTEGER);
								} else {
									pstmt_tDBOutput_2.setInt(21, Load_Data.number_of_persons_injured);
								}

								if (Load_Data.number_of_persons_killed == null) {
									pstmt_tDBOutput_2.setNull(22, java.sql.Types.INTEGER);
								} else {
									pstmt_tDBOutput_2.setInt(22, Load_Data.number_of_persons_killed);
								}

								if (Load_Data.off_street_name == null) {
									pstmt_tDBOutput_2.setNull(23, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_2.setString(23, Load_Data.off_street_name);
								}

								if (Load_Data.on_street_name == null) {
									pstmt_tDBOutput_2.setNull(24, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_2.setString(24, Load_Data.on_street_name);
								}

								pstmt_tDBOutput_2.setInt(25, Load_Data.unique_key);

								if (Load_Data.vehicle_type_code1 == null) {
									pstmt_tDBOutput_2.setNull(26, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_2.setString(26, Load_Data.vehicle_type_code1);
								}

								if (Load_Data.vehicle_type_code2 == null) {
									pstmt_tDBOutput_2.setNull(27, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_2.setString(27, Load_Data.vehicle_type_code2);
								}

								if (Load_Data.vehicle_type_code3 == null) {
									pstmt_tDBOutput_2.setNull(28, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_2.setString(28, Load_Data.vehicle_type_code3);
								}

								if (Load_Data.vehicle_type_code4 == null) {
									pstmt_tDBOutput_2.setNull(29, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_2.setString(29, Load_Data.vehicle_type_code4);
								}

								if (Load_Data.vehicle_type_code5 == null) {
									pstmt_tDBOutput_2.setNull(30, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_2.setString(30, Load_Data.vehicle_type_code5);
								}

								if (Load_Data.zip_code == null) {
									pstmt_tDBOutput_2.setNull(31, java.sql.Types.INTEGER);
								} else {
									pstmt_tDBOutput_2.setInt(31, Load_Data.zip_code);
								}

								pstmt_tDBOutput_2.addBatch();
								nb_line_tDBOutput_2++;

								if (log.isDebugEnabled())
									log.debug("tDBOutput_2 - " + ("Adding the record ") + (nb_line_tDBOutput_2)
											+ (" to the ") + ("INSERT") + (" batch."));
								batchSizeCounter_tDBOutput_2++;

								////////// batch execute by batch size///////
								class LimitBytesHelper_tDBOutput_2 {
									public int limitBytePart1(int counter, java.sql.PreparedStatement pstmt_tDBOutput_2)
											throws Exception {
										try {

											if (log.isDebugEnabled())
												log.debug("tDBOutput_2 - " + ("Executing the ") + ("INSERT")
														+ (" batch."));
											for (int countEach_tDBOutput_2 : pstmt_tDBOutput_2.executeBatch()) {
												if (countEach_tDBOutput_2 == -2 || countEach_tDBOutput_2 == -3) {
													break;
												}
												counter += countEach_tDBOutput_2;
											}

											if (log.isDebugEnabled())
												log.debug("tDBOutput_2 - " + ("The ") + ("INSERT")
														+ (" batch execution has succeeded."));
										} catch (java.sql.BatchUpdateException e) {
											globalMap.put("tDBOutput_2_ERROR_MESSAGE", e.getMessage());

											int countSum_tDBOutput_2 = 0;
											for (int countEach_tDBOutput_2 : e.getUpdateCounts()) {
												counter += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
											}

											log.error("tDBOutput_2 - " + (e.getMessage()));
											System.err.println(e.getMessage());

										}
										return counter;
									}

									public int limitBytePart2(int counter, java.sql.PreparedStatement pstmt_tDBOutput_2)
											throws Exception {
										try {

											if (log.isDebugEnabled())
												log.debug("tDBOutput_2 - " + ("Executing the ") + ("INSERT")
														+ (" batch."));
											for (int countEach_tDBOutput_2 : pstmt_tDBOutput_2.executeBatch()) {
												if (countEach_tDBOutput_2 == -2 || countEach_tDBOutput_2 == -3) {
													break;
												}
												counter += countEach_tDBOutput_2;
											}

											if (log.isDebugEnabled())
												log.debug("tDBOutput_2 - " + ("The ") + ("INSERT")
														+ (" batch execution has succeeded."));
										} catch (java.sql.BatchUpdateException e) {
											globalMap.put("tDBOutput_2_ERROR_MESSAGE", e.getMessage());

											for (int countEach_tDBOutput_2 : e.getUpdateCounts()) {
												counter += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
											}

											log.error("tDBOutput_2 - " + (e.getMessage()));
											System.err.println(e.getMessage());

										}
										return counter;
									}
								}
								if ((batchSize_tDBOutput_2 > 0)
										&& (batchSize_tDBOutput_2 <= batchSizeCounter_tDBOutput_2)) {

									insertedCount_tDBOutput_2 = new LimitBytesHelper_tDBOutput_2()
											.limitBytePart1(insertedCount_tDBOutput_2, pstmt_tDBOutput_2);
									rowsToCommitCount_tDBOutput_2 = insertedCount_tDBOutput_2;

									batchSizeCounter_tDBOutput_2 = 0;
								}

								//////////// commit every////////////

								commitCounter_tDBOutput_2++;
								if (commitEvery_tDBOutput_2 <= commitCounter_tDBOutput_2) {
									if ((batchSize_tDBOutput_2 > 0) && (batchSizeCounter_tDBOutput_2 > 0)) {

										insertedCount_tDBOutput_2 = new LimitBytesHelper_tDBOutput_2()
												.limitBytePart1(insertedCount_tDBOutput_2, pstmt_tDBOutput_2);

										batchSizeCounter_tDBOutput_2 = 0;
									}
									if (rowsToCommitCount_tDBOutput_2 != 0) {

										if (log.isDebugEnabled())
											log.debug("tDBOutput_2 - " + ("Connection starting to commit ")
													+ (rowsToCommitCount_tDBOutput_2) + (" record(s)."));
									}
									conn_tDBOutput_2.commit();
									if (rowsToCommitCount_tDBOutput_2 != 0) {

										if (log.isDebugEnabled())
											log.debug("tDBOutput_2 - " + ("Connection commit has succeeded."));
										rowsToCommitCount_tDBOutput_2 = 0;
									}
									commitCounter_tDBOutput_2 = 0;
								}

								tos_count_tDBOutput_2++;

								/**
								 * [tDBOutput_2 main ] stop
								 */

								/**
								 * [tDBOutput_2 process_data_begin ] start
								 */

								currentComponent = "tDBOutput_2";

								/**
								 * [tDBOutput_2 process_data_begin ] stop
								 */

								/**
								 * [tDBOutput_2 process_data_end ] start
								 */

								currentComponent = "tDBOutput_2";

								/**
								 * [tDBOutput_2 process_data_end ] stop
								 */

							} // End of branch "Load_Data"

							/**
							 * [tMap_1 process_data_end ] start
							 */

							currentComponent = "tMap_1";

							/**
							 * [tMap_1 process_data_end ] stop
							 */

							/**
							 * [tBigQueryInput_1 process_data_end ] start
							 */

							currentComponent = "tBigQueryInput_1";

							/**
							 * [tBigQueryInput_1 process_data_end ] stop
							 */

							/**
							 * [tBigQueryInput_1 end ] start
							 */

							currentComponent = "tBigQueryInput_1";

						}
						if (child_statistics_tBigQueryInput_1 != null) {
							globalMap.put("tBigQueryInput_1_STATISTICS_CHILD",
									child_statistics_tBigQueryInput_1.stream().collect(
											java.util.stream.Collectors.joining(",", "{\"statistics\": [", "]}")));
						}
						// }
						log.debug("tBigQueryInput_1 - Retrieved records count: " + nb_line_tBigQueryInput_1 + " .");

					}
				} catch (Exception e_tBigQueryInput_1) {
					String message_tBigQueryInput_1 = e_tBigQueryInput_1.getMessage();
					log.error(message_tBigQueryInput_1);
					globalMap.put("tBigQueryInput_1_ERROR_MESSAGE", message_tBigQueryInput_1);
					throw e_tBigQueryInput_1;
				} finally {
					serviceAccountBigQueryUtil_tBigQueryInput_1.cleanup();
				}

				if (log.isDebugEnabled())
					log.debug("tBigQueryInput_1 - " + ("Done."));

				ok_Hash.put("tBigQueryInput_1", true);
				end_Hash.put("tBigQueryInput_1", System.currentTimeMillis());

				/**
				 * [tBigQueryInput_1 end ] stop
				 */

				/**
				 * [tMap_1 end ] start
				 */

				currentComponent = "tMap_1";

// ###############################
// # Lookup hashes releasing
// ###############################      
				log.debug("tMap_1 - Written records count in the table 'Load_Data': " + count_Load_Data_tMap_1 + ".");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "row1", 2, 0,
						"tBigQueryInput_1", "tBigQueryInput_1", "tBigQueryInput", "tMap_1", "tMap_1", "tMap",
						"output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tMap_1 - " + ("Done."));

				ok_Hash.put("tMap_1", true);
				end_Hash.put("tMap_1", System.currentTimeMillis());

				/**
				 * [tMap_1 end ] stop
				 */

				/**
				 * [tDBOutput_2 end ] start
				 */

				currentComponent = "tDBOutput_2";

				try {
					int countSum_tDBOutput_2 = 0;
					if (pstmt_tDBOutput_2 != null && batchSizeCounter_tDBOutput_2 > 0) {

						if (log.isDebugEnabled())
							log.debug("tDBOutput_2 - " + ("Executing the ") + ("INSERT") + (" batch."));
						for (int countEach_tDBOutput_2 : pstmt_tDBOutput_2.executeBatch()) {
							if (countEach_tDBOutput_2 == -2 || countEach_tDBOutput_2 == -3) {
								break;
							}
							countSum_tDBOutput_2 += countEach_tDBOutput_2;
						}
						rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;

						if (log.isDebugEnabled())
							log.debug("tDBOutput_2 - " + ("The ") + ("INSERT") + (" batch execution has succeeded."));
					}

					insertedCount_tDBOutput_2 += countSum_tDBOutput_2;

				} catch (java.sql.BatchUpdateException e) {
					globalMap.put("tDBOutput_2_ERROR_MESSAGE", e.getMessage());

					int countSum_tDBOutput_2 = 0;
					for (int countEach_tDBOutput_2 : e.getUpdateCounts()) {
						countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
					}
					rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;

					insertedCount_tDBOutput_2 += countSum_tDBOutput_2;

					log.error("tDBOutput_2 - " + (e.getMessage()));
					System.err.println(e.getMessage());

				}
				if (pstmt_tDBOutput_2 != null) {

					pstmt_tDBOutput_2.close();
					resourceMap.remove("pstmt_tDBOutput_2");

				}
				resourceMap.put("statementClosed_tDBOutput_2", true);
				if (rowsToCommitCount_tDBOutput_2 != 0) {

					if (log.isDebugEnabled())
						log.debug("tDBOutput_2 - " + ("Connection starting to commit ")
								+ (rowsToCommitCount_tDBOutput_2) + (" record(s)."));
				}
				conn_tDBOutput_2.commit();
				if (rowsToCommitCount_tDBOutput_2 != 0) {

					if (log.isDebugEnabled())
						log.debug("tDBOutput_2 - " + ("Connection commit has succeeded."));
					rowsToCommitCount_tDBOutput_2 = 0;
				}
				commitCounter_tDBOutput_2 = 0;
				if (log.isDebugEnabled())
					log.debug("tDBOutput_2 - " + ("Closing the connection to the database."));
				conn_tDBOutput_2.close();
				if (log.isDebugEnabled())
					log.debug("tDBOutput_2 - " + ("Connection to the database has closed."));
				resourceMap.put("finish_tDBOutput_2", true);

				nb_line_deleted_tDBOutput_2 = nb_line_deleted_tDBOutput_2 + deletedCount_tDBOutput_2;
				nb_line_update_tDBOutput_2 = nb_line_update_tDBOutput_2 + updatedCount_tDBOutput_2;
				nb_line_inserted_tDBOutput_2 = nb_line_inserted_tDBOutput_2 + insertedCount_tDBOutput_2;
				nb_line_rejected_tDBOutput_2 = nb_line_rejected_tDBOutput_2 + rejectedCount_tDBOutput_2;

				globalMap.put("tDBOutput_2_NB_LINE", nb_line_tDBOutput_2);
				globalMap.put("tDBOutput_2_NB_LINE_UPDATED", nb_line_update_tDBOutput_2);
				globalMap.put("tDBOutput_2_NB_LINE_INSERTED", nb_line_inserted_tDBOutput_2);
				globalMap.put("tDBOutput_2_NB_LINE_DELETED", nb_line_deleted_tDBOutput_2);
				globalMap.put("tDBOutput_2_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_2);

				if (log.isDebugEnabled())
					log.debug("tDBOutput_2 - " + ("Has ") + ("inserted") + (" ") + (nb_line_inserted_tDBOutput_2)
							+ (" record(s)."));

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "Load_Data", 2, 0,
						"tMap_1", "tMap_1", "tMap", "tDBOutput_2", "tDBOutput_2", "tMSSqlOutput", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tDBOutput_2 - " + ("Done."));

				ok_Hash.put("tDBOutput_2", true);
				end_Hash.put("tDBOutput_2", System.currentTimeMillis());

				/**
				 * [tDBOutput_2 end ] stop
				 */

			} // end the resume

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage(), e);
			}

			TalendException te = new TalendException(e, currentComponent, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [tBigQueryInput_1 finally ] start
				 */

				currentComponent = "tBigQueryInput_1";

				/**
				 * [tBigQueryInput_1 finally ] stop
				 */

				/**
				 * [tMap_1 finally ] start
				 */

				currentComponent = "tMap_1";

				/**
				 * [tMap_1 finally ] stop
				 */

				/**
				 * [tDBOutput_2 finally ] start
				 */

				currentComponent = "tDBOutput_2";

				try {
					if (resourceMap.get("statementClosed_tDBOutput_2") == null) {
						java.sql.PreparedStatement pstmtToClose_tDBOutput_2 = null;
						if ((pstmtToClose_tDBOutput_2 = (java.sql.PreparedStatement) resourceMap
								.remove("pstmt_tDBOutput_2")) != null) {
							pstmtToClose_tDBOutput_2.close();
						}
					}
				} finally {
					if (resourceMap.get("finish_tDBOutput_2") == null) {
						java.sql.Connection ctn_tDBOutput_2 = null;
						if ((ctn_tDBOutput_2 = (java.sql.Connection) resourceMap.get("conn_tDBOutput_2")) != null) {
							try {
								if (log.isDebugEnabled())
									log.debug("tDBOutput_2 - " + ("Closing the connection to the database."));
								ctn_tDBOutput_2.close();
								if (log.isDebugEnabled())
									log.debug("tDBOutput_2 - " + ("Connection to the database has closed."));
							} catch (java.sql.SQLException sqlEx_tDBOutput_2) {
								String errorMessage_tDBOutput_2 = "failed to close the connection in tDBOutput_2 :"
										+ sqlEx_tDBOutput_2.getMessage();
								log.error("tDBOutput_2 - " + (errorMessage_tDBOutput_2));
								System.err.println(errorMessage_tDBOutput_2);
							}
						}
					}
				}

				/**
				 * [tDBOutput_2 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tBigQueryInput_1_SUBPROCESS_STATE", 1);
	}

	public void talendJobLogProcess(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("talendJobLog_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				/**
				 * [talendJobLog begin ] start
				 */

				ok_Hash.put("talendJobLog", false);
				start_Hash.put("talendJobLog", System.currentTimeMillis());

				currentComponent = "talendJobLog";

				int tos_count_talendJobLog = 0;

				for (JobStructureCatcherUtils.JobStructureCatcherMessage jcm : talendJobLog.getMessages()) {
					org.talend.job.audit.JobContextBuilder builder_talendJobLog = org.talend.job.audit.JobContextBuilder
							.create().jobName(jcm.job_name).jobId(jcm.job_id).jobVersion(jcm.job_version)
							.custom("process_id", jcm.pid).custom("thread_id", jcm.tid).custom("pid", pid)
							.custom("father_pid", fatherPid).custom("root_pid", rootPid);
					org.talend.logging.audit.Context log_context_talendJobLog = null;

					if (jcm.log_type == JobStructureCatcherUtils.LogType.PERFORMANCE) {
						long timeMS = jcm.end_time - jcm.start_time;
						String duration = String.valueOf(timeMS);

						log_context_talendJobLog = builder_talendJobLog.sourceId(jcm.sourceId)
								.sourceLabel(jcm.sourceLabel).sourceConnectorType(jcm.sourceComponentName)
								.targetId(jcm.targetId).targetLabel(jcm.targetLabel)
								.targetConnectorType(jcm.targetComponentName).connectionName(jcm.current_connector)
								.rows(jcm.row_count).duration(duration).build();
						auditLogger_talendJobLog.flowExecution(log_context_talendJobLog);
					} else if (jcm.log_type == JobStructureCatcherUtils.LogType.JOBSTART) {
						log_context_talendJobLog = builder_talendJobLog.timestamp(jcm.moment).build();
						auditLogger_talendJobLog.jobstart(log_context_talendJobLog);
					} else if (jcm.log_type == JobStructureCatcherUtils.LogType.JOBEND) {
						long timeMS = jcm.end_time - jcm.start_time;
						String duration = String.valueOf(timeMS);

						log_context_talendJobLog = builder_talendJobLog.timestamp(jcm.moment).duration(duration)
								.status(jcm.status).build();
						auditLogger_talendJobLog.jobstop(log_context_talendJobLog);
					} else if (jcm.log_type == JobStructureCatcherUtils.LogType.RUNCOMPONENT) {
						log_context_talendJobLog = builder_talendJobLog.timestamp(jcm.moment)
								.connectorType(jcm.component_name).connectorId(jcm.component_id)
								.connectorLabel(jcm.component_label).build();
						auditLogger_talendJobLog.runcomponent(log_context_talendJobLog);
					} else if (jcm.log_type == JobStructureCatcherUtils.LogType.FLOWINPUT) {// log current component
																							// input line
						long timeMS = jcm.end_time - jcm.start_time;
						String duration = String.valueOf(timeMS);

						log_context_talendJobLog = builder_talendJobLog.connectorType(jcm.component_name)
								.connectorId(jcm.component_id).connectorLabel(jcm.component_label)
								.connectionName(jcm.current_connector).connectionType(jcm.current_connector_type)
								.rows(jcm.total_row_number).duration(duration).build();
						auditLogger_talendJobLog.flowInput(log_context_talendJobLog);
					} else if (jcm.log_type == JobStructureCatcherUtils.LogType.FLOWOUTPUT) {// log current component
																								// output/reject line
						long timeMS = jcm.end_time - jcm.start_time;
						String duration = String.valueOf(timeMS);

						log_context_talendJobLog = builder_talendJobLog.connectorType(jcm.component_name)
								.connectorId(jcm.component_id).connectorLabel(jcm.component_label)
								.connectionName(jcm.current_connector).connectionType(jcm.current_connector_type)
								.rows(jcm.total_row_number).duration(duration).build();
						auditLogger_talendJobLog.flowOutput(log_context_talendJobLog);
					}

				}

				/**
				 * [talendJobLog begin ] stop
				 */

				/**
				 * [talendJobLog main ] start
				 */

				currentComponent = "talendJobLog";

				tos_count_talendJobLog++;

				/**
				 * [talendJobLog main ] stop
				 */

				/**
				 * [talendJobLog process_data_begin ] start
				 */

				currentComponent = "talendJobLog";

				/**
				 * [talendJobLog process_data_begin ] stop
				 */

				/**
				 * [talendJobLog process_data_end ] start
				 */

				currentComponent = "talendJobLog";

				/**
				 * [talendJobLog process_data_end ] stop
				 */

				/**
				 * [talendJobLog end ] start
				 */

				currentComponent = "talendJobLog";

				ok_Hash.put("talendJobLog", true);
				end_Hash.put("talendJobLog", System.currentTimeMillis());

				/**
				 * [talendJobLog end ] stop
				 */
			} // end the resume

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage(), e);
			}

			TalendException te = new TalendException(e, currentComponent, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [talendJobLog finally ] start
				 */

				currentComponent = "talendJobLog";

				/**
				 * [talendJobLog finally ] stop
				 */
			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("talendJobLog_SUBPROCESS_STATE", 1);
	}

	public String resuming_logs_dir_path = null;
	public String resuming_checkpoint_path = null;
	public String parent_part_launcher = null;
	private String resumeEntryMethodName = null;
	private boolean globalResumeTicket = false;

	public boolean watch = false;
	// portStats is null, it means don't execute the statistics
	public Integer portStats = null;
	public int portTraces = 4334;
	public String clientHost;
	public String defaultClientHost = "localhost";
	public String contextStr = "Default";
	public boolean isDefaultContext = true;
	public String pid = "0";
	public String rootPid = null;
	public String fatherPid = null;
	public String fatherNode = null;
	public long startTime = 0;
	public boolean isChildJob = false;
	public String log4jLevel = "";

	private boolean enableLogStash;

	private boolean execStat = true;

	private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
		protected java.util.Map<String, String> initialValue() {
			java.util.Map<String, String> threadRunResultMap = new java.util.HashMap<String, String>();
			threadRunResultMap.put("errorCode", null);
			threadRunResultMap.put("status", "");
			return threadRunResultMap;
		};
	};

	protected PropertiesWithType context_param = new PropertiesWithType();
	public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

	public String status = "";

	public static void main(String[] args) {
		final MVC_Crash_Stage MVC_Crash_StageClass = new MVC_Crash_Stage();

		int exitCode = MVC_Crash_StageClass.runJobInTOS(args);
		if (exitCode == 0) {
			log.info("TalendJob: 'MVC_Crash_Stage' - Done.");
		}

		System.exit(exitCode);
	}

	public String[][] runJob(String[] args) {

		int exitCode = runJobInTOS(args);
		String[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };

		return bufferValue;
	}

	public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;

		return hastBufferOutput;
	}

	public int runJobInTOS(String[] args) {
		// reset status
		status = "";

		String lastStr = "";
		for (String arg : args) {
			if (arg.equalsIgnoreCase("--context_param")) {
				lastStr = arg;
			} else if (lastStr.equals("")) {
				evalParam(arg);
			} else {
				evalParam(lastStr + " " + arg);
				lastStr = "";
			}
		}
		enableLogStash = "true".equalsIgnoreCase(System.getProperty("audit.enabled"));

		if (!"".equals(log4jLevel)) {

			if ("trace".equalsIgnoreCase(log4jLevel)) {
				org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(),
						org.apache.logging.log4j.Level.TRACE);
			} else if ("debug".equalsIgnoreCase(log4jLevel)) {
				org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(),
						org.apache.logging.log4j.Level.DEBUG);
			} else if ("info".equalsIgnoreCase(log4jLevel)) {
				org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(),
						org.apache.logging.log4j.Level.INFO);
			} else if ("warn".equalsIgnoreCase(log4jLevel)) {
				org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(),
						org.apache.logging.log4j.Level.WARN);
			} else if ("error".equalsIgnoreCase(log4jLevel)) {
				org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(),
						org.apache.logging.log4j.Level.ERROR);
			} else if ("fatal".equalsIgnoreCase(log4jLevel)) {
				org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(),
						org.apache.logging.log4j.Level.FATAL);
			} else if ("off".equalsIgnoreCase(log4jLevel)) {
				org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(),
						org.apache.logging.log4j.Level.OFF);
			}
			org.apache.logging.log4j.core.config.Configurator
					.setLevel(org.apache.logging.log4j.LogManager.getRootLogger().getName(), log.getLevel());

		}
		log.info("TalendJob: 'MVC_Crash_Stage' - Start.");

		if (enableLogStash) {
			java.util.Properties properties_talendJobLog = new java.util.Properties();
			properties_talendJobLog.setProperty("root.logger", "audit");
			properties_talendJobLog.setProperty("encoding", "UTF-8");
			properties_talendJobLog.setProperty("application.name", "Talend Studio");
			properties_talendJobLog.setProperty("service.name", "Talend Studio Job");
			properties_talendJobLog.setProperty("instance.name", "Talend Studio Job Instance");
			properties_talendJobLog.setProperty("propagate.appender.exceptions", "none");
			properties_talendJobLog.setProperty("log.appender", "file");
			properties_talendJobLog.setProperty("appender.file.path", "audit.json");
			properties_talendJobLog.setProperty("appender.file.maxsize", "52428800");
			properties_talendJobLog.setProperty("appender.file.maxbackup", "20");
			properties_talendJobLog.setProperty("host", "false");

			System.getProperties().stringPropertyNames().stream().filter(it -> it.startsWith("audit.logger."))
					.forEach(key -> properties_talendJobLog.setProperty(key.substring("audit.logger.".length()),
							System.getProperty(key)));

			org.apache.logging.log4j.core.config.Configurator
					.setLevel(properties_talendJobLog.getProperty("root.logger"), org.apache.logging.log4j.Level.DEBUG);

			auditLogger_talendJobLog = org.talend.job.audit.JobEventAuditLoggerFactory
					.createJobAuditLogger(properties_talendJobLog);
		}

		if (clientHost == null) {
			clientHost = defaultClientHost;
		}

		if (pid == null || "0".equals(pid)) {
			pid = TalendString.getAsciiRandomString(6);
		}

		if (rootPid == null) {
			rootPid = pid;
		}
		if (fatherPid == null) {
			fatherPid = pid;
		} else {
			isChildJob = true;
		}

		if (portStats != null) {
			// portStats = -1; //for testing
			if (portStats < 0 || portStats > 65535) {
				// issue:10869, the portStats is invalid, so this client socket can't open
				System.err.println("The statistics socket port " + portStats + " is invalid.");
				execStat = false;
			}
		} else {
			execStat = false;
		}
		boolean inOSGi = routines.system.BundleUtils.inOSGi();

		if (inOSGi) {
			java.util.Dictionary<String, Object> jobProperties = routines.system.BundleUtils.getJobProperties(jobName);

			if (jobProperties != null && jobProperties.get("context") != null) {
				contextStr = (String) jobProperties.get("context");
			}
		}

		try {
			// call job/subjob with an existing context, like: --context=production. if
			// without this parameter, there will use the default context instead.
			java.io.InputStream inContext = MVC_Crash_Stage.class.getClassLoader()
					.getResourceAsStream("mvc_talend/mvc_crash_stage_0_1/contexts/" + contextStr + ".properties");
			if (inContext == null) {
				inContext = MVC_Crash_Stage.class.getClassLoader()
						.getResourceAsStream("config/contexts/" + contextStr + ".properties");
			}
			if (inContext != null) {
				try {
					// defaultProps is in order to keep the original context value
					if (context != null && context.isEmpty()) {
						defaultProps.load(inContext);
						context = new ContextProperties(defaultProps);
					}
				} finally {
					inContext.close();
				}
			} else if (!isDefaultContext) {
				// print info and job continue to run, for case: context_param is not empty.
				System.err.println("Could not find the context " + contextStr);
			}

			if (!context_param.isEmpty()) {
				context.putAll(context_param);
				// set types for params from parentJobs
				for (Object key : context_param.keySet()) {
					String context_key = key.toString();
					String context_type = context_param.getContextType(context_key);
					context.setContextType(context_key, context_type);

				}
			}
			class ContextProcessing {
				private void processContext_0() {
				}

				public void processAllContext() {
					processContext_0();
				}
			}

			new ContextProcessing().processAllContext();
		} catch (java.io.IOException ie) {
			System.err.println("Could not load context " + contextStr);
			ie.printStackTrace();
		}

		// get context value from parent directly
		if (parentContextMap != null && !parentContextMap.isEmpty()) {
		}

		// Resume: init the resumeUtil
		resumeEntryMethodName = ResumeUtil.getResumeEntryMethodName(resuming_checkpoint_path);
		resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
		resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName, jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
		// Resume: jobStart
		resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "",
				"", "", "", "", resumeUtil.convertToJsonText(context, parametersToEncrypt));

		if (execStat) {
			try {
				runStat.openSocket(!isChildJob);
				runStat.setAllPID(rootPid, fatherPid, pid, jobName);
				runStat.startThreadStat(clientHost, portStats);
				runStat.updateStatOnJob(RunStat.JOBSTART, fatherNode);
			} catch (java.io.IOException ioException) {
				ioException.printStackTrace();
			}
		}

		java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
		globalMap.put("concurrentHashMap", concurrentHashMap);

		long startUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
		long endUsedMemory = 0;
		long end = 0;

		startTime = System.currentTimeMillis();

		this.globalResumeTicket = true;// to run tPreJob

		if (enableLogStash) {
			talendJobLog.addJobStartMessage();
			try {
				talendJobLogProcess(globalMap);
			} catch (java.lang.Exception e) {
				e.printStackTrace();
			}
		}

		this.globalResumeTicket = false;// to run others jobs

		try {
			errorCode = null;
			tBigQueryInput_1Process(globalMap);
			if (!"failure".equals(status)) {
				status = "end";
			}
		} catch (TalendException e_tBigQueryInput_1) {
			globalMap.put("tBigQueryInput_1_SUBPROCESS_STATE", -1);

			e_tBigQueryInput_1.printStackTrace();

		}

		this.globalResumeTicket = true;// to run tPostJob

		end = System.currentTimeMillis();

		if (watch) {
			System.out.println((end - startTime) + " milliseconds");
		}

		endUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
		if (false) {
			System.out.println(
					(endUsedMemory - startUsedMemory) + " bytes memory increase when running : MVC_Crash_Stage");
		}
		if (enableLogStash) {
			talendJobLog.addJobEndMessage(startTime, end, status);
			try {
				talendJobLogProcess(globalMap);
			} catch (java.lang.Exception e) {
				e.printStackTrace();
			}
		}

		if (execStat) {
			runStat.updateStatOnJob(RunStat.JOBEND, fatherNode);
			runStat.stopThreadStat();
		}
		int returnCode = 0;

		if (errorCode == null) {
			returnCode = status != null && status.equals("failure") ? 1 : 0;
		} else {
			returnCode = errorCode.intValue();
		}
		resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "",
				"" + returnCode, "", "", "");

		return returnCode;

	}

	// only for OSGi env
	public void destroy() {

	}

	private java.util.Map<String, Object> getSharedConnections4REST() {
		java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();

		return connections;
	}

	private void evalParam(String arg) {
		if (arg.startsWith("--resuming_logs_dir_path")) {
			resuming_logs_dir_path = arg.substring(25);
		} else if (arg.startsWith("--resuming_checkpoint_path")) {
			resuming_checkpoint_path = arg.substring(27);
		} else if (arg.startsWith("--parent_part_launcher")) {
			parent_part_launcher = arg.substring(23);
		} else if (arg.startsWith("--watch")) {
			watch = true;
		} else if (arg.startsWith("--stat_port=")) {
			String portStatsStr = arg.substring(12);
			if (portStatsStr != null && !portStatsStr.equals("null")) {
				portStats = Integer.parseInt(portStatsStr);
			}
		} else if (arg.startsWith("--trace_port=")) {
			portTraces = Integer.parseInt(arg.substring(13));
		} else if (arg.startsWith("--client_host=")) {
			clientHost = arg.substring(14);
		} else if (arg.startsWith("--context=")) {
			contextStr = arg.substring(10);
			isDefaultContext = false;
		} else if (arg.startsWith("--father_pid=")) {
			fatherPid = arg.substring(13);
		} else if (arg.startsWith("--root_pid=")) {
			rootPid = arg.substring(11);
		} else if (arg.startsWith("--father_node=")) {
			fatherNode = arg.substring(14);
		} else if (arg.startsWith("--pid=")) {
			pid = arg.substring(6);
		} else if (arg.startsWith("--context_type")) {
			String keyValue = arg.substring(15);
			int index = -1;
			if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
				if (fatherPid == null) {
					context_param.setContextType(keyValue.substring(0, index),
							replaceEscapeChars(keyValue.substring(index + 1)));
				} else { // the subjob won't escape the especial chars
					context_param.setContextType(keyValue.substring(0, index), keyValue.substring(index + 1));
				}

			}

		} else if (arg.startsWith("--context_param")) {
			String keyValue = arg.substring(16);
			int index = -1;
			if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
				if (fatherPid == null) {
					context_param.put(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
				} else { // the subjob won't escape the especial chars
					context_param.put(keyValue.substring(0, index), keyValue.substring(index + 1));
				}
			}
		} else if (arg.startsWith("--log4jLevel=")) {
			log4jLevel = arg.substring(13);
		} else if (arg.startsWith("--audit.enabled") && arg.contains("=")) {// for trunjob call
			final int equal = arg.indexOf('=');
			final String key = arg.substring("--".length(), equal);
			System.setProperty(key, arg.substring(equal + 1));
		}
	}

	private static final String NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY = "<TALEND_NULL>";

	private final String[][] escapeChars = { { "\\\\", "\\" }, { "\\n", "\n" }, { "\\'", "\'" }, { "\\r", "\r" },
			{ "\\f", "\f" }, { "\\b", "\b" }, { "\\t", "\t" } };

	private String replaceEscapeChars(String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0], currIndex);
				if (index >= 0) {

					result.append(keyValue.substring(currIndex, index + strArray[0].length()).replace(strArray[0],
							strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left into the
			// result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
	}

	public Integer getErrorCode() {
		return errorCode;
	}

	public String getStatus() {
		return status;
	}

	ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 * 166675 characters generated by Talend Real-time Big Data Platform on the
 * April 20, 2023 at 9:32:31 PM EDT
 ************************************************************************************************/