
package mvc_talend.loading_dimension_0_1;

import routines.Numeric;
import routines.DataOperation;
import routines.TalendDataGenerator;
import routines.TalendStringUtil;
import routines.TalendString;
import routines.StringHandling;
import routines.Relational;
import routines.TalendDate;
import routines.Mathematical;
import routines.SQLike;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;

@SuppressWarnings("unused")

/**
 * Job: Loading_Dimension Purpose: <br>
 * Description: <br>
 * 
 * @author chokshi.ra@northeastern.edu
 * @version 8.0.1.20211109_1610
 * @status
 */
public class Loading_Dimension implements TalendJob {
	static {
		System.setProperty("TalendJob.log", "Loading_Dimension.log");
	}

	private static org.apache.logging.log4j.Logger log = org.apache.logging.log4j.LogManager
			.getLogger(Loading_Dimension.class);

	protected static void logIgnoredError(String message, Throwable cause) {
		log.error(message, cause);

	}

	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}

	private final static String defaultCharset = java.nio.charset.Charset.defaultCharset().name();

	private final static String utf8Charset = "UTF-8";

	// contains type for every context property
	public class PropertiesWithType extends java.util.Properties {
		private static final long serialVersionUID = 1L;
		private java.util.Map<String, String> propertyTypes = new java.util.HashMap<>();

		public PropertiesWithType(java.util.Properties properties) {
			super(properties);
		}

		public PropertiesWithType() {
			super();
		}

		public void setContextType(String key, String type) {
			propertyTypes.put(key, type);
		}

		public String getContextType(String key) {
			return propertyTypes.get(key);
		}
	}

	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();

	// create application properties with default
	public class ContextProperties extends PropertiesWithType {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties) {
			super(properties);
		}

		public ContextProperties() {
			super();
		}

		public void synchronizeContext() {

		}

		// if the stored or passed value is "<TALEND_NULL>" string, it mean null
		public String getStringValue(String key) {
			String origin_value = this.getProperty(key);
			if (NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY.equals(origin_value)) {
				return null;
			}
			return origin_value;
		}

	}

	protected ContextProperties context = new ContextProperties(); // will be instanciated by MS.

	public ContextProperties getContext() {
		return this.context;
	}

	private final String jobVersion = "0.1";
	private final String jobName = "Loading_Dimension";
	private final String projectName = "MVC_TALEND";
	public Integer errorCode = null;
	private String currentComponent = "";

	private final java.util.Map<String, Object> globalMap = new java.util.HashMap<String, Object>();
	private final static java.util.Map<String, Object> junitGlobalMap = new java.util.HashMap<String, Object>();

	private final java.util.Map<String, Long> start_Hash = new java.util.HashMap<String, Long>();
	private final java.util.Map<String, Long> end_Hash = new java.util.HashMap<String, Long>();
	private final java.util.Map<String, Boolean> ok_Hash = new java.util.HashMap<String, Boolean>();
	public final java.util.List<String[]> globalBuffer = new java.util.ArrayList<String[]>();

	private final JobStructureCatcherUtils talendJobLog = new JobStructureCatcherUtils(jobName,
			"_b7WfoN-yEe2Yj57cYiJ99Q", "0.1");
	private org.talend.job.audit.JobAuditLogger auditLogger_talendJobLog = null;

	private RunStat runStat = new RunStat(talendJobLog, System.getProperty("audit.interval"));

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";

	private final static String KEY_DB_DATASOURCES_RAW = "KEY_DB_DATASOURCES_RAW";

	public void setDataSources(java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources.entrySet()) {
			talendDataSources.put(dataSourceEntry.getKey(),
					new routines.system.TalendDataSource(dataSourceEntry.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}

	public void setDataSourceReferences(List serviceReferences) throws Exception {

		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		java.util.Map<String, javax.sql.DataSource> dataSources = new java.util.HashMap<String, javax.sql.DataSource>();

		for (java.util.Map.Entry<String, javax.sql.DataSource> entry : BundleUtils
				.getServices(serviceReferences, javax.sql.DataSource.class).entrySet()) {
			dataSources.put(entry.getKey(), entry.getValue());
			talendDataSources.put(entry.getKey(), new routines.system.TalendDataSource(entry.getValue()));
		}

		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}

	private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
	private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(new java.io.BufferedOutputStream(baos));

	public String getExceptionStackTrace() {
		if ("failure".equals(this.getStatus())) {
			errorMessagePS.flush();
			return baos.toString();
		}
		return null;
	}

	private Exception exception;

	public Exception getException() {
		if ("failure".equals(this.getStatus())) {
			return this.exception;
		}
		return null;
	}

	private class TalendException extends Exception {

		private static final long serialVersionUID = 1L;

		private java.util.Map<String, Object> globalMap = null;
		private Exception e = null;
		private String currentComponent = null;
		private String virtualComponentName = null;

		public void setVirtualComponentName(String virtualComponentName) {
			this.virtualComponentName = virtualComponentName;
		}

		private TalendException(Exception e, String errorComponent, final java.util.Map<String, Object> globalMap) {
			this.currentComponent = errorComponent;
			this.globalMap = globalMap;
			this.e = e;
		}

		public Exception getException() {
			return this.e;
		}

		public String getCurrentComponent() {
			return this.currentComponent;
		}

		public String getExceptionCauseMessage(Exception e) {
			Throwable cause = e;
			String message = null;
			int i = 10;
			while (null != cause && 0 < i--) {
				message = cause.getMessage();
				if (null == message) {
					cause = cause.getCause();
				} else {
					break;
				}
			}
			if (null == message) {
				message = e.getClass().getName();
			}
			return message;
		}

		@Override
		public void printStackTrace() {
			if (!(e instanceof TalendException || e instanceof TDieException)) {
				if (virtualComponentName != null && currentComponent.indexOf(virtualComponentName + "_") == 0) {
					globalMap.put(virtualComponentName + "_ERROR_MESSAGE", getExceptionCauseMessage(e));
				}
				globalMap.put(currentComponent + "_ERROR_MESSAGE", getExceptionCauseMessage(e));
				System.err.println("Exception in component " + currentComponent + " (" + jobName + ")");
			}
			if (!(e instanceof TDieException)) {
				if (e instanceof TalendException) {
					e.printStackTrace();
				} else {
					e.printStackTrace();
					e.printStackTrace(errorMessagePS);
					Loading_Dimension.this.exception = e;
				}
			}
			if (!(e instanceof TalendException)) {
				try {
					for (java.lang.reflect.Method m : this.getClass().getEnclosingClass().getMethods()) {
						if (m.getName().compareTo(currentComponent + "_error") == 0) {
							m.invoke(Loading_Dimension.this, new Object[] { e, currentComponent, globalMap });
							break;
						}
					}

					if (!(e instanceof TDieException)) {
					}
				} catch (Exception e) {
					this.e.printStackTrace();
				}
			}
		}
	}

	public void tDBInput_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMap_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tUniqRow_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMap_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBOutput_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tUniqRow_2_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMap_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBOutput_2_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tUniqRow_3_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMap_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBOutput_3_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tUniqRow_5_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMap_6_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBOutput_4_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tUniqRow_7_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMap_7_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBOutput_5_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tUniqRow_4_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMap_9_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBOutput_6_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tUniqRow_8_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMap_10_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBOutput_7_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tUniqRow_9_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMap_11_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBOutput_8_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tUniqRow_10_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMap_12_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBOutput_9_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tUniqRow_11_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMap_13_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBOutput_10_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tUniqRow_12_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMap_14_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBOutput_11_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tUniqRow_13_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMap_15_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBOutput_12_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void talendJobLog_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		talendJobLog_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBInput_1_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void talendJobLog_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public static class Person_Sex1Struct implements routines.system.IPersistableRow<Person_Sex1Struct> {
		final static byte[] commonByteArrayLock_MVC_TALEND_Loading_Dimension = new byte[0];
		static byte[] commonByteArray_MVC_TALEND_Loading_Dimension = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public Integer PERSON_SEX_SK;

		public Integer getPERSON_SEX_SK() {
			return this.PERSON_SEX_SK;
		}

		public String PERSON_SEX;

		public String getPERSON_SEX() {
			return this.PERSON_SEX;
		}

		public String DI_PID;

		public String getDI_PID() {
			return this.DI_PID;
		}

		public java.util.Date DI_Create_Date;

		public java.util.Date getDI_Create_Date() {
			return this.DI_Create_Date;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + ((this.PERSON_SEX_SK == null) ? 0 : this.PERSON_SEX_SK.hashCode());

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final Person_Sex1Struct other = (Person_Sex1Struct) obj;

			if (this.PERSON_SEX_SK == null) {
				if (other.PERSON_SEX_SK != null)
					return false;

			} else if (!this.PERSON_SEX_SK.equals(other.PERSON_SEX_SK))

				return false;

			return true;
		}

		public void copyDataTo(Person_Sex1Struct other) {

			other.PERSON_SEX_SK = this.PERSON_SEX_SK;
			other.PERSON_SEX = this.PERSON_SEX;
			other.DI_PID = this.DI_PID;
			other.DI_Create_Date = this.DI_Create_Date;

		}

		public void copyKeysDataTo(Person_Sex1Struct other) {

			other.PERSON_SEX_SK = this.PERSON_SEX_SK;

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension) {

				try {

					int length = 0;

					this.PERSON_SEX_SK = readInteger(dis);

					this.PERSON_SEX = readString(dis);

					this.DI_PID = readString(dis);

					this.DI_Create_Date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension) {

				try {

					int length = 0;

					this.PERSON_SEX_SK = readInteger(dis);

					this.PERSON_SEX = readString(dis);

					this.DI_PID = readString(dis);

					this.DI_Create_Date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.PERSON_SEX_SK, dos);

				// String

				writeString(this.PERSON_SEX, dos);

				// String

				writeString(this.DI_PID, dos);

				// java.util.Date

				writeDate(this.DI_Create_Date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.PERSON_SEX_SK, dos);

				// String

				writeString(this.PERSON_SEX, dos);

				// String

				writeString(this.DI_PID, dos);

				// java.util.Date

				writeDate(this.DI_Create_Date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("PERSON_SEX_SK=" + String.valueOf(PERSON_SEX_SK));
			sb.append(",PERSON_SEX=" + PERSON_SEX);
			sb.append(",DI_PID=" + DI_PID);
			sb.append(",DI_Create_Date=" + String.valueOf(DI_Create_Date));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (PERSON_SEX_SK == null) {
				sb.append("<null>");
			} else {
				sb.append(PERSON_SEX_SK);
			}

			sb.append("|");

			if (PERSON_SEX == null) {
				sb.append("<null>");
			} else {
				sb.append(PERSON_SEX);
			}

			sb.append("|");

			if (DI_PID == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_PID);
			}

			sb.append("|");

			if (DI_Create_Date == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_Create_Date);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(Person_Sex1Struct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.PERSON_SEX_SK, other.PERSON_SEX_SK);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row13Struct implements routines.system.IPersistableRow<row13Struct> {
		final static byte[] commonByteArrayLock_MVC_TALEND_Loading_Dimension = new byte[0];
		static byte[] commonByteArray_MVC_TALEND_Loading_Dimension = new byte[0];

		public String PERSON_SEX;

		public String getPERSON_SEX() {
			return this.PERSON_SEX;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension) {

				try {

					int length = 0;

					this.PERSON_SEX = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension) {

				try {

					int length = 0;

					this.PERSON_SEX = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.PERSON_SEX, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.PERSON_SEX, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("PERSON_SEX=" + PERSON_SEX);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (PERSON_SEX == null) {
				sb.append("<null>");
			} else {
				sb.append(PERSON_SEX);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row13Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class Ped_Role_LoadStruct implements routines.system.IPersistableRow<Ped_Role_LoadStruct> {
		final static byte[] commonByteArrayLock_MVC_TALEND_Loading_Dimension = new byte[0];
		static byte[] commonByteArray_MVC_TALEND_Loading_Dimension = new byte[0];

		public Integer PED_ROLE_SK;

		public Integer getPED_ROLE_SK() {
			return this.PED_ROLE_SK;
		}

		public String PED_ROLE;

		public String getPED_ROLE() {
			return this.PED_ROLE;
		}

		public String DI_PID;

		public String getDI_PID() {
			return this.DI_PID;
		}

		public java.util.Date DI_Create_Date;

		public java.util.Date getDI_Create_Date() {
			return this.DI_Create_Date;
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension) {

				try {

					int length = 0;

					this.PED_ROLE_SK = readInteger(dis);

					this.PED_ROLE = readString(dis);

					this.DI_PID = readString(dis);

					this.DI_Create_Date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension) {

				try {

					int length = 0;

					this.PED_ROLE_SK = readInteger(dis);

					this.PED_ROLE = readString(dis);

					this.DI_PID = readString(dis);

					this.DI_Create_Date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.PED_ROLE_SK, dos);

				// String

				writeString(this.PED_ROLE, dos);

				// String

				writeString(this.DI_PID, dos);

				// java.util.Date

				writeDate(this.DI_Create_Date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.PED_ROLE_SK, dos);

				// String

				writeString(this.PED_ROLE, dos);

				// String

				writeString(this.DI_PID, dos);

				// java.util.Date

				writeDate(this.DI_Create_Date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("PED_ROLE_SK=" + String.valueOf(PED_ROLE_SK));
			sb.append(",PED_ROLE=" + PED_ROLE);
			sb.append(",DI_PID=" + DI_PID);
			sb.append(",DI_Create_Date=" + String.valueOf(DI_Create_Date));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (PED_ROLE_SK == null) {
				sb.append("<null>");
			} else {
				sb.append(PED_ROLE_SK);
			}

			sb.append("|");

			if (PED_ROLE == null) {
				sb.append("<null>");
			} else {
				sb.append(PED_ROLE);
			}

			sb.append("|");

			if (DI_PID == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_PID);
			}

			sb.append("|");

			if (DI_Create_Date == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_Create_Date);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(Ped_Role_LoadStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row12Struct implements routines.system.IPersistableRow<row12Struct> {
		final static byte[] commonByteArrayLock_MVC_TALEND_Loading_Dimension = new byte[0];
		static byte[] commonByteArray_MVC_TALEND_Loading_Dimension = new byte[0];

		public String PED_ROLE;

		public String getPED_ROLE() {
			return this.PED_ROLE;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension) {

				try {

					int length = 0;

					this.PED_ROLE = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension) {

				try {

					int length = 0;

					this.PED_ROLE = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.PED_ROLE, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.PED_ROLE, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("PED_ROLE=" + PED_ROLE);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (PED_ROLE == null) {
				sb.append("<null>");
			} else {
				sb.append(PED_ROLE);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row12Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class Complain_LoadStruct implements routines.system.IPersistableRow<Complain_LoadStruct> {
		final static byte[] commonByteArrayLock_MVC_TALEND_Loading_Dimension = new byte[0];
		static byte[] commonByteArray_MVC_TALEND_Loading_Dimension = new byte[0];

		public String COMPLAINT;

		public String getCOMPLAINT() {
			return this.COMPLAINT;
		}

		public Integer COMPLAINT_SK;

		public Integer getCOMPLAINT_SK() {
			return this.COMPLAINT_SK;
		}

		public String DI_PID;

		public String getDI_PID() {
			return this.DI_PID;
		}

		public java.util.Date DI_Create_Date;

		public java.util.Date getDI_Create_Date() {
			return this.DI_Create_Date;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension) {

				try {

					int length = 0;

					this.COMPLAINT = readString(dis);

					this.COMPLAINT_SK = readInteger(dis);

					this.DI_PID = readString(dis);

					this.DI_Create_Date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension) {

				try {

					int length = 0;

					this.COMPLAINT = readString(dis);

					this.COMPLAINT_SK = readInteger(dis);

					this.DI_PID = readString(dis);

					this.DI_Create_Date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.COMPLAINT, dos);

				// Integer

				writeInteger(this.COMPLAINT_SK, dos);

				// String

				writeString(this.DI_PID, dos);

				// java.util.Date

				writeDate(this.DI_Create_Date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.COMPLAINT, dos);

				// Integer

				writeInteger(this.COMPLAINT_SK, dos);

				// String

				writeString(this.DI_PID, dos);

				// java.util.Date

				writeDate(this.DI_Create_Date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("COMPLAINT=" + COMPLAINT);
			sb.append(",COMPLAINT_SK=" + String.valueOf(COMPLAINT_SK));
			sb.append(",DI_PID=" + DI_PID);
			sb.append(",DI_Create_Date=" + String.valueOf(DI_Create_Date));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (COMPLAINT == null) {
				sb.append("<null>");
			} else {
				sb.append(COMPLAINT);
			}

			sb.append("|");

			if (COMPLAINT_SK == null) {
				sb.append("<null>");
			} else {
				sb.append(COMPLAINT_SK);
			}

			sb.append("|");

			if (DI_PID == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_PID);
			}

			sb.append("|");

			if (DI_Create_Date == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_Create_Date);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(Complain_LoadStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row11Struct implements routines.system.IPersistableRow<row11Struct> {
		final static byte[] commonByteArrayLock_MVC_TALEND_Loading_Dimension = new byte[0];
		static byte[] commonByteArray_MVC_TALEND_Loading_Dimension = new byte[0];

		public String COMPLAINT;

		public String getCOMPLAINT() {
			return this.COMPLAINT;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension) {

				try {

					int length = 0;

					this.COMPLAINT = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension) {

				try {

					int length = 0;

					this.COMPLAINT = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.COMPLAINT, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.COMPLAINT, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("COMPLAINT=" + COMPLAINT);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (COMPLAINT == null) {
				sb.append("<null>");
			} else {
				sb.append(COMPLAINT);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row11Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class Ped_ActionStruct implements routines.system.IPersistableRow<Ped_ActionStruct> {
		final static byte[] commonByteArrayLock_MVC_TALEND_Loading_Dimension = new byte[0];
		static byte[] commonByteArray_MVC_TALEND_Loading_Dimension = new byte[0];

		public String PED_ACTION;

		public String getPED_ACTION() {
			return this.PED_ACTION;
		}

		public Integer PED_ACTION_SK;

		public Integer getPED_ACTION_SK() {
			return this.PED_ACTION_SK;
		}

		public String DI_PID;

		public String getDI_PID() {
			return this.DI_PID;
		}

		public java.util.Date DI_Create_Date;

		public java.util.Date getDI_Create_Date() {
			return this.DI_Create_Date;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension) {

				try {

					int length = 0;

					this.PED_ACTION = readString(dis);

					this.PED_ACTION_SK = readInteger(dis);

					this.DI_PID = readString(dis);

					this.DI_Create_Date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension) {

				try {

					int length = 0;

					this.PED_ACTION = readString(dis);

					this.PED_ACTION_SK = readInteger(dis);

					this.DI_PID = readString(dis);

					this.DI_Create_Date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.PED_ACTION, dos);

				// Integer

				writeInteger(this.PED_ACTION_SK, dos);

				// String

				writeString(this.DI_PID, dos);

				// java.util.Date

				writeDate(this.DI_Create_Date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.PED_ACTION, dos);

				// Integer

				writeInteger(this.PED_ACTION_SK, dos);

				// String

				writeString(this.DI_PID, dos);

				// java.util.Date

				writeDate(this.DI_Create_Date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("PED_ACTION=" + PED_ACTION);
			sb.append(",PED_ACTION_SK=" + String.valueOf(PED_ACTION_SK));
			sb.append(",DI_PID=" + DI_PID);
			sb.append(",DI_Create_Date=" + String.valueOf(DI_Create_Date));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (PED_ACTION == null) {
				sb.append("<null>");
			} else {
				sb.append(PED_ACTION);
			}

			sb.append("|");

			if (PED_ACTION_SK == null) {
				sb.append("<null>");
			} else {
				sb.append(PED_ACTION_SK);
			}

			sb.append("|");

			if (DI_PID == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_PID);
			}

			sb.append("|");

			if (DI_Create_Date == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_Create_Date);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(Ped_ActionStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row10Struct implements routines.system.IPersistableRow<row10Struct> {
		final static byte[] commonByteArrayLock_MVC_TALEND_Loading_Dimension = new byte[0];
		static byte[] commonByteArray_MVC_TALEND_Loading_Dimension = new byte[0];

		public String PED_ACTION;

		public String getPED_ACTION() {
			return this.PED_ACTION;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension) {

				try {

					int length = 0;

					this.PED_ACTION = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension) {

				try {

					int length = 0;

					this.PED_ACTION = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.PED_ACTION, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.PED_ACTION, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("PED_ACTION=" + PED_ACTION);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (PED_ACTION == null) {
				sb.append("<null>");
			} else {
				sb.append(PED_ACTION);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row10Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class Ped_Location_LoadStruct implements routines.system.IPersistableRow<Ped_Location_LoadStruct> {
		final static byte[] commonByteArrayLock_MVC_TALEND_Loading_Dimension = new byte[0];
		static byte[] commonByteArray_MVC_TALEND_Loading_Dimension = new byte[0];

		public String PED_LOCATION_SK;

		public String getPED_LOCATION_SK() {
			return this.PED_LOCATION_SK;
		}

		public String PED_LOCATION;

		public String getPED_LOCATION() {
			return this.PED_LOCATION;
		}

		public String DI_PID;

		public String getDI_PID() {
			return this.DI_PID;
		}

		public java.util.Date DI_Create_Date;

		public java.util.Date getDI_Create_Date() {
			return this.DI_Create_Date;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension) {

				try {

					int length = 0;

					this.PED_LOCATION_SK = readString(dis);

					this.PED_LOCATION = readString(dis);

					this.DI_PID = readString(dis);

					this.DI_Create_Date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension) {

				try {

					int length = 0;

					this.PED_LOCATION_SK = readString(dis);

					this.PED_LOCATION = readString(dis);

					this.DI_PID = readString(dis);

					this.DI_Create_Date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.PED_LOCATION_SK, dos);

				// String

				writeString(this.PED_LOCATION, dos);

				// String

				writeString(this.DI_PID, dos);

				// java.util.Date

				writeDate(this.DI_Create_Date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.PED_LOCATION_SK, dos);

				// String

				writeString(this.PED_LOCATION, dos);

				// String

				writeString(this.DI_PID, dos);

				// java.util.Date

				writeDate(this.DI_Create_Date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("PED_LOCATION_SK=" + PED_LOCATION_SK);
			sb.append(",PED_LOCATION=" + PED_LOCATION);
			sb.append(",DI_PID=" + DI_PID);
			sb.append(",DI_Create_Date=" + String.valueOf(DI_Create_Date));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (PED_LOCATION_SK == null) {
				sb.append("<null>");
			} else {
				sb.append(PED_LOCATION_SK);
			}

			sb.append("|");

			if (PED_LOCATION == null) {
				sb.append("<null>");
			} else {
				sb.append(PED_LOCATION);
			}

			sb.append("|");

			if (DI_PID == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_PID);
			}

			sb.append("|");

			if (DI_Create_Date == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_Create_Date);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(Ped_Location_LoadStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row9Struct implements routines.system.IPersistableRow<row9Struct> {
		final static byte[] commonByteArrayLock_MVC_TALEND_Loading_Dimension = new byte[0];
		static byte[] commonByteArray_MVC_TALEND_Loading_Dimension = new byte[0];

		public String PED_LOCATION;

		public String getPED_LOCATION() {
			return this.PED_LOCATION;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension) {

				try {

					int length = 0;

					this.PED_LOCATION = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension) {

				try {

					int length = 0;

					this.PED_LOCATION = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.PED_LOCATION, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.PED_LOCATION, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("PED_LOCATION=" + PED_LOCATION);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (PED_LOCATION == null) {
				sb.append("<null>");
			} else {
				sb.append(PED_LOCATION);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row9Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class Safety_Equipment1Struct implements routines.system.IPersistableRow<Safety_Equipment1Struct> {
		final static byte[] commonByteArrayLock_MVC_TALEND_Loading_Dimension = new byte[0];
		static byte[] commonByteArray_MVC_TALEND_Loading_Dimension = new byte[0];

		public String SAFETY_EQUIPMENT;

		public String getSAFETY_EQUIPMENT() {
			return this.SAFETY_EQUIPMENT;
		}

		public String SAFETY_EQUIPMENT_SK;

		public String getSAFETY_EQUIPMENT_SK() {
			return this.SAFETY_EQUIPMENT_SK;
		}

		public String DI_PID;

		public String getDI_PID() {
			return this.DI_PID;
		}

		public java.util.Date DI_Create_Date;

		public java.util.Date getDI_Create_Date() {
			return this.DI_Create_Date;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension) {

				try {

					int length = 0;

					this.SAFETY_EQUIPMENT = readString(dis);

					this.SAFETY_EQUIPMENT_SK = readString(dis);

					this.DI_PID = readString(dis);

					this.DI_Create_Date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension) {

				try {

					int length = 0;

					this.SAFETY_EQUIPMENT = readString(dis);

					this.SAFETY_EQUIPMENT_SK = readString(dis);

					this.DI_PID = readString(dis);

					this.DI_Create_Date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.SAFETY_EQUIPMENT, dos);

				// String

				writeString(this.SAFETY_EQUIPMENT_SK, dos);

				// String

				writeString(this.DI_PID, dos);

				// java.util.Date

				writeDate(this.DI_Create_Date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.SAFETY_EQUIPMENT, dos);

				// String

				writeString(this.SAFETY_EQUIPMENT_SK, dos);

				// String

				writeString(this.DI_PID, dos);

				// java.util.Date

				writeDate(this.DI_Create_Date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("SAFETY_EQUIPMENT=" + SAFETY_EQUIPMENT);
			sb.append(",SAFETY_EQUIPMENT_SK=" + SAFETY_EQUIPMENT_SK);
			sb.append(",DI_PID=" + DI_PID);
			sb.append(",DI_Create_Date=" + String.valueOf(DI_Create_Date));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (SAFETY_EQUIPMENT == null) {
				sb.append("<null>");
			} else {
				sb.append(SAFETY_EQUIPMENT);
			}

			sb.append("|");

			if (SAFETY_EQUIPMENT_SK == null) {
				sb.append("<null>");
			} else {
				sb.append(SAFETY_EQUIPMENT_SK);
			}

			sb.append("|");

			if (DI_PID == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_PID);
			}

			sb.append("|");

			if (DI_Create_Date == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_Create_Date);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(Safety_Equipment1Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row8Struct implements routines.system.IPersistableRow<row8Struct> {
		final static byte[] commonByteArrayLock_MVC_TALEND_Loading_Dimension = new byte[0];
		static byte[] commonByteArray_MVC_TALEND_Loading_Dimension = new byte[0];

		public String SAFETY_EQUIPMENT;

		public String getSAFETY_EQUIPMENT() {
			return this.SAFETY_EQUIPMENT;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension) {

				try {

					int length = 0;

					this.SAFETY_EQUIPMENT = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension) {

				try {

					int length = 0;

					this.SAFETY_EQUIPMENT = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.SAFETY_EQUIPMENT, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.SAFETY_EQUIPMENT, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("SAFETY_EQUIPMENT=" + SAFETY_EQUIPMENT);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (SAFETY_EQUIPMENT == null) {
				sb.append("<null>");
			} else {
				sb.append(SAFETY_EQUIPMENT);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row8Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class Position_In_Vehicle1Struct
			implements routines.system.IPersistableRow<Position_In_Vehicle1Struct> {
		final static byte[] commonByteArrayLock_MVC_TALEND_Loading_Dimension = new byte[0];
		static byte[] commonByteArray_MVC_TALEND_Loading_Dimension = new byte[0];

		public String POSITION_IN_VEHICLE_SK;

		public String getPOSITION_IN_VEHICLE_SK() {
			return this.POSITION_IN_VEHICLE_SK;
		}

		public String POSITION_IN_VEHICLE;

		public String getPOSITION_IN_VEHICLE() {
			return this.POSITION_IN_VEHICLE;
		}

		public String DI_PID;

		public String getDI_PID() {
			return this.DI_PID;
		}

		public java.util.Date DI_Create_Date;

		public java.util.Date getDI_Create_Date() {
			return this.DI_Create_Date;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension) {

				try {

					int length = 0;

					this.POSITION_IN_VEHICLE_SK = readString(dis);

					this.POSITION_IN_VEHICLE = readString(dis);

					this.DI_PID = readString(dis);

					this.DI_Create_Date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension) {

				try {

					int length = 0;

					this.POSITION_IN_VEHICLE_SK = readString(dis);

					this.POSITION_IN_VEHICLE = readString(dis);

					this.DI_PID = readString(dis);

					this.DI_Create_Date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.POSITION_IN_VEHICLE_SK, dos);

				// String

				writeString(this.POSITION_IN_VEHICLE, dos);

				// String

				writeString(this.DI_PID, dos);

				// java.util.Date

				writeDate(this.DI_Create_Date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.POSITION_IN_VEHICLE_SK, dos);

				// String

				writeString(this.POSITION_IN_VEHICLE, dos);

				// String

				writeString(this.DI_PID, dos);

				// java.util.Date

				writeDate(this.DI_Create_Date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("POSITION_IN_VEHICLE_SK=" + POSITION_IN_VEHICLE_SK);
			sb.append(",POSITION_IN_VEHICLE=" + POSITION_IN_VEHICLE);
			sb.append(",DI_PID=" + DI_PID);
			sb.append(",DI_Create_Date=" + String.valueOf(DI_Create_Date));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (POSITION_IN_VEHICLE_SK == null) {
				sb.append("<null>");
			} else {
				sb.append(POSITION_IN_VEHICLE_SK);
			}

			sb.append("|");

			if (POSITION_IN_VEHICLE == null) {
				sb.append("<null>");
			} else {
				sb.append(POSITION_IN_VEHICLE);
			}

			sb.append("|");

			if (DI_PID == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_PID);
			}

			sb.append("|");

			if (DI_Create_Date == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_Create_Date);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(Position_In_Vehicle1Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row7Struct implements routines.system.IPersistableRow<row7Struct> {
		final static byte[] commonByteArrayLock_MVC_TALEND_Loading_Dimension = new byte[0];
		static byte[] commonByteArray_MVC_TALEND_Loading_Dimension = new byte[0];

		public String POSITION_IN_VEHICLE;

		public String getPOSITION_IN_VEHICLE() {
			return this.POSITION_IN_VEHICLE;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension) {

				try {

					int length = 0;

					this.POSITION_IN_VEHICLE = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension) {

				try {

					int length = 0;

					this.POSITION_IN_VEHICLE = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.POSITION_IN_VEHICLE, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.POSITION_IN_VEHICLE, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("POSITION_IN_VEHICLE=" + POSITION_IN_VEHICLE);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (POSITION_IN_VEHICLE == null) {
				sb.append("<null>");
			} else {
				sb.append(POSITION_IN_VEHICLE);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row7Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class Bodily_loadStruct implements routines.system.IPersistableRow<Bodily_loadStruct> {
		final static byte[] commonByteArrayLock_MVC_TALEND_Loading_Dimension = new byte[0];
		static byte[] commonByteArray_MVC_TALEND_Loading_Dimension = new byte[0];

		public String BODILY_INJURY_SK;

		public String getBODILY_INJURY_SK() {
			return this.BODILY_INJURY_SK;
		}

		public String BODILY_INJURY;

		public String getBODILY_INJURY() {
			return this.BODILY_INJURY;
		}

		public String DI_PID;

		public String getDI_PID() {
			return this.DI_PID;
		}

		public java.util.Date DI_Create_Date;

		public java.util.Date getDI_Create_Date() {
			return this.DI_Create_Date;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension) {

				try {

					int length = 0;

					this.BODILY_INJURY_SK = readString(dis);

					this.BODILY_INJURY = readString(dis);

					this.DI_PID = readString(dis);

					this.DI_Create_Date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension) {

				try {

					int length = 0;

					this.BODILY_INJURY_SK = readString(dis);

					this.BODILY_INJURY = readString(dis);

					this.DI_PID = readString(dis);

					this.DI_Create_Date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.BODILY_INJURY_SK, dos);

				// String

				writeString(this.BODILY_INJURY, dos);

				// String

				writeString(this.DI_PID, dos);

				// java.util.Date

				writeDate(this.DI_Create_Date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.BODILY_INJURY_SK, dos);

				// String

				writeString(this.BODILY_INJURY, dos);

				// String

				writeString(this.DI_PID, dos);

				// java.util.Date

				writeDate(this.DI_Create_Date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("BODILY_INJURY_SK=" + BODILY_INJURY_SK);
			sb.append(",BODILY_INJURY=" + BODILY_INJURY);
			sb.append(",DI_PID=" + DI_PID);
			sb.append(",DI_Create_Date=" + String.valueOf(DI_Create_Date));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (BODILY_INJURY_SK == null) {
				sb.append("<null>");
			} else {
				sb.append(BODILY_INJURY_SK);
			}

			sb.append("|");

			if (BODILY_INJURY == null) {
				sb.append("<null>");
			} else {
				sb.append(BODILY_INJURY);
			}

			sb.append("|");

			if (DI_PID == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_PID);
			}

			sb.append("|");

			if (DI_Create_Date == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_Create_Date);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(Bodily_loadStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row6Struct implements routines.system.IPersistableRow<row6Struct> {
		final static byte[] commonByteArrayLock_MVC_TALEND_Loading_Dimension = new byte[0];
		static byte[] commonByteArray_MVC_TALEND_Loading_Dimension = new byte[0];

		public String BODILY_INJURY;

		public String getBODILY_INJURY() {
			return this.BODILY_INJURY;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension) {

				try {

					int length = 0;

					this.BODILY_INJURY = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension) {

				try {

					int length = 0;

					this.BODILY_INJURY = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.BODILY_INJURY, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.BODILY_INJURY, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("BODILY_INJURY=" + BODILY_INJURY);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (BODILY_INJURY == null) {
				sb.append("<null>");
			} else {
				sb.append(BODILY_INJURY);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row6Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class Ejection_LoadStruct implements routines.system.IPersistableRow<Ejection_LoadStruct> {
		final static byte[] commonByteArrayLock_MVC_TALEND_Loading_Dimension = new byte[0];
		static byte[] commonByteArray_MVC_TALEND_Loading_Dimension = new byte[0];

		public String EJECTION_SK;

		public String getEJECTION_SK() {
			return this.EJECTION_SK;
		}

		public String EJECTION;

		public String getEJECTION() {
			return this.EJECTION;
		}

		public String DI_PID;

		public String getDI_PID() {
			return this.DI_PID;
		}

		public java.util.Date DI_Create_Date;

		public java.util.Date getDI_Create_Date() {
			return this.DI_Create_Date;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension) {

				try {

					int length = 0;

					this.EJECTION_SK = readString(dis);

					this.EJECTION = readString(dis);

					this.DI_PID = readString(dis);

					this.DI_Create_Date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension) {

				try {

					int length = 0;

					this.EJECTION_SK = readString(dis);

					this.EJECTION = readString(dis);

					this.DI_PID = readString(dis);

					this.DI_Create_Date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.EJECTION_SK, dos);

				// String

				writeString(this.EJECTION, dos);

				// String

				writeString(this.DI_PID, dos);

				// java.util.Date

				writeDate(this.DI_Create_Date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.EJECTION_SK, dos);

				// String

				writeString(this.EJECTION, dos);

				// String

				writeString(this.DI_PID, dos);

				// java.util.Date

				writeDate(this.DI_Create_Date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("EJECTION_SK=" + EJECTION_SK);
			sb.append(",EJECTION=" + EJECTION);
			sb.append(",DI_PID=" + DI_PID);
			sb.append(",DI_Create_Date=" + String.valueOf(DI_Create_Date));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (EJECTION_SK == null) {
				sb.append("<null>");
			} else {
				sb.append(EJECTION_SK);
			}

			sb.append("|");

			if (EJECTION == null) {
				sb.append("<null>");
			} else {
				sb.append(EJECTION);
			}

			sb.append("|");

			if (DI_PID == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_PID);
			}

			sb.append("|");

			if (DI_Create_Date == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_Create_Date);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(Ejection_LoadStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row5Struct implements routines.system.IPersistableRow<row5Struct> {
		final static byte[] commonByteArrayLock_MVC_TALEND_Loading_Dimension = new byte[0];
		static byte[] commonByteArray_MVC_TALEND_Loading_Dimension = new byte[0];

		public String EJECTION;

		public String getEJECTION() {
			return this.EJECTION;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension) {

				try {

					int length = 0;

					this.EJECTION = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension) {

				try {

					int length = 0;

					this.EJECTION = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.EJECTION, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.EJECTION, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("EJECTION=" + EJECTION);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (EJECTION == null) {
				sb.append("<null>");
			} else {
				sb.append(EJECTION);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row5Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class Load3Struct implements routines.system.IPersistableRow<Load3Struct> {
		final static byte[] commonByteArrayLock_MVC_TALEND_Loading_Dimension = new byte[0];
		static byte[] commonByteArray_MVC_TALEND_Loading_Dimension = new byte[0];

		public String EMOTIONAL_STATUS_SK;

		public String getEMOTIONAL_STATUS_SK() {
			return this.EMOTIONAL_STATUS_SK;
		}

		public String EMOTIONAL_STATUS;

		public String getEMOTIONAL_STATUS() {
			return this.EMOTIONAL_STATUS;
		}

		public java.util.Date DI_Create_Date;

		public java.util.Date getDI_Create_Date() {
			return this.DI_Create_Date;
		}

		public String DI_PID;

		public String getDI_PID() {
			return this.DI_PID;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension) {

				try {

					int length = 0;

					this.EMOTIONAL_STATUS_SK = readString(dis);

					this.EMOTIONAL_STATUS = readString(dis);

					this.DI_Create_Date = readDate(dis);

					this.DI_PID = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension) {

				try {

					int length = 0;

					this.EMOTIONAL_STATUS_SK = readString(dis);

					this.EMOTIONAL_STATUS = readString(dis);

					this.DI_Create_Date = readDate(dis);

					this.DI_PID = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.EMOTIONAL_STATUS_SK, dos);

				// String

				writeString(this.EMOTIONAL_STATUS, dos);

				// java.util.Date

				writeDate(this.DI_Create_Date, dos);

				// String

				writeString(this.DI_PID, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.EMOTIONAL_STATUS_SK, dos);

				// String

				writeString(this.EMOTIONAL_STATUS, dos);

				// java.util.Date

				writeDate(this.DI_Create_Date, dos);

				// String

				writeString(this.DI_PID, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("EMOTIONAL_STATUS_SK=" + EMOTIONAL_STATUS_SK);
			sb.append(",EMOTIONAL_STATUS=" + EMOTIONAL_STATUS);
			sb.append(",DI_Create_Date=" + String.valueOf(DI_Create_Date));
			sb.append(",DI_PID=" + DI_PID);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (EMOTIONAL_STATUS_SK == null) {
				sb.append("<null>");
			} else {
				sb.append(EMOTIONAL_STATUS_SK);
			}

			sb.append("|");

			if (EMOTIONAL_STATUS == null) {
				sb.append("<null>");
			} else {
				sb.append(EMOTIONAL_STATUS);
			}

			sb.append("|");

			if (DI_Create_Date == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_Create_Date);
			}

			sb.append("|");

			if (DI_PID == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_PID);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(Load3Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row4Struct implements routines.system.IPersistableRow<row4Struct> {
		final static byte[] commonByteArrayLock_MVC_TALEND_Loading_Dimension = new byte[0];
		static byte[] commonByteArray_MVC_TALEND_Loading_Dimension = new byte[0];

		public String EMOTIONAL_STATUS;

		public String getEMOTIONAL_STATUS() {
			return this.EMOTIONAL_STATUS;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension) {

				try {

					int length = 0;

					this.EMOTIONAL_STATUS = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension) {

				try {

					int length = 0;

					this.EMOTIONAL_STATUS = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.EMOTIONAL_STATUS, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.EMOTIONAL_STATUS, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("EMOTIONAL_STATUS=" + EMOTIONAL_STATUS);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (EMOTIONAL_STATUS == null) {
				sb.append("<null>");
			} else {
				sb.append(EMOTIONAL_STATUS);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row4Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class Person_Injury1Struct implements routines.system.IPersistableRow<Person_Injury1Struct> {
		final static byte[] commonByteArrayLock_MVC_TALEND_Loading_Dimension = new byte[0];
		static byte[] commonByteArray_MVC_TALEND_Loading_Dimension = new byte[0];

		public Integer PERSON_INJURY_SK;

		public Integer getPERSON_INJURY_SK() {
			return this.PERSON_INJURY_SK;
		}

		public String PERSON_INJURY;

		public String getPERSON_INJURY() {
			return this.PERSON_INJURY;
		}

		public String DI_PID;

		public String getDI_PID() {
			return this.DI_PID;
		}

		public java.util.Date DI_Create_Date;

		public java.util.Date getDI_Create_Date() {
			return this.DI_Create_Date;
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension) {

				try {

					int length = 0;

					this.PERSON_INJURY_SK = readInteger(dis);

					this.PERSON_INJURY = readString(dis);

					this.DI_PID = readString(dis);

					this.DI_Create_Date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension) {

				try {

					int length = 0;

					this.PERSON_INJURY_SK = readInteger(dis);

					this.PERSON_INJURY = readString(dis);

					this.DI_PID = readString(dis);

					this.DI_Create_Date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.PERSON_INJURY_SK, dos);

				// String

				writeString(this.PERSON_INJURY, dos);

				// String

				writeString(this.DI_PID, dos);

				// java.util.Date

				writeDate(this.DI_Create_Date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.PERSON_INJURY_SK, dos);

				// String

				writeString(this.PERSON_INJURY, dos);

				// String

				writeString(this.DI_PID, dos);

				// java.util.Date

				writeDate(this.DI_Create_Date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("PERSON_INJURY_SK=" + String.valueOf(PERSON_INJURY_SK));
			sb.append(",PERSON_INJURY=" + PERSON_INJURY);
			sb.append(",DI_PID=" + DI_PID);
			sb.append(",DI_Create_Date=" + String.valueOf(DI_Create_Date));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (PERSON_INJURY_SK == null) {
				sb.append("<null>");
			} else {
				sb.append(PERSON_INJURY_SK);
			}

			sb.append("|");

			if (PERSON_INJURY == null) {
				sb.append("<null>");
			} else {
				sb.append(PERSON_INJURY);
			}

			sb.append("|");

			if (DI_PID == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_PID);
			}

			sb.append("|");

			if (DI_Create_Date == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_Create_Date);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(Person_Injury1Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row3Struct implements routines.system.IPersistableRow<row3Struct> {
		final static byte[] commonByteArrayLock_MVC_TALEND_Loading_Dimension = new byte[0];
		static byte[] commonByteArray_MVC_TALEND_Loading_Dimension = new byte[0];

		public String PERSON_INJURY;

		public String getPERSON_INJURY() {
			return this.PERSON_INJURY;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension) {

				try {

					int length = 0;

					this.PERSON_INJURY = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension) {

				try {

					int length = 0;

					this.PERSON_INJURY = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.PERSON_INJURY, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.PERSON_INJURY, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("PERSON_INJURY=" + PERSON_INJURY);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (PERSON_INJURY == null) {
				sb.append("<null>");
			} else {
				sb.append(PERSON_INJURY);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row3Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class Person_Type_FormulaStruct
			implements routines.system.IPersistableRow<Person_Type_FormulaStruct> {
		final static byte[] commonByteArrayLock_MVC_TALEND_Loading_Dimension = new byte[0];
		static byte[] commonByteArray_MVC_TALEND_Loading_Dimension = new byte[0];

		public Integer PERSON_TYPE_SK;

		public Integer getPERSON_TYPE_SK() {
			return this.PERSON_TYPE_SK;
		}

		public String PERSON_TYPE;

		public String getPERSON_TYPE() {
			return this.PERSON_TYPE;
		}

		public String DI_PID;

		public String getDI_PID() {
			return this.DI_PID;
		}

		public java.util.Date DI_Create_Date;

		public java.util.Date getDI_Create_Date() {
			return this.DI_Create_Date;
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension) {

				try {

					int length = 0;

					this.PERSON_TYPE_SK = readInteger(dis);

					this.PERSON_TYPE = readString(dis);

					this.DI_PID = readString(dis);

					this.DI_Create_Date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension) {

				try {

					int length = 0;

					this.PERSON_TYPE_SK = readInteger(dis);

					this.PERSON_TYPE = readString(dis);

					this.DI_PID = readString(dis);

					this.DI_Create_Date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.PERSON_TYPE_SK, dos);

				// String

				writeString(this.PERSON_TYPE, dos);

				// String

				writeString(this.DI_PID, dos);

				// java.util.Date

				writeDate(this.DI_Create_Date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.PERSON_TYPE_SK, dos);

				// String

				writeString(this.PERSON_TYPE, dos);

				// String

				writeString(this.DI_PID, dos);

				// java.util.Date

				writeDate(this.DI_Create_Date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("PERSON_TYPE_SK=" + String.valueOf(PERSON_TYPE_SK));
			sb.append(",PERSON_TYPE=" + PERSON_TYPE);
			sb.append(",DI_PID=" + DI_PID);
			sb.append(",DI_Create_Date=" + String.valueOf(DI_Create_Date));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (PERSON_TYPE_SK == null) {
				sb.append("<null>");
			} else {
				sb.append(PERSON_TYPE_SK);
			}

			sb.append("|");

			if (PERSON_TYPE == null) {
				sb.append("<null>");
			} else {
				sb.append(PERSON_TYPE);
			}

			sb.append("|");

			if (DI_PID == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_PID);
			}

			sb.append("|");

			if (DI_Create_Date == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_Create_Date);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(Person_Type_FormulaStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row2Struct implements routines.system.IPersistableRow<row2Struct> {
		final static byte[] commonByteArrayLock_MVC_TALEND_Loading_Dimension = new byte[0];
		static byte[] commonByteArray_MVC_TALEND_Loading_Dimension = new byte[0];

		public String PERSON_TYPE;

		public String getPERSON_TYPE() {
			return this.PERSON_TYPE;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension) {

				try {

					int length = 0;

					this.PERSON_TYPE = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension) {

				try {

					int length = 0;

					this.PERSON_TYPE = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.PERSON_TYPE, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.PERSON_TYPE, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("PERSON_TYPE=" + PERSON_TYPE);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (PERSON_TYPE == null) {
				sb.append("<null>");
			} else {
				sb.append(PERSON_TYPE);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row2Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class Person_typeStruct implements routines.system.IPersistableRow<Person_typeStruct> {
		final static byte[] commonByteArrayLock_MVC_TALEND_Loading_Dimension = new byte[0];
		static byte[] commonByteArray_MVC_TALEND_Loading_Dimension = new byte[0];

		public String PERSON_TYPE;

		public String getPERSON_TYPE() {
			return this.PERSON_TYPE;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension) {

				try {

					int length = 0;

					this.PERSON_TYPE = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension) {

				try {

					int length = 0;

					this.PERSON_TYPE = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.PERSON_TYPE, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.PERSON_TYPE, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("PERSON_TYPE=" + PERSON_TYPE);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (PERSON_TYPE == null) {
				sb.append("<null>");
			} else {
				sb.append(PERSON_TYPE);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(Person_typeStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class Person_InjuryStruct implements routines.system.IPersistableRow<Person_InjuryStruct> {
		final static byte[] commonByteArrayLock_MVC_TALEND_Loading_Dimension = new byte[0];
		static byte[] commonByteArray_MVC_TALEND_Loading_Dimension = new byte[0];

		public String PERSON_INJURY;

		public String getPERSON_INJURY() {
			return this.PERSON_INJURY;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension) {

				try {

					int length = 0;

					this.PERSON_INJURY = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension) {

				try {

					int length = 0;

					this.PERSON_INJURY = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.PERSON_INJURY, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.PERSON_INJURY, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("PERSON_INJURY=" + PERSON_INJURY);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (PERSON_INJURY == null) {
				sb.append("<null>");
			} else {
				sb.append(PERSON_INJURY);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(Person_InjuryStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class Emotional_StatusStruct implements routines.system.IPersistableRow<Emotional_StatusStruct> {
		final static byte[] commonByteArrayLock_MVC_TALEND_Loading_Dimension = new byte[0];
		static byte[] commonByteArray_MVC_TALEND_Loading_Dimension = new byte[0];

		public String EMOTIONAL_STATUS;

		public String getEMOTIONAL_STATUS() {
			return this.EMOTIONAL_STATUS;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension) {

				try {

					int length = 0;

					this.EMOTIONAL_STATUS = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension) {

				try {

					int length = 0;

					this.EMOTIONAL_STATUS = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.EMOTIONAL_STATUS, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.EMOTIONAL_STATUS, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("EMOTIONAL_STATUS=" + EMOTIONAL_STATUS);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (EMOTIONAL_STATUS == null) {
				sb.append("<null>");
			} else {
				sb.append(EMOTIONAL_STATUS);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(Emotional_StatusStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class EjectionStruct implements routines.system.IPersistableRow<EjectionStruct> {
		final static byte[] commonByteArrayLock_MVC_TALEND_Loading_Dimension = new byte[0];
		static byte[] commonByteArray_MVC_TALEND_Loading_Dimension = new byte[0];

		public String EJECTION;

		public String getEJECTION() {
			return this.EJECTION;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension) {

				try {

					int length = 0;

					this.EJECTION = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension) {

				try {

					int length = 0;

					this.EJECTION = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.EJECTION, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.EJECTION, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("EJECTION=" + EJECTION);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (EJECTION == null) {
				sb.append("<null>");
			} else {
				sb.append(EJECTION);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(EjectionStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class Bodily_InjuryStruct implements routines.system.IPersistableRow<Bodily_InjuryStruct> {
		final static byte[] commonByteArrayLock_MVC_TALEND_Loading_Dimension = new byte[0];
		static byte[] commonByteArray_MVC_TALEND_Loading_Dimension = new byte[0];

		public String BODILY_INJURY;

		public String getBODILY_INJURY() {
			return this.BODILY_INJURY;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension) {

				try {

					int length = 0;

					this.BODILY_INJURY = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension) {

				try {

					int length = 0;

					this.BODILY_INJURY = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.BODILY_INJURY, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.BODILY_INJURY, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("BODILY_INJURY=" + BODILY_INJURY);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (BODILY_INJURY == null) {
				sb.append("<null>");
			} else {
				sb.append(BODILY_INJURY);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(Bodily_InjuryStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class Position_In_vehicleStruct
			implements routines.system.IPersistableRow<Position_In_vehicleStruct> {
		final static byte[] commonByteArrayLock_MVC_TALEND_Loading_Dimension = new byte[0];
		static byte[] commonByteArray_MVC_TALEND_Loading_Dimension = new byte[0];

		public String POSITION_IN_VEHICLE;

		public String getPOSITION_IN_VEHICLE() {
			return this.POSITION_IN_VEHICLE;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension) {

				try {

					int length = 0;

					this.POSITION_IN_VEHICLE = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension) {

				try {

					int length = 0;

					this.POSITION_IN_VEHICLE = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.POSITION_IN_VEHICLE, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.POSITION_IN_VEHICLE, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("POSITION_IN_VEHICLE=" + POSITION_IN_VEHICLE);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (POSITION_IN_VEHICLE == null) {
				sb.append("<null>");
			} else {
				sb.append(POSITION_IN_VEHICLE);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(Position_In_vehicleStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class Safety_EquipmentStruct implements routines.system.IPersistableRow<Safety_EquipmentStruct> {
		final static byte[] commonByteArrayLock_MVC_TALEND_Loading_Dimension = new byte[0];
		static byte[] commonByteArray_MVC_TALEND_Loading_Dimension = new byte[0];

		public String SAFETY_EQUIPMENT;

		public String getSAFETY_EQUIPMENT() {
			return this.SAFETY_EQUIPMENT;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension) {

				try {

					int length = 0;

					this.SAFETY_EQUIPMENT = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension) {

				try {

					int length = 0;

					this.SAFETY_EQUIPMENT = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.SAFETY_EQUIPMENT, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.SAFETY_EQUIPMENT, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("SAFETY_EQUIPMENT=" + SAFETY_EQUIPMENT);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (SAFETY_EQUIPMENT == null) {
				sb.append("<null>");
			} else {
				sb.append(SAFETY_EQUIPMENT);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(Safety_EquipmentStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class Ped_LocationStruct implements routines.system.IPersistableRow<Ped_LocationStruct> {
		final static byte[] commonByteArrayLock_MVC_TALEND_Loading_Dimension = new byte[0];
		static byte[] commonByteArray_MVC_TALEND_Loading_Dimension = new byte[0];

		public String PED_LOCATION;

		public String getPED_LOCATION() {
			return this.PED_LOCATION;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension) {

				try {

					int length = 0;

					this.PED_LOCATION = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension) {

				try {

					int length = 0;

					this.PED_LOCATION = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.PED_LOCATION, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.PED_LOCATION, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("PED_LOCATION=" + PED_LOCATION);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (PED_LOCATION == null) {
				sb.append("<null>");
			} else {
				sb.append(PED_LOCATION);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(Ped_LocationStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class Ped_Location1Struct implements routines.system.IPersistableRow<Ped_Location1Struct> {
		final static byte[] commonByteArrayLock_MVC_TALEND_Loading_Dimension = new byte[0];
		static byte[] commonByteArray_MVC_TALEND_Loading_Dimension = new byte[0];

		public String PED_ACTION;

		public String getPED_ACTION() {
			return this.PED_ACTION;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension) {

				try {

					int length = 0;

					this.PED_ACTION = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension) {

				try {

					int length = 0;

					this.PED_ACTION = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.PED_ACTION, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.PED_ACTION, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("PED_ACTION=" + PED_ACTION);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (PED_ACTION == null) {
				sb.append("<null>");
			} else {
				sb.append(PED_ACTION);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(Ped_Location1Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class ComplaintStruct implements routines.system.IPersistableRow<ComplaintStruct> {
		final static byte[] commonByteArrayLock_MVC_TALEND_Loading_Dimension = new byte[0];
		static byte[] commonByteArray_MVC_TALEND_Loading_Dimension = new byte[0];

		public String COMPLAINT;

		public String getCOMPLAINT() {
			return this.COMPLAINT;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension) {

				try {

					int length = 0;

					this.COMPLAINT = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension) {

				try {

					int length = 0;

					this.COMPLAINT = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.COMPLAINT, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.COMPLAINT, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("COMPLAINT=" + COMPLAINT);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (COMPLAINT == null) {
				sb.append("<null>");
			} else {
				sb.append(COMPLAINT);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(ComplaintStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class Ped_RoleStruct implements routines.system.IPersistableRow<Ped_RoleStruct> {
		final static byte[] commonByteArrayLock_MVC_TALEND_Loading_Dimension = new byte[0];
		static byte[] commonByteArray_MVC_TALEND_Loading_Dimension = new byte[0];

		public String PED_ROLE;

		public String getPED_ROLE() {
			return this.PED_ROLE;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension) {

				try {

					int length = 0;

					this.PED_ROLE = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension) {

				try {

					int length = 0;

					this.PED_ROLE = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.PED_ROLE, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.PED_ROLE, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("PED_ROLE=" + PED_ROLE);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (PED_ROLE == null) {
				sb.append("<null>");
			} else {
				sb.append(PED_ROLE);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(Ped_RoleStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class Person_SexStruct implements routines.system.IPersistableRow<Person_SexStruct> {
		final static byte[] commonByteArrayLock_MVC_TALEND_Loading_Dimension = new byte[0];
		static byte[] commonByteArray_MVC_TALEND_Loading_Dimension = new byte[0];

		public String PERSON_SEX;

		public String getPERSON_SEX() {
			return this.PERSON_SEX;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension) {

				try {

					int length = 0;

					this.PERSON_SEX = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension) {

				try {

					int length = 0;

					this.PERSON_SEX = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.PERSON_SEX, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.PERSON_SEX, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("PERSON_SEX=" + PERSON_SEX);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (PERSON_SEX == null) {
				sb.append("<null>");
			} else {
				sb.append(PERSON_SEX);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(Person_SexStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row1Struct implements routines.system.IPersistableRow<row1Struct> {
		final static byte[] commonByteArrayLock_MVC_TALEND_Loading_Dimension = new byte[0];
		static byte[] commonByteArray_MVC_TALEND_Loading_Dimension = new byte[0];

		public Integer UNIQUE_ID;

		public Integer getUNIQUE_ID() {
			return this.UNIQUE_ID;
		}

		public Integer COLLISION_ID;

		public Integer getCOLLISION_ID() {
			return this.COLLISION_ID;
		}

		public String CRASH_DATE;

		public String getCRASH_DATE() {
			return this.CRASH_DATE;
		}

		public String CRASH_TIME;

		public String getCRASH_TIME() {
			return this.CRASH_TIME;
		}

		public String PERSON_ID;

		public String getPERSON_ID() {
			return this.PERSON_ID;
		}

		public String PERSON_TYPE;

		public String getPERSON_TYPE() {
			return this.PERSON_TYPE;
		}

		public String PERSON_INJURY;

		public String getPERSON_INJURY() {
			return this.PERSON_INJURY;
		}

		public String VEHICLE_ID;

		public String getVEHICLE_ID() {
			return this.VEHICLE_ID;
		}

		public String PERSON_AGE;

		public String getPERSON_AGE() {
			return this.PERSON_AGE;
		}

		public String EJECTION;

		public String getEJECTION() {
			return this.EJECTION;
		}

		public String EMOTIONAL_STATUS;

		public String getEMOTIONAL_STATUS() {
			return this.EMOTIONAL_STATUS;
		}

		public String BODILY_INJURY;

		public String getBODILY_INJURY() {
			return this.BODILY_INJURY;
		}

		public String POSITION_IN_VEHICLE;

		public String getPOSITION_IN_VEHICLE() {
			return this.POSITION_IN_VEHICLE;
		}

		public String SAFETY_EQUIPMENT;

		public String getSAFETY_EQUIPMENT() {
			return this.SAFETY_EQUIPMENT;
		}

		public String PED_LOCATION;

		public String getPED_LOCATION() {
			return this.PED_LOCATION;
		}

		public String PED_ACTION;

		public String getPED_ACTION() {
			return this.PED_ACTION;
		}

		public String COMPLAINT;

		public String getCOMPLAINT() {
			return this.COMPLAINT;
		}

		public String PED_ROLE;

		public String getPED_ROLE() {
			return this.PED_ROLE;
		}

		public String CONTRIBUTING_FACTOR_1;

		public String getCONTRIBUTING_FACTOR_1() {
			return this.CONTRIBUTING_FACTOR_1;
		}

		public String CONTRIBUTING_FACTOR_2;

		public String getCONTRIBUTING_FACTOR_2() {
			return this.CONTRIBUTING_FACTOR_2;
		}

		public String PERSON_SEX;

		public String getPERSON_SEX() {
			return this.PERSON_SEX;
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension) {

				try {

					int length = 0;

					this.UNIQUE_ID = readInteger(dis);

					this.COLLISION_ID = readInteger(dis);

					this.CRASH_DATE = readString(dis);

					this.CRASH_TIME = readString(dis);

					this.PERSON_ID = readString(dis);

					this.PERSON_TYPE = readString(dis);

					this.PERSON_INJURY = readString(dis);

					this.VEHICLE_ID = readString(dis);

					this.PERSON_AGE = readString(dis);

					this.EJECTION = readString(dis);

					this.EMOTIONAL_STATUS = readString(dis);

					this.BODILY_INJURY = readString(dis);

					this.POSITION_IN_VEHICLE = readString(dis);

					this.SAFETY_EQUIPMENT = readString(dis);

					this.PED_LOCATION = readString(dis);

					this.PED_ACTION = readString(dis);

					this.COMPLAINT = readString(dis);

					this.PED_ROLE = readString(dis);

					this.CONTRIBUTING_FACTOR_1 = readString(dis);

					this.CONTRIBUTING_FACTOR_2 = readString(dis);

					this.PERSON_SEX = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension) {

				try {

					int length = 0;

					this.UNIQUE_ID = readInteger(dis);

					this.COLLISION_ID = readInteger(dis);

					this.CRASH_DATE = readString(dis);

					this.CRASH_TIME = readString(dis);

					this.PERSON_ID = readString(dis);

					this.PERSON_TYPE = readString(dis);

					this.PERSON_INJURY = readString(dis);

					this.VEHICLE_ID = readString(dis);

					this.PERSON_AGE = readString(dis);

					this.EJECTION = readString(dis);

					this.EMOTIONAL_STATUS = readString(dis);

					this.BODILY_INJURY = readString(dis);

					this.POSITION_IN_VEHICLE = readString(dis);

					this.SAFETY_EQUIPMENT = readString(dis);

					this.PED_LOCATION = readString(dis);

					this.PED_ACTION = readString(dis);

					this.COMPLAINT = readString(dis);

					this.PED_ROLE = readString(dis);

					this.CONTRIBUTING_FACTOR_1 = readString(dis);

					this.CONTRIBUTING_FACTOR_2 = readString(dis);

					this.PERSON_SEX = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.UNIQUE_ID, dos);

				// Integer

				writeInteger(this.COLLISION_ID, dos);

				// String

				writeString(this.CRASH_DATE, dos);

				// String

				writeString(this.CRASH_TIME, dos);

				// String

				writeString(this.PERSON_ID, dos);

				// String

				writeString(this.PERSON_TYPE, dos);

				// String

				writeString(this.PERSON_INJURY, dos);

				// String

				writeString(this.VEHICLE_ID, dos);

				// String

				writeString(this.PERSON_AGE, dos);

				// String

				writeString(this.EJECTION, dos);

				// String

				writeString(this.EMOTIONAL_STATUS, dos);

				// String

				writeString(this.BODILY_INJURY, dos);

				// String

				writeString(this.POSITION_IN_VEHICLE, dos);

				// String

				writeString(this.SAFETY_EQUIPMENT, dos);

				// String

				writeString(this.PED_LOCATION, dos);

				// String

				writeString(this.PED_ACTION, dos);

				// String

				writeString(this.COMPLAINT, dos);

				// String

				writeString(this.PED_ROLE, dos);

				// String

				writeString(this.CONTRIBUTING_FACTOR_1, dos);

				// String

				writeString(this.CONTRIBUTING_FACTOR_2, dos);

				// String

				writeString(this.PERSON_SEX, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.UNIQUE_ID, dos);

				// Integer

				writeInteger(this.COLLISION_ID, dos);

				// String

				writeString(this.CRASH_DATE, dos);

				// String

				writeString(this.CRASH_TIME, dos);

				// String

				writeString(this.PERSON_ID, dos);

				// String

				writeString(this.PERSON_TYPE, dos);

				// String

				writeString(this.PERSON_INJURY, dos);

				// String

				writeString(this.VEHICLE_ID, dos);

				// String

				writeString(this.PERSON_AGE, dos);

				// String

				writeString(this.EJECTION, dos);

				// String

				writeString(this.EMOTIONAL_STATUS, dos);

				// String

				writeString(this.BODILY_INJURY, dos);

				// String

				writeString(this.POSITION_IN_VEHICLE, dos);

				// String

				writeString(this.SAFETY_EQUIPMENT, dos);

				// String

				writeString(this.PED_LOCATION, dos);

				// String

				writeString(this.PED_ACTION, dos);

				// String

				writeString(this.COMPLAINT, dos);

				// String

				writeString(this.PED_ROLE, dos);

				// String

				writeString(this.CONTRIBUTING_FACTOR_1, dos);

				// String

				writeString(this.CONTRIBUTING_FACTOR_2, dos);

				// String

				writeString(this.PERSON_SEX, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("UNIQUE_ID=" + String.valueOf(UNIQUE_ID));
			sb.append(",COLLISION_ID=" + String.valueOf(COLLISION_ID));
			sb.append(",CRASH_DATE=" + CRASH_DATE);
			sb.append(",CRASH_TIME=" + CRASH_TIME);
			sb.append(",PERSON_ID=" + PERSON_ID);
			sb.append(",PERSON_TYPE=" + PERSON_TYPE);
			sb.append(",PERSON_INJURY=" + PERSON_INJURY);
			sb.append(",VEHICLE_ID=" + VEHICLE_ID);
			sb.append(",PERSON_AGE=" + PERSON_AGE);
			sb.append(",EJECTION=" + EJECTION);
			sb.append(",EMOTIONAL_STATUS=" + EMOTIONAL_STATUS);
			sb.append(",BODILY_INJURY=" + BODILY_INJURY);
			sb.append(",POSITION_IN_VEHICLE=" + POSITION_IN_VEHICLE);
			sb.append(",SAFETY_EQUIPMENT=" + SAFETY_EQUIPMENT);
			sb.append(",PED_LOCATION=" + PED_LOCATION);
			sb.append(",PED_ACTION=" + PED_ACTION);
			sb.append(",COMPLAINT=" + COMPLAINT);
			sb.append(",PED_ROLE=" + PED_ROLE);
			sb.append(",CONTRIBUTING_FACTOR_1=" + CONTRIBUTING_FACTOR_1);
			sb.append(",CONTRIBUTING_FACTOR_2=" + CONTRIBUTING_FACTOR_2);
			sb.append(",PERSON_SEX=" + PERSON_SEX);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (UNIQUE_ID == null) {
				sb.append("<null>");
			} else {
				sb.append(UNIQUE_ID);
			}

			sb.append("|");

			if (COLLISION_ID == null) {
				sb.append("<null>");
			} else {
				sb.append(COLLISION_ID);
			}

			sb.append("|");

			if (CRASH_DATE == null) {
				sb.append("<null>");
			} else {
				sb.append(CRASH_DATE);
			}

			sb.append("|");

			if (CRASH_TIME == null) {
				sb.append("<null>");
			} else {
				sb.append(CRASH_TIME);
			}

			sb.append("|");

			if (PERSON_ID == null) {
				sb.append("<null>");
			} else {
				sb.append(PERSON_ID);
			}

			sb.append("|");

			if (PERSON_TYPE == null) {
				sb.append("<null>");
			} else {
				sb.append(PERSON_TYPE);
			}

			sb.append("|");

			if (PERSON_INJURY == null) {
				sb.append("<null>");
			} else {
				sb.append(PERSON_INJURY);
			}

			sb.append("|");

			if (VEHICLE_ID == null) {
				sb.append("<null>");
			} else {
				sb.append(VEHICLE_ID);
			}

			sb.append("|");

			if (PERSON_AGE == null) {
				sb.append("<null>");
			} else {
				sb.append(PERSON_AGE);
			}

			sb.append("|");

			if (EJECTION == null) {
				sb.append("<null>");
			} else {
				sb.append(EJECTION);
			}

			sb.append("|");

			if (EMOTIONAL_STATUS == null) {
				sb.append("<null>");
			} else {
				sb.append(EMOTIONAL_STATUS);
			}

			sb.append("|");

			if (BODILY_INJURY == null) {
				sb.append("<null>");
			} else {
				sb.append(BODILY_INJURY);
			}

			sb.append("|");

			if (POSITION_IN_VEHICLE == null) {
				sb.append("<null>");
			} else {
				sb.append(POSITION_IN_VEHICLE);
			}

			sb.append("|");

			if (SAFETY_EQUIPMENT == null) {
				sb.append("<null>");
			} else {
				sb.append(SAFETY_EQUIPMENT);
			}

			sb.append("|");

			if (PED_LOCATION == null) {
				sb.append("<null>");
			} else {
				sb.append(PED_LOCATION);
			}

			sb.append("|");

			if (PED_ACTION == null) {
				sb.append("<null>");
			} else {
				sb.append(PED_ACTION);
			}

			sb.append("|");

			if (COMPLAINT == null) {
				sb.append("<null>");
			} else {
				sb.append(COMPLAINT);
			}

			sb.append("|");

			if (PED_ROLE == null) {
				sb.append("<null>");
			} else {
				sb.append(PED_ROLE);
			}

			sb.append("|");

			if (CONTRIBUTING_FACTOR_1 == null) {
				sb.append("<null>");
			} else {
				sb.append(CONTRIBUTING_FACTOR_1);
			}

			sb.append("|");

			if (CONTRIBUTING_FACTOR_2 == null) {
				sb.append("<null>");
			} else {
				sb.append(CONTRIBUTING_FACTOR_2);
			}

			sb.append("|");

			if (PERSON_SEX == null) {
				sb.append("<null>");
			} else {
				sb.append(PERSON_SEX);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row1Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tDBInput_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tDBInput_1_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				row1Struct row1 = new row1Struct();
				Person_typeStruct Person_type = new Person_typeStruct();
				row2Struct row2 = new row2Struct();
				Person_Type_FormulaStruct Person_Type_Formula = new Person_Type_FormulaStruct();
				Person_InjuryStruct Person_Injury = new Person_InjuryStruct();
				row3Struct row3 = new row3Struct();
				Person_Injury1Struct Person_Injury1 = new Person_Injury1Struct();
				Emotional_StatusStruct Emotional_Status = new Emotional_StatusStruct();
				row4Struct row4 = new row4Struct();
				Load3Struct Load3 = new Load3Struct();
				EjectionStruct Ejection = new EjectionStruct();
				row5Struct row5 = new row5Struct();
				Ejection_LoadStruct Ejection_Load = new Ejection_LoadStruct();
				Bodily_InjuryStruct Bodily_Injury = new Bodily_InjuryStruct();
				row6Struct row6 = new row6Struct();
				Bodily_loadStruct Bodily_load = new Bodily_loadStruct();
				Position_In_vehicleStruct Position_In_vehicle = new Position_In_vehicleStruct();
				row7Struct row7 = new row7Struct();
				Position_In_Vehicle1Struct Position_In_Vehicle1 = new Position_In_Vehicle1Struct();
				Safety_EquipmentStruct Safety_Equipment = new Safety_EquipmentStruct();
				row8Struct row8 = new row8Struct();
				Safety_Equipment1Struct Safety_Equipment1 = new Safety_Equipment1Struct();
				Ped_LocationStruct Ped_Location = new Ped_LocationStruct();
				row9Struct row9 = new row9Struct();
				Ped_Location_LoadStruct Ped_Location_Load = new Ped_Location_LoadStruct();
				Ped_Location1Struct Ped_Location1 = new Ped_Location1Struct();
				row10Struct row10 = new row10Struct();
				Ped_ActionStruct Ped_Action = new Ped_ActionStruct();
				ComplaintStruct Complaint = new ComplaintStruct();
				row11Struct row11 = new row11Struct();
				Complain_LoadStruct Complain_Load = new Complain_LoadStruct();
				Ped_RoleStruct Ped_Role = new Ped_RoleStruct();
				row12Struct row12 = new row12Struct();
				Ped_Role_LoadStruct Ped_Role_Load = new Ped_Role_LoadStruct();
				Person_SexStruct Person_Sex = new Person_SexStruct();
				row13Struct row13 = new row13Struct();
				Person_Sex1Struct Person_Sex1 = new Person_Sex1Struct();

				/**
				 * [tDBOutput_1 begin ] start
				 */

				ok_Hash.put("tDBOutput_1", false);
				start_Hash.put("tDBOutput_1", System.currentTimeMillis());

				currentComponent = "tDBOutput_1";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "Person_Type_Formula");

				int tos_count_tDBOutput_1 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tDBOutput_1 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tDBOutput_1 = new StringBuilder();
							log4jParamters_tDBOutput_1.append("Parameters:");
							log4jParamters_tDBOutput_1.append("USE_EXISTING_CONNECTION" + " = " + "false");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("DRIVER" + " = " + "JTDS");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("HOST" + " = " + "\"localhost\"");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("PORT" + " = " + "\"1433\"");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("DB_SCHEMA" + " = " + "\"\"");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("DBNAME" + " = " + "\"MVC_Stage\"");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("USER" + " = " + "\"\"");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("PASS" + " = "
									+ String.valueOf(
											"enc:routine.encryption.key.v1:5ikHEnb4YlLDzAlSsB9MnveIBAQAekMi4A/+/w==")
											.substring(0, 4)
									+ "...");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("TABLE" + " = " + "\"Dim_PersonType\"");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("TABLE_ACTION" + " = " + "NONE");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("IDENTITY_INSERT" + " = " + "false");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("DATA_ACTION" + " = " + "INSERT");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("DIE_ON_ERROR" + " = " + "false");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("PROPERTIES" + " = " + "\"\"");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("COMMIT_EVERY" + " = " + "10000");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("ADD_COLS" + " = " + "[]");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("USE_FIELD_OPTIONS" + " = " + "false");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("IGNORE_DATE_OUTOF_RANGE" + " = " + "false");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("ENABLE_DEBUG_MODE" + " = " + "false");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("SUPPORT_NULL_WHERE" + " = " + "false");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("USE_BATCH_SIZE" + " = " + "true");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("BATCH_SIZE" + " = " + "10000");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("UNIFIED_COMPONENTS" + " = " + "tMSSqlOutput");
							log4jParamters_tDBOutput_1.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tDBOutput_1 - " + (log4jParamters_tDBOutput_1));
						}
					}
					new BytesLimit65535_tDBOutput_1().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tDBOutput_1", "__TABLE__", "tMSSqlOutput");
					talendJobLogProcess(globalMap);
				}

				int nb_line_tDBOutput_1 = 0;
				int nb_line_update_tDBOutput_1 = 0;
				int nb_line_inserted_tDBOutput_1 = 0;
				int nb_line_deleted_tDBOutput_1 = 0;
				int nb_line_rejected_tDBOutput_1 = 0;

				int deletedCount_tDBOutput_1 = 0;
				int updatedCount_tDBOutput_1 = 0;
				int insertedCount_tDBOutput_1 = 0;
				int rowsToCommitCount_tDBOutput_1 = 0;
				int rejectedCount_tDBOutput_1 = 0;
				String dbschema_tDBOutput_1 = null;
				String tableName_tDBOutput_1 = null;
				boolean whetherReject_tDBOutput_1 = false;

				java.util.Calendar calendar_tDBOutput_1 = java.util.Calendar.getInstance();
				long year1_tDBOutput_1 = TalendDate.parseDate("yyyy-MM-dd", "0001-01-01").getTime();
				long year2_tDBOutput_1 = TalendDate.parseDate("yyyy-MM-dd", "1753-01-01").getTime();
				long year10000_tDBOutput_1 = TalendDate.parseDate("yyyy-MM-dd HH:mm:ss", "9999-12-31 24:00:00")
						.getTime();
				long date_tDBOutput_1;

				java.util.Calendar calendar_datetimeoffset_tDBOutput_1 = java.util.Calendar
						.getInstance(java.util.TimeZone.getTimeZone("UTC"));

				java.sql.Connection conn_tDBOutput_1 = null;
				String dbUser_tDBOutput_1 = null;
				dbschema_tDBOutput_1 = "";
				String driverClass_tDBOutput_1 = "net.sourceforge.jtds.jdbc.Driver";

				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Driver ClassName: ") + (driverClass_tDBOutput_1) + ("."));
				java.lang.Class.forName(driverClass_tDBOutput_1);
				String port_tDBOutput_1 = "1433";
				String dbname_tDBOutput_1 = "MVC_Stage";
				String url_tDBOutput_1 = "jdbc:jtds:sqlserver://" + "localhost";
				if (!"".equals(port_tDBOutput_1)) {
					url_tDBOutput_1 += ":" + "1433";
				}
				if (!"".equals(dbname_tDBOutput_1)) {
					url_tDBOutput_1 += "//" + "MVC_Stage";

				}
				url_tDBOutput_1 += ";appName=" + projectName + ";" + "";
				dbUser_tDBOutput_1 = "";

				final String decryptedPassword_tDBOutput_1 = routines.system.PasswordEncryptUtil
						.decryptPassword("enc:routine.encryption.key.v1:863kTZmtdqysv9rJEIkdc4VlttkHcURworF0tQ==");

				String dbPwd_tDBOutput_1 = decryptedPassword_tDBOutput_1;
				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Connection attempts to '") + (url_tDBOutput_1)
							+ ("' with the username '") + (dbUser_tDBOutput_1) + ("'."));
				conn_tDBOutput_1 = java.sql.DriverManager.getConnection(url_tDBOutput_1, dbUser_tDBOutput_1,
						dbPwd_tDBOutput_1);
				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Connection to '") + (url_tDBOutput_1) + ("' has succeeded."));

				resourceMap.put("conn_tDBOutput_1", conn_tDBOutput_1);

				conn_tDBOutput_1.setAutoCommit(false);
				int commitEvery_tDBOutput_1 = 10000;
				int commitCounter_tDBOutput_1 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Connection is set auto commit to '")
							+ (conn_tDBOutput_1.getAutoCommit()) + ("'."));
				int batchSize_tDBOutput_1 = 10000;
				int batchSizeCounter_tDBOutput_1 = 0;

				if (dbschema_tDBOutput_1 == null || dbschema_tDBOutput_1.trim().length() == 0) {
					tableName_tDBOutput_1 = "Dim_PersonType";
				} else {
					tableName_tDBOutput_1 = dbschema_tDBOutput_1 + "].[" + "Dim_PersonType";
				}
				int count_tDBOutput_1 = 0;

				String insert_tDBOutput_1 = "INSERT INTO [" + tableName_tDBOutput_1
						+ "] ([PERSON_TYPE_SK],[PERSON_TYPE],[DI_PID],[DI_Create_Date]) VALUES (?,?,?,?)";
				java.sql.PreparedStatement pstmt_tDBOutput_1 = conn_tDBOutput_1.prepareStatement(insert_tDBOutput_1);
				resourceMap.put("pstmt_tDBOutput_1", pstmt_tDBOutput_1);

				/**
				 * [tDBOutput_1 begin ] stop
				 */

				/**
				 * [tMap_2 begin ] start
				 */

				ok_Hash.put("tMap_2", false);
				start_Hash.put("tMap_2", System.currentTimeMillis());

				currentComponent = "tMap_2";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "row2");

				int tos_count_tMap_2 = 0;

				if (log.isDebugEnabled())
					log.debug("tMap_2 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tMap_2 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tMap_2 = new StringBuilder();
							log4jParamters_tMap_2.append("Parameters:");
							log4jParamters_tMap_2.append("LINK_STYLE" + " = " + "AUTO");
							log4jParamters_tMap_2.append(" | ");
							log4jParamters_tMap_2.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
							log4jParamters_tMap_2.append(" | ");
							log4jParamters_tMap_2.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
							log4jParamters_tMap_2.append(" | ");
							log4jParamters_tMap_2.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "true");
							log4jParamters_tMap_2.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tMap_2 - " + (log4jParamters_tMap_2));
						}
					}
					new BytesLimit65535_tMap_2().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tMap_2", "tMap_2", "tMap");
					talendJobLogProcess(globalMap);
				}

// ###############################
// # Lookup's keys initialization
				int count_row2_tMap_2 = 0;

// ###############################        

// ###############################
// # Vars initialization
				class Var__tMap_2__Struct {
				}
				Var__tMap_2__Struct Var__tMap_2 = new Var__tMap_2__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_Person_Type_Formula_tMap_2 = 0;

				Person_Type_FormulaStruct Person_Type_Formula_tmp = new Person_Type_FormulaStruct();
// ###############################

				/**
				 * [tMap_2 begin ] stop
				 */

				/**
				 * [tUniqRow_1 begin ] start
				 */

				ok_Hash.put("tUniqRow_1", false);
				start_Hash.put("tUniqRow_1", System.currentTimeMillis());

				currentComponent = "tUniqRow_1";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "Person_type");

				int tos_count_tUniqRow_1 = 0;

				if (log.isDebugEnabled())
					log.debug("tUniqRow_1 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tUniqRow_1 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tUniqRow_1 = new StringBuilder();
							log4jParamters_tUniqRow_1.append("Parameters:");
							log4jParamters_tUniqRow_1.append("UNIQUE_KEY" + " = " + "[{CASE_SENSITIVE=" + ("false")
									+ ", KEY_ATTRIBUTE=" + ("true") + ", SCHEMA_COLUMN=" + ("PERSON_TYPE") + "}]");
							log4jParamters_tUniqRow_1.append(" | ");
							log4jParamters_tUniqRow_1.append("ONLY_ONCE_EACH_DUPLICATED_KEY" + " = " + "false");
							log4jParamters_tUniqRow_1.append(" | ");
							log4jParamters_tUniqRow_1.append("IS_VIRTUAL_COMPONENT" + " = " + "false");
							log4jParamters_tUniqRow_1.append(" | ");
							log4jParamters_tUniqRow_1.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "false");
							log4jParamters_tUniqRow_1.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tUniqRow_1 - " + (log4jParamters_tUniqRow_1));
						}
					}
					new BytesLimit65535_tUniqRow_1().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tUniqRow_1", "tUniqRow_1", "tUniqRow");
					talendJobLogProcess(globalMap);
				}

				class KeyStruct_tUniqRow_1 {

					private static final int DEFAULT_HASHCODE = 1;
					private static final int PRIME = 31;
					private int hashCode = DEFAULT_HASHCODE;
					public boolean hashCodeDirty = true;

					String PERSON_TYPE;

					@Override
					public int hashCode() {
						if (this.hashCodeDirty) {
							final int prime = PRIME;
							int result = DEFAULT_HASHCODE;

							result = prime * result + ((this.PERSON_TYPE == null) ? 0 : this.PERSON_TYPE.hashCode());

							this.hashCode = result;
							this.hashCodeDirty = false;
						}
						return this.hashCode;
					}

					@Override
					public boolean equals(Object obj) {
						if (this == obj)
							return true;
						if (obj == null)
							return false;
						if (getClass() != obj.getClass())
							return false;
						final KeyStruct_tUniqRow_1 other = (KeyStruct_tUniqRow_1) obj;

						if (this.PERSON_TYPE == null) {
							if (other.PERSON_TYPE != null)
								return false;

						} else if (!this.PERSON_TYPE.equals(other.PERSON_TYPE))

							return false;

						return true;
					}

				}

				int nb_uniques_tUniqRow_1 = 0;
				int nb_duplicates_tUniqRow_1 = 0;
				log.debug("tUniqRow_1 - Start to process the data from datasource.");
				KeyStruct_tUniqRow_1 finder_tUniqRow_1 = new KeyStruct_tUniqRow_1();
				java.util.Set<KeyStruct_tUniqRow_1> keystUniqRow_1 = new java.util.HashSet<KeyStruct_tUniqRow_1>();

				/**
				 * [tUniqRow_1 begin ] stop
				 */

				/**
				 * [tDBOutput_2 begin ] start
				 */

				ok_Hash.put("tDBOutput_2", false);
				start_Hash.put("tDBOutput_2", System.currentTimeMillis());

				currentComponent = "tDBOutput_2";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "Person_Injury1");

				int tos_count_tDBOutput_2 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBOutput_2 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tDBOutput_2 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tDBOutput_2 = new StringBuilder();
							log4jParamters_tDBOutput_2.append("Parameters:");
							log4jParamters_tDBOutput_2.append("USE_EXISTING_CONNECTION" + " = " + "false");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("DRIVER" + " = " + "JTDS");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("HOST" + " = " + "\"localhost\"");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("PORT" + " = " + "\"1433\"");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("DB_SCHEMA" + " = " + "\"\"");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("DBNAME" + " = " + "\"MVC_Stage\"");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("USER" + " = " + "\"\"");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("PASS" + " = "
									+ String.valueOf(
											"enc:routine.encryption.key.v1:IFWdI8RJzYejHI9T4FNK/w8Z7z57lBAs1gl+Hg==")
											.substring(0, 4)
									+ "...");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("TABLE" + " = " + "\"Dim_PERSON_INJURY\"");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("TABLE_ACTION" + " = " + "NONE");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("IDENTITY_INSERT" + " = " + "false");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("DATA_ACTION" + " = " + "INSERT");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("DIE_ON_ERROR" + " = " + "false");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("PROPERTIES" + " = " + "\"\"");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("COMMIT_EVERY" + " = " + "10000");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("ADD_COLS" + " = " + "[]");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("USE_FIELD_OPTIONS" + " = " + "false");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("IGNORE_DATE_OUTOF_RANGE" + " = " + "false");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("ENABLE_DEBUG_MODE" + " = " + "false");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("SUPPORT_NULL_WHERE" + " = " + "false");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("USE_BATCH_SIZE" + " = " + "true");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("BATCH_SIZE" + " = " + "10000");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("UNIFIED_COMPONENTS" + " = " + "tMSSqlOutput");
							log4jParamters_tDBOutput_2.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tDBOutput_2 - " + (log4jParamters_tDBOutput_2));
						}
					}
					new BytesLimit65535_tDBOutput_2().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tDBOutput_2", "__TABLE__", "tMSSqlOutput");
					talendJobLogProcess(globalMap);
				}

				int nb_line_tDBOutput_2 = 0;
				int nb_line_update_tDBOutput_2 = 0;
				int nb_line_inserted_tDBOutput_2 = 0;
				int nb_line_deleted_tDBOutput_2 = 0;
				int nb_line_rejected_tDBOutput_2 = 0;

				int deletedCount_tDBOutput_2 = 0;
				int updatedCount_tDBOutput_2 = 0;
				int insertedCount_tDBOutput_2 = 0;
				int rowsToCommitCount_tDBOutput_2 = 0;
				int rejectedCount_tDBOutput_2 = 0;
				String dbschema_tDBOutput_2 = null;
				String tableName_tDBOutput_2 = null;
				boolean whetherReject_tDBOutput_2 = false;

				java.util.Calendar calendar_tDBOutput_2 = java.util.Calendar.getInstance();
				long year1_tDBOutput_2 = TalendDate.parseDate("yyyy-MM-dd", "0001-01-01").getTime();
				long year2_tDBOutput_2 = TalendDate.parseDate("yyyy-MM-dd", "1753-01-01").getTime();
				long year10000_tDBOutput_2 = TalendDate.parseDate("yyyy-MM-dd HH:mm:ss", "9999-12-31 24:00:00")
						.getTime();
				long date_tDBOutput_2;

				java.util.Calendar calendar_datetimeoffset_tDBOutput_2 = java.util.Calendar
						.getInstance(java.util.TimeZone.getTimeZone("UTC"));

				java.sql.Connection conn_tDBOutput_2 = null;
				String dbUser_tDBOutput_2 = null;
				dbschema_tDBOutput_2 = "";
				String driverClass_tDBOutput_2 = "net.sourceforge.jtds.jdbc.Driver";

				if (log.isDebugEnabled())
					log.debug("tDBOutput_2 - " + ("Driver ClassName: ") + (driverClass_tDBOutput_2) + ("."));
				java.lang.Class.forName(driverClass_tDBOutput_2);
				String port_tDBOutput_2 = "1433";
				String dbname_tDBOutput_2 = "MVC_Stage";
				String url_tDBOutput_2 = "jdbc:jtds:sqlserver://" + "localhost";
				if (!"".equals(port_tDBOutput_2)) {
					url_tDBOutput_2 += ":" + "1433";
				}
				if (!"".equals(dbname_tDBOutput_2)) {
					url_tDBOutput_2 += "//" + "MVC_Stage";

				}
				url_tDBOutput_2 += ";appName=" + projectName + ";" + "";
				dbUser_tDBOutput_2 = "";

				final String decryptedPassword_tDBOutput_2 = routines.system.PasswordEncryptUtil
						.decryptPassword("enc:routine.encryption.key.v1:sWB5tQBoEHzsobzZgpXYFGJBZp0wjgEjhisRGQ==");

				String dbPwd_tDBOutput_2 = decryptedPassword_tDBOutput_2;
				if (log.isDebugEnabled())
					log.debug("tDBOutput_2 - " + ("Connection attempts to '") + (url_tDBOutput_2)
							+ ("' with the username '") + (dbUser_tDBOutput_2) + ("'."));
				conn_tDBOutput_2 = java.sql.DriverManager.getConnection(url_tDBOutput_2, dbUser_tDBOutput_2,
						dbPwd_tDBOutput_2);
				if (log.isDebugEnabled())
					log.debug("tDBOutput_2 - " + ("Connection to '") + (url_tDBOutput_2) + ("' has succeeded."));

				resourceMap.put("conn_tDBOutput_2", conn_tDBOutput_2);

				conn_tDBOutput_2.setAutoCommit(false);
				int commitEvery_tDBOutput_2 = 10000;
				int commitCounter_tDBOutput_2 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBOutput_2 - " + ("Connection is set auto commit to '")
							+ (conn_tDBOutput_2.getAutoCommit()) + ("'."));
				int batchSize_tDBOutput_2 = 10000;
				int batchSizeCounter_tDBOutput_2 = 0;

				if (dbschema_tDBOutput_2 == null || dbschema_tDBOutput_2.trim().length() == 0) {
					tableName_tDBOutput_2 = "Dim_PERSON_INJURY";
				} else {
					tableName_tDBOutput_2 = dbschema_tDBOutput_2 + "].[" + "Dim_PERSON_INJURY";
				}
				int count_tDBOutput_2 = 0;

				String insert_tDBOutput_2 = "INSERT INTO [" + tableName_tDBOutput_2
						+ "] ([PERSON_INJURY_SK],[PERSON_INJURY],[DI_PID],[DI_Create_Date]) VALUES (?,?,?,?)";
				java.sql.PreparedStatement pstmt_tDBOutput_2 = conn_tDBOutput_2.prepareStatement(insert_tDBOutput_2);
				resourceMap.put("pstmt_tDBOutput_2", pstmt_tDBOutput_2);

				/**
				 * [tDBOutput_2 begin ] stop
				 */

				/**
				 * [tMap_3 begin ] start
				 */

				ok_Hash.put("tMap_3", false);
				start_Hash.put("tMap_3", System.currentTimeMillis());

				currentComponent = "tMap_3";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "row3");

				int tos_count_tMap_3 = 0;

				if (log.isDebugEnabled())
					log.debug("tMap_3 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tMap_3 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tMap_3 = new StringBuilder();
							log4jParamters_tMap_3.append("Parameters:");
							log4jParamters_tMap_3.append("LINK_STYLE" + " = " + "AUTO");
							log4jParamters_tMap_3.append(" | ");
							log4jParamters_tMap_3.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
							log4jParamters_tMap_3.append(" | ");
							log4jParamters_tMap_3.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
							log4jParamters_tMap_3.append(" | ");
							log4jParamters_tMap_3.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "true");
							log4jParamters_tMap_3.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tMap_3 - " + (log4jParamters_tMap_3));
						}
					}
					new BytesLimit65535_tMap_3().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tMap_3", "tMap_3", "tMap");
					talendJobLogProcess(globalMap);
				}

// ###############################
// # Lookup's keys initialization
				int count_row3_tMap_3 = 0;

// ###############################        

// ###############################
// # Vars initialization
				class Var__tMap_3__Struct {
				}
				Var__tMap_3__Struct Var__tMap_3 = new Var__tMap_3__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_Person_Injury1_tMap_3 = 0;

				Person_Injury1Struct Person_Injury1_tmp = new Person_Injury1Struct();
// ###############################

				/**
				 * [tMap_3 begin ] stop
				 */

				/**
				 * [tUniqRow_2 begin ] start
				 */

				ok_Hash.put("tUniqRow_2", false);
				start_Hash.put("tUniqRow_2", System.currentTimeMillis());

				currentComponent = "tUniqRow_2";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "Person_Injury");

				int tos_count_tUniqRow_2 = 0;

				if (log.isDebugEnabled())
					log.debug("tUniqRow_2 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tUniqRow_2 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tUniqRow_2 = new StringBuilder();
							log4jParamters_tUniqRow_2.append("Parameters:");
							log4jParamters_tUniqRow_2.append("UNIQUE_KEY" + " = " + "[{CASE_SENSITIVE=" + ("false")
									+ ", KEY_ATTRIBUTE=" + ("true") + ", SCHEMA_COLUMN=" + ("PERSON_INJURY") + "}]");
							log4jParamters_tUniqRow_2.append(" | ");
							log4jParamters_tUniqRow_2.append("ONLY_ONCE_EACH_DUPLICATED_KEY" + " = " + "false");
							log4jParamters_tUniqRow_2.append(" | ");
							log4jParamters_tUniqRow_2.append("IS_VIRTUAL_COMPONENT" + " = " + "false");
							log4jParamters_tUniqRow_2.append(" | ");
							log4jParamters_tUniqRow_2.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "false");
							log4jParamters_tUniqRow_2.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tUniqRow_2 - " + (log4jParamters_tUniqRow_2));
						}
					}
					new BytesLimit65535_tUniqRow_2().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tUniqRow_2", "tUniqRow_2", "tUniqRow");
					talendJobLogProcess(globalMap);
				}

				class KeyStruct_tUniqRow_2 {

					private static final int DEFAULT_HASHCODE = 1;
					private static final int PRIME = 31;
					private int hashCode = DEFAULT_HASHCODE;
					public boolean hashCodeDirty = true;

					String PERSON_INJURY;

					@Override
					public int hashCode() {
						if (this.hashCodeDirty) {
							final int prime = PRIME;
							int result = DEFAULT_HASHCODE;

							result = prime * result
									+ ((this.PERSON_INJURY == null) ? 0 : this.PERSON_INJURY.hashCode());

							this.hashCode = result;
							this.hashCodeDirty = false;
						}
						return this.hashCode;
					}

					@Override
					public boolean equals(Object obj) {
						if (this == obj)
							return true;
						if (obj == null)
							return false;
						if (getClass() != obj.getClass())
							return false;
						final KeyStruct_tUniqRow_2 other = (KeyStruct_tUniqRow_2) obj;

						if (this.PERSON_INJURY == null) {
							if (other.PERSON_INJURY != null)
								return false;

						} else if (!this.PERSON_INJURY.equals(other.PERSON_INJURY))

							return false;

						return true;
					}

				}

				int nb_uniques_tUniqRow_2 = 0;
				int nb_duplicates_tUniqRow_2 = 0;
				log.debug("tUniqRow_2 - Start to process the data from datasource.");
				KeyStruct_tUniqRow_2 finder_tUniqRow_2 = new KeyStruct_tUniqRow_2();
				java.util.Set<KeyStruct_tUniqRow_2> keystUniqRow_2 = new java.util.HashSet<KeyStruct_tUniqRow_2>();

				/**
				 * [tUniqRow_2 begin ] stop
				 */

				/**
				 * [tDBOutput_3 begin ] start
				 */

				ok_Hash.put("tDBOutput_3", false);
				start_Hash.put("tDBOutput_3", System.currentTimeMillis());

				currentComponent = "tDBOutput_3";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "Load3");

				int tos_count_tDBOutput_3 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBOutput_3 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tDBOutput_3 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tDBOutput_3 = new StringBuilder();
							log4jParamters_tDBOutput_3.append("Parameters:");
							log4jParamters_tDBOutput_3.append("USE_EXISTING_CONNECTION" + " = " + "false");
							log4jParamters_tDBOutput_3.append(" | ");
							log4jParamters_tDBOutput_3.append("DRIVER" + " = " + "JTDS");
							log4jParamters_tDBOutput_3.append(" | ");
							log4jParamters_tDBOutput_3.append("HOST" + " = " + "\"localhost\"");
							log4jParamters_tDBOutput_3.append(" | ");
							log4jParamters_tDBOutput_3.append("PORT" + " = " + "\"1433\"");
							log4jParamters_tDBOutput_3.append(" | ");
							log4jParamters_tDBOutput_3.append("DB_SCHEMA" + " = " + "\"\"");
							log4jParamters_tDBOutput_3.append(" | ");
							log4jParamters_tDBOutput_3.append("DBNAME" + " = " + "\"MVC_Stage\"");
							log4jParamters_tDBOutput_3.append(" | ");
							log4jParamters_tDBOutput_3.append("USER" + " = " + "\"\"");
							log4jParamters_tDBOutput_3.append(" | ");
							log4jParamters_tDBOutput_3.append("PASS" + " = "
									+ String.valueOf(
											"enc:routine.encryption.key.v1:qBbFclMp0CGMxrSTZeBL/uArlzvV/C5qAn9GGg==")
											.substring(0, 4)
									+ "...");
							log4jParamters_tDBOutput_3.append(" | ");
							log4jParamters_tDBOutput_3.append("TABLE" + " = " + "\"Dim_EMOTIONAL_STATUS\"");
							log4jParamters_tDBOutput_3.append(" | ");
							log4jParamters_tDBOutput_3.append("TABLE_ACTION" + " = " + "NONE");
							log4jParamters_tDBOutput_3.append(" | ");
							log4jParamters_tDBOutput_3.append("IDENTITY_INSERT" + " = " + "false");
							log4jParamters_tDBOutput_3.append(" | ");
							log4jParamters_tDBOutput_3.append("DATA_ACTION" + " = " + "INSERT");
							log4jParamters_tDBOutput_3.append(" | ");
							log4jParamters_tDBOutput_3.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
							log4jParamters_tDBOutput_3.append(" | ");
							log4jParamters_tDBOutput_3.append("DIE_ON_ERROR" + " = " + "false");
							log4jParamters_tDBOutput_3.append(" | ");
							log4jParamters_tDBOutput_3.append("PROPERTIES" + " = " + "\"\"");
							log4jParamters_tDBOutput_3.append(" | ");
							log4jParamters_tDBOutput_3.append("COMMIT_EVERY" + " = " + "10000");
							log4jParamters_tDBOutput_3.append(" | ");
							log4jParamters_tDBOutput_3.append("ADD_COLS" + " = " + "[]");
							log4jParamters_tDBOutput_3.append(" | ");
							log4jParamters_tDBOutput_3.append("USE_FIELD_OPTIONS" + " = " + "false");
							log4jParamters_tDBOutput_3.append(" | ");
							log4jParamters_tDBOutput_3.append("IGNORE_DATE_OUTOF_RANGE" + " = " + "false");
							log4jParamters_tDBOutput_3.append(" | ");
							log4jParamters_tDBOutput_3.append("ENABLE_DEBUG_MODE" + " = " + "false");
							log4jParamters_tDBOutput_3.append(" | ");
							log4jParamters_tDBOutput_3.append("SUPPORT_NULL_WHERE" + " = " + "false");
							log4jParamters_tDBOutput_3.append(" | ");
							log4jParamters_tDBOutput_3.append("USE_BATCH_SIZE" + " = " + "true");
							log4jParamters_tDBOutput_3.append(" | ");
							log4jParamters_tDBOutput_3.append("BATCH_SIZE" + " = " + "10000");
							log4jParamters_tDBOutput_3.append(" | ");
							log4jParamters_tDBOutput_3.append("UNIFIED_COMPONENTS" + " = " + "tMSSqlOutput");
							log4jParamters_tDBOutput_3.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tDBOutput_3 - " + (log4jParamters_tDBOutput_3));
						}
					}
					new BytesLimit65535_tDBOutput_3().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tDBOutput_3", "__TABLE__", "tMSSqlOutput");
					talendJobLogProcess(globalMap);
				}

				int nb_line_tDBOutput_3 = 0;
				int nb_line_update_tDBOutput_3 = 0;
				int nb_line_inserted_tDBOutput_3 = 0;
				int nb_line_deleted_tDBOutput_3 = 0;
				int nb_line_rejected_tDBOutput_3 = 0;

				int deletedCount_tDBOutput_3 = 0;
				int updatedCount_tDBOutput_3 = 0;
				int insertedCount_tDBOutput_3 = 0;
				int rowsToCommitCount_tDBOutput_3 = 0;
				int rejectedCount_tDBOutput_3 = 0;
				String dbschema_tDBOutput_3 = null;
				String tableName_tDBOutput_3 = null;
				boolean whetherReject_tDBOutput_3 = false;

				java.util.Calendar calendar_tDBOutput_3 = java.util.Calendar.getInstance();
				long year1_tDBOutput_3 = TalendDate.parseDate("yyyy-MM-dd", "0001-01-01").getTime();
				long year2_tDBOutput_3 = TalendDate.parseDate("yyyy-MM-dd", "1753-01-01").getTime();
				long year10000_tDBOutput_3 = TalendDate.parseDate("yyyy-MM-dd HH:mm:ss", "9999-12-31 24:00:00")
						.getTime();
				long date_tDBOutput_3;

				java.util.Calendar calendar_datetimeoffset_tDBOutput_3 = java.util.Calendar
						.getInstance(java.util.TimeZone.getTimeZone("UTC"));

				java.sql.Connection conn_tDBOutput_3 = null;
				String dbUser_tDBOutput_3 = null;
				dbschema_tDBOutput_3 = "";
				String driverClass_tDBOutput_3 = "net.sourceforge.jtds.jdbc.Driver";

				if (log.isDebugEnabled())
					log.debug("tDBOutput_3 - " + ("Driver ClassName: ") + (driverClass_tDBOutput_3) + ("."));
				java.lang.Class.forName(driverClass_tDBOutput_3);
				String port_tDBOutput_3 = "1433";
				String dbname_tDBOutput_3 = "MVC_Stage";
				String url_tDBOutput_3 = "jdbc:jtds:sqlserver://" + "localhost";
				if (!"".equals(port_tDBOutput_3)) {
					url_tDBOutput_3 += ":" + "1433";
				}
				if (!"".equals(dbname_tDBOutput_3)) {
					url_tDBOutput_3 += "//" + "MVC_Stage";

				}
				url_tDBOutput_3 += ";appName=" + projectName + ";" + "";
				dbUser_tDBOutput_3 = "";

				final String decryptedPassword_tDBOutput_3 = routines.system.PasswordEncryptUtil
						.decryptPassword("enc:routine.encryption.key.v1:jkuFSyxYsLWgipkcXLfmthy89W0Er0O5X9JaVw==");

				String dbPwd_tDBOutput_3 = decryptedPassword_tDBOutput_3;
				if (log.isDebugEnabled())
					log.debug("tDBOutput_3 - " + ("Connection attempts to '") + (url_tDBOutput_3)
							+ ("' with the username '") + (dbUser_tDBOutput_3) + ("'."));
				conn_tDBOutput_3 = java.sql.DriverManager.getConnection(url_tDBOutput_3, dbUser_tDBOutput_3,
						dbPwd_tDBOutput_3);
				if (log.isDebugEnabled())
					log.debug("tDBOutput_3 - " + ("Connection to '") + (url_tDBOutput_3) + ("' has succeeded."));

				resourceMap.put("conn_tDBOutput_3", conn_tDBOutput_3);

				conn_tDBOutput_3.setAutoCommit(false);
				int commitEvery_tDBOutput_3 = 10000;
				int commitCounter_tDBOutput_3 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBOutput_3 - " + ("Connection is set auto commit to '")
							+ (conn_tDBOutput_3.getAutoCommit()) + ("'."));
				int batchSize_tDBOutput_3 = 10000;
				int batchSizeCounter_tDBOutput_3 = 0;

				if (dbschema_tDBOutput_3 == null || dbschema_tDBOutput_3.trim().length() == 0) {
					tableName_tDBOutput_3 = "Dim_EMOTIONAL_STATUS";
				} else {
					tableName_tDBOutput_3 = dbschema_tDBOutput_3 + "].[" + "Dim_EMOTIONAL_STATUS";
				}
				int count_tDBOutput_3 = 0;

				String insert_tDBOutput_3 = "INSERT INTO [" + tableName_tDBOutput_3
						+ "] ([EMOTIONAL_STATUS_SK],[EMOTIONAL_STATUS],[DI_Create_Date],[DI_PID]) VALUES (?,?,?,?)";
				java.sql.PreparedStatement pstmt_tDBOutput_3 = conn_tDBOutput_3.prepareStatement(insert_tDBOutput_3);
				resourceMap.put("pstmt_tDBOutput_3", pstmt_tDBOutput_3);

				/**
				 * [tDBOutput_3 begin ] stop
				 */

				/**
				 * [tMap_4 begin ] start
				 */

				ok_Hash.put("tMap_4", false);
				start_Hash.put("tMap_4", System.currentTimeMillis());

				currentComponent = "tMap_4";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "row4");

				int tos_count_tMap_4 = 0;

				if (log.isDebugEnabled())
					log.debug("tMap_4 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tMap_4 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tMap_4 = new StringBuilder();
							log4jParamters_tMap_4.append("Parameters:");
							log4jParamters_tMap_4.append("LINK_STYLE" + " = " + "AUTO");
							log4jParamters_tMap_4.append(" | ");
							log4jParamters_tMap_4.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
							log4jParamters_tMap_4.append(" | ");
							log4jParamters_tMap_4.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
							log4jParamters_tMap_4.append(" | ");
							log4jParamters_tMap_4.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "true");
							log4jParamters_tMap_4.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tMap_4 - " + (log4jParamters_tMap_4));
						}
					}
					new BytesLimit65535_tMap_4().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tMap_4", "tMap_4", "tMap");
					talendJobLogProcess(globalMap);
				}

// ###############################
// # Lookup's keys initialization
				int count_row4_tMap_4 = 0;

// ###############################        

// ###############################
// # Vars initialization
				class Var__tMap_4__Struct {
				}
				Var__tMap_4__Struct Var__tMap_4 = new Var__tMap_4__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_Load3_tMap_4 = 0;

				Load3Struct Load3_tmp = new Load3Struct();
// ###############################

				/**
				 * [tMap_4 begin ] stop
				 */

				/**
				 * [tUniqRow_3 begin ] start
				 */

				ok_Hash.put("tUniqRow_3", false);
				start_Hash.put("tUniqRow_3", System.currentTimeMillis());

				currentComponent = "tUniqRow_3";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "Emotional_Status");

				int tos_count_tUniqRow_3 = 0;

				if (log.isDebugEnabled())
					log.debug("tUniqRow_3 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tUniqRow_3 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tUniqRow_3 = new StringBuilder();
							log4jParamters_tUniqRow_3.append("Parameters:");
							log4jParamters_tUniqRow_3.append("UNIQUE_KEY" + " = " + "[{CASE_SENSITIVE=" + ("false")
									+ ", KEY_ATTRIBUTE=" + ("true") + ", SCHEMA_COLUMN=" + ("EMOTIONAL_STATUS") + "}]");
							log4jParamters_tUniqRow_3.append(" | ");
							log4jParamters_tUniqRow_3.append("ONLY_ONCE_EACH_DUPLICATED_KEY" + " = " + "false");
							log4jParamters_tUniqRow_3.append(" | ");
							log4jParamters_tUniqRow_3.append("IS_VIRTUAL_COMPONENT" + " = " + "false");
							log4jParamters_tUniqRow_3.append(" | ");
							log4jParamters_tUniqRow_3.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "false");
							log4jParamters_tUniqRow_3.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tUniqRow_3 - " + (log4jParamters_tUniqRow_3));
						}
					}
					new BytesLimit65535_tUniqRow_3().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tUniqRow_3", "tUniqRow_3", "tUniqRow");
					talendJobLogProcess(globalMap);
				}

				class KeyStruct_tUniqRow_3 {

					private static final int DEFAULT_HASHCODE = 1;
					private static final int PRIME = 31;
					private int hashCode = DEFAULT_HASHCODE;
					public boolean hashCodeDirty = true;

					String EMOTIONAL_STATUS;

					@Override
					public int hashCode() {
						if (this.hashCodeDirty) {
							final int prime = PRIME;
							int result = DEFAULT_HASHCODE;

							result = prime * result
									+ ((this.EMOTIONAL_STATUS == null) ? 0 : this.EMOTIONAL_STATUS.hashCode());

							this.hashCode = result;
							this.hashCodeDirty = false;
						}
						return this.hashCode;
					}

					@Override
					public boolean equals(Object obj) {
						if (this == obj)
							return true;
						if (obj == null)
							return false;
						if (getClass() != obj.getClass())
							return false;
						final KeyStruct_tUniqRow_3 other = (KeyStruct_tUniqRow_3) obj;

						if (this.EMOTIONAL_STATUS == null) {
							if (other.EMOTIONAL_STATUS != null)
								return false;

						} else if (!this.EMOTIONAL_STATUS.equals(other.EMOTIONAL_STATUS))

							return false;

						return true;
					}

				}

				int nb_uniques_tUniqRow_3 = 0;
				int nb_duplicates_tUniqRow_3 = 0;
				log.debug("tUniqRow_3 - Start to process the data from datasource.");
				KeyStruct_tUniqRow_3 finder_tUniqRow_3 = new KeyStruct_tUniqRow_3();
				java.util.Set<KeyStruct_tUniqRow_3> keystUniqRow_3 = new java.util.HashSet<KeyStruct_tUniqRow_3>();

				/**
				 * [tUniqRow_3 begin ] stop
				 */

				/**
				 * [tDBOutput_4 begin ] start
				 */

				ok_Hash.put("tDBOutput_4", false);
				start_Hash.put("tDBOutput_4", System.currentTimeMillis());

				currentComponent = "tDBOutput_4";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "Ejection_Load");

				int tos_count_tDBOutput_4 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBOutput_4 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tDBOutput_4 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tDBOutput_4 = new StringBuilder();
							log4jParamters_tDBOutput_4.append("Parameters:");
							log4jParamters_tDBOutput_4.append("USE_EXISTING_CONNECTION" + " = " + "false");
							log4jParamters_tDBOutput_4.append(" | ");
							log4jParamters_tDBOutput_4.append("DRIVER" + " = " + "JTDS");
							log4jParamters_tDBOutput_4.append(" | ");
							log4jParamters_tDBOutput_4.append("HOST" + " = " + "\"localhost\"");
							log4jParamters_tDBOutput_4.append(" | ");
							log4jParamters_tDBOutput_4.append("PORT" + " = " + "\"1433\"");
							log4jParamters_tDBOutput_4.append(" | ");
							log4jParamters_tDBOutput_4.append("DB_SCHEMA" + " = " + "\"\"");
							log4jParamters_tDBOutput_4.append(" | ");
							log4jParamters_tDBOutput_4.append("DBNAME" + " = " + "\"MVC_Stage\"");
							log4jParamters_tDBOutput_4.append(" | ");
							log4jParamters_tDBOutput_4.append("USER" + " = " + "\"\"");
							log4jParamters_tDBOutput_4.append(" | ");
							log4jParamters_tDBOutput_4.append("PASS" + " = "
									+ String.valueOf(
											"enc:routine.encryption.key.v1:RzSapQFtu719I9WHANSyF/7fxida5AoR426Zrw==")
											.substring(0, 4)
									+ "...");
							log4jParamters_tDBOutput_4.append(" | ");
							log4jParamters_tDBOutput_4.append("TABLE" + " = " + "\"Dim_EJECTION\"");
							log4jParamters_tDBOutput_4.append(" | ");
							log4jParamters_tDBOutput_4.append("TABLE_ACTION" + " = " + "NONE");
							log4jParamters_tDBOutput_4.append(" | ");
							log4jParamters_tDBOutput_4.append("IDENTITY_INSERT" + " = " + "false");
							log4jParamters_tDBOutput_4.append(" | ");
							log4jParamters_tDBOutput_4.append("DATA_ACTION" + " = " + "INSERT");
							log4jParamters_tDBOutput_4.append(" | ");
							log4jParamters_tDBOutput_4.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
							log4jParamters_tDBOutput_4.append(" | ");
							log4jParamters_tDBOutput_4.append("DIE_ON_ERROR" + " = " + "false");
							log4jParamters_tDBOutput_4.append(" | ");
							log4jParamters_tDBOutput_4.append("PROPERTIES" + " = " + "\"\"");
							log4jParamters_tDBOutput_4.append(" | ");
							log4jParamters_tDBOutput_4.append("COMMIT_EVERY" + " = " + "10000");
							log4jParamters_tDBOutput_4.append(" | ");
							log4jParamters_tDBOutput_4.append("ADD_COLS" + " = " + "[]");
							log4jParamters_tDBOutput_4.append(" | ");
							log4jParamters_tDBOutput_4.append("USE_FIELD_OPTIONS" + " = " + "false");
							log4jParamters_tDBOutput_4.append(" | ");
							log4jParamters_tDBOutput_4.append("IGNORE_DATE_OUTOF_RANGE" + " = " + "false");
							log4jParamters_tDBOutput_4.append(" | ");
							log4jParamters_tDBOutput_4.append("ENABLE_DEBUG_MODE" + " = " + "false");
							log4jParamters_tDBOutput_4.append(" | ");
							log4jParamters_tDBOutput_4.append("SUPPORT_NULL_WHERE" + " = " + "false");
							log4jParamters_tDBOutput_4.append(" | ");
							log4jParamters_tDBOutput_4.append("USE_BATCH_SIZE" + " = " + "true");
							log4jParamters_tDBOutput_4.append(" | ");
							log4jParamters_tDBOutput_4.append("BATCH_SIZE" + " = " + "10000");
							log4jParamters_tDBOutput_4.append(" | ");
							log4jParamters_tDBOutput_4.append("UNIFIED_COMPONENTS" + " = " + "tMSSqlOutput");
							log4jParamters_tDBOutput_4.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tDBOutput_4 - " + (log4jParamters_tDBOutput_4));
						}
					}
					new BytesLimit65535_tDBOutput_4().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tDBOutput_4", "__TABLE__", "tMSSqlOutput");
					talendJobLogProcess(globalMap);
				}

				int nb_line_tDBOutput_4 = 0;
				int nb_line_update_tDBOutput_4 = 0;
				int nb_line_inserted_tDBOutput_4 = 0;
				int nb_line_deleted_tDBOutput_4 = 0;
				int nb_line_rejected_tDBOutput_4 = 0;

				int deletedCount_tDBOutput_4 = 0;
				int updatedCount_tDBOutput_4 = 0;
				int insertedCount_tDBOutput_4 = 0;
				int rowsToCommitCount_tDBOutput_4 = 0;
				int rejectedCount_tDBOutput_4 = 0;
				String dbschema_tDBOutput_4 = null;
				String tableName_tDBOutput_4 = null;
				boolean whetherReject_tDBOutput_4 = false;

				java.util.Calendar calendar_tDBOutput_4 = java.util.Calendar.getInstance();
				long year1_tDBOutput_4 = TalendDate.parseDate("yyyy-MM-dd", "0001-01-01").getTime();
				long year2_tDBOutput_4 = TalendDate.parseDate("yyyy-MM-dd", "1753-01-01").getTime();
				long year10000_tDBOutput_4 = TalendDate.parseDate("yyyy-MM-dd HH:mm:ss", "9999-12-31 24:00:00")
						.getTime();
				long date_tDBOutput_4;

				java.util.Calendar calendar_datetimeoffset_tDBOutput_4 = java.util.Calendar
						.getInstance(java.util.TimeZone.getTimeZone("UTC"));

				java.sql.Connection conn_tDBOutput_4 = null;
				String dbUser_tDBOutput_4 = null;
				dbschema_tDBOutput_4 = "";
				String driverClass_tDBOutput_4 = "net.sourceforge.jtds.jdbc.Driver";

				if (log.isDebugEnabled())
					log.debug("tDBOutput_4 - " + ("Driver ClassName: ") + (driverClass_tDBOutput_4) + ("."));
				java.lang.Class.forName(driverClass_tDBOutput_4);
				String port_tDBOutput_4 = "1433";
				String dbname_tDBOutput_4 = "MVC_Stage";
				String url_tDBOutput_4 = "jdbc:jtds:sqlserver://" + "localhost";
				if (!"".equals(port_tDBOutput_4)) {
					url_tDBOutput_4 += ":" + "1433";
				}
				if (!"".equals(dbname_tDBOutput_4)) {
					url_tDBOutput_4 += "//" + "MVC_Stage";

				}
				url_tDBOutput_4 += ";appName=" + projectName + ";" + "";
				dbUser_tDBOutput_4 = "";

				final String decryptedPassword_tDBOutput_4 = routines.system.PasswordEncryptUtil
						.decryptPassword("enc:routine.encryption.key.v1:fbNEssIS4xk85s436bcYNVGXY4lHMKg00+/T7g==");

				String dbPwd_tDBOutput_4 = decryptedPassword_tDBOutput_4;
				if (log.isDebugEnabled())
					log.debug("tDBOutput_4 - " + ("Connection attempts to '") + (url_tDBOutput_4)
							+ ("' with the username '") + (dbUser_tDBOutput_4) + ("'."));
				conn_tDBOutput_4 = java.sql.DriverManager.getConnection(url_tDBOutput_4, dbUser_tDBOutput_4,
						dbPwd_tDBOutput_4);
				if (log.isDebugEnabled())
					log.debug("tDBOutput_4 - " + ("Connection to '") + (url_tDBOutput_4) + ("' has succeeded."));

				resourceMap.put("conn_tDBOutput_4", conn_tDBOutput_4);

				conn_tDBOutput_4.setAutoCommit(false);
				int commitEvery_tDBOutput_4 = 10000;
				int commitCounter_tDBOutput_4 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBOutput_4 - " + ("Connection is set auto commit to '")
							+ (conn_tDBOutput_4.getAutoCommit()) + ("'."));
				int batchSize_tDBOutput_4 = 10000;
				int batchSizeCounter_tDBOutput_4 = 0;

				if (dbschema_tDBOutput_4 == null || dbschema_tDBOutput_4.trim().length() == 0) {
					tableName_tDBOutput_4 = "Dim_EJECTION";
				} else {
					tableName_tDBOutput_4 = dbschema_tDBOutput_4 + "].[" + "Dim_EJECTION";
				}
				int count_tDBOutput_4 = 0;

				String insert_tDBOutput_4 = "INSERT INTO [" + tableName_tDBOutput_4
						+ "] ([EJECTION_SK],[EJECTION],[DI_PID],[DI_Create_Date]) VALUES (?,?,?,?)";
				java.sql.PreparedStatement pstmt_tDBOutput_4 = conn_tDBOutput_4.prepareStatement(insert_tDBOutput_4);
				resourceMap.put("pstmt_tDBOutput_4", pstmt_tDBOutput_4);

				/**
				 * [tDBOutput_4 begin ] stop
				 */

				/**
				 * [tMap_6 begin ] start
				 */

				ok_Hash.put("tMap_6", false);
				start_Hash.put("tMap_6", System.currentTimeMillis());

				currentComponent = "tMap_6";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "row5");

				int tos_count_tMap_6 = 0;

				if (log.isDebugEnabled())
					log.debug("tMap_6 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tMap_6 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tMap_6 = new StringBuilder();
							log4jParamters_tMap_6.append("Parameters:");
							log4jParamters_tMap_6.append("LINK_STYLE" + " = " + "AUTO");
							log4jParamters_tMap_6.append(" | ");
							log4jParamters_tMap_6.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
							log4jParamters_tMap_6.append(" | ");
							log4jParamters_tMap_6.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
							log4jParamters_tMap_6.append(" | ");
							log4jParamters_tMap_6.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "true");
							log4jParamters_tMap_6.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tMap_6 - " + (log4jParamters_tMap_6));
						}
					}
					new BytesLimit65535_tMap_6().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tMap_6", "tMap_6", "tMap");
					talendJobLogProcess(globalMap);
				}

// ###############################
// # Lookup's keys initialization
				int count_row5_tMap_6 = 0;

// ###############################        

// ###############################
// # Vars initialization
				class Var__tMap_6__Struct {
				}
				Var__tMap_6__Struct Var__tMap_6 = new Var__tMap_6__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_Ejection_Load_tMap_6 = 0;

				Ejection_LoadStruct Ejection_Load_tmp = new Ejection_LoadStruct();
// ###############################

				/**
				 * [tMap_6 begin ] stop
				 */

				/**
				 * [tUniqRow_5 begin ] start
				 */

				ok_Hash.put("tUniqRow_5", false);
				start_Hash.put("tUniqRow_5", System.currentTimeMillis());

				currentComponent = "tUniqRow_5";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "Ejection");

				int tos_count_tUniqRow_5 = 0;

				if (log.isDebugEnabled())
					log.debug("tUniqRow_5 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tUniqRow_5 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tUniqRow_5 = new StringBuilder();
							log4jParamters_tUniqRow_5.append("Parameters:");
							log4jParamters_tUniqRow_5.append("UNIQUE_KEY" + " = " + "[{CASE_SENSITIVE=" + ("false")
									+ ", KEY_ATTRIBUTE=" + ("true") + ", SCHEMA_COLUMN=" + ("EJECTION") + "}]");
							log4jParamters_tUniqRow_5.append(" | ");
							log4jParamters_tUniqRow_5.append("ONLY_ONCE_EACH_DUPLICATED_KEY" + " = " + "false");
							log4jParamters_tUniqRow_5.append(" | ");
							log4jParamters_tUniqRow_5.append("IS_VIRTUAL_COMPONENT" + " = " + "false");
							log4jParamters_tUniqRow_5.append(" | ");
							log4jParamters_tUniqRow_5.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "false");
							log4jParamters_tUniqRow_5.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tUniqRow_5 - " + (log4jParamters_tUniqRow_5));
						}
					}
					new BytesLimit65535_tUniqRow_5().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tUniqRow_5", "tUniqRow_5", "tUniqRow");
					talendJobLogProcess(globalMap);
				}

				class KeyStruct_tUniqRow_5 {

					private static final int DEFAULT_HASHCODE = 1;
					private static final int PRIME = 31;
					private int hashCode = DEFAULT_HASHCODE;
					public boolean hashCodeDirty = true;

					String EJECTION;

					@Override
					public int hashCode() {
						if (this.hashCodeDirty) {
							final int prime = PRIME;
							int result = DEFAULT_HASHCODE;

							result = prime * result + ((this.EJECTION == null) ? 0 : this.EJECTION.hashCode());

							this.hashCode = result;
							this.hashCodeDirty = false;
						}
						return this.hashCode;
					}

					@Override
					public boolean equals(Object obj) {
						if (this == obj)
							return true;
						if (obj == null)
							return false;
						if (getClass() != obj.getClass())
							return false;
						final KeyStruct_tUniqRow_5 other = (KeyStruct_tUniqRow_5) obj;

						if (this.EJECTION == null) {
							if (other.EJECTION != null)
								return false;

						} else if (!this.EJECTION.equals(other.EJECTION))

							return false;

						return true;
					}

				}

				int nb_uniques_tUniqRow_5 = 0;
				int nb_duplicates_tUniqRow_5 = 0;
				log.debug("tUniqRow_5 - Start to process the data from datasource.");
				KeyStruct_tUniqRow_5 finder_tUniqRow_5 = new KeyStruct_tUniqRow_5();
				java.util.Set<KeyStruct_tUniqRow_5> keystUniqRow_5 = new java.util.HashSet<KeyStruct_tUniqRow_5>();

				/**
				 * [tUniqRow_5 begin ] stop
				 */

				/**
				 * [tDBOutput_5 begin ] start
				 */

				ok_Hash.put("tDBOutput_5", false);
				start_Hash.put("tDBOutput_5", System.currentTimeMillis());

				currentComponent = "tDBOutput_5";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "Bodily_load");

				int tos_count_tDBOutput_5 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBOutput_5 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tDBOutput_5 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tDBOutput_5 = new StringBuilder();
							log4jParamters_tDBOutput_5.append("Parameters:");
							log4jParamters_tDBOutput_5.append("USE_EXISTING_CONNECTION" + " = " + "false");
							log4jParamters_tDBOutput_5.append(" | ");
							log4jParamters_tDBOutput_5.append("DRIVER" + " = " + "JTDS");
							log4jParamters_tDBOutput_5.append(" | ");
							log4jParamters_tDBOutput_5.append("HOST" + " = " + "\"localhost\"");
							log4jParamters_tDBOutput_5.append(" | ");
							log4jParamters_tDBOutput_5.append("PORT" + " = " + "\"1433\"");
							log4jParamters_tDBOutput_5.append(" | ");
							log4jParamters_tDBOutput_5.append("DB_SCHEMA" + " = " + "\"\"");
							log4jParamters_tDBOutput_5.append(" | ");
							log4jParamters_tDBOutput_5.append("DBNAME" + " = " + "\"MVC_Stage\"");
							log4jParamters_tDBOutput_5.append(" | ");
							log4jParamters_tDBOutput_5.append("USER" + " = " + "\"\"");
							log4jParamters_tDBOutput_5.append(" | ");
							log4jParamters_tDBOutput_5.append("PASS" + " = "
									+ String.valueOf(
											"enc:routine.encryption.key.v1:o2wIY+VCu1p9DEWQ9rZ5t1tb2FEUQuWUJGrNVg==")
											.substring(0, 4)
									+ "...");
							log4jParamters_tDBOutput_5.append(" | ");
							log4jParamters_tDBOutput_5.append("TABLE" + " = " + "\"Dim_BODILY_INJURY\"");
							log4jParamters_tDBOutput_5.append(" | ");
							log4jParamters_tDBOutput_5.append("TABLE_ACTION" + " = " + "NONE");
							log4jParamters_tDBOutput_5.append(" | ");
							log4jParamters_tDBOutput_5.append("IDENTITY_INSERT" + " = " + "false");
							log4jParamters_tDBOutput_5.append(" | ");
							log4jParamters_tDBOutput_5.append("DATA_ACTION" + " = " + "INSERT");
							log4jParamters_tDBOutput_5.append(" | ");
							log4jParamters_tDBOutput_5.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
							log4jParamters_tDBOutput_5.append(" | ");
							log4jParamters_tDBOutput_5.append("DIE_ON_ERROR" + " = " + "false");
							log4jParamters_tDBOutput_5.append(" | ");
							log4jParamters_tDBOutput_5.append("PROPERTIES" + " = " + "\"\"");
							log4jParamters_tDBOutput_5.append(" | ");
							log4jParamters_tDBOutput_5.append("COMMIT_EVERY" + " = " + "10000");
							log4jParamters_tDBOutput_5.append(" | ");
							log4jParamters_tDBOutput_5.append("ADD_COLS" + " = " + "[]");
							log4jParamters_tDBOutput_5.append(" | ");
							log4jParamters_tDBOutput_5.append("USE_FIELD_OPTIONS" + " = " + "false");
							log4jParamters_tDBOutput_5.append(" | ");
							log4jParamters_tDBOutput_5.append("IGNORE_DATE_OUTOF_RANGE" + " = " + "false");
							log4jParamters_tDBOutput_5.append(" | ");
							log4jParamters_tDBOutput_5.append("ENABLE_DEBUG_MODE" + " = " + "false");
							log4jParamters_tDBOutput_5.append(" | ");
							log4jParamters_tDBOutput_5.append("SUPPORT_NULL_WHERE" + " = " + "false");
							log4jParamters_tDBOutput_5.append(" | ");
							log4jParamters_tDBOutput_5.append("USE_BATCH_SIZE" + " = " + "true");
							log4jParamters_tDBOutput_5.append(" | ");
							log4jParamters_tDBOutput_5.append("BATCH_SIZE" + " = " + "10000");
							log4jParamters_tDBOutput_5.append(" | ");
							log4jParamters_tDBOutput_5.append("UNIFIED_COMPONENTS" + " = " + "tMSSqlOutput");
							log4jParamters_tDBOutput_5.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tDBOutput_5 - " + (log4jParamters_tDBOutput_5));
						}
					}
					new BytesLimit65535_tDBOutput_5().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tDBOutput_5", "__TABLE__", "tMSSqlOutput");
					talendJobLogProcess(globalMap);
				}

				int nb_line_tDBOutput_5 = 0;
				int nb_line_update_tDBOutput_5 = 0;
				int nb_line_inserted_tDBOutput_5 = 0;
				int nb_line_deleted_tDBOutput_5 = 0;
				int nb_line_rejected_tDBOutput_5 = 0;

				int deletedCount_tDBOutput_5 = 0;
				int updatedCount_tDBOutput_5 = 0;
				int insertedCount_tDBOutput_5 = 0;
				int rowsToCommitCount_tDBOutput_5 = 0;
				int rejectedCount_tDBOutput_5 = 0;
				String dbschema_tDBOutput_5 = null;
				String tableName_tDBOutput_5 = null;
				boolean whetherReject_tDBOutput_5 = false;

				java.util.Calendar calendar_tDBOutput_5 = java.util.Calendar.getInstance();
				long year1_tDBOutput_5 = TalendDate.parseDate("yyyy-MM-dd", "0001-01-01").getTime();
				long year2_tDBOutput_5 = TalendDate.parseDate("yyyy-MM-dd", "1753-01-01").getTime();
				long year10000_tDBOutput_5 = TalendDate.parseDate("yyyy-MM-dd HH:mm:ss", "9999-12-31 24:00:00")
						.getTime();
				long date_tDBOutput_5;

				java.util.Calendar calendar_datetimeoffset_tDBOutput_5 = java.util.Calendar
						.getInstance(java.util.TimeZone.getTimeZone("UTC"));

				java.sql.Connection conn_tDBOutput_5 = null;
				String dbUser_tDBOutput_5 = null;
				dbschema_tDBOutput_5 = "";
				String driverClass_tDBOutput_5 = "net.sourceforge.jtds.jdbc.Driver";

				if (log.isDebugEnabled())
					log.debug("tDBOutput_5 - " + ("Driver ClassName: ") + (driverClass_tDBOutput_5) + ("."));
				java.lang.Class.forName(driverClass_tDBOutput_5);
				String port_tDBOutput_5 = "1433";
				String dbname_tDBOutput_5 = "MVC_Stage";
				String url_tDBOutput_5 = "jdbc:jtds:sqlserver://" + "localhost";
				if (!"".equals(port_tDBOutput_5)) {
					url_tDBOutput_5 += ":" + "1433";
				}
				if (!"".equals(dbname_tDBOutput_5)) {
					url_tDBOutput_5 += "//" + "MVC_Stage";

				}
				url_tDBOutput_5 += ";appName=" + projectName + ";" + "";
				dbUser_tDBOutput_5 = "";

				final String decryptedPassword_tDBOutput_5 = routines.system.PasswordEncryptUtil
						.decryptPassword("enc:routine.encryption.key.v1:8i1LT5aESY4XsCyWhAZJf46/IVPGifomNWaebA==");

				String dbPwd_tDBOutput_5 = decryptedPassword_tDBOutput_5;
				if (log.isDebugEnabled())
					log.debug("tDBOutput_5 - " + ("Connection attempts to '") + (url_tDBOutput_5)
							+ ("' with the username '") + (dbUser_tDBOutput_5) + ("'."));
				conn_tDBOutput_5 = java.sql.DriverManager.getConnection(url_tDBOutput_5, dbUser_tDBOutput_5,
						dbPwd_tDBOutput_5);
				if (log.isDebugEnabled())
					log.debug("tDBOutput_5 - " + ("Connection to '") + (url_tDBOutput_5) + ("' has succeeded."));

				resourceMap.put("conn_tDBOutput_5", conn_tDBOutput_5);

				conn_tDBOutput_5.setAutoCommit(false);
				int commitEvery_tDBOutput_5 = 10000;
				int commitCounter_tDBOutput_5 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBOutput_5 - " + ("Connection is set auto commit to '")
							+ (conn_tDBOutput_5.getAutoCommit()) + ("'."));
				int batchSize_tDBOutput_5 = 10000;
				int batchSizeCounter_tDBOutput_5 = 0;

				if (dbschema_tDBOutput_5 == null || dbschema_tDBOutput_5.trim().length() == 0) {
					tableName_tDBOutput_5 = "Dim_BODILY_INJURY";
				} else {
					tableName_tDBOutput_5 = dbschema_tDBOutput_5 + "].[" + "Dim_BODILY_INJURY";
				}
				int count_tDBOutput_5 = 0;

				String insert_tDBOutput_5 = "INSERT INTO [" + tableName_tDBOutput_5
						+ "] ([BODILY_INJURY_SK],[BODILY_INJURY],[DI_PID],[DI_Create_Date]) VALUES (?,?,?,?)";
				java.sql.PreparedStatement pstmt_tDBOutput_5 = conn_tDBOutput_5.prepareStatement(insert_tDBOutput_5);
				resourceMap.put("pstmt_tDBOutput_5", pstmt_tDBOutput_5);

				/**
				 * [tDBOutput_5 begin ] stop
				 */

				/**
				 * [tMap_7 begin ] start
				 */

				ok_Hash.put("tMap_7", false);
				start_Hash.put("tMap_7", System.currentTimeMillis());

				currentComponent = "tMap_7";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "row6");

				int tos_count_tMap_7 = 0;

				if (log.isDebugEnabled())
					log.debug("tMap_7 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tMap_7 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tMap_7 = new StringBuilder();
							log4jParamters_tMap_7.append("Parameters:");
							log4jParamters_tMap_7.append("LINK_STYLE" + " = " + "AUTO");
							log4jParamters_tMap_7.append(" | ");
							log4jParamters_tMap_7.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
							log4jParamters_tMap_7.append(" | ");
							log4jParamters_tMap_7.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
							log4jParamters_tMap_7.append(" | ");
							log4jParamters_tMap_7.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "true");
							log4jParamters_tMap_7.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tMap_7 - " + (log4jParamters_tMap_7));
						}
					}
					new BytesLimit65535_tMap_7().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tMap_7", "tMap_7", "tMap");
					talendJobLogProcess(globalMap);
				}

// ###############################
// # Lookup's keys initialization
				int count_row6_tMap_7 = 0;

// ###############################        

// ###############################
// # Vars initialization
				class Var__tMap_7__Struct {
				}
				Var__tMap_7__Struct Var__tMap_7 = new Var__tMap_7__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_Bodily_load_tMap_7 = 0;

				Bodily_loadStruct Bodily_load_tmp = new Bodily_loadStruct();
// ###############################

				/**
				 * [tMap_7 begin ] stop
				 */

				/**
				 * [tUniqRow_7 begin ] start
				 */

				ok_Hash.put("tUniqRow_7", false);
				start_Hash.put("tUniqRow_7", System.currentTimeMillis());

				currentComponent = "tUniqRow_7";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "Bodily_Injury");

				int tos_count_tUniqRow_7 = 0;

				if (log.isDebugEnabled())
					log.debug("tUniqRow_7 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tUniqRow_7 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tUniqRow_7 = new StringBuilder();
							log4jParamters_tUniqRow_7.append("Parameters:");
							log4jParamters_tUniqRow_7.append("UNIQUE_KEY" + " = " + "[{CASE_SENSITIVE=" + ("false")
									+ ", KEY_ATTRIBUTE=" + ("true") + ", SCHEMA_COLUMN=" + ("BODILY_INJURY") + "}]");
							log4jParamters_tUniqRow_7.append(" | ");
							log4jParamters_tUniqRow_7.append("ONLY_ONCE_EACH_DUPLICATED_KEY" + " = " + "false");
							log4jParamters_tUniqRow_7.append(" | ");
							log4jParamters_tUniqRow_7.append("IS_VIRTUAL_COMPONENT" + " = " + "false");
							log4jParamters_tUniqRow_7.append(" | ");
							log4jParamters_tUniqRow_7.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "false");
							log4jParamters_tUniqRow_7.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tUniqRow_7 - " + (log4jParamters_tUniqRow_7));
						}
					}
					new BytesLimit65535_tUniqRow_7().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tUniqRow_7", "tUniqRow_7", "tUniqRow");
					talendJobLogProcess(globalMap);
				}

				class KeyStruct_tUniqRow_7 {

					private static final int DEFAULT_HASHCODE = 1;
					private static final int PRIME = 31;
					private int hashCode = DEFAULT_HASHCODE;
					public boolean hashCodeDirty = true;

					String BODILY_INJURY;

					@Override
					public int hashCode() {
						if (this.hashCodeDirty) {
							final int prime = PRIME;
							int result = DEFAULT_HASHCODE;

							result = prime * result
									+ ((this.BODILY_INJURY == null) ? 0 : this.BODILY_INJURY.hashCode());

							this.hashCode = result;
							this.hashCodeDirty = false;
						}
						return this.hashCode;
					}

					@Override
					public boolean equals(Object obj) {
						if (this == obj)
							return true;
						if (obj == null)
							return false;
						if (getClass() != obj.getClass())
							return false;
						final KeyStruct_tUniqRow_7 other = (KeyStruct_tUniqRow_7) obj;

						if (this.BODILY_INJURY == null) {
							if (other.BODILY_INJURY != null)
								return false;

						} else if (!this.BODILY_INJURY.equals(other.BODILY_INJURY))

							return false;

						return true;
					}

				}

				int nb_uniques_tUniqRow_7 = 0;
				int nb_duplicates_tUniqRow_7 = 0;
				log.debug("tUniqRow_7 - Start to process the data from datasource.");
				KeyStruct_tUniqRow_7 finder_tUniqRow_7 = new KeyStruct_tUniqRow_7();
				java.util.Set<KeyStruct_tUniqRow_7> keystUniqRow_7 = new java.util.HashSet<KeyStruct_tUniqRow_7>();

				/**
				 * [tUniqRow_7 begin ] stop
				 */

				/**
				 * [tDBOutput_6 begin ] start
				 */

				ok_Hash.put("tDBOutput_6", false);
				start_Hash.put("tDBOutput_6", System.currentTimeMillis());

				currentComponent = "tDBOutput_6";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0,
						"Position_In_Vehicle1");

				int tos_count_tDBOutput_6 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBOutput_6 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tDBOutput_6 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tDBOutput_6 = new StringBuilder();
							log4jParamters_tDBOutput_6.append("Parameters:");
							log4jParamters_tDBOutput_6.append("USE_EXISTING_CONNECTION" + " = " + "false");
							log4jParamters_tDBOutput_6.append(" | ");
							log4jParamters_tDBOutput_6.append("DRIVER" + " = " + "JTDS");
							log4jParamters_tDBOutput_6.append(" | ");
							log4jParamters_tDBOutput_6.append("HOST" + " = " + "\"localhost\"");
							log4jParamters_tDBOutput_6.append(" | ");
							log4jParamters_tDBOutput_6.append("PORT" + " = " + "\"1433\"");
							log4jParamters_tDBOutput_6.append(" | ");
							log4jParamters_tDBOutput_6.append("DB_SCHEMA" + " = " + "\"\"");
							log4jParamters_tDBOutput_6.append(" | ");
							log4jParamters_tDBOutput_6.append("DBNAME" + " = " + "\"MVC_Stage\"");
							log4jParamters_tDBOutput_6.append(" | ");
							log4jParamters_tDBOutput_6.append("USER" + " = " + "\"\"");
							log4jParamters_tDBOutput_6.append(" | ");
							log4jParamters_tDBOutput_6.append("PASS" + " = "
									+ String.valueOf(
											"enc:routine.encryption.key.v1:h5ivnU/YYHRWrDCOoylJWdq+bFdNpfwpxjNjQw==")
											.substring(0, 4)
									+ "...");
							log4jParamters_tDBOutput_6.append(" | ");
							log4jParamters_tDBOutput_6.append("TABLE" + " = " + "\"Dim_POSITION_IN_VEHICLE\"");
							log4jParamters_tDBOutput_6.append(" | ");
							log4jParamters_tDBOutput_6.append("TABLE_ACTION" + " = " + "NONE");
							log4jParamters_tDBOutput_6.append(" | ");
							log4jParamters_tDBOutput_6.append("IDENTITY_INSERT" + " = " + "false");
							log4jParamters_tDBOutput_6.append(" | ");
							log4jParamters_tDBOutput_6.append("DATA_ACTION" + " = " + "INSERT");
							log4jParamters_tDBOutput_6.append(" | ");
							log4jParamters_tDBOutput_6.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
							log4jParamters_tDBOutput_6.append(" | ");
							log4jParamters_tDBOutput_6.append("DIE_ON_ERROR" + " = " + "false");
							log4jParamters_tDBOutput_6.append(" | ");
							log4jParamters_tDBOutput_6.append("PROPERTIES" + " = " + "\"\"");
							log4jParamters_tDBOutput_6.append(" | ");
							log4jParamters_tDBOutput_6.append("COMMIT_EVERY" + " = " + "10000");
							log4jParamters_tDBOutput_6.append(" | ");
							log4jParamters_tDBOutput_6.append("ADD_COLS" + " = " + "[]");
							log4jParamters_tDBOutput_6.append(" | ");
							log4jParamters_tDBOutput_6.append("USE_FIELD_OPTIONS" + " = " + "false");
							log4jParamters_tDBOutput_6.append(" | ");
							log4jParamters_tDBOutput_6.append("IGNORE_DATE_OUTOF_RANGE" + " = " + "false");
							log4jParamters_tDBOutput_6.append(" | ");
							log4jParamters_tDBOutput_6.append("ENABLE_DEBUG_MODE" + " = " + "false");
							log4jParamters_tDBOutput_6.append(" | ");
							log4jParamters_tDBOutput_6.append("SUPPORT_NULL_WHERE" + " = " + "false");
							log4jParamters_tDBOutput_6.append(" | ");
							log4jParamters_tDBOutput_6.append("USE_BATCH_SIZE" + " = " + "true");
							log4jParamters_tDBOutput_6.append(" | ");
							log4jParamters_tDBOutput_6.append("BATCH_SIZE" + " = " + "10000");
							log4jParamters_tDBOutput_6.append(" | ");
							log4jParamters_tDBOutput_6.append("UNIFIED_COMPONENTS" + " = " + "tMSSqlOutput");
							log4jParamters_tDBOutput_6.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tDBOutput_6 - " + (log4jParamters_tDBOutput_6));
						}
					}
					new BytesLimit65535_tDBOutput_6().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tDBOutput_6", "__TABLE__", "tMSSqlOutput");
					talendJobLogProcess(globalMap);
				}

				int nb_line_tDBOutput_6 = 0;
				int nb_line_update_tDBOutput_6 = 0;
				int nb_line_inserted_tDBOutput_6 = 0;
				int nb_line_deleted_tDBOutput_6 = 0;
				int nb_line_rejected_tDBOutput_6 = 0;

				int deletedCount_tDBOutput_6 = 0;
				int updatedCount_tDBOutput_6 = 0;
				int insertedCount_tDBOutput_6 = 0;
				int rowsToCommitCount_tDBOutput_6 = 0;
				int rejectedCount_tDBOutput_6 = 0;
				String dbschema_tDBOutput_6 = null;
				String tableName_tDBOutput_6 = null;
				boolean whetherReject_tDBOutput_6 = false;

				java.util.Calendar calendar_tDBOutput_6 = java.util.Calendar.getInstance();
				long year1_tDBOutput_6 = TalendDate.parseDate("yyyy-MM-dd", "0001-01-01").getTime();
				long year2_tDBOutput_6 = TalendDate.parseDate("yyyy-MM-dd", "1753-01-01").getTime();
				long year10000_tDBOutput_6 = TalendDate.parseDate("yyyy-MM-dd HH:mm:ss", "9999-12-31 24:00:00")
						.getTime();
				long date_tDBOutput_6;

				java.util.Calendar calendar_datetimeoffset_tDBOutput_6 = java.util.Calendar
						.getInstance(java.util.TimeZone.getTimeZone("UTC"));

				java.sql.Connection conn_tDBOutput_6 = null;
				String dbUser_tDBOutput_6 = null;
				dbschema_tDBOutput_6 = "";
				String driverClass_tDBOutput_6 = "net.sourceforge.jtds.jdbc.Driver";

				if (log.isDebugEnabled())
					log.debug("tDBOutput_6 - " + ("Driver ClassName: ") + (driverClass_tDBOutput_6) + ("."));
				java.lang.Class.forName(driverClass_tDBOutput_6);
				String port_tDBOutput_6 = "1433";
				String dbname_tDBOutput_6 = "MVC_Stage";
				String url_tDBOutput_6 = "jdbc:jtds:sqlserver://" + "localhost";
				if (!"".equals(port_tDBOutput_6)) {
					url_tDBOutput_6 += ":" + "1433";
				}
				if (!"".equals(dbname_tDBOutput_6)) {
					url_tDBOutput_6 += "//" + "MVC_Stage";

				}
				url_tDBOutput_6 += ";appName=" + projectName + ";" + "";
				dbUser_tDBOutput_6 = "";

				final String decryptedPassword_tDBOutput_6 = routines.system.PasswordEncryptUtil
						.decryptPassword("enc:routine.encryption.key.v1:/QK1ivaR+3fAoUz4jV7w9SR8+Hk5gLuY83gXDg==");

				String dbPwd_tDBOutput_6 = decryptedPassword_tDBOutput_6;
				if (log.isDebugEnabled())
					log.debug("tDBOutput_6 - " + ("Connection attempts to '") + (url_tDBOutput_6)
							+ ("' with the username '") + (dbUser_tDBOutput_6) + ("'."));
				conn_tDBOutput_6 = java.sql.DriverManager.getConnection(url_tDBOutput_6, dbUser_tDBOutput_6,
						dbPwd_tDBOutput_6);
				if (log.isDebugEnabled())
					log.debug("tDBOutput_6 - " + ("Connection to '") + (url_tDBOutput_6) + ("' has succeeded."));

				resourceMap.put("conn_tDBOutput_6", conn_tDBOutput_6);

				conn_tDBOutput_6.setAutoCommit(false);
				int commitEvery_tDBOutput_6 = 10000;
				int commitCounter_tDBOutput_6 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBOutput_6 - " + ("Connection is set auto commit to '")
							+ (conn_tDBOutput_6.getAutoCommit()) + ("'."));
				int batchSize_tDBOutput_6 = 10000;
				int batchSizeCounter_tDBOutput_6 = 0;

				if (dbschema_tDBOutput_6 == null || dbschema_tDBOutput_6.trim().length() == 0) {
					tableName_tDBOutput_6 = "Dim_POSITION_IN_VEHICLE";
				} else {
					tableName_tDBOutput_6 = dbschema_tDBOutput_6 + "].[" + "Dim_POSITION_IN_VEHICLE";
				}
				int count_tDBOutput_6 = 0;

				String insert_tDBOutput_6 = "INSERT INTO [" + tableName_tDBOutput_6
						+ "] ([POSITION_IN_VEHICLE_SK],[POSITION_IN_VEHICLE],[DI_PID],[DI_Create_Date]) VALUES (?,?,?,?)";
				java.sql.PreparedStatement pstmt_tDBOutput_6 = conn_tDBOutput_6.prepareStatement(insert_tDBOutput_6);
				resourceMap.put("pstmt_tDBOutput_6", pstmt_tDBOutput_6);

				/**
				 * [tDBOutput_6 begin ] stop
				 */

				/**
				 * [tMap_9 begin ] start
				 */

				ok_Hash.put("tMap_9", false);
				start_Hash.put("tMap_9", System.currentTimeMillis());

				currentComponent = "tMap_9";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "row7");

				int tos_count_tMap_9 = 0;

				if (log.isDebugEnabled())
					log.debug("tMap_9 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tMap_9 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tMap_9 = new StringBuilder();
							log4jParamters_tMap_9.append("Parameters:");
							log4jParamters_tMap_9.append("LINK_STYLE" + " = " + "AUTO");
							log4jParamters_tMap_9.append(" | ");
							log4jParamters_tMap_9.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
							log4jParamters_tMap_9.append(" | ");
							log4jParamters_tMap_9.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
							log4jParamters_tMap_9.append(" | ");
							log4jParamters_tMap_9.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "true");
							log4jParamters_tMap_9.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tMap_9 - " + (log4jParamters_tMap_9));
						}
					}
					new BytesLimit65535_tMap_9().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tMap_9", "tMap_9", "tMap");
					talendJobLogProcess(globalMap);
				}

// ###############################
// # Lookup's keys initialization
				int count_row7_tMap_9 = 0;

// ###############################        

// ###############################
// # Vars initialization
				class Var__tMap_9__Struct {
				}
				Var__tMap_9__Struct Var__tMap_9 = new Var__tMap_9__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_Position_In_Vehicle1_tMap_9 = 0;

				Position_In_Vehicle1Struct Position_In_Vehicle1_tmp = new Position_In_Vehicle1Struct();
// ###############################

				/**
				 * [tMap_9 begin ] stop
				 */

				/**
				 * [tUniqRow_4 begin ] start
				 */

				ok_Hash.put("tUniqRow_4", false);
				start_Hash.put("tUniqRow_4", System.currentTimeMillis());

				currentComponent = "tUniqRow_4";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "Position_In_vehicle");

				int tos_count_tUniqRow_4 = 0;

				if (log.isDebugEnabled())
					log.debug("tUniqRow_4 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tUniqRow_4 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tUniqRow_4 = new StringBuilder();
							log4jParamters_tUniqRow_4.append("Parameters:");
							log4jParamters_tUniqRow_4
									.append("UNIQUE_KEY" + " = " + "[{CASE_SENSITIVE=" + ("false") + ", KEY_ATTRIBUTE="
											+ ("true") + ", SCHEMA_COLUMN=" + ("POSITION_IN_VEHICLE") + "}]");
							log4jParamters_tUniqRow_4.append(" | ");
							log4jParamters_tUniqRow_4.append("ONLY_ONCE_EACH_DUPLICATED_KEY" + " = " + "false");
							log4jParamters_tUniqRow_4.append(" | ");
							log4jParamters_tUniqRow_4.append("IS_VIRTUAL_COMPONENT" + " = " + "false");
							log4jParamters_tUniqRow_4.append(" | ");
							log4jParamters_tUniqRow_4.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "false");
							log4jParamters_tUniqRow_4.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tUniqRow_4 - " + (log4jParamters_tUniqRow_4));
						}
					}
					new BytesLimit65535_tUniqRow_4().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tUniqRow_4", "tUniqRow_4", "tUniqRow");
					talendJobLogProcess(globalMap);
				}

				class KeyStruct_tUniqRow_4 {

					private static final int DEFAULT_HASHCODE = 1;
					private static final int PRIME = 31;
					private int hashCode = DEFAULT_HASHCODE;
					public boolean hashCodeDirty = true;

					String POSITION_IN_VEHICLE;

					@Override
					public int hashCode() {
						if (this.hashCodeDirty) {
							final int prime = PRIME;
							int result = DEFAULT_HASHCODE;

							result = prime * result
									+ ((this.POSITION_IN_VEHICLE == null) ? 0 : this.POSITION_IN_VEHICLE.hashCode());

							this.hashCode = result;
							this.hashCodeDirty = false;
						}
						return this.hashCode;
					}

					@Override
					public boolean equals(Object obj) {
						if (this == obj)
							return true;
						if (obj == null)
							return false;
						if (getClass() != obj.getClass())
							return false;
						final KeyStruct_tUniqRow_4 other = (KeyStruct_tUniqRow_4) obj;

						if (this.POSITION_IN_VEHICLE == null) {
							if (other.POSITION_IN_VEHICLE != null)
								return false;

						} else if (!this.POSITION_IN_VEHICLE.equals(other.POSITION_IN_VEHICLE))

							return false;

						return true;
					}

				}

				int nb_uniques_tUniqRow_4 = 0;
				int nb_duplicates_tUniqRow_4 = 0;
				log.debug("tUniqRow_4 - Start to process the data from datasource.");
				KeyStruct_tUniqRow_4 finder_tUniqRow_4 = new KeyStruct_tUniqRow_4();
				java.util.Set<KeyStruct_tUniqRow_4> keystUniqRow_4 = new java.util.HashSet<KeyStruct_tUniqRow_4>();

				/**
				 * [tUniqRow_4 begin ] stop
				 */

				/**
				 * [tDBOutput_7 begin ] start
				 */

				ok_Hash.put("tDBOutput_7", false);
				start_Hash.put("tDBOutput_7", System.currentTimeMillis());

				currentComponent = "tDBOutput_7";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "Safety_Equipment1");

				int tos_count_tDBOutput_7 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBOutput_7 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tDBOutput_7 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tDBOutput_7 = new StringBuilder();
							log4jParamters_tDBOutput_7.append("Parameters:");
							log4jParamters_tDBOutput_7.append("USE_EXISTING_CONNECTION" + " = " + "false");
							log4jParamters_tDBOutput_7.append(" | ");
							log4jParamters_tDBOutput_7.append("DRIVER" + " = " + "JTDS");
							log4jParamters_tDBOutput_7.append(" | ");
							log4jParamters_tDBOutput_7.append("HOST" + " = " + "\"localhost\"");
							log4jParamters_tDBOutput_7.append(" | ");
							log4jParamters_tDBOutput_7.append("PORT" + " = " + "\"1433\"");
							log4jParamters_tDBOutput_7.append(" | ");
							log4jParamters_tDBOutput_7.append("DB_SCHEMA" + " = " + "\"\"");
							log4jParamters_tDBOutput_7.append(" | ");
							log4jParamters_tDBOutput_7.append("DBNAME" + " = " + "\"MVC_Stage\"");
							log4jParamters_tDBOutput_7.append(" | ");
							log4jParamters_tDBOutput_7.append("USER" + " = " + "\"\"");
							log4jParamters_tDBOutput_7.append(" | ");
							log4jParamters_tDBOutput_7.append("PASS" + " = "
									+ String.valueOf(
											"enc:routine.encryption.key.v1:uD/ejLpIWDrfLAC1a6tt9+l9OfUcNLfYzBceQw==")
											.substring(0, 4)
									+ "...");
							log4jParamters_tDBOutput_7.append(" | ");
							log4jParamters_tDBOutput_7.append("TABLE" + " = " + "\"Dim_SAFETY_EQUIPMENT\"");
							log4jParamters_tDBOutput_7.append(" | ");
							log4jParamters_tDBOutput_7.append("TABLE_ACTION" + " = " + "NONE");
							log4jParamters_tDBOutput_7.append(" | ");
							log4jParamters_tDBOutput_7.append("IDENTITY_INSERT" + " = " + "false");
							log4jParamters_tDBOutput_7.append(" | ");
							log4jParamters_tDBOutput_7.append("DATA_ACTION" + " = " + "INSERT");
							log4jParamters_tDBOutput_7.append(" | ");
							log4jParamters_tDBOutput_7.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
							log4jParamters_tDBOutput_7.append(" | ");
							log4jParamters_tDBOutput_7.append("DIE_ON_ERROR" + " = " + "false");
							log4jParamters_tDBOutput_7.append(" | ");
							log4jParamters_tDBOutput_7.append("PROPERTIES" + " = " + "\"\"");
							log4jParamters_tDBOutput_7.append(" | ");
							log4jParamters_tDBOutput_7.append("COMMIT_EVERY" + " = " + "10000");
							log4jParamters_tDBOutput_7.append(" | ");
							log4jParamters_tDBOutput_7.append("ADD_COLS" + " = " + "[]");
							log4jParamters_tDBOutput_7.append(" | ");
							log4jParamters_tDBOutput_7.append("USE_FIELD_OPTIONS" + " = " + "false");
							log4jParamters_tDBOutput_7.append(" | ");
							log4jParamters_tDBOutput_7.append("IGNORE_DATE_OUTOF_RANGE" + " = " + "false");
							log4jParamters_tDBOutput_7.append(" | ");
							log4jParamters_tDBOutput_7.append("ENABLE_DEBUG_MODE" + " = " + "false");
							log4jParamters_tDBOutput_7.append(" | ");
							log4jParamters_tDBOutput_7.append("SUPPORT_NULL_WHERE" + " = " + "false");
							log4jParamters_tDBOutput_7.append(" | ");
							log4jParamters_tDBOutput_7.append("USE_BATCH_SIZE" + " = " + "true");
							log4jParamters_tDBOutput_7.append(" | ");
							log4jParamters_tDBOutput_7.append("BATCH_SIZE" + " = " + "10000");
							log4jParamters_tDBOutput_7.append(" | ");
							log4jParamters_tDBOutput_7.append("UNIFIED_COMPONENTS" + " = " + "tMSSqlOutput");
							log4jParamters_tDBOutput_7.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tDBOutput_7 - " + (log4jParamters_tDBOutput_7));
						}
					}
					new BytesLimit65535_tDBOutput_7().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tDBOutput_7", "__TABLE__", "tMSSqlOutput");
					talendJobLogProcess(globalMap);
				}

				int nb_line_tDBOutput_7 = 0;
				int nb_line_update_tDBOutput_7 = 0;
				int nb_line_inserted_tDBOutput_7 = 0;
				int nb_line_deleted_tDBOutput_7 = 0;
				int nb_line_rejected_tDBOutput_7 = 0;

				int deletedCount_tDBOutput_7 = 0;
				int updatedCount_tDBOutput_7 = 0;
				int insertedCount_tDBOutput_7 = 0;
				int rowsToCommitCount_tDBOutput_7 = 0;
				int rejectedCount_tDBOutput_7 = 0;
				String dbschema_tDBOutput_7 = null;
				String tableName_tDBOutput_7 = null;
				boolean whetherReject_tDBOutput_7 = false;

				java.util.Calendar calendar_tDBOutput_7 = java.util.Calendar.getInstance();
				long year1_tDBOutput_7 = TalendDate.parseDate("yyyy-MM-dd", "0001-01-01").getTime();
				long year2_tDBOutput_7 = TalendDate.parseDate("yyyy-MM-dd", "1753-01-01").getTime();
				long year10000_tDBOutput_7 = TalendDate.parseDate("yyyy-MM-dd HH:mm:ss", "9999-12-31 24:00:00")
						.getTime();
				long date_tDBOutput_7;

				java.util.Calendar calendar_datetimeoffset_tDBOutput_7 = java.util.Calendar
						.getInstance(java.util.TimeZone.getTimeZone("UTC"));

				java.sql.Connection conn_tDBOutput_7 = null;
				String dbUser_tDBOutput_7 = null;
				dbschema_tDBOutput_7 = "";
				String driverClass_tDBOutput_7 = "net.sourceforge.jtds.jdbc.Driver";

				if (log.isDebugEnabled())
					log.debug("tDBOutput_7 - " + ("Driver ClassName: ") + (driverClass_tDBOutput_7) + ("."));
				java.lang.Class.forName(driverClass_tDBOutput_7);
				String port_tDBOutput_7 = "1433";
				String dbname_tDBOutput_7 = "MVC_Stage";
				String url_tDBOutput_7 = "jdbc:jtds:sqlserver://" + "localhost";
				if (!"".equals(port_tDBOutput_7)) {
					url_tDBOutput_7 += ":" + "1433";
				}
				if (!"".equals(dbname_tDBOutput_7)) {
					url_tDBOutput_7 += "//" + "MVC_Stage";

				}
				url_tDBOutput_7 += ";appName=" + projectName + ";" + "";
				dbUser_tDBOutput_7 = "";

				final String decryptedPassword_tDBOutput_7 = routines.system.PasswordEncryptUtil
						.decryptPassword("enc:routine.encryption.key.v1:1BhpgnX1v677vwngqQ/al5lWA+jGa0U6X7I54w==");

				String dbPwd_tDBOutput_7 = decryptedPassword_tDBOutput_7;
				if (log.isDebugEnabled())
					log.debug("tDBOutput_7 - " + ("Connection attempts to '") + (url_tDBOutput_7)
							+ ("' with the username '") + (dbUser_tDBOutput_7) + ("'."));
				conn_tDBOutput_7 = java.sql.DriverManager.getConnection(url_tDBOutput_7, dbUser_tDBOutput_7,
						dbPwd_tDBOutput_7);
				if (log.isDebugEnabled())
					log.debug("tDBOutput_7 - " + ("Connection to '") + (url_tDBOutput_7) + ("' has succeeded."));

				resourceMap.put("conn_tDBOutput_7", conn_tDBOutput_7);

				conn_tDBOutput_7.setAutoCommit(false);
				int commitEvery_tDBOutput_7 = 10000;
				int commitCounter_tDBOutput_7 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBOutput_7 - " + ("Connection is set auto commit to '")
							+ (conn_tDBOutput_7.getAutoCommit()) + ("'."));
				int batchSize_tDBOutput_7 = 10000;
				int batchSizeCounter_tDBOutput_7 = 0;

				if (dbschema_tDBOutput_7 == null || dbschema_tDBOutput_7.trim().length() == 0) {
					tableName_tDBOutput_7 = "Dim_SAFETY_EQUIPMENT";
				} else {
					tableName_tDBOutput_7 = dbschema_tDBOutput_7 + "].[" + "Dim_SAFETY_EQUIPMENT";
				}
				int count_tDBOutput_7 = 0;

				String insert_tDBOutput_7 = "INSERT INTO [" + tableName_tDBOutput_7
						+ "] ([SAFETY_EQUIPMENT],[SAFETY_EQUIPMENT_SK],[DI_PID],[DI_Create_Date]) VALUES (?,?,?,?)";
				java.sql.PreparedStatement pstmt_tDBOutput_7 = conn_tDBOutput_7.prepareStatement(insert_tDBOutput_7);
				resourceMap.put("pstmt_tDBOutput_7", pstmt_tDBOutput_7);

				/**
				 * [tDBOutput_7 begin ] stop
				 */

				/**
				 * [tMap_10 begin ] start
				 */

				ok_Hash.put("tMap_10", false);
				start_Hash.put("tMap_10", System.currentTimeMillis());

				currentComponent = "tMap_10";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "row8");

				int tos_count_tMap_10 = 0;

				if (log.isDebugEnabled())
					log.debug("tMap_10 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tMap_10 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tMap_10 = new StringBuilder();
							log4jParamters_tMap_10.append("Parameters:");
							log4jParamters_tMap_10.append("LINK_STYLE" + " = " + "AUTO");
							log4jParamters_tMap_10.append(" | ");
							log4jParamters_tMap_10.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
							log4jParamters_tMap_10.append(" | ");
							log4jParamters_tMap_10.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
							log4jParamters_tMap_10.append(" | ");
							log4jParamters_tMap_10.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "true");
							log4jParamters_tMap_10.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tMap_10 - " + (log4jParamters_tMap_10));
						}
					}
					new BytesLimit65535_tMap_10().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tMap_10", "tMap_10", "tMap");
					talendJobLogProcess(globalMap);
				}

// ###############################
// # Lookup's keys initialization
				int count_row8_tMap_10 = 0;

// ###############################        

// ###############################
// # Vars initialization
				class Var__tMap_10__Struct {
				}
				Var__tMap_10__Struct Var__tMap_10 = new Var__tMap_10__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_Safety_Equipment1_tMap_10 = 0;

				Safety_Equipment1Struct Safety_Equipment1_tmp = new Safety_Equipment1Struct();
// ###############################

				/**
				 * [tMap_10 begin ] stop
				 */

				/**
				 * [tUniqRow_8 begin ] start
				 */

				ok_Hash.put("tUniqRow_8", false);
				start_Hash.put("tUniqRow_8", System.currentTimeMillis());

				currentComponent = "tUniqRow_8";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "Safety_Equipment");

				int tos_count_tUniqRow_8 = 0;

				if (log.isDebugEnabled())
					log.debug("tUniqRow_8 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tUniqRow_8 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tUniqRow_8 = new StringBuilder();
							log4jParamters_tUniqRow_8.append("Parameters:");
							log4jParamters_tUniqRow_8.append("UNIQUE_KEY" + " = " + "[{CASE_SENSITIVE=" + ("false")
									+ ", KEY_ATTRIBUTE=" + ("true") + ", SCHEMA_COLUMN=" + ("SAFETY_EQUIPMENT") + "}]");
							log4jParamters_tUniqRow_8.append(" | ");
							log4jParamters_tUniqRow_8.append("ONLY_ONCE_EACH_DUPLICATED_KEY" + " = " + "false");
							log4jParamters_tUniqRow_8.append(" | ");
							log4jParamters_tUniqRow_8.append("IS_VIRTUAL_COMPONENT" + " = " + "false");
							log4jParamters_tUniqRow_8.append(" | ");
							log4jParamters_tUniqRow_8.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "false");
							log4jParamters_tUniqRow_8.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tUniqRow_8 - " + (log4jParamters_tUniqRow_8));
						}
					}
					new BytesLimit65535_tUniqRow_8().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tUniqRow_8", "tUniqRow_8", "tUniqRow");
					talendJobLogProcess(globalMap);
				}

				class KeyStruct_tUniqRow_8 {

					private static final int DEFAULT_HASHCODE = 1;
					private static final int PRIME = 31;
					private int hashCode = DEFAULT_HASHCODE;
					public boolean hashCodeDirty = true;

					String SAFETY_EQUIPMENT;

					@Override
					public int hashCode() {
						if (this.hashCodeDirty) {
							final int prime = PRIME;
							int result = DEFAULT_HASHCODE;

							result = prime * result
									+ ((this.SAFETY_EQUIPMENT == null) ? 0 : this.SAFETY_EQUIPMENT.hashCode());

							this.hashCode = result;
							this.hashCodeDirty = false;
						}
						return this.hashCode;
					}

					@Override
					public boolean equals(Object obj) {
						if (this == obj)
							return true;
						if (obj == null)
							return false;
						if (getClass() != obj.getClass())
							return false;
						final KeyStruct_tUniqRow_8 other = (KeyStruct_tUniqRow_8) obj;

						if (this.SAFETY_EQUIPMENT == null) {
							if (other.SAFETY_EQUIPMENT != null)
								return false;

						} else if (!this.SAFETY_EQUIPMENT.equals(other.SAFETY_EQUIPMENT))

							return false;

						return true;
					}

				}

				int nb_uniques_tUniqRow_8 = 0;
				int nb_duplicates_tUniqRow_8 = 0;
				log.debug("tUniqRow_8 - Start to process the data from datasource.");
				KeyStruct_tUniqRow_8 finder_tUniqRow_8 = new KeyStruct_tUniqRow_8();
				java.util.Set<KeyStruct_tUniqRow_8> keystUniqRow_8 = new java.util.HashSet<KeyStruct_tUniqRow_8>();

				/**
				 * [tUniqRow_8 begin ] stop
				 */

				/**
				 * [tDBOutput_8 begin ] start
				 */

				ok_Hash.put("tDBOutput_8", false);
				start_Hash.put("tDBOutput_8", System.currentTimeMillis());

				currentComponent = "tDBOutput_8";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "Ped_Location_Load");

				int tos_count_tDBOutput_8 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBOutput_8 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tDBOutput_8 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tDBOutput_8 = new StringBuilder();
							log4jParamters_tDBOutput_8.append("Parameters:");
							log4jParamters_tDBOutput_8.append("USE_EXISTING_CONNECTION" + " = " + "false");
							log4jParamters_tDBOutput_8.append(" | ");
							log4jParamters_tDBOutput_8.append("DRIVER" + " = " + "JTDS");
							log4jParamters_tDBOutput_8.append(" | ");
							log4jParamters_tDBOutput_8.append("HOST" + " = " + "\"localhost\"");
							log4jParamters_tDBOutput_8.append(" | ");
							log4jParamters_tDBOutput_8.append("PORT" + " = " + "\"1433\"");
							log4jParamters_tDBOutput_8.append(" | ");
							log4jParamters_tDBOutput_8.append("DB_SCHEMA" + " = " + "\"\"");
							log4jParamters_tDBOutput_8.append(" | ");
							log4jParamters_tDBOutput_8.append("DBNAME" + " = " + "\"MVC_Stage\"");
							log4jParamters_tDBOutput_8.append(" | ");
							log4jParamters_tDBOutput_8.append("USER" + " = " + "\"\"");
							log4jParamters_tDBOutput_8.append(" | ");
							log4jParamters_tDBOutput_8.append("PASS" + " = "
									+ String.valueOf(
											"enc:routine.encryption.key.v1:glrXUe4YMO/qB6ucctJbXAZrLHYVxUwU+aFJNA==")
											.substring(0, 4)
									+ "...");
							log4jParamters_tDBOutput_8.append(" | ");
							log4jParamters_tDBOutput_8.append("TABLE" + " = " + "\"Dim_PED_LOCATION\"");
							log4jParamters_tDBOutput_8.append(" | ");
							log4jParamters_tDBOutput_8.append("TABLE_ACTION" + " = " + "NONE");
							log4jParamters_tDBOutput_8.append(" | ");
							log4jParamters_tDBOutput_8.append("IDENTITY_INSERT" + " = " + "false");
							log4jParamters_tDBOutput_8.append(" | ");
							log4jParamters_tDBOutput_8.append("DATA_ACTION" + " = " + "INSERT");
							log4jParamters_tDBOutput_8.append(" | ");
							log4jParamters_tDBOutput_8.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
							log4jParamters_tDBOutput_8.append(" | ");
							log4jParamters_tDBOutput_8.append("DIE_ON_ERROR" + " = " + "false");
							log4jParamters_tDBOutput_8.append(" | ");
							log4jParamters_tDBOutput_8.append("PROPERTIES" + " = " + "\"\"");
							log4jParamters_tDBOutput_8.append(" | ");
							log4jParamters_tDBOutput_8.append("COMMIT_EVERY" + " = " + "10000");
							log4jParamters_tDBOutput_8.append(" | ");
							log4jParamters_tDBOutput_8.append("ADD_COLS" + " = " + "[]");
							log4jParamters_tDBOutput_8.append(" | ");
							log4jParamters_tDBOutput_8.append("USE_FIELD_OPTIONS" + " = " + "false");
							log4jParamters_tDBOutput_8.append(" | ");
							log4jParamters_tDBOutput_8.append("IGNORE_DATE_OUTOF_RANGE" + " = " + "false");
							log4jParamters_tDBOutput_8.append(" | ");
							log4jParamters_tDBOutput_8.append("ENABLE_DEBUG_MODE" + " = " + "false");
							log4jParamters_tDBOutput_8.append(" | ");
							log4jParamters_tDBOutput_8.append("SUPPORT_NULL_WHERE" + " = " + "false");
							log4jParamters_tDBOutput_8.append(" | ");
							log4jParamters_tDBOutput_8.append("USE_BATCH_SIZE" + " = " + "true");
							log4jParamters_tDBOutput_8.append(" | ");
							log4jParamters_tDBOutput_8.append("BATCH_SIZE" + " = " + "10000");
							log4jParamters_tDBOutput_8.append(" | ");
							log4jParamters_tDBOutput_8.append("UNIFIED_COMPONENTS" + " = " + "tMSSqlOutput");
							log4jParamters_tDBOutput_8.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tDBOutput_8 - " + (log4jParamters_tDBOutput_8));
						}
					}
					new BytesLimit65535_tDBOutput_8().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tDBOutput_8", "__TABLE__", "tMSSqlOutput");
					talendJobLogProcess(globalMap);
				}

				int nb_line_tDBOutput_8 = 0;
				int nb_line_update_tDBOutput_8 = 0;
				int nb_line_inserted_tDBOutput_8 = 0;
				int nb_line_deleted_tDBOutput_8 = 0;
				int nb_line_rejected_tDBOutput_8 = 0;

				int deletedCount_tDBOutput_8 = 0;
				int updatedCount_tDBOutput_8 = 0;
				int insertedCount_tDBOutput_8 = 0;
				int rowsToCommitCount_tDBOutput_8 = 0;
				int rejectedCount_tDBOutput_8 = 0;
				String dbschema_tDBOutput_8 = null;
				String tableName_tDBOutput_8 = null;
				boolean whetherReject_tDBOutput_8 = false;

				java.util.Calendar calendar_tDBOutput_8 = java.util.Calendar.getInstance();
				long year1_tDBOutput_8 = TalendDate.parseDate("yyyy-MM-dd", "0001-01-01").getTime();
				long year2_tDBOutput_8 = TalendDate.parseDate("yyyy-MM-dd", "1753-01-01").getTime();
				long year10000_tDBOutput_8 = TalendDate.parseDate("yyyy-MM-dd HH:mm:ss", "9999-12-31 24:00:00")
						.getTime();
				long date_tDBOutput_8;

				java.util.Calendar calendar_datetimeoffset_tDBOutput_8 = java.util.Calendar
						.getInstance(java.util.TimeZone.getTimeZone("UTC"));

				java.sql.Connection conn_tDBOutput_8 = null;
				String dbUser_tDBOutput_8 = null;
				dbschema_tDBOutput_8 = "";
				String driverClass_tDBOutput_8 = "net.sourceforge.jtds.jdbc.Driver";

				if (log.isDebugEnabled())
					log.debug("tDBOutput_8 - " + ("Driver ClassName: ") + (driverClass_tDBOutput_8) + ("."));
				java.lang.Class.forName(driverClass_tDBOutput_8);
				String port_tDBOutput_8 = "1433";
				String dbname_tDBOutput_8 = "MVC_Stage";
				String url_tDBOutput_8 = "jdbc:jtds:sqlserver://" + "localhost";
				if (!"".equals(port_tDBOutput_8)) {
					url_tDBOutput_8 += ":" + "1433";
				}
				if (!"".equals(dbname_tDBOutput_8)) {
					url_tDBOutput_8 += "//" + "MVC_Stage";

				}
				url_tDBOutput_8 += ";appName=" + projectName + ";" + "";
				dbUser_tDBOutput_8 = "";

				final String decryptedPassword_tDBOutput_8 = routines.system.PasswordEncryptUtil
						.decryptPassword("enc:routine.encryption.key.v1:u646izxTuG9bCdszcOuadJndBzwaSc9YurSEqg==");

				String dbPwd_tDBOutput_8 = decryptedPassword_tDBOutput_8;
				if (log.isDebugEnabled())
					log.debug("tDBOutput_8 - " + ("Connection attempts to '") + (url_tDBOutput_8)
							+ ("' with the username '") + (dbUser_tDBOutput_8) + ("'."));
				conn_tDBOutput_8 = java.sql.DriverManager.getConnection(url_tDBOutput_8, dbUser_tDBOutput_8,
						dbPwd_tDBOutput_8);
				if (log.isDebugEnabled())
					log.debug("tDBOutput_8 - " + ("Connection to '") + (url_tDBOutput_8) + ("' has succeeded."));

				resourceMap.put("conn_tDBOutput_8", conn_tDBOutput_8);

				conn_tDBOutput_8.setAutoCommit(false);
				int commitEvery_tDBOutput_8 = 10000;
				int commitCounter_tDBOutput_8 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBOutput_8 - " + ("Connection is set auto commit to '")
							+ (conn_tDBOutput_8.getAutoCommit()) + ("'."));
				int batchSize_tDBOutput_8 = 10000;
				int batchSizeCounter_tDBOutput_8 = 0;

				if (dbschema_tDBOutput_8 == null || dbschema_tDBOutput_8.trim().length() == 0) {
					tableName_tDBOutput_8 = "Dim_PED_LOCATION";
				} else {
					tableName_tDBOutput_8 = dbschema_tDBOutput_8 + "].[" + "Dim_PED_LOCATION";
				}
				int count_tDBOutput_8 = 0;

				String insert_tDBOutput_8 = "INSERT INTO [" + tableName_tDBOutput_8
						+ "] ([PED_LOCATION_SK],[PED_LOCATION],[DI_PID],[DI_Create_Date]) VALUES (?,?,?,?)";
				java.sql.PreparedStatement pstmt_tDBOutput_8 = conn_tDBOutput_8.prepareStatement(insert_tDBOutput_8);
				resourceMap.put("pstmt_tDBOutput_8", pstmt_tDBOutput_8);

				/**
				 * [tDBOutput_8 begin ] stop
				 */

				/**
				 * [tMap_11 begin ] start
				 */

				ok_Hash.put("tMap_11", false);
				start_Hash.put("tMap_11", System.currentTimeMillis());

				currentComponent = "tMap_11";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "row9");

				int tos_count_tMap_11 = 0;

				if (log.isDebugEnabled())
					log.debug("tMap_11 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tMap_11 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tMap_11 = new StringBuilder();
							log4jParamters_tMap_11.append("Parameters:");
							log4jParamters_tMap_11.append("LINK_STYLE" + " = " + "AUTO");
							log4jParamters_tMap_11.append(" | ");
							log4jParamters_tMap_11.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
							log4jParamters_tMap_11.append(" | ");
							log4jParamters_tMap_11.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
							log4jParamters_tMap_11.append(" | ");
							log4jParamters_tMap_11.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "true");
							log4jParamters_tMap_11.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tMap_11 - " + (log4jParamters_tMap_11));
						}
					}
					new BytesLimit65535_tMap_11().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tMap_11", "tMap_11", "tMap");
					talendJobLogProcess(globalMap);
				}

// ###############################
// # Lookup's keys initialization
				int count_row9_tMap_11 = 0;

// ###############################        

// ###############################
// # Vars initialization
				class Var__tMap_11__Struct {
				}
				Var__tMap_11__Struct Var__tMap_11 = new Var__tMap_11__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_Ped_Location_Load_tMap_11 = 0;

				Ped_Location_LoadStruct Ped_Location_Load_tmp = new Ped_Location_LoadStruct();
// ###############################

				/**
				 * [tMap_11 begin ] stop
				 */

				/**
				 * [tUniqRow_9 begin ] start
				 */

				ok_Hash.put("tUniqRow_9", false);
				start_Hash.put("tUniqRow_9", System.currentTimeMillis());

				currentComponent = "tUniqRow_9";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "Ped_Location");

				int tos_count_tUniqRow_9 = 0;

				if (log.isDebugEnabled())
					log.debug("tUniqRow_9 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tUniqRow_9 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tUniqRow_9 = new StringBuilder();
							log4jParamters_tUniqRow_9.append("Parameters:");
							log4jParamters_tUniqRow_9.append("UNIQUE_KEY" + " = " + "[{CASE_SENSITIVE=" + ("false")
									+ ", KEY_ATTRIBUTE=" + ("true") + ", SCHEMA_COLUMN=" + ("PED_LOCATION") + "}]");
							log4jParamters_tUniqRow_9.append(" | ");
							log4jParamters_tUniqRow_9.append("ONLY_ONCE_EACH_DUPLICATED_KEY" + " = " + "false");
							log4jParamters_tUniqRow_9.append(" | ");
							log4jParamters_tUniqRow_9.append("IS_VIRTUAL_COMPONENT" + " = " + "false");
							log4jParamters_tUniqRow_9.append(" | ");
							log4jParamters_tUniqRow_9.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "false");
							log4jParamters_tUniqRow_9.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tUniqRow_9 - " + (log4jParamters_tUniqRow_9));
						}
					}
					new BytesLimit65535_tUniqRow_9().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tUniqRow_9", "tUniqRow_9", "tUniqRow");
					talendJobLogProcess(globalMap);
				}

				class KeyStruct_tUniqRow_9 {

					private static final int DEFAULT_HASHCODE = 1;
					private static final int PRIME = 31;
					private int hashCode = DEFAULT_HASHCODE;
					public boolean hashCodeDirty = true;

					String PED_LOCATION;

					@Override
					public int hashCode() {
						if (this.hashCodeDirty) {
							final int prime = PRIME;
							int result = DEFAULT_HASHCODE;

							result = prime * result + ((this.PED_LOCATION == null) ? 0 : this.PED_LOCATION.hashCode());

							this.hashCode = result;
							this.hashCodeDirty = false;
						}
						return this.hashCode;
					}

					@Override
					public boolean equals(Object obj) {
						if (this == obj)
							return true;
						if (obj == null)
							return false;
						if (getClass() != obj.getClass())
							return false;
						final KeyStruct_tUniqRow_9 other = (KeyStruct_tUniqRow_9) obj;

						if (this.PED_LOCATION == null) {
							if (other.PED_LOCATION != null)
								return false;

						} else if (!this.PED_LOCATION.equals(other.PED_LOCATION))

							return false;

						return true;
					}

				}

				int nb_uniques_tUniqRow_9 = 0;
				int nb_duplicates_tUniqRow_9 = 0;
				log.debug("tUniqRow_9 - Start to process the data from datasource.");
				KeyStruct_tUniqRow_9 finder_tUniqRow_9 = new KeyStruct_tUniqRow_9();
				java.util.Set<KeyStruct_tUniqRow_9> keystUniqRow_9 = new java.util.HashSet<KeyStruct_tUniqRow_9>();

				/**
				 * [tUniqRow_9 begin ] stop
				 */

				/**
				 * [tDBOutput_9 begin ] start
				 */

				ok_Hash.put("tDBOutput_9", false);
				start_Hash.put("tDBOutput_9", System.currentTimeMillis());

				currentComponent = "tDBOutput_9";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "Ped_Action");

				int tos_count_tDBOutput_9 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBOutput_9 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tDBOutput_9 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tDBOutput_9 = new StringBuilder();
							log4jParamters_tDBOutput_9.append("Parameters:");
							log4jParamters_tDBOutput_9.append("USE_EXISTING_CONNECTION" + " = " + "false");
							log4jParamters_tDBOutput_9.append(" | ");
							log4jParamters_tDBOutput_9.append("DRIVER" + " = " + "JTDS");
							log4jParamters_tDBOutput_9.append(" | ");
							log4jParamters_tDBOutput_9.append("HOST" + " = " + "\"localhost\"");
							log4jParamters_tDBOutput_9.append(" | ");
							log4jParamters_tDBOutput_9.append("PORT" + " = " + "\"1433\"");
							log4jParamters_tDBOutput_9.append(" | ");
							log4jParamters_tDBOutput_9.append("DB_SCHEMA" + " = " + "\"\"");
							log4jParamters_tDBOutput_9.append(" | ");
							log4jParamters_tDBOutput_9.append("DBNAME" + " = " + "\"MVC_Stage\"");
							log4jParamters_tDBOutput_9.append(" | ");
							log4jParamters_tDBOutput_9.append("USER" + " = " + "\"\"");
							log4jParamters_tDBOutput_9.append(" | ");
							log4jParamters_tDBOutput_9.append("PASS" + " = "
									+ String.valueOf(
											"enc:routine.encryption.key.v1:XMpdkDsSbn9oinYQ1JptOJyv9EEFYqfr61m06A==")
											.substring(0, 4)
									+ "...");
							log4jParamters_tDBOutput_9.append(" | ");
							log4jParamters_tDBOutput_9.append("TABLE" + " = " + "\"Dim_PED_ACTION\"");
							log4jParamters_tDBOutput_9.append(" | ");
							log4jParamters_tDBOutput_9.append("TABLE_ACTION" + " = " + "NONE");
							log4jParamters_tDBOutput_9.append(" | ");
							log4jParamters_tDBOutput_9.append("IDENTITY_INSERT" + " = " + "false");
							log4jParamters_tDBOutput_9.append(" | ");
							log4jParamters_tDBOutput_9.append("DATA_ACTION" + " = " + "INSERT");
							log4jParamters_tDBOutput_9.append(" | ");
							log4jParamters_tDBOutput_9.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
							log4jParamters_tDBOutput_9.append(" | ");
							log4jParamters_tDBOutput_9.append("DIE_ON_ERROR" + " = " + "false");
							log4jParamters_tDBOutput_9.append(" | ");
							log4jParamters_tDBOutput_9.append("PROPERTIES" + " = " + "\"\"");
							log4jParamters_tDBOutput_9.append(" | ");
							log4jParamters_tDBOutput_9.append("COMMIT_EVERY" + " = " + "10000");
							log4jParamters_tDBOutput_9.append(" | ");
							log4jParamters_tDBOutput_9.append("ADD_COLS" + " = " + "[]");
							log4jParamters_tDBOutput_9.append(" | ");
							log4jParamters_tDBOutput_9.append("USE_FIELD_OPTIONS" + " = " + "false");
							log4jParamters_tDBOutput_9.append(" | ");
							log4jParamters_tDBOutput_9.append("IGNORE_DATE_OUTOF_RANGE" + " = " + "false");
							log4jParamters_tDBOutput_9.append(" | ");
							log4jParamters_tDBOutput_9.append("ENABLE_DEBUG_MODE" + " = " + "false");
							log4jParamters_tDBOutput_9.append(" | ");
							log4jParamters_tDBOutput_9.append("SUPPORT_NULL_WHERE" + " = " + "false");
							log4jParamters_tDBOutput_9.append(" | ");
							log4jParamters_tDBOutput_9.append("USE_BATCH_SIZE" + " = " + "true");
							log4jParamters_tDBOutput_9.append(" | ");
							log4jParamters_tDBOutput_9.append("BATCH_SIZE" + " = " + "10000");
							log4jParamters_tDBOutput_9.append(" | ");
							log4jParamters_tDBOutput_9.append("UNIFIED_COMPONENTS" + " = " + "tMSSqlOutput");
							log4jParamters_tDBOutput_9.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tDBOutput_9 - " + (log4jParamters_tDBOutput_9));
						}
					}
					new BytesLimit65535_tDBOutput_9().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tDBOutput_9", "__TABLE__", "tMSSqlOutput");
					talendJobLogProcess(globalMap);
				}

				int nb_line_tDBOutput_9 = 0;
				int nb_line_update_tDBOutput_9 = 0;
				int nb_line_inserted_tDBOutput_9 = 0;
				int nb_line_deleted_tDBOutput_9 = 0;
				int nb_line_rejected_tDBOutput_9 = 0;

				int deletedCount_tDBOutput_9 = 0;
				int updatedCount_tDBOutput_9 = 0;
				int insertedCount_tDBOutput_9 = 0;
				int rowsToCommitCount_tDBOutput_9 = 0;
				int rejectedCount_tDBOutput_9 = 0;
				String dbschema_tDBOutput_9 = null;
				String tableName_tDBOutput_9 = null;
				boolean whetherReject_tDBOutput_9 = false;

				java.util.Calendar calendar_tDBOutput_9 = java.util.Calendar.getInstance();
				long year1_tDBOutput_9 = TalendDate.parseDate("yyyy-MM-dd", "0001-01-01").getTime();
				long year2_tDBOutput_9 = TalendDate.parseDate("yyyy-MM-dd", "1753-01-01").getTime();
				long year10000_tDBOutput_9 = TalendDate.parseDate("yyyy-MM-dd HH:mm:ss", "9999-12-31 24:00:00")
						.getTime();
				long date_tDBOutput_9;

				java.util.Calendar calendar_datetimeoffset_tDBOutput_9 = java.util.Calendar
						.getInstance(java.util.TimeZone.getTimeZone("UTC"));

				java.sql.Connection conn_tDBOutput_9 = null;
				String dbUser_tDBOutput_9 = null;
				dbschema_tDBOutput_9 = "";
				String driverClass_tDBOutput_9 = "net.sourceforge.jtds.jdbc.Driver";

				if (log.isDebugEnabled())
					log.debug("tDBOutput_9 - " + ("Driver ClassName: ") + (driverClass_tDBOutput_9) + ("."));
				java.lang.Class.forName(driverClass_tDBOutput_9);
				String port_tDBOutput_9 = "1433";
				String dbname_tDBOutput_9 = "MVC_Stage";
				String url_tDBOutput_9 = "jdbc:jtds:sqlserver://" + "localhost";
				if (!"".equals(port_tDBOutput_9)) {
					url_tDBOutput_9 += ":" + "1433";
				}
				if (!"".equals(dbname_tDBOutput_9)) {
					url_tDBOutput_9 += "//" + "MVC_Stage";

				}
				url_tDBOutput_9 += ";appName=" + projectName + ";" + "";
				dbUser_tDBOutput_9 = "";

				final String decryptedPassword_tDBOutput_9 = routines.system.PasswordEncryptUtil
						.decryptPassword("enc:routine.encryption.key.v1:4j8cdv27T5uEX3pa+fyPAOniZ98FwDK/zXxnEg==");

				String dbPwd_tDBOutput_9 = decryptedPassword_tDBOutput_9;
				if (log.isDebugEnabled())
					log.debug("tDBOutput_9 - " + ("Connection attempts to '") + (url_tDBOutput_9)
							+ ("' with the username '") + (dbUser_tDBOutput_9) + ("'."));
				conn_tDBOutput_9 = java.sql.DriverManager.getConnection(url_tDBOutput_9, dbUser_tDBOutput_9,
						dbPwd_tDBOutput_9);
				if (log.isDebugEnabled())
					log.debug("tDBOutput_9 - " + ("Connection to '") + (url_tDBOutput_9) + ("' has succeeded."));

				resourceMap.put("conn_tDBOutput_9", conn_tDBOutput_9);

				conn_tDBOutput_9.setAutoCommit(false);
				int commitEvery_tDBOutput_9 = 10000;
				int commitCounter_tDBOutput_9 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBOutput_9 - " + ("Connection is set auto commit to '")
							+ (conn_tDBOutput_9.getAutoCommit()) + ("'."));
				int batchSize_tDBOutput_9 = 10000;
				int batchSizeCounter_tDBOutput_9 = 0;

				if (dbschema_tDBOutput_9 == null || dbschema_tDBOutput_9.trim().length() == 0) {
					tableName_tDBOutput_9 = "Dim_PED_ACTION";
				} else {
					tableName_tDBOutput_9 = dbschema_tDBOutput_9 + "].[" + "Dim_PED_ACTION";
				}
				int count_tDBOutput_9 = 0;

				String insert_tDBOutput_9 = "INSERT INTO [" + tableName_tDBOutput_9
						+ "] ([PED_ACTION],[PED_ACTION_SK],[DI_PID],[DI_Create_Date]) VALUES (?,?,?,?)";
				java.sql.PreparedStatement pstmt_tDBOutput_9 = conn_tDBOutput_9.prepareStatement(insert_tDBOutput_9);
				resourceMap.put("pstmt_tDBOutput_9", pstmt_tDBOutput_9);

				/**
				 * [tDBOutput_9 begin ] stop
				 */

				/**
				 * [tMap_12 begin ] start
				 */

				ok_Hash.put("tMap_12", false);
				start_Hash.put("tMap_12", System.currentTimeMillis());

				currentComponent = "tMap_12";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "row10");

				int tos_count_tMap_12 = 0;

				if (log.isDebugEnabled())
					log.debug("tMap_12 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tMap_12 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tMap_12 = new StringBuilder();
							log4jParamters_tMap_12.append("Parameters:");
							log4jParamters_tMap_12.append("LINK_STYLE" + " = " + "AUTO");
							log4jParamters_tMap_12.append(" | ");
							log4jParamters_tMap_12.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
							log4jParamters_tMap_12.append(" | ");
							log4jParamters_tMap_12.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
							log4jParamters_tMap_12.append(" | ");
							log4jParamters_tMap_12.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "true");
							log4jParamters_tMap_12.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tMap_12 - " + (log4jParamters_tMap_12));
						}
					}
					new BytesLimit65535_tMap_12().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tMap_12", "tMap_12", "tMap");
					talendJobLogProcess(globalMap);
				}

// ###############################
// # Lookup's keys initialization
				int count_row10_tMap_12 = 0;

// ###############################        

// ###############################
// # Vars initialization
				class Var__tMap_12__Struct {
				}
				Var__tMap_12__Struct Var__tMap_12 = new Var__tMap_12__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_Ped_Action_tMap_12 = 0;

				Ped_ActionStruct Ped_Action_tmp = new Ped_ActionStruct();
// ###############################

				/**
				 * [tMap_12 begin ] stop
				 */

				/**
				 * [tUniqRow_10 begin ] start
				 */

				ok_Hash.put("tUniqRow_10", false);
				start_Hash.put("tUniqRow_10", System.currentTimeMillis());

				currentComponent = "tUniqRow_10";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "Ped_Location1");

				int tos_count_tUniqRow_10 = 0;

				if (log.isDebugEnabled())
					log.debug("tUniqRow_10 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tUniqRow_10 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tUniqRow_10 = new StringBuilder();
							log4jParamters_tUniqRow_10.append("Parameters:");
							log4jParamters_tUniqRow_10.append("UNIQUE_KEY" + " = " + "[{CASE_SENSITIVE=" + ("false")
									+ ", KEY_ATTRIBUTE=" + ("true") + ", SCHEMA_COLUMN=" + ("PED_ACTION") + "}]");
							log4jParamters_tUniqRow_10.append(" | ");
							log4jParamters_tUniqRow_10.append("ONLY_ONCE_EACH_DUPLICATED_KEY" + " = " + "false");
							log4jParamters_tUniqRow_10.append(" | ");
							log4jParamters_tUniqRow_10.append("IS_VIRTUAL_COMPONENT" + " = " + "false");
							log4jParamters_tUniqRow_10.append(" | ");
							log4jParamters_tUniqRow_10
									.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "false");
							log4jParamters_tUniqRow_10.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tUniqRow_10 - " + (log4jParamters_tUniqRow_10));
						}
					}
					new BytesLimit65535_tUniqRow_10().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tUniqRow_10", "tUniqRow_10", "tUniqRow");
					talendJobLogProcess(globalMap);
				}

				class KeyStruct_tUniqRow_10 {

					private static final int DEFAULT_HASHCODE = 1;
					private static final int PRIME = 31;
					private int hashCode = DEFAULT_HASHCODE;
					public boolean hashCodeDirty = true;

					String PED_ACTION;

					@Override
					public int hashCode() {
						if (this.hashCodeDirty) {
							final int prime = PRIME;
							int result = DEFAULT_HASHCODE;

							result = prime * result + ((this.PED_ACTION == null) ? 0 : this.PED_ACTION.hashCode());

							this.hashCode = result;
							this.hashCodeDirty = false;
						}
						return this.hashCode;
					}

					@Override
					public boolean equals(Object obj) {
						if (this == obj)
							return true;
						if (obj == null)
							return false;
						if (getClass() != obj.getClass())
							return false;
						final KeyStruct_tUniqRow_10 other = (KeyStruct_tUniqRow_10) obj;

						if (this.PED_ACTION == null) {
							if (other.PED_ACTION != null)
								return false;

						} else if (!this.PED_ACTION.equals(other.PED_ACTION))

							return false;

						return true;
					}

				}

				int nb_uniques_tUniqRow_10 = 0;
				int nb_duplicates_tUniqRow_10 = 0;
				log.debug("tUniqRow_10 - Start to process the data from datasource.");
				KeyStruct_tUniqRow_10 finder_tUniqRow_10 = new KeyStruct_tUniqRow_10();
				java.util.Set<KeyStruct_tUniqRow_10> keystUniqRow_10 = new java.util.HashSet<KeyStruct_tUniqRow_10>();

				/**
				 * [tUniqRow_10 begin ] stop
				 */

				/**
				 * [tDBOutput_10 begin ] start
				 */

				ok_Hash.put("tDBOutput_10", false);
				start_Hash.put("tDBOutput_10", System.currentTimeMillis());

				currentComponent = "tDBOutput_10";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "Complain_Load");

				int tos_count_tDBOutput_10 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBOutput_10 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tDBOutput_10 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tDBOutput_10 = new StringBuilder();
							log4jParamters_tDBOutput_10.append("Parameters:");
							log4jParamters_tDBOutput_10.append("USE_EXISTING_CONNECTION" + " = " + "false");
							log4jParamters_tDBOutput_10.append(" | ");
							log4jParamters_tDBOutput_10.append("DRIVER" + " = " + "JTDS");
							log4jParamters_tDBOutput_10.append(" | ");
							log4jParamters_tDBOutput_10.append("HOST" + " = " + "\"localhost\"");
							log4jParamters_tDBOutput_10.append(" | ");
							log4jParamters_tDBOutput_10.append("PORT" + " = " + "\"1433\"");
							log4jParamters_tDBOutput_10.append(" | ");
							log4jParamters_tDBOutput_10.append("DB_SCHEMA" + " = " + "\"\"");
							log4jParamters_tDBOutput_10.append(" | ");
							log4jParamters_tDBOutput_10.append("DBNAME" + " = " + "\"MVC_Stage\"");
							log4jParamters_tDBOutput_10.append(" | ");
							log4jParamters_tDBOutput_10.append("USER" + " = " + "\"\"");
							log4jParamters_tDBOutput_10.append(" | ");
							log4jParamters_tDBOutput_10.append("PASS" + " = "
									+ String.valueOf(
											"enc:routine.encryption.key.v1:sXvAqfTimnS6klR/+HXBy+9ehZeyShttjyLCtg==")
											.substring(0, 4)
									+ "...");
							log4jParamters_tDBOutput_10.append(" | ");
							log4jParamters_tDBOutput_10.append("TABLE" + " = " + "\"Dim_COMPLAINT\"");
							log4jParamters_tDBOutput_10.append(" | ");
							log4jParamters_tDBOutput_10.append("TABLE_ACTION" + " = " + "NONE");
							log4jParamters_tDBOutput_10.append(" | ");
							log4jParamters_tDBOutput_10.append("IDENTITY_INSERT" + " = " + "false");
							log4jParamters_tDBOutput_10.append(" | ");
							log4jParamters_tDBOutput_10.append("DATA_ACTION" + " = " + "INSERT");
							log4jParamters_tDBOutput_10.append(" | ");
							log4jParamters_tDBOutput_10.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
							log4jParamters_tDBOutput_10.append(" | ");
							log4jParamters_tDBOutput_10.append("DIE_ON_ERROR" + " = " + "false");
							log4jParamters_tDBOutput_10.append(" | ");
							log4jParamters_tDBOutput_10.append("PROPERTIES" + " = " + "\"\"");
							log4jParamters_tDBOutput_10.append(" | ");
							log4jParamters_tDBOutput_10.append("COMMIT_EVERY" + " = " + "10000");
							log4jParamters_tDBOutput_10.append(" | ");
							log4jParamters_tDBOutput_10.append("ADD_COLS" + " = " + "[]");
							log4jParamters_tDBOutput_10.append(" | ");
							log4jParamters_tDBOutput_10.append("USE_FIELD_OPTIONS" + " = " + "false");
							log4jParamters_tDBOutput_10.append(" | ");
							log4jParamters_tDBOutput_10.append("IGNORE_DATE_OUTOF_RANGE" + " = " + "false");
							log4jParamters_tDBOutput_10.append(" | ");
							log4jParamters_tDBOutput_10.append("ENABLE_DEBUG_MODE" + " = " + "false");
							log4jParamters_tDBOutput_10.append(" | ");
							log4jParamters_tDBOutput_10.append("SUPPORT_NULL_WHERE" + " = " + "false");
							log4jParamters_tDBOutput_10.append(" | ");
							log4jParamters_tDBOutput_10.append("USE_BATCH_SIZE" + " = " + "true");
							log4jParamters_tDBOutput_10.append(" | ");
							log4jParamters_tDBOutput_10.append("BATCH_SIZE" + " = " + "10000");
							log4jParamters_tDBOutput_10.append(" | ");
							log4jParamters_tDBOutput_10.append("UNIFIED_COMPONENTS" + " = " + "tMSSqlOutput");
							log4jParamters_tDBOutput_10.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tDBOutput_10 - " + (log4jParamters_tDBOutput_10));
						}
					}
					new BytesLimit65535_tDBOutput_10().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tDBOutput_10", "__TABLE__", "tMSSqlOutput");
					talendJobLogProcess(globalMap);
				}

				int nb_line_tDBOutput_10 = 0;
				int nb_line_update_tDBOutput_10 = 0;
				int nb_line_inserted_tDBOutput_10 = 0;
				int nb_line_deleted_tDBOutput_10 = 0;
				int nb_line_rejected_tDBOutput_10 = 0;

				int deletedCount_tDBOutput_10 = 0;
				int updatedCount_tDBOutput_10 = 0;
				int insertedCount_tDBOutput_10 = 0;
				int rowsToCommitCount_tDBOutput_10 = 0;
				int rejectedCount_tDBOutput_10 = 0;
				String dbschema_tDBOutput_10 = null;
				String tableName_tDBOutput_10 = null;
				boolean whetherReject_tDBOutput_10 = false;

				java.util.Calendar calendar_tDBOutput_10 = java.util.Calendar.getInstance();
				long year1_tDBOutput_10 = TalendDate.parseDate("yyyy-MM-dd", "0001-01-01").getTime();
				long year2_tDBOutput_10 = TalendDate.parseDate("yyyy-MM-dd", "1753-01-01").getTime();
				long year10000_tDBOutput_10 = TalendDate.parseDate("yyyy-MM-dd HH:mm:ss", "9999-12-31 24:00:00")
						.getTime();
				long date_tDBOutput_10;

				java.util.Calendar calendar_datetimeoffset_tDBOutput_10 = java.util.Calendar
						.getInstance(java.util.TimeZone.getTimeZone("UTC"));

				java.sql.Connection conn_tDBOutput_10 = null;
				String dbUser_tDBOutput_10 = null;
				dbschema_tDBOutput_10 = "";
				String driverClass_tDBOutput_10 = "net.sourceforge.jtds.jdbc.Driver";

				if (log.isDebugEnabled())
					log.debug("tDBOutput_10 - " + ("Driver ClassName: ") + (driverClass_tDBOutput_10) + ("."));
				java.lang.Class.forName(driverClass_tDBOutput_10);
				String port_tDBOutput_10 = "1433";
				String dbname_tDBOutput_10 = "MVC_Stage";
				String url_tDBOutput_10 = "jdbc:jtds:sqlserver://" + "localhost";
				if (!"".equals(port_tDBOutput_10)) {
					url_tDBOutput_10 += ":" + "1433";
				}
				if (!"".equals(dbname_tDBOutput_10)) {
					url_tDBOutput_10 += "//" + "MVC_Stage";

				}
				url_tDBOutput_10 += ";appName=" + projectName + ";" + "";
				dbUser_tDBOutput_10 = "";

				final String decryptedPassword_tDBOutput_10 = routines.system.PasswordEncryptUtil
						.decryptPassword("enc:routine.encryption.key.v1:R69Yn/vrDJ0OKFJS4UCp9DRbnpiDZh5cVD6zFg==");

				String dbPwd_tDBOutput_10 = decryptedPassword_tDBOutput_10;
				if (log.isDebugEnabled())
					log.debug("tDBOutput_10 - " + ("Connection attempts to '") + (url_tDBOutput_10)
							+ ("' with the username '") + (dbUser_tDBOutput_10) + ("'."));
				conn_tDBOutput_10 = java.sql.DriverManager.getConnection(url_tDBOutput_10, dbUser_tDBOutput_10,
						dbPwd_tDBOutput_10);
				if (log.isDebugEnabled())
					log.debug("tDBOutput_10 - " + ("Connection to '") + (url_tDBOutput_10) + ("' has succeeded."));

				resourceMap.put("conn_tDBOutput_10", conn_tDBOutput_10);

				conn_tDBOutput_10.setAutoCommit(false);
				int commitEvery_tDBOutput_10 = 10000;
				int commitCounter_tDBOutput_10 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBOutput_10 - " + ("Connection is set auto commit to '")
							+ (conn_tDBOutput_10.getAutoCommit()) + ("'."));
				int batchSize_tDBOutput_10 = 10000;
				int batchSizeCounter_tDBOutput_10 = 0;

				if (dbschema_tDBOutput_10 == null || dbschema_tDBOutput_10.trim().length() == 0) {
					tableName_tDBOutput_10 = "Dim_COMPLAINT";
				} else {
					tableName_tDBOutput_10 = dbschema_tDBOutput_10 + "].[" + "Dim_COMPLAINT";
				}
				int count_tDBOutput_10 = 0;

				String insert_tDBOutput_10 = "INSERT INTO [" + tableName_tDBOutput_10
						+ "] ([COMPLAINT],[COMPLAINT_SK],[DI_PID],[DI_Create_Date]) VALUES (?,?,?,?)";
				java.sql.PreparedStatement pstmt_tDBOutput_10 = conn_tDBOutput_10.prepareStatement(insert_tDBOutput_10);
				resourceMap.put("pstmt_tDBOutput_10", pstmt_tDBOutput_10);

				/**
				 * [tDBOutput_10 begin ] stop
				 */

				/**
				 * [tMap_13 begin ] start
				 */

				ok_Hash.put("tMap_13", false);
				start_Hash.put("tMap_13", System.currentTimeMillis());

				currentComponent = "tMap_13";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "row11");

				int tos_count_tMap_13 = 0;

				if (log.isDebugEnabled())
					log.debug("tMap_13 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tMap_13 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tMap_13 = new StringBuilder();
							log4jParamters_tMap_13.append("Parameters:");
							log4jParamters_tMap_13.append("LINK_STYLE" + " = " + "AUTO");
							log4jParamters_tMap_13.append(" | ");
							log4jParamters_tMap_13.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
							log4jParamters_tMap_13.append(" | ");
							log4jParamters_tMap_13.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
							log4jParamters_tMap_13.append(" | ");
							log4jParamters_tMap_13.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "true");
							log4jParamters_tMap_13.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tMap_13 - " + (log4jParamters_tMap_13));
						}
					}
					new BytesLimit65535_tMap_13().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tMap_13", "tMap_13", "tMap");
					talendJobLogProcess(globalMap);
				}

// ###############################
// # Lookup's keys initialization
				int count_row11_tMap_13 = 0;

// ###############################        

// ###############################
// # Vars initialization
				class Var__tMap_13__Struct {
				}
				Var__tMap_13__Struct Var__tMap_13 = new Var__tMap_13__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_Complain_Load_tMap_13 = 0;

				Complain_LoadStruct Complain_Load_tmp = new Complain_LoadStruct();
// ###############################

				/**
				 * [tMap_13 begin ] stop
				 */

				/**
				 * [tUniqRow_11 begin ] start
				 */

				ok_Hash.put("tUniqRow_11", false);
				start_Hash.put("tUniqRow_11", System.currentTimeMillis());

				currentComponent = "tUniqRow_11";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "Complaint");

				int tos_count_tUniqRow_11 = 0;

				if (log.isDebugEnabled())
					log.debug("tUniqRow_11 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tUniqRow_11 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tUniqRow_11 = new StringBuilder();
							log4jParamters_tUniqRow_11.append("Parameters:");
							log4jParamters_tUniqRow_11.append("UNIQUE_KEY" + " = " + "[{CASE_SENSITIVE=" + ("false")
									+ ", KEY_ATTRIBUTE=" + ("true") + ", SCHEMA_COLUMN=" + ("COMPLAINT") + "}]");
							log4jParamters_tUniqRow_11.append(" | ");
							log4jParamters_tUniqRow_11.append("ONLY_ONCE_EACH_DUPLICATED_KEY" + " = " + "false");
							log4jParamters_tUniqRow_11.append(" | ");
							log4jParamters_tUniqRow_11.append("IS_VIRTUAL_COMPONENT" + " = " + "false");
							log4jParamters_tUniqRow_11.append(" | ");
							log4jParamters_tUniqRow_11
									.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "false");
							log4jParamters_tUniqRow_11.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tUniqRow_11 - " + (log4jParamters_tUniqRow_11));
						}
					}
					new BytesLimit65535_tUniqRow_11().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tUniqRow_11", "tUniqRow_11", "tUniqRow");
					talendJobLogProcess(globalMap);
				}

				class KeyStruct_tUniqRow_11 {

					private static final int DEFAULT_HASHCODE = 1;
					private static final int PRIME = 31;
					private int hashCode = DEFAULT_HASHCODE;
					public boolean hashCodeDirty = true;

					String COMPLAINT;

					@Override
					public int hashCode() {
						if (this.hashCodeDirty) {
							final int prime = PRIME;
							int result = DEFAULT_HASHCODE;

							result = prime * result + ((this.COMPLAINT == null) ? 0 : this.COMPLAINT.hashCode());

							this.hashCode = result;
							this.hashCodeDirty = false;
						}
						return this.hashCode;
					}

					@Override
					public boolean equals(Object obj) {
						if (this == obj)
							return true;
						if (obj == null)
							return false;
						if (getClass() != obj.getClass())
							return false;
						final KeyStruct_tUniqRow_11 other = (KeyStruct_tUniqRow_11) obj;

						if (this.COMPLAINT == null) {
							if (other.COMPLAINT != null)
								return false;

						} else if (!this.COMPLAINT.equals(other.COMPLAINT))

							return false;

						return true;
					}

				}

				int nb_uniques_tUniqRow_11 = 0;
				int nb_duplicates_tUniqRow_11 = 0;
				log.debug("tUniqRow_11 - Start to process the data from datasource.");
				KeyStruct_tUniqRow_11 finder_tUniqRow_11 = new KeyStruct_tUniqRow_11();
				java.util.Set<KeyStruct_tUniqRow_11> keystUniqRow_11 = new java.util.HashSet<KeyStruct_tUniqRow_11>();

				/**
				 * [tUniqRow_11 begin ] stop
				 */

				/**
				 * [tDBOutput_11 begin ] start
				 */

				ok_Hash.put("tDBOutput_11", false);
				start_Hash.put("tDBOutput_11", System.currentTimeMillis());

				currentComponent = "tDBOutput_11";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "Ped_Role_Load");

				int tos_count_tDBOutput_11 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBOutput_11 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tDBOutput_11 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tDBOutput_11 = new StringBuilder();
							log4jParamters_tDBOutput_11.append("Parameters:");
							log4jParamters_tDBOutput_11.append("USE_EXISTING_CONNECTION" + " = " + "false");
							log4jParamters_tDBOutput_11.append(" | ");
							log4jParamters_tDBOutput_11.append("DRIVER" + " = " + "JTDS");
							log4jParamters_tDBOutput_11.append(" | ");
							log4jParamters_tDBOutput_11.append("HOST" + " = " + "\"localhost\"");
							log4jParamters_tDBOutput_11.append(" | ");
							log4jParamters_tDBOutput_11.append("PORT" + " = " + "\"1433\"");
							log4jParamters_tDBOutput_11.append(" | ");
							log4jParamters_tDBOutput_11.append("DB_SCHEMA" + " = " + "\"\"");
							log4jParamters_tDBOutput_11.append(" | ");
							log4jParamters_tDBOutput_11.append("DBNAME" + " = " + "\"MVC_Stage\"");
							log4jParamters_tDBOutput_11.append(" | ");
							log4jParamters_tDBOutput_11.append("USER" + " = " + "\"\"");
							log4jParamters_tDBOutput_11.append(" | ");
							log4jParamters_tDBOutput_11.append("PASS" + " = "
									+ String.valueOf(
											"enc:routine.encryption.key.v1:QkCSdGHCUwN7h9oTwruCqApIpspUpWPVKRZugw==")
											.substring(0, 4)
									+ "...");
							log4jParamters_tDBOutput_11.append(" | ");
							log4jParamters_tDBOutput_11.append("TABLE" + " = " + "\"Dim_PED_ROLE\"");
							log4jParamters_tDBOutput_11.append(" | ");
							log4jParamters_tDBOutput_11.append("TABLE_ACTION" + " = " + "NONE");
							log4jParamters_tDBOutput_11.append(" | ");
							log4jParamters_tDBOutput_11.append("IDENTITY_INSERT" + " = " + "false");
							log4jParamters_tDBOutput_11.append(" | ");
							log4jParamters_tDBOutput_11.append("DATA_ACTION" + " = " + "INSERT");
							log4jParamters_tDBOutput_11.append(" | ");
							log4jParamters_tDBOutput_11.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
							log4jParamters_tDBOutput_11.append(" | ");
							log4jParamters_tDBOutput_11.append("DIE_ON_ERROR" + " = " + "false");
							log4jParamters_tDBOutput_11.append(" | ");
							log4jParamters_tDBOutput_11.append("PROPERTIES" + " = " + "\"\"");
							log4jParamters_tDBOutput_11.append(" | ");
							log4jParamters_tDBOutput_11.append("COMMIT_EVERY" + " = " + "10000");
							log4jParamters_tDBOutput_11.append(" | ");
							log4jParamters_tDBOutput_11.append("ADD_COLS" + " = " + "[]");
							log4jParamters_tDBOutput_11.append(" | ");
							log4jParamters_tDBOutput_11.append("USE_FIELD_OPTIONS" + " = " + "false");
							log4jParamters_tDBOutput_11.append(" | ");
							log4jParamters_tDBOutput_11.append("IGNORE_DATE_OUTOF_RANGE" + " = " + "false");
							log4jParamters_tDBOutput_11.append(" | ");
							log4jParamters_tDBOutput_11.append("ENABLE_DEBUG_MODE" + " = " + "false");
							log4jParamters_tDBOutput_11.append(" | ");
							log4jParamters_tDBOutput_11.append("SUPPORT_NULL_WHERE" + " = " + "false");
							log4jParamters_tDBOutput_11.append(" | ");
							log4jParamters_tDBOutput_11.append("USE_BATCH_SIZE" + " = " + "true");
							log4jParamters_tDBOutput_11.append(" | ");
							log4jParamters_tDBOutput_11.append("BATCH_SIZE" + " = " + "10000");
							log4jParamters_tDBOutput_11.append(" | ");
							log4jParamters_tDBOutput_11.append("UNIFIED_COMPONENTS" + " = " + "tMSSqlOutput");
							log4jParamters_tDBOutput_11.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tDBOutput_11 - " + (log4jParamters_tDBOutput_11));
						}
					}
					new BytesLimit65535_tDBOutput_11().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tDBOutput_11", "__TABLE__", "tMSSqlOutput");
					talendJobLogProcess(globalMap);
				}

				int nb_line_tDBOutput_11 = 0;
				int nb_line_update_tDBOutput_11 = 0;
				int nb_line_inserted_tDBOutput_11 = 0;
				int nb_line_deleted_tDBOutput_11 = 0;
				int nb_line_rejected_tDBOutput_11 = 0;

				int deletedCount_tDBOutput_11 = 0;
				int updatedCount_tDBOutput_11 = 0;
				int insertedCount_tDBOutput_11 = 0;
				int rowsToCommitCount_tDBOutput_11 = 0;
				int rejectedCount_tDBOutput_11 = 0;
				String dbschema_tDBOutput_11 = null;
				String tableName_tDBOutput_11 = null;
				boolean whetherReject_tDBOutput_11 = false;

				java.util.Calendar calendar_tDBOutput_11 = java.util.Calendar.getInstance();
				long year1_tDBOutput_11 = TalendDate.parseDate("yyyy-MM-dd", "0001-01-01").getTime();
				long year2_tDBOutput_11 = TalendDate.parseDate("yyyy-MM-dd", "1753-01-01").getTime();
				long year10000_tDBOutput_11 = TalendDate.parseDate("yyyy-MM-dd HH:mm:ss", "9999-12-31 24:00:00")
						.getTime();
				long date_tDBOutput_11;

				java.util.Calendar calendar_datetimeoffset_tDBOutput_11 = java.util.Calendar
						.getInstance(java.util.TimeZone.getTimeZone("UTC"));

				java.sql.Connection conn_tDBOutput_11 = null;
				String dbUser_tDBOutput_11 = null;
				dbschema_tDBOutput_11 = "";
				String driverClass_tDBOutput_11 = "net.sourceforge.jtds.jdbc.Driver";

				if (log.isDebugEnabled())
					log.debug("tDBOutput_11 - " + ("Driver ClassName: ") + (driverClass_tDBOutput_11) + ("."));
				java.lang.Class.forName(driverClass_tDBOutput_11);
				String port_tDBOutput_11 = "1433";
				String dbname_tDBOutput_11 = "MVC_Stage";
				String url_tDBOutput_11 = "jdbc:jtds:sqlserver://" + "localhost";
				if (!"".equals(port_tDBOutput_11)) {
					url_tDBOutput_11 += ":" + "1433";
				}
				if (!"".equals(dbname_tDBOutput_11)) {
					url_tDBOutput_11 += "//" + "MVC_Stage";

				}
				url_tDBOutput_11 += ";appName=" + projectName + ";" + "";
				dbUser_tDBOutput_11 = "";

				final String decryptedPassword_tDBOutput_11 = routines.system.PasswordEncryptUtil
						.decryptPassword("enc:routine.encryption.key.v1:BFqB1grI5V8tYg6QhlDWv/iyb8fpR5vxhK6mZQ==");

				String dbPwd_tDBOutput_11 = decryptedPassword_tDBOutput_11;
				if (log.isDebugEnabled())
					log.debug("tDBOutput_11 - " + ("Connection attempts to '") + (url_tDBOutput_11)
							+ ("' with the username '") + (dbUser_tDBOutput_11) + ("'."));
				conn_tDBOutput_11 = java.sql.DriverManager.getConnection(url_tDBOutput_11, dbUser_tDBOutput_11,
						dbPwd_tDBOutput_11);
				if (log.isDebugEnabled())
					log.debug("tDBOutput_11 - " + ("Connection to '") + (url_tDBOutput_11) + ("' has succeeded."));

				resourceMap.put("conn_tDBOutput_11", conn_tDBOutput_11);

				conn_tDBOutput_11.setAutoCommit(false);
				int commitEvery_tDBOutput_11 = 10000;
				int commitCounter_tDBOutput_11 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBOutput_11 - " + ("Connection is set auto commit to '")
							+ (conn_tDBOutput_11.getAutoCommit()) + ("'."));
				int batchSize_tDBOutput_11 = 10000;
				int batchSizeCounter_tDBOutput_11 = 0;

				if (dbschema_tDBOutput_11 == null || dbschema_tDBOutput_11.trim().length() == 0) {
					tableName_tDBOutput_11 = "Dim_PED_ROLE";
				} else {
					tableName_tDBOutput_11 = dbschema_tDBOutput_11 + "].[" + "Dim_PED_ROLE";
				}
				int count_tDBOutput_11 = 0;

				String insert_tDBOutput_11 = "INSERT INTO [" + tableName_tDBOutput_11
						+ "] ([PED_ROLE_SK],[PED_ROLE],[DI_PID],[DI_Create_Date]) VALUES (?,?,?,?)";
				java.sql.PreparedStatement pstmt_tDBOutput_11 = conn_tDBOutput_11.prepareStatement(insert_tDBOutput_11);
				resourceMap.put("pstmt_tDBOutput_11", pstmt_tDBOutput_11);

				/**
				 * [tDBOutput_11 begin ] stop
				 */

				/**
				 * [tMap_14 begin ] start
				 */

				ok_Hash.put("tMap_14", false);
				start_Hash.put("tMap_14", System.currentTimeMillis());

				currentComponent = "tMap_14";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "row12");

				int tos_count_tMap_14 = 0;

				if (log.isDebugEnabled())
					log.debug("tMap_14 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tMap_14 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tMap_14 = new StringBuilder();
							log4jParamters_tMap_14.append("Parameters:");
							log4jParamters_tMap_14.append("LINK_STYLE" + " = " + "AUTO");
							log4jParamters_tMap_14.append(" | ");
							log4jParamters_tMap_14.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
							log4jParamters_tMap_14.append(" | ");
							log4jParamters_tMap_14.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
							log4jParamters_tMap_14.append(" | ");
							log4jParamters_tMap_14.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "true");
							log4jParamters_tMap_14.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tMap_14 - " + (log4jParamters_tMap_14));
						}
					}
					new BytesLimit65535_tMap_14().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tMap_14", "tMap_14", "tMap");
					talendJobLogProcess(globalMap);
				}

// ###############################
// # Lookup's keys initialization
				int count_row12_tMap_14 = 0;

// ###############################        

// ###############################
// # Vars initialization
				class Var__tMap_14__Struct {
				}
				Var__tMap_14__Struct Var__tMap_14 = new Var__tMap_14__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_Ped_Role_Load_tMap_14 = 0;

				Ped_Role_LoadStruct Ped_Role_Load_tmp = new Ped_Role_LoadStruct();
// ###############################

				/**
				 * [tMap_14 begin ] stop
				 */

				/**
				 * [tUniqRow_12 begin ] start
				 */

				ok_Hash.put("tUniqRow_12", false);
				start_Hash.put("tUniqRow_12", System.currentTimeMillis());

				currentComponent = "tUniqRow_12";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "Ped_Role");

				int tos_count_tUniqRow_12 = 0;

				if (log.isDebugEnabled())
					log.debug("tUniqRow_12 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tUniqRow_12 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tUniqRow_12 = new StringBuilder();
							log4jParamters_tUniqRow_12.append("Parameters:");
							log4jParamters_tUniqRow_12.append("UNIQUE_KEY" + " = " + "[{CASE_SENSITIVE=" + ("false")
									+ ", KEY_ATTRIBUTE=" + ("true") + ", SCHEMA_COLUMN=" + ("PED_ROLE") + "}]");
							log4jParamters_tUniqRow_12.append(" | ");
							log4jParamters_tUniqRow_12.append("ONLY_ONCE_EACH_DUPLICATED_KEY" + " = " + "false");
							log4jParamters_tUniqRow_12.append(" | ");
							log4jParamters_tUniqRow_12.append("IS_VIRTUAL_COMPONENT" + " = " + "false");
							log4jParamters_tUniqRow_12.append(" | ");
							log4jParamters_tUniqRow_12
									.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "false");
							log4jParamters_tUniqRow_12.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tUniqRow_12 - " + (log4jParamters_tUniqRow_12));
						}
					}
					new BytesLimit65535_tUniqRow_12().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tUniqRow_12", "tUniqRow_12", "tUniqRow");
					talendJobLogProcess(globalMap);
				}

				class KeyStruct_tUniqRow_12 {

					private static final int DEFAULT_HASHCODE = 1;
					private static final int PRIME = 31;
					private int hashCode = DEFAULT_HASHCODE;
					public boolean hashCodeDirty = true;

					String PED_ROLE;

					@Override
					public int hashCode() {
						if (this.hashCodeDirty) {
							final int prime = PRIME;
							int result = DEFAULT_HASHCODE;

							result = prime * result + ((this.PED_ROLE == null) ? 0 : this.PED_ROLE.hashCode());

							this.hashCode = result;
							this.hashCodeDirty = false;
						}
						return this.hashCode;
					}

					@Override
					public boolean equals(Object obj) {
						if (this == obj)
							return true;
						if (obj == null)
							return false;
						if (getClass() != obj.getClass())
							return false;
						final KeyStruct_tUniqRow_12 other = (KeyStruct_tUniqRow_12) obj;

						if (this.PED_ROLE == null) {
							if (other.PED_ROLE != null)
								return false;

						} else if (!this.PED_ROLE.equals(other.PED_ROLE))

							return false;

						return true;
					}

				}

				int nb_uniques_tUniqRow_12 = 0;
				int nb_duplicates_tUniqRow_12 = 0;
				log.debug("tUniqRow_12 - Start to process the data from datasource.");
				KeyStruct_tUniqRow_12 finder_tUniqRow_12 = new KeyStruct_tUniqRow_12();
				java.util.Set<KeyStruct_tUniqRow_12> keystUniqRow_12 = new java.util.HashSet<KeyStruct_tUniqRow_12>();

				/**
				 * [tUniqRow_12 begin ] stop
				 */

				/**
				 * [tDBOutput_12 begin ] start
				 */

				ok_Hash.put("tDBOutput_12", false);
				start_Hash.put("tDBOutput_12", System.currentTimeMillis());

				currentComponent = "tDBOutput_12";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "Person_Sex1");

				int tos_count_tDBOutput_12 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBOutput_12 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tDBOutput_12 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tDBOutput_12 = new StringBuilder();
							log4jParamters_tDBOutput_12.append("Parameters:");
							log4jParamters_tDBOutput_12.append("USE_EXISTING_CONNECTION" + " = " + "false");
							log4jParamters_tDBOutput_12.append(" | ");
							log4jParamters_tDBOutput_12.append("DRIVER" + " = " + "JTDS");
							log4jParamters_tDBOutput_12.append(" | ");
							log4jParamters_tDBOutput_12.append("HOST" + " = " + "\"localhost\"");
							log4jParamters_tDBOutput_12.append(" | ");
							log4jParamters_tDBOutput_12.append("PORT" + " = " + "\"1433\"");
							log4jParamters_tDBOutput_12.append(" | ");
							log4jParamters_tDBOutput_12.append("DB_SCHEMA" + " = " + "\"\"");
							log4jParamters_tDBOutput_12.append(" | ");
							log4jParamters_tDBOutput_12.append("DBNAME" + " = " + "\"MVC_Stage\"");
							log4jParamters_tDBOutput_12.append(" | ");
							log4jParamters_tDBOutput_12.append("USER" + " = " + "\"\"");
							log4jParamters_tDBOutput_12.append(" | ");
							log4jParamters_tDBOutput_12.append("PASS" + " = "
									+ String.valueOf(
											"enc:routine.encryption.key.v1:q3OES82J+VYQwpplOLZ20KwkrpOA5IG1Howwew==")
											.substring(0, 4)
									+ "...");
							log4jParamters_tDBOutput_12.append(" | ");
							log4jParamters_tDBOutput_12.append("TABLE" + " = " + "\"Dim_PERSON_SEX\"");
							log4jParamters_tDBOutput_12.append(" | ");
							log4jParamters_tDBOutput_12.append("TABLE_ACTION" + " = " + "NONE");
							log4jParamters_tDBOutput_12.append(" | ");
							log4jParamters_tDBOutput_12.append("IDENTITY_INSERT" + " = " + "false");
							log4jParamters_tDBOutput_12.append(" | ");
							log4jParamters_tDBOutput_12.append("DATA_ACTION" + " = " + "INSERT");
							log4jParamters_tDBOutput_12.append(" | ");
							log4jParamters_tDBOutput_12.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
							log4jParamters_tDBOutput_12.append(" | ");
							log4jParamters_tDBOutput_12.append("DIE_ON_ERROR" + " = " + "false");
							log4jParamters_tDBOutput_12.append(" | ");
							log4jParamters_tDBOutput_12.append("PROPERTIES" + " = " + "\"\"");
							log4jParamters_tDBOutput_12.append(" | ");
							log4jParamters_tDBOutput_12.append("COMMIT_EVERY" + " = " + "10000");
							log4jParamters_tDBOutput_12.append(" | ");
							log4jParamters_tDBOutput_12.append("ADD_COLS" + " = " + "[]");
							log4jParamters_tDBOutput_12.append(" | ");
							log4jParamters_tDBOutput_12.append("USE_FIELD_OPTIONS" + " = " + "false");
							log4jParamters_tDBOutput_12.append(" | ");
							log4jParamters_tDBOutput_12.append("IGNORE_DATE_OUTOF_RANGE" + " = " + "false");
							log4jParamters_tDBOutput_12.append(" | ");
							log4jParamters_tDBOutput_12.append("ENABLE_DEBUG_MODE" + " = " + "false");
							log4jParamters_tDBOutput_12.append(" | ");
							log4jParamters_tDBOutput_12.append("SUPPORT_NULL_WHERE" + " = " + "false");
							log4jParamters_tDBOutput_12.append(" | ");
							log4jParamters_tDBOutput_12.append("USE_BATCH_SIZE" + " = " + "true");
							log4jParamters_tDBOutput_12.append(" | ");
							log4jParamters_tDBOutput_12.append("BATCH_SIZE" + " = " + "10000");
							log4jParamters_tDBOutput_12.append(" | ");
							log4jParamters_tDBOutput_12.append("UNIFIED_COMPONENTS" + " = " + "tMSSqlOutput");
							log4jParamters_tDBOutput_12.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tDBOutput_12 - " + (log4jParamters_tDBOutput_12));
						}
					}
					new BytesLimit65535_tDBOutput_12().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tDBOutput_12", "__TABLE__", "tMSSqlOutput");
					talendJobLogProcess(globalMap);
				}

				int nb_line_tDBOutput_12 = 0;
				int nb_line_update_tDBOutput_12 = 0;
				int nb_line_inserted_tDBOutput_12 = 0;
				int nb_line_deleted_tDBOutput_12 = 0;
				int nb_line_rejected_tDBOutput_12 = 0;

				int deletedCount_tDBOutput_12 = 0;
				int updatedCount_tDBOutput_12 = 0;
				int insertedCount_tDBOutput_12 = 0;
				int rowsToCommitCount_tDBOutput_12 = 0;
				int rejectedCount_tDBOutput_12 = 0;
				String dbschema_tDBOutput_12 = null;
				String tableName_tDBOutput_12 = null;
				boolean whetherReject_tDBOutput_12 = false;

				java.util.Calendar calendar_tDBOutput_12 = java.util.Calendar.getInstance();
				long year1_tDBOutput_12 = TalendDate.parseDate("yyyy-MM-dd", "0001-01-01").getTime();
				long year2_tDBOutput_12 = TalendDate.parseDate("yyyy-MM-dd", "1753-01-01").getTime();
				long year10000_tDBOutput_12 = TalendDate.parseDate("yyyy-MM-dd HH:mm:ss", "9999-12-31 24:00:00")
						.getTime();
				long date_tDBOutput_12;

				java.util.Calendar calendar_datetimeoffset_tDBOutput_12 = java.util.Calendar
						.getInstance(java.util.TimeZone.getTimeZone("UTC"));

				java.sql.Connection conn_tDBOutput_12 = null;
				String dbUser_tDBOutput_12 = null;
				dbschema_tDBOutput_12 = "";
				String driverClass_tDBOutput_12 = "net.sourceforge.jtds.jdbc.Driver";

				if (log.isDebugEnabled())
					log.debug("tDBOutput_12 - " + ("Driver ClassName: ") + (driverClass_tDBOutput_12) + ("."));
				java.lang.Class.forName(driverClass_tDBOutput_12);
				String port_tDBOutput_12 = "1433";
				String dbname_tDBOutput_12 = "MVC_Stage";
				String url_tDBOutput_12 = "jdbc:jtds:sqlserver://" + "localhost";
				if (!"".equals(port_tDBOutput_12)) {
					url_tDBOutput_12 += ":" + "1433";
				}
				if (!"".equals(dbname_tDBOutput_12)) {
					url_tDBOutput_12 += "//" + "MVC_Stage";

				}
				url_tDBOutput_12 += ";appName=" + projectName + ";" + "";
				dbUser_tDBOutput_12 = "";

				final String decryptedPassword_tDBOutput_12 = routines.system.PasswordEncryptUtil
						.decryptPassword("enc:routine.encryption.key.v1:BYQfcFDcH87LcFgzL8w4gk0oUZitVyIKNIDfAA==");

				String dbPwd_tDBOutput_12 = decryptedPassword_tDBOutput_12;
				if (log.isDebugEnabled())
					log.debug("tDBOutput_12 - " + ("Connection attempts to '") + (url_tDBOutput_12)
							+ ("' with the username '") + (dbUser_tDBOutput_12) + ("'."));
				conn_tDBOutput_12 = java.sql.DriverManager.getConnection(url_tDBOutput_12, dbUser_tDBOutput_12,
						dbPwd_tDBOutput_12);
				if (log.isDebugEnabled())
					log.debug("tDBOutput_12 - " + ("Connection to '") + (url_tDBOutput_12) + ("' has succeeded."));

				resourceMap.put("conn_tDBOutput_12", conn_tDBOutput_12);

				conn_tDBOutput_12.setAutoCommit(false);
				int commitEvery_tDBOutput_12 = 10000;
				int commitCounter_tDBOutput_12 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBOutput_12 - " + ("Connection is set auto commit to '")
							+ (conn_tDBOutput_12.getAutoCommit()) + ("'."));
				int batchSize_tDBOutput_12 = 10000;
				int batchSizeCounter_tDBOutput_12 = 0;

				if (dbschema_tDBOutput_12 == null || dbschema_tDBOutput_12.trim().length() == 0) {
					tableName_tDBOutput_12 = "Dim_PERSON_SEX";
				} else {
					tableName_tDBOutput_12 = dbschema_tDBOutput_12 + "].[" + "Dim_PERSON_SEX";
				}
				int count_tDBOutput_12 = 0;

				String insert_tDBOutput_12 = "INSERT INTO [" + tableName_tDBOutput_12
						+ "] ([PERSON_SEX_SK],[PERSON_SEX],[DI_PID],[DI_Create_Date]) VALUES (?,?,?,?)";
				java.sql.PreparedStatement pstmt_tDBOutput_12 = conn_tDBOutput_12.prepareStatement(insert_tDBOutput_12);
				resourceMap.put("pstmt_tDBOutput_12", pstmt_tDBOutput_12);

				/**
				 * [tDBOutput_12 begin ] stop
				 */

				/**
				 * [tMap_15 begin ] start
				 */

				ok_Hash.put("tMap_15", false);
				start_Hash.put("tMap_15", System.currentTimeMillis());

				currentComponent = "tMap_15";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "row13");

				int tos_count_tMap_15 = 0;

				if (log.isDebugEnabled())
					log.debug("tMap_15 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tMap_15 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tMap_15 = new StringBuilder();
							log4jParamters_tMap_15.append("Parameters:");
							log4jParamters_tMap_15.append("LINK_STYLE" + " = " + "AUTO");
							log4jParamters_tMap_15.append(" | ");
							log4jParamters_tMap_15.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
							log4jParamters_tMap_15.append(" | ");
							log4jParamters_tMap_15.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
							log4jParamters_tMap_15.append(" | ");
							log4jParamters_tMap_15.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "true");
							log4jParamters_tMap_15.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tMap_15 - " + (log4jParamters_tMap_15));
						}
					}
					new BytesLimit65535_tMap_15().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tMap_15", "tMap_15", "tMap");
					talendJobLogProcess(globalMap);
				}

// ###############################
// # Lookup's keys initialization
				int count_row13_tMap_15 = 0;

// ###############################        

// ###############################
// # Vars initialization
				class Var__tMap_15__Struct {
				}
				Var__tMap_15__Struct Var__tMap_15 = new Var__tMap_15__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_Person_Sex1_tMap_15 = 0;

				Person_Sex1Struct Person_Sex1_tmp = new Person_Sex1Struct();
// ###############################

				/**
				 * [tMap_15 begin ] stop
				 */

				/**
				 * [tUniqRow_13 begin ] start
				 */

				ok_Hash.put("tUniqRow_13", false);
				start_Hash.put("tUniqRow_13", System.currentTimeMillis());

				currentComponent = "tUniqRow_13";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "Person_Sex");

				int tos_count_tUniqRow_13 = 0;

				if (log.isDebugEnabled())
					log.debug("tUniqRow_13 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tUniqRow_13 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tUniqRow_13 = new StringBuilder();
							log4jParamters_tUniqRow_13.append("Parameters:");
							log4jParamters_tUniqRow_13.append("UNIQUE_KEY" + " = " + "[{CASE_SENSITIVE=" + ("false")
									+ ", KEY_ATTRIBUTE=" + ("true") + ", SCHEMA_COLUMN=" + ("PERSON_SEX") + "}]");
							log4jParamters_tUniqRow_13.append(" | ");
							log4jParamters_tUniqRow_13.append("ONLY_ONCE_EACH_DUPLICATED_KEY" + " = " + "false");
							log4jParamters_tUniqRow_13.append(" | ");
							log4jParamters_tUniqRow_13.append("IS_VIRTUAL_COMPONENT" + " = " + "false");
							log4jParamters_tUniqRow_13.append(" | ");
							log4jParamters_tUniqRow_13
									.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "false");
							log4jParamters_tUniqRow_13.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tUniqRow_13 - " + (log4jParamters_tUniqRow_13));
						}
					}
					new BytesLimit65535_tUniqRow_13().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tUniqRow_13", "tUniqRow_13", "tUniqRow");
					talendJobLogProcess(globalMap);
				}

				class KeyStruct_tUniqRow_13 {

					private static final int DEFAULT_HASHCODE = 1;
					private static final int PRIME = 31;
					private int hashCode = DEFAULT_HASHCODE;
					public boolean hashCodeDirty = true;

					String PERSON_SEX;

					@Override
					public int hashCode() {
						if (this.hashCodeDirty) {
							final int prime = PRIME;
							int result = DEFAULT_HASHCODE;

							result = prime * result + ((this.PERSON_SEX == null) ? 0 : this.PERSON_SEX.hashCode());

							this.hashCode = result;
							this.hashCodeDirty = false;
						}
						return this.hashCode;
					}

					@Override
					public boolean equals(Object obj) {
						if (this == obj)
							return true;
						if (obj == null)
							return false;
						if (getClass() != obj.getClass())
							return false;
						final KeyStruct_tUniqRow_13 other = (KeyStruct_tUniqRow_13) obj;

						if (this.PERSON_SEX == null) {
							if (other.PERSON_SEX != null)
								return false;

						} else if (!this.PERSON_SEX.equals(other.PERSON_SEX))

							return false;

						return true;
					}

				}

				int nb_uniques_tUniqRow_13 = 0;
				int nb_duplicates_tUniqRow_13 = 0;
				log.debug("tUniqRow_13 - Start to process the data from datasource.");
				KeyStruct_tUniqRow_13 finder_tUniqRow_13 = new KeyStruct_tUniqRow_13();
				java.util.Set<KeyStruct_tUniqRow_13> keystUniqRow_13 = new java.util.HashSet<KeyStruct_tUniqRow_13>();

				/**
				 * [tUniqRow_13 begin ] stop
				 */

				/**
				 * [tMap_1 begin ] start
				 */

				ok_Hash.put("tMap_1", false);
				start_Hash.put("tMap_1", System.currentTimeMillis());

				currentComponent = "tMap_1";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "row1");

				int tos_count_tMap_1 = 0;

				if (log.isDebugEnabled())
					log.debug("tMap_1 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tMap_1 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tMap_1 = new StringBuilder();
							log4jParamters_tMap_1.append("Parameters:");
							log4jParamters_tMap_1.append("LINK_STYLE" + " = " + "AUTO");
							log4jParamters_tMap_1.append(" | ");
							log4jParamters_tMap_1.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
							log4jParamters_tMap_1.append(" | ");
							log4jParamters_tMap_1.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
							log4jParamters_tMap_1.append(" | ");
							log4jParamters_tMap_1.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "true");
							log4jParamters_tMap_1.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tMap_1 - " + (log4jParamters_tMap_1));
						}
					}
					new BytesLimit65535_tMap_1().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tMap_1", "tMap_1", "tMap");
					talendJobLogProcess(globalMap);
				}

// ###############################
// # Lookup's keys initialization
				int count_row1_tMap_1 = 0;

// ###############################        

// ###############################
// # Vars initialization
				class Var__tMap_1__Struct {
				}
				Var__tMap_1__Struct Var__tMap_1 = new Var__tMap_1__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_Person_type_tMap_1 = 0;

				Person_typeStruct Person_type_tmp = new Person_typeStruct();
				int count_Person_Injury_tMap_1 = 0;

				Person_InjuryStruct Person_Injury_tmp = new Person_InjuryStruct();
				int count_Emotional_Status_tMap_1 = 0;

				Emotional_StatusStruct Emotional_Status_tmp = new Emotional_StatusStruct();
				int count_Ejection_tMap_1 = 0;

				EjectionStruct Ejection_tmp = new EjectionStruct();
				int count_Bodily_Injury_tMap_1 = 0;

				Bodily_InjuryStruct Bodily_Injury_tmp = new Bodily_InjuryStruct();
				int count_Position_In_vehicle_tMap_1 = 0;

				Position_In_vehicleStruct Position_In_vehicle_tmp = new Position_In_vehicleStruct();
				int count_Safety_Equipment_tMap_1 = 0;

				Safety_EquipmentStruct Safety_Equipment_tmp = new Safety_EquipmentStruct();
				int count_Ped_Location_tMap_1 = 0;

				Ped_LocationStruct Ped_Location_tmp = new Ped_LocationStruct();
				int count_Ped_Location1_tMap_1 = 0;

				Ped_Location1Struct Ped_Location1_tmp = new Ped_Location1Struct();
				int count_Complaint_tMap_1 = 0;

				ComplaintStruct Complaint_tmp = new ComplaintStruct();
				int count_Ped_Role_tMap_1 = 0;

				Ped_RoleStruct Ped_Role_tmp = new Ped_RoleStruct();
				int count_Person_Sex_tMap_1 = 0;

				Person_SexStruct Person_Sex_tmp = new Person_SexStruct();
// ###############################

				/**
				 * [tMap_1 begin ] stop
				 */

				/**
				 * [tDBInput_1 begin ] start
				 */

				ok_Hash.put("tDBInput_1", false);
				start_Hash.put("tDBInput_1", System.currentTimeMillis());

				currentComponent = "tDBInput_1";

				int tos_count_tDBInput_1 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBInput_1 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tDBInput_1 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tDBInput_1 = new StringBuilder();
							log4jParamters_tDBInput_1.append("Parameters:");
							log4jParamters_tDBInput_1.append("USE_EXISTING_CONNECTION" + " = " + "false");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("HOST" + " = " + "\"localhost\"");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("DRIVER" + " = " + "JTDS");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("PORT" + " = " + "\"1433\"");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("DB_SCHEMA" + " = " + "\"\"");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("DBNAME" + " = " + "\"MVC_Stage\"");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("USER" + " = " + "\"\"");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("PASS" + " = "
									+ String.valueOf(
											"enc:routine.encryption.key.v1:8wNq2FAirWcskK880YJtTTBE3+WFpPjTA78clw==")
											.substring(0, 4)
									+ "...");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("TABLE" + " = " + "\"MVC_People_Stage\"");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("QUERYSTORE" + " = " + "\"\"");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("QUERY" + " = "
									+ "\"SELECT MVC_People_Stage.UNIQUE_ID, 		MVC_People_Stage.COLLISION_ID, 		MVC_People_Stage.CRASH_DATE, 		MVC_People_Stage.CRASH_TIME, 		MVC_People_Stage.PERSON_ID, 		MVC_People_Stage.PERSON_TYPE, 		MVC_People_Stage.PERSON_INJURY, 		MVC_People_Stage.VEHICLE_ID, 		MVC_People_Stage.PERSON_AGE, 		MVC_People_Stage.EJECTION, 		MVC_People_Stage.EMOTIONAL_STATUS, 		MVC_People_Stage.BODILY_INJURY, 		MVC_People_Stage.POSITION_IN_VEHICLE, 		MVC_People_Stage.SAFETY_EQUIPMENT, 		MVC_People_Stage.PED_LOCATION, 		MVC_People_Stage.PED_ACTION, 		MVC_People_Stage.COMPLAINT, 		MVC_People_Stage.PED_ROLE, 		MVC_People_Stage.CONTRIBUTING_FACTOR_1, 		MVC_People_Stage.CONTRIBUTING_FACTOR_2, 		MVC_People_Stage.PERSON_SEX FROM	MVC_People_Stage\"");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("PROPERTIES" + " = " + "\"\"");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("TRIM_ALL_COLUMN" + " = " + "false");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("TRIM_COLUMN" + " = " + "[{TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("UNIQUE_ID") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN="
									+ ("COLLISION_ID") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN=" + ("CRASH_DATE")
									+ "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN=" + ("CRASH_TIME") + "}, {TRIM="
									+ ("false") + ", SCHEMA_COLUMN=" + ("PERSON_ID") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("PERSON_TYPE") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("PERSON_INJURY") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("VEHICLE_ID") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN="
									+ ("PERSON_AGE") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN=" + ("EJECTION")
									+ "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN=" + ("EMOTIONAL_STATUS") + "}, {TRIM="
									+ ("false") + ", SCHEMA_COLUMN=" + ("BODILY_INJURY") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("POSITION_IN_VEHICLE") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("SAFETY_EQUIPMENT") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("PED_LOCATION") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("PED_ACTION") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN="
									+ ("COMPLAINT") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN=" + ("PED_ROLE")
									+ "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN=" + ("CONTRIBUTING_FACTOR_1")
									+ "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN=" + ("CONTRIBUTING_FACTOR_2")
									+ "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN=" + ("PERSON_SEX") + "}]");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("UNIFIED_COMPONENTS" + " = " + "tMSSqlInput");
							log4jParamters_tDBInput_1.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tDBInput_1 - " + (log4jParamters_tDBInput_1));
						}
					}
					new BytesLimit65535_tDBInput_1().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tDBInput_1", "__TABLE__", "tMSSqlInput");
					talendJobLogProcess(globalMap);
				}

				org.talend.designer.components.util.mssql.MSSqlGenerateTimestampUtil mssqlGTU_tDBInput_1 = org.talend.designer.components.util.mssql.MSSqlUtilFactory
						.getMSSqlGenerateTimestampUtil();

				java.util.List<String> talendToDBList_tDBInput_1 = new java.util.ArrayList();
				String[] talendToDBArray_tDBInput_1 = new String[] { "FLOAT", "NUMERIC", "NUMERIC IDENTITY", "DECIMAL",
						"DECIMAL IDENTITY", "REAL" };
				java.util.Collections.addAll(talendToDBList_tDBInput_1, talendToDBArray_tDBInput_1);
				int nb_line_tDBInput_1 = 0;
				java.sql.Connection conn_tDBInput_1 = null;
				String driverClass_tDBInput_1 = "net.sourceforge.jtds.jdbc.Driver";
				java.lang.Class jdbcclazz_tDBInput_1 = java.lang.Class.forName(driverClass_tDBInput_1);
				String dbUser_tDBInput_1 = "";

				final String decryptedPassword_tDBInput_1 = routines.system.PasswordEncryptUtil
						.decryptPassword("enc:routine.encryption.key.v1:5GMiEqpzKnyLWINcNpQjzNM+lQ4RL6fr5bghAg==");

				String dbPwd_tDBInput_1 = decryptedPassword_tDBInput_1;

				String port_tDBInput_1 = "1433";
				String dbname_tDBInput_1 = "MVC_Stage";
				String url_tDBInput_1 = "jdbc:jtds:sqlserver://" + "localhost";
				if (!"".equals(port_tDBInput_1)) {
					url_tDBInput_1 += ":" + "1433";
				}
				if (!"".equals(dbname_tDBInput_1)) {
					url_tDBInput_1 += "//" + "MVC_Stage";
				}
				url_tDBInput_1 += ";appName=" + projectName + ";" + "";
				String dbschema_tDBInput_1 = "";

				log.debug("tDBInput_1 - Driver ClassName: " + driverClass_tDBInput_1 + ".");

				log.debug("tDBInput_1 - Connection attempt to '" + url_tDBInput_1 + "' with the username '"
						+ dbUser_tDBInput_1 + "'.");

				conn_tDBInput_1 = java.sql.DriverManager.getConnection(url_tDBInput_1, dbUser_tDBInput_1,
						dbPwd_tDBInput_1);
				log.debug("tDBInput_1 - Connection to '" + url_tDBInput_1 + "' has succeeded.");

				java.sql.Statement stmt_tDBInput_1 = conn_tDBInput_1.createStatement();

				String dbquery_tDBInput_1 = "SELECT MVC_People_Stage.UNIQUE_ID,\n		MVC_People_Stage.COLLISION_ID,\n		MVC_People_Stage.CRASH_DATE,\n		MVC_People_Stage.C"
						+ "RASH_TIME,\n		MVC_People_Stage.PERSON_ID,\n		MVC_People_Stage.PERSON_TYPE,\n		MVC_People_Stage.PERSON_INJURY,\n		MVC_People_"
						+ "Stage.VEHICLE_ID,\n		MVC_People_Stage.PERSON_AGE,\n		MVC_People_Stage.EJECTION,\n		MVC_People_Stage.EMOTIONAL_STATUS,\n		MVC"
						+ "_People_Stage.BODILY_INJURY,\n		MVC_People_Stage.POSITION_IN_VEHICLE,\n		MVC_People_Stage.SAFETY_EQUIPMENT,\n		MVC_People_S"
						+ "tage.PED_LOCATION,\n		MVC_People_Stage.PED_ACTION,\n		MVC_People_Stage.COMPLAINT,\n		MVC_People_Stage.PED_ROLE,\n		MVC_Peopl"
						+ "e_Stage.CONTRIBUTING_FACTOR_1,\n		MVC_People_Stage.CONTRIBUTING_FACTOR_2,\n		MVC_People_Stage.PERSON_SEX\nFROM	MVC_People_S"
						+ "tage";

				log.debug("tDBInput_1 - Executing the query: '" + dbquery_tDBInput_1 + "'.");

				globalMap.put("tDBInput_1_QUERY", dbquery_tDBInput_1);
				java.sql.ResultSet rs_tDBInput_1 = null;

				try {
					rs_tDBInput_1 = stmt_tDBInput_1.executeQuery(dbquery_tDBInput_1);
					java.sql.ResultSetMetaData rsmd_tDBInput_1 = rs_tDBInput_1.getMetaData();
					int colQtyInRs_tDBInput_1 = rsmd_tDBInput_1.getColumnCount();

					String tmpContent_tDBInput_1 = null;

					log.debug("tDBInput_1 - Retrieving records from the database.");

					while (rs_tDBInput_1.next()) {
						nb_line_tDBInput_1++;

						if (colQtyInRs_tDBInput_1 < 1) {
							row1.UNIQUE_ID = null;
						} else {

							row1.UNIQUE_ID = rs_tDBInput_1.getInt(1);
							if (rs_tDBInput_1.wasNull()) {
								row1.UNIQUE_ID = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 2) {
							row1.COLLISION_ID = null;
						} else {

							row1.COLLISION_ID = rs_tDBInput_1.getInt(2);
							if (rs_tDBInput_1.wasNull()) {
								row1.COLLISION_ID = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 3) {
							row1.CRASH_DATE = null;
						} else {

							tmpContent_tDBInput_1 = rs_tDBInput_1.getString(3);
							if (tmpContent_tDBInput_1 != null) {
								if (talendToDBList_tDBInput_1.contains(
										rsmd_tDBInput_1.getColumnTypeName(3).toUpperCase(java.util.Locale.ENGLISH))) {
									row1.CRASH_DATE = FormatterUtils.formatUnwithE(tmpContent_tDBInput_1);
								} else {
									row1.CRASH_DATE = tmpContent_tDBInput_1;
								}
							} else {
								row1.CRASH_DATE = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 4) {
							row1.CRASH_TIME = null;
						} else {

							tmpContent_tDBInput_1 = rs_tDBInput_1.getString(4);
							if (tmpContent_tDBInput_1 != null) {
								if (talendToDBList_tDBInput_1.contains(
										rsmd_tDBInput_1.getColumnTypeName(4).toUpperCase(java.util.Locale.ENGLISH))) {
									row1.CRASH_TIME = FormatterUtils.formatUnwithE(tmpContent_tDBInput_1);
								} else {
									row1.CRASH_TIME = tmpContent_tDBInput_1;
								}
							} else {
								row1.CRASH_TIME = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 5) {
							row1.PERSON_ID = null;
						} else {

							tmpContent_tDBInput_1 = rs_tDBInput_1.getString(5);
							if (tmpContent_tDBInput_1 != null) {
								if (talendToDBList_tDBInput_1.contains(
										rsmd_tDBInput_1.getColumnTypeName(5).toUpperCase(java.util.Locale.ENGLISH))) {
									row1.PERSON_ID = FormatterUtils.formatUnwithE(tmpContent_tDBInput_1);
								} else {
									row1.PERSON_ID = tmpContent_tDBInput_1;
								}
							} else {
								row1.PERSON_ID = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 6) {
							row1.PERSON_TYPE = null;
						} else {

							tmpContent_tDBInput_1 = rs_tDBInput_1.getString(6);
							if (tmpContent_tDBInput_1 != null) {
								if (talendToDBList_tDBInput_1.contains(
										rsmd_tDBInput_1.getColumnTypeName(6).toUpperCase(java.util.Locale.ENGLISH))) {
									row1.PERSON_TYPE = FormatterUtils.formatUnwithE(tmpContent_tDBInput_1);
								} else {
									row1.PERSON_TYPE = tmpContent_tDBInput_1;
								}
							} else {
								row1.PERSON_TYPE = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 7) {
							row1.PERSON_INJURY = null;
						} else {

							tmpContent_tDBInput_1 = rs_tDBInput_1.getString(7);
							if (tmpContent_tDBInput_1 != null) {
								if (talendToDBList_tDBInput_1.contains(
										rsmd_tDBInput_1.getColumnTypeName(7).toUpperCase(java.util.Locale.ENGLISH))) {
									row1.PERSON_INJURY = FormatterUtils.formatUnwithE(tmpContent_tDBInput_1);
								} else {
									row1.PERSON_INJURY = tmpContent_tDBInput_1;
								}
							} else {
								row1.PERSON_INJURY = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 8) {
							row1.VEHICLE_ID = null;
						} else {

							tmpContent_tDBInput_1 = rs_tDBInput_1.getString(8);
							if (tmpContent_tDBInput_1 != null) {
								if (talendToDBList_tDBInput_1.contains(
										rsmd_tDBInput_1.getColumnTypeName(8).toUpperCase(java.util.Locale.ENGLISH))) {
									row1.VEHICLE_ID = FormatterUtils.formatUnwithE(tmpContent_tDBInput_1);
								} else {
									row1.VEHICLE_ID = tmpContent_tDBInput_1;
								}
							} else {
								row1.VEHICLE_ID = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 9) {
							row1.PERSON_AGE = null;
						} else {

							tmpContent_tDBInput_1 = rs_tDBInput_1.getString(9);
							if (tmpContent_tDBInput_1 != null) {
								if (talendToDBList_tDBInput_1.contains(
										rsmd_tDBInput_1.getColumnTypeName(9).toUpperCase(java.util.Locale.ENGLISH))) {
									row1.PERSON_AGE = FormatterUtils.formatUnwithE(tmpContent_tDBInput_1);
								} else {
									row1.PERSON_AGE = tmpContent_tDBInput_1;
								}
							} else {
								row1.PERSON_AGE = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 10) {
							row1.EJECTION = null;
						} else {

							tmpContent_tDBInput_1 = rs_tDBInput_1.getString(10);
							if (tmpContent_tDBInput_1 != null) {
								if (talendToDBList_tDBInput_1.contains(
										rsmd_tDBInput_1.getColumnTypeName(10).toUpperCase(java.util.Locale.ENGLISH))) {
									row1.EJECTION = FormatterUtils.formatUnwithE(tmpContent_tDBInput_1);
								} else {
									row1.EJECTION = tmpContent_tDBInput_1;
								}
							} else {
								row1.EJECTION = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 11) {
							row1.EMOTIONAL_STATUS = null;
						} else {

							tmpContent_tDBInput_1 = rs_tDBInput_1.getString(11);
							if (tmpContent_tDBInput_1 != null) {
								if (talendToDBList_tDBInput_1.contains(
										rsmd_tDBInput_1.getColumnTypeName(11).toUpperCase(java.util.Locale.ENGLISH))) {
									row1.EMOTIONAL_STATUS = FormatterUtils.formatUnwithE(tmpContent_tDBInput_1);
								} else {
									row1.EMOTIONAL_STATUS = tmpContent_tDBInput_1;
								}
							} else {
								row1.EMOTIONAL_STATUS = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 12) {
							row1.BODILY_INJURY = null;
						} else {

							tmpContent_tDBInput_1 = rs_tDBInput_1.getString(12);
							if (tmpContent_tDBInput_1 != null) {
								if (talendToDBList_tDBInput_1.contains(
										rsmd_tDBInput_1.getColumnTypeName(12).toUpperCase(java.util.Locale.ENGLISH))) {
									row1.BODILY_INJURY = FormatterUtils.formatUnwithE(tmpContent_tDBInput_1);
								} else {
									row1.BODILY_INJURY = tmpContent_tDBInput_1;
								}
							} else {
								row1.BODILY_INJURY = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 13) {
							row1.POSITION_IN_VEHICLE = null;
						} else {

							tmpContent_tDBInput_1 = rs_tDBInput_1.getString(13);
							if (tmpContent_tDBInput_1 != null) {
								if (talendToDBList_tDBInput_1.contains(
										rsmd_tDBInput_1.getColumnTypeName(13).toUpperCase(java.util.Locale.ENGLISH))) {
									row1.POSITION_IN_VEHICLE = FormatterUtils.formatUnwithE(tmpContent_tDBInput_1);
								} else {
									row1.POSITION_IN_VEHICLE = tmpContent_tDBInput_1;
								}
							} else {
								row1.POSITION_IN_VEHICLE = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 14) {
							row1.SAFETY_EQUIPMENT = null;
						} else {

							tmpContent_tDBInput_1 = rs_tDBInput_1.getString(14);
							if (tmpContent_tDBInput_1 != null) {
								if (talendToDBList_tDBInput_1.contains(
										rsmd_tDBInput_1.getColumnTypeName(14).toUpperCase(java.util.Locale.ENGLISH))) {
									row1.SAFETY_EQUIPMENT = FormatterUtils.formatUnwithE(tmpContent_tDBInput_1);
								} else {
									row1.SAFETY_EQUIPMENT = tmpContent_tDBInput_1;
								}
							} else {
								row1.SAFETY_EQUIPMENT = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 15) {
							row1.PED_LOCATION = null;
						} else {

							tmpContent_tDBInput_1 = rs_tDBInput_1.getString(15);
							if (tmpContent_tDBInput_1 != null) {
								if (talendToDBList_tDBInput_1.contains(
										rsmd_tDBInput_1.getColumnTypeName(15).toUpperCase(java.util.Locale.ENGLISH))) {
									row1.PED_LOCATION = FormatterUtils.formatUnwithE(tmpContent_tDBInput_1);
								} else {
									row1.PED_LOCATION = tmpContent_tDBInput_1;
								}
							} else {
								row1.PED_LOCATION = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 16) {
							row1.PED_ACTION = null;
						} else {

							tmpContent_tDBInput_1 = rs_tDBInput_1.getString(16);
							if (tmpContent_tDBInput_1 != null) {
								if (talendToDBList_tDBInput_1.contains(
										rsmd_tDBInput_1.getColumnTypeName(16).toUpperCase(java.util.Locale.ENGLISH))) {
									row1.PED_ACTION = FormatterUtils.formatUnwithE(tmpContent_tDBInput_1);
								} else {
									row1.PED_ACTION = tmpContent_tDBInput_1;
								}
							} else {
								row1.PED_ACTION = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 17) {
							row1.COMPLAINT = null;
						} else {

							tmpContent_tDBInput_1 = rs_tDBInput_1.getString(17);
							if (tmpContent_tDBInput_1 != null) {
								if (talendToDBList_tDBInput_1.contains(
										rsmd_tDBInput_1.getColumnTypeName(17).toUpperCase(java.util.Locale.ENGLISH))) {
									row1.COMPLAINT = FormatterUtils.formatUnwithE(tmpContent_tDBInput_1);
								} else {
									row1.COMPLAINT = tmpContent_tDBInput_1;
								}
							} else {
								row1.COMPLAINT = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 18) {
							row1.PED_ROLE = null;
						} else {

							tmpContent_tDBInput_1 = rs_tDBInput_1.getString(18);
							if (tmpContent_tDBInput_1 != null) {
								if (talendToDBList_tDBInput_1.contains(
										rsmd_tDBInput_1.getColumnTypeName(18).toUpperCase(java.util.Locale.ENGLISH))) {
									row1.PED_ROLE = FormatterUtils.formatUnwithE(tmpContent_tDBInput_1);
								} else {
									row1.PED_ROLE = tmpContent_tDBInput_1;
								}
							} else {
								row1.PED_ROLE = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 19) {
							row1.CONTRIBUTING_FACTOR_1 = null;
						} else {

							tmpContent_tDBInput_1 = rs_tDBInput_1.getString(19);
							if (tmpContent_tDBInput_1 != null) {
								if (talendToDBList_tDBInput_1.contains(
										rsmd_tDBInput_1.getColumnTypeName(19).toUpperCase(java.util.Locale.ENGLISH))) {
									row1.CONTRIBUTING_FACTOR_1 = FormatterUtils.formatUnwithE(tmpContent_tDBInput_1);
								} else {
									row1.CONTRIBUTING_FACTOR_1 = tmpContent_tDBInput_1;
								}
							} else {
								row1.CONTRIBUTING_FACTOR_1 = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 20) {
							row1.CONTRIBUTING_FACTOR_2 = null;
						} else {

							tmpContent_tDBInput_1 = rs_tDBInput_1.getString(20);
							if (tmpContent_tDBInput_1 != null) {
								if (talendToDBList_tDBInput_1.contains(
										rsmd_tDBInput_1.getColumnTypeName(20).toUpperCase(java.util.Locale.ENGLISH))) {
									row1.CONTRIBUTING_FACTOR_2 = FormatterUtils.formatUnwithE(tmpContent_tDBInput_1);
								} else {
									row1.CONTRIBUTING_FACTOR_2 = tmpContent_tDBInput_1;
								}
							} else {
								row1.CONTRIBUTING_FACTOR_2 = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 21) {
							row1.PERSON_SEX = null;
						} else {

							tmpContent_tDBInput_1 = rs_tDBInput_1.getString(21);
							if (tmpContent_tDBInput_1 != null) {
								if (talendToDBList_tDBInput_1.contains(
										rsmd_tDBInput_1.getColumnTypeName(21).toUpperCase(java.util.Locale.ENGLISH))) {
									row1.PERSON_SEX = FormatterUtils.formatUnwithE(tmpContent_tDBInput_1);
								} else {
									row1.PERSON_SEX = tmpContent_tDBInput_1;
								}
							} else {
								row1.PERSON_SEX = null;
							}
						}

						log.debug("tDBInput_1 - Retrieving the record " + nb_line_tDBInput_1 + ".");

						/**
						 * [tDBInput_1 begin ] stop
						 */

						/**
						 * [tDBInput_1 main ] start
						 */

						currentComponent = "tDBInput_1";

						tos_count_tDBInput_1++;

						/**
						 * [tDBInput_1 main ] stop
						 */

						/**
						 * [tDBInput_1 process_data_begin ] start
						 */

						currentComponent = "tDBInput_1";

						/**
						 * [tDBInput_1 process_data_begin ] stop
						 */

						/**
						 * [tMap_1 main ] start
						 */

						currentComponent = "tMap_1";

						if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

								, "row1", "tDBInput_1", "__TABLE__", "tMSSqlInput", "tMap_1", "tMap_1", "tMap"

						)) {
							talendJobLogProcess(globalMap);
						}

						if (log.isTraceEnabled()) {
							log.trace("row1 - " + (row1 == null ? "" : row1.toLogString()));
						}

						boolean hasCasePrimitiveKeyWithNull_tMap_1 = false;

						// ###############################
						// # Input tables (lookups)
						boolean rejectedInnerJoin_tMap_1 = false;
						boolean mainRowRejected_tMap_1 = false;

						// ###############################
						{ // start of Var scope

							// ###############################
							// # Vars tables

							Var__tMap_1__Struct Var = Var__tMap_1;// ###############################
							// ###############################
							// # Output tables

							Person_type = null;
							Person_Injury = null;
							Emotional_Status = null;
							Ejection = null;
							Bodily_Injury = null;
							Position_In_vehicle = null;
							Safety_Equipment = null;
							Ped_Location = null;
							Ped_Location1 = null;
							Complaint = null;
							Ped_Role = null;
							Person_Sex = null;

// # Output table : 'Person_type'
							count_Person_type_tMap_1++;

							Person_type_tmp.PERSON_TYPE = row1.PERSON_TYPE;
							Person_type = Person_type_tmp;
							log.debug("tMap_1 - Outputting the record " + count_Person_type_tMap_1
									+ " of the output table 'Person_type'.");

// # Output table : 'Person_Injury'
							count_Person_Injury_tMap_1++;

							Person_Injury_tmp.PERSON_INJURY = row1.PERSON_INJURY;
							Person_Injury = Person_Injury_tmp;
							log.debug("tMap_1 - Outputting the record " + count_Person_Injury_tMap_1
									+ " of the output table 'Person_Injury'.");

// # Output table : 'Emotional_Status'
							count_Emotional_Status_tMap_1++;

							Emotional_Status_tmp.EMOTIONAL_STATUS = row1.EMOTIONAL_STATUS;
							Emotional_Status = Emotional_Status_tmp;
							log.debug("tMap_1 - Outputting the record " + count_Emotional_Status_tMap_1
									+ " of the output table 'Emotional_Status'.");

// # Output table : 'Ejection'
							count_Ejection_tMap_1++;

							Ejection_tmp.EJECTION = row1.EJECTION;
							Ejection = Ejection_tmp;
							log.debug("tMap_1 - Outputting the record " + count_Ejection_tMap_1
									+ " of the output table 'Ejection'.");

// # Output table : 'Bodily_Injury'
							count_Bodily_Injury_tMap_1++;

							Bodily_Injury_tmp.BODILY_INJURY = row1.BODILY_INJURY;
							Bodily_Injury = Bodily_Injury_tmp;
							log.debug("tMap_1 - Outputting the record " + count_Bodily_Injury_tMap_1
									+ " of the output table 'Bodily_Injury'.");

// # Output table : 'Position_In_vehicle'
							count_Position_In_vehicle_tMap_1++;

							Position_In_vehicle_tmp.POSITION_IN_VEHICLE = row1.POSITION_IN_VEHICLE;
							Position_In_vehicle = Position_In_vehicle_tmp;
							log.debug("tMap_1 - Outputting the record " + count_Position_In_vehicle_tMap_1
									+ " of the output table 'Position_In_vehicle'.");

// # Output table : 'Safety_Equipment'
							count_Safety_Equipment_tMap_1++;

							Safety_Equipment_tmp.SAFETY_EQUIPMENT = row1.SAFETY_EQUIPMENT;
							Safety_Equipment = Safety_Equipment_tmp;
							log.debug("tMap_1 - Outputting the record " + count_Safety_Equipment_tMap_1
									+ " of the output table 'Safety_Equipment'.");

// # Output table : 'Ped_Location'
							count_Ped_Location_tMap_1++;

							Ped_Location_tmp.PED_LOCATION = row1.PED_LOCATION;
							Ped_Location = Ped_Location_tmp;
							log.debug("tMap_1 - Outputting the record " + count_Ped_Location_tMap_1
									+ " of the output table 'Ped_Location'.");

// # Output table : 'Ped_Location1'
							count_Ped_Location1_tMap_1++;

							Ped_Location1_tmp.PED_ACTION = row1.PED_ACTION;
							Ped_Location1 = Ped_Location1_tmp;
							log.debug("tMap_1 - Outputting the record " + count_Ped_Location1_tMap_1
									+ " of the output table 'Ped_Location1'.");

// # Output table : 'Complaint'
							count_Complaint_tMap_1++;

							Complaint_tmp.COMPLAINT = row1.COMPLAINT;
							Complaint = Complaint_tmp;
							log.debug("tMap_1 - Outputting the record " + count_Complaint_tMap_1
									+ " of the output table 'Complaint'.");

// # Output table : 'Ped_Role'
							count_Ped_Role_tMap_1++;

							Ped_Role_tmp.PED_ROLE = row1.PED_ROLE;
							Ped_Role = Ped_Role_tmp;
							log.debug("tMap_1 - Outputting the record " + count_Ped_Role_tMap_1
									+ " of the output table 'Ped_Role'.");

// # Output table : 'Person_Sex'
							count_Person_Sex_tMap_1++;

							Person_Sex_tmp.PERSON_SEX = row1.PERSON_SEX;
							Person_Sex = Person_Sex_tmp;
							log.debug("tMap_1 - Outputting the record " + count_Person_Sex_tMap_1
									+ " of the output table 'Person_Sex'.");

// ###############################

						} // end of Var scope

						rejectedInnerJoin_tMap_1 = false;

						tos_count_tMap_1++;

						/**
						 * [tMap_1 main ] stop
						 */

						/**
						 * [tMap_1 process_data_begin ] start
						 */

						currentComponent = "tMap_1";

						/**
						 * [tMap_1 process_data_begin ] stop
						 */
// Start of branch "Person_type"
						if (Person_type != null) {

							/**
							 * [tUniqRow_1 main ] start
							 */

							currentComponent = "tUniqRow_1";

							if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

									, "Person_type", "tMap_1", "tMap_1", "tMap", "tUniqRow_1", "tUniqRow_1", "tUniqRow"

							)) {
								talendJobLogProcess(globalMap);
							}

							if (log.isTraceEnabled()) {
								log.trace("Person_type - " + (Person_type == null ? "" : Person_type.toLogString()));
							}

							row2 = null;
							if (Person_type.PERSON_TYPE == null) {
								finder_tUniqRow_1.PERSON_TYPE = null;
							} else {
								finder_tUniqRow_1.PERSON_TYPE = Person_type.PERSON_TYPE.toLowerCase();
							}
							finder_tUniqRow_1.hashCodeDirty = true;
							if (!keystUniqRow_1.contains(finder_tUniqRow_1)) {
								KeyStruct_tUniqRow_1 new_tUniqRow_1 = new KeyStruct_tUniqRow_1();

								if (Person_type.PERSON_TYPE == null) {
									new_tUniqRow_1.PERSON_TYPE = null;
								} else {
									new_tUniqRow_1.PERSON_TYPE = Person_type.PERSON_TYPE.toLowerCase();
								}

								keystUniqRow_1.add(new_tUniqRow_1);
								if (row2 == null) {

									log.trace("tUniqRow_1 - Writing the unique record " + (nb_uniques_tUniqRow_1 + 1)
											+ " into row2.");

									row2 = new row2Struct();
								}
								row2.PERSON_TYPE = Person_type.PERSON_TYPE;
								nb_uniques_tUniqRow_1++;
							} else {
								nb_duplicates_tUniqRow_1++;
							}

							tos_count_tUniqRow_1++;

							/**
							 * [tUniqRow_1 main ] stop
							 */

							/**
							 * [tUniqRow_1 process_data_begin ] start
							 */

							currentComponent = "tUniqRow_1";

							/**
							 * [tUniqRow_1 process_data_begin ] stop
							 */
// Start of branch "row2"
							if (row2 != null) {

								/**
								 * [tMap_2 main ] start
								 */

								currentComponent = "tMap_2";

								if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

										, "row2", "tUniqRow_1", "tUniqRow_1", "tUniqRow", "tMap_2", "tMap_2", "tMap"

								)) {
									talendJobLogProcess(globalMap);
								}

								if (log.isTraceEnabled()) {
									log.trace("row2 - " + (row2 == null ? "" : row2.toLogString()));
								}

								boolean hasCasePrimitiveKeyWithNull_tMap_2 = false;

								// ###############################
								// # Input tables (lookups)
								boolean rejectedInnerJoin_tMap_2 = false;
								boolean mainRowRejected_tMap_2 = false;

								// ###############################
								{ // start of Var scope

									// ###############################
									// # Vars tables

									Var__tMap_2__Struct Var = Var__tMap_2;// ###############################
									// ###############################
									// # Output tables

									Person_Type_Formula = null;

// # Output table : 'Person_Type_Formula'
									count_Person_Type_Formula_tMap_2++;

									Person_Type_Formula_tmp.PERSON_TYPE_SK = null;
									Person_Type_Formula_tmp.PERSON_TYPE = row2.PERSON_TYPE;
									Person_Type_Formula_tmp.DI_PID = "MVC_Load";
									Person_Type_Formula_tmp.DI_Create_Date = TalendDate.getCurrentDate();
									Person_Type_Formula = Person_Type_Formula_tmp;
									log.debug("tMap_2 - Outputting the record " + count_Person_Type_Formula_tMap_2
											+ " of the output table 'Person_Type_Formula'.");

// ###############################

								} // end of Var scope

								rejectedInnerJoin_tMap_2 = false;

								tos_count_tMap_2++;

								/**
								 * [tMap_2 main ] stop
								 */

								/**
								 * [tMap_2 process_data_begin ] start
								 */

								currentComponent = "tMap_2";

								/**
								 * [tMap_2 process_data_begin ] stop
								 */
// Start of branch "Person_Type_Formula"
								if (Person_Type_Formula != null) {

									/**
									 * [tDBOutput_1 main ] start
									 */

									currentComponent = "tDBOutput_1";

									if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

											, "Person_Type_Formula", "tMap_2", "tMap_2", "tMap", "tDBOutput_1",
											"__TABLE__", "tMSSqlOutput"

									)) {
										talendJobLogProcess(globalMap);
									}

									if (log.isTraceEnabled()) {
										log.trace("Person_Type_Formula - " + (Person_Type_Formula == null ? ""
												: Person_Type_Formula.toLogString()));
									}

									whetherReject_tDBOutput_1 = false;
									if (Person_Type_Formula.PERSON_TYPE_SK == null) {
										pstmt_tDBOutput_1.setNull(1, java.sql.Types.INTEGER);
									} else {
										pstmt_tDBOutput_1.setInt(1, Person_Type_Formula.PERSON_TYPE_SK);
									}

									if (Person_Type_Formula.PERSON_TYPE == null) {
										pstmt_tDBOutput_1.setNull(2, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_1.setString(2, Person_Type_Formula.PERSON_TYPE);
									}

									if (Person_Type_Formula.DI_PID == null) {
										pstmt_tDBOutput_1.setNull(3, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_1.setString(3, Person_Type_Formula.DI_PID);
									}

									if (Person_Type_Formula.DI_Create_Date != null) {
										pstmt_tDBOutput_1.setTimestamp(4,
												new java.sql.Timestamp(Person_Type_Formula.DI_Create_Date.getTime()));
									} else {
										pstmt_tDBOutput_1.setNull(4, java.sql.Types.TIMESTAMP);
									}

									pstmt_tDBOutput_1.addBatch();
									nb_line_tDBOutput_1++;

									if (log.isDebugEnabled())
										log.debug("tDBOutput_1 - " + ("Adding the record ") + (nb_line_tDBOutput_1)
												+ (" to the ") + ("INSERT") + (" batch."));
									batchSizeCounter_tDBOutput_1++;

									////////// batch execute by batch size///////
									class LimitBytesHelper_tDBOutput_1 {
										public int limitBytePart1(int counter,
												java.sql.PreparedStatement pstmt_tDBOutput_1) throws Exception {
											try {

												if (log.isDebugEnabled())
													log.debug("tDBOutput_1 - " + ("Executing the ") + ("INSERT")
															+ (" batch."));
												for (int countEach_tDBOutput_1 : pstmt_tDBOutput_1.executeBatch()) {
													if (countEach_tDBOutput_1 == -2 || countEach_tDBOutput_1 == -3) {
														break;
													}
													counter += countEach_tDBOutput_1;
												}

												if (log.isDebugEnabled())
													log.debug("tDBOutput_1 - " + ("The ") + ("INSERT")
															+ (" batch execution has succeeded."));
											} catch (java.sql.BatchUpdateException e) {
												globalMap.put("tDBOutput_1_ERROR_MESSAGE", e.getMessage());

												int countSum_tDBOutput_1 = 0;
												for (int countEach_tDBOutput_1 : e.getUpdateCounts()) {
													counter += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
												}

												log.error("tDBOutput_1 - " + (e.getMessage()));
												System.err.println(e.getMessage());

											}
											return counter;
										}

										public int limitBytePart2(int counter,
												java.sql.PreparedStatement pstmt_tDBOutput_1) throws Exception {
											try {

												if (log.isDebugEnabled())
													log.debug("tDBOutput_1 - " + ("Executing the ") + ("INSERT")
															+ (" batch."));
												for (int countEach_tDBOutput_1 : pstmt_tDBOutput_1.executeBatch()) {
													if (countEach_tDBOutput_1 == -2 || countEach_tDBOutput_1 == -3) {
														break;
													}
													counter += countEach_tDBOutput_1;
												}

												if (log.isDebugEnabled())
													log.debug("tDBOutput_1 - " + ("The ") + ("INSERT")
															+ (" batch execution has succeeded."));
											} catch (java.sql.BatchUpdateException e) {
												globalMap.put("tDBOutput_1_ERROR_MESSAGE", e.getMessage());

												for (int countEach_tDBOutput_1 : e.getUpdateCounts()) {
													counter += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
												}

												log.error("tDBOutput_1 - " + (e.getMessage()));
												System.err.println(e.getMessage());

											}
											return counter;
										}
									}
									if ((batchSize_tDBOutput_1 > 0)
											&& (batchSize_tDBOutput_1 <= batchSizeCounter_tDBOutput_1)) {

										insertedCount_tDBOutput_1 = new LimitBytesHelper_tDBOutput_1()
												.limitBytePart1(insertedCount_tDBOutput_1, pstmt_tDBOutput_1);
										rowsToCommitCount_tDBOutput_1 = insertedCount_tDBOutput_1;

										batchSizeCounter_tDBOutput_1 = 0;
									}

									//////////// commit every////////////

									commitCounter_tDBOutput_1++;
									if (commitEvery_tDBOutput_1 <= commitCounter_tDBOutput_1) {
										if ((batchSize_tDBOutput_1 > 0) && (batchSizeCounter_tDBOutput_1 > 0)) {

											insertedCount_tDBOutput_1 = new LimitBytesHelper_tDBOutput_1()
													.limitBytePart1(insertedCount_tDBOutput_1, pstmt_tDBOutput_1);

											batchSizeCounter_tDBOutput_1 = 0;
										}
										if (rowsToCommitCount_tDBOutput_1 != 0) {

											if (log.isDebugEnabled())
												log.debug("tDBOutput_1 - " + ("Connection starting to commit ")
														+ (rowsToCommitCount_tDBOutput_1) + (" record(s)."));
										}
										conn_tDBOutput_1.commit();
										if (rowsToCommitCount_tDBOutput_1 != 0) {

											if (log.isDebugEnabled())
												log.debug("tDBOutput_1 - " + ("Connection commit has succeeded."));
											rowsToCommitCount_tDBOutput_1 = 0;
										}
										commitCounter_tDBOutput_1 = 0;
									}

									tos_count_tDBOutput_1++;

									/**
									 * [tDBOutput_1 main ] stop
									 */

									/**
									 * [tDBOutput_1 process_data_begin ] start
									 */

									currentComponent = "tDBOutput_1";

									/**
									 * [tDBOutput_1 process_data_begin ] stop
									 */

									/**
									 * [tDBOutput_1 process_data_end ] start
									 */

									currentComponent = "tDBOutput_1";

									/**
									 * [tDBOutput_1 process_data_end ] stop
									 */

								} // End of branch "Person_Type_Formula"

								/**
								 * [tMap_2 process_data_end ] start
								 */

								currentComponent = "tMap_2";

								/**
								 * [tMap_2 process_data_end ] stop
								 */

							} // End of branch "row2"

							/**
							 * [tUniqRow_1 process_data_end ] start
							 */

							currentComponent = "tUniqRow_1";

							/**
							 * [tUniqRow_1 process_data_end ] stop
							 */

						} // End of branch "Person_type"

// Start of branch "Person_Injury"
						if (Person_Injury != null) {

							/**
							 * [tUniqRow_2 main ] start
							 */

							currentComponent = "tUniqRow_2";

							if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

									, "Person_Injury", "tMap_1", "tMap_1", "tMap", "tUniqRow_2", "tUniqRow_2",
									"tUniqRow"

							)) {
								talendJobLogProcess(globalMap);
							}

							if (log.isTraceEnabled()) {
								log.trace("Person_Injury - "
										+ (Person_Injury == null ? "" : Person_Injury.toLogString()));
							}

							row3 = null;
							if (Person_Injury.PERSON_INJURY == null) {
								finder_tUniqRow_2.PERSON_INJURY = null;
							} else {
								finder_tUniqRow_2.PERSON_INJURY = Person_Injury.PERSON_INJURY.toLowerCase();
							}
							finder_tUniqRow_2.hashCodeDirty = true;
							if (!keystUniqRow_2.contains(finder_tUniqRow_2)) {
								KeyStruct_tUniqRow_2 new_tUniqRow_2 = new KeyStruct_tUniqRow_2();

								if (Person_Injury.PERSON_INJURY == null) {
									new_tUniqRow_2.PERSON_INJURY = null;
								} else {
									new_tUniqRow_2.PERSON_INJURY = Person_Injury.PERSON_INJURY.toLowerCase();
								}

								keystUniqRow_2.add(new_tUniqRow_2);
								if (row3 == null) {

									log.trace("tUniqRow_2 - Writing the unique record " + (nb_uniques_tUniqRow_2 + 1)
											+ " into row3.");

									row3 = new row3Struct();
								}
								row3.PERSON_INJURY = Person_Injury.PERSON_INJURY;
								nb_uniques_tUniqRow_2++;
							} else {
								nb_duplicates_tUniqRow_2++;
							}

							tos_count_tUniqRow_2++;

							/**
							 * [tUniqRow_2 main ] stop
							 */

							/**
							 * [tUniqRow_2 process_data_begin ] start
							 */

							currentComponent = "tUniqRow_2";

							/**
							 * [tUniqRow_2 process_data_begin ] stop
							 */
// Start of branch "row3"
							if (row3 != null) {

								/**
								 * [tMap_3 main ] start
								 */

								currentComponent = "tMap_3";

								if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

										, "row3", "tUniqRow_2", "tUniqRow_2", "tUniqRow", "tMap_3", "tMap_3", "tMap"

								)) {
									talendJobLogProcess(globalMap);
								}

								if (log.isTraceEnabled()) {
									log.trace("row3 - " + (row3 == null ? "" : row3.toLogString()));
								}

								boolean hasCasePrimitiveKeyWithNull_tMap_3 = false;

								// ###############################
								// # Input tables (lookups)
								boolean rejectedInnerJoin_tMap_3 = false;
								boolean mainRowRejected_tMap_3 = false;

								// ###############################
								{ // start of Var scope

									// ###############################
									// # Vars tables

									Var__tMap_3__Struct Var = Var__tMap_3;// ###############################
									// ###############################
									// # Output tables

									Person_Injury1 = null;

// # Output table : 'Person_Injury1'
									count_Person_Injury1_tMap_3++;

									Person_Injury1_tmp.PERSON_INJURY_SK = null;
									Person_Injury1_tmp.PERSON_INJURY = row3.PERSON_INJURY;
									Person_Injury1_tmp.DI_PID = "MVC_Load";
									Person_Injury1_tmp.DI_Create_Date = TalendDate.getCurrentDate();
									Person_Injury1 = Person_Injury1_tmp;
									log.debug("tMap_3 - Outputting the record " + count_Person_Injury1_tMap_3
											+ " of the output table 'Person_Injury1'.");

// ###############################

								} // end of Var scope

								rejectedInnerJoin_tMap_3 = false;

								tos_count_tMap_3++;

								/**
								 * [tMap_3 main ] stop
								 */

								/**
								 * [tMap_3 process_data_begin ] start
								 */

								currentComponent = "tMap_3";

								/**
								 * [tMap_3 process_data_begin ] stop
								 */
// Start of branch "Person_Injury1"
								if (Person_Injury1 != null) {

									/**
									 * [tDBOutput_2 main ] start
									 */

									currentComponent = "tDBOutput_2";

									if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

											, "Person_Injury1", "tMap_3", "tMap_3", "tMap", "tDBOutput_2", "__TABLE__",
											"tMSSqlOutput"

									)) {
										talendJobLogProcess(globalMap);
									}

									if (log.isTraceEnabled()) {
										log.trace("Person_Injury1 - "
												+ (Person_Injury1 == null ? "" : Person_Injury1.toLogString()));
									}

									whetherReject_tDBOutput_2 = false;
									if (Person_Injury1.PERSON_INJURY_SK == null) {
										pstmt_tDBOutput_2.setNull(1, java.sql.Types.INTEGER);
									} else {
										pstmt_tDBOutput_2.setInt(1, Person_Injury1.PERSON_INJURY_SK);
									}

									if (Person_Injury1.PERSON_INJURY == null) {
										pstmt_tDBOutput_2.setNull(2, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_2.setString(2, Person_Injury1.PERSON_INJURY);
									}

									if (Person_Injury1.DI_PID == null) {
										pstmt_tDBOutput_2.setNull(3, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_2.setString(3, Person_Injury1.DI_PID);
									}

									if (Person_Injury1.DI_Create_Date != null) {
										pstmt_tDBOutput_2.setTimestamp(4,
												new java.sql.Timestamp(Person_Injury1.DI_Create_Date.getTime()));
									} else {
										pstmt_tDBOutput_2.setNull(4, java.sql.Types.TIMESTAMP);
									}

									pstmt_tDBOutput_2.addBatch();
									nb_line_tDBOutput_2++;

									if (log.isDebugEnabled())
										log.debug("tDBOutput_2 - " + ("Adding the record ") + (nb_line_tDBOutput_2)
												+ (" to the ") + ("INSERT") + (" batch."));
									batchSizeCounter_tDBOutput_2++;

									////////// batch execute by batch size///////
									class LimitBytesHelper_tDBOutput_2 {
										public int limitBytePart1(int counter,
												java.sql.PreparedStatement pstmt_tDBOutput_2) throws Exception {
											try {

												if (log.isDebugEnabled())
													log.debug("tDBOutput_2 - " + ("Executing the ") + ("INSERT")
															+ (" batch."));
												for (int countEach_tDBOutput_2 : pstmt_tDBOutput_2.executeBatch()) {
													if (countEach_tDBOutput_2 == -2 || countEach_tDBOutput_2 == -3) {
														break;
													}
													counter += countEach_tDBOutput_2;
												}

												if (log.isDebugEnabled())
													log.debug("tDBOutput_2 - " + ("The ") + ("INSERT")
															+ (" batch execution has succeeded."));
											} catch (java.sql.BatchUpdateException e) {
												globalMap.put("tDBOutput_2_ERROR_MESSAGE", e.getMessage());

												int countSum_tDBOutput_2 = 0;
												for (int countEach_tDBOutput_2 : e.getUpdateCounts()) {
													counter += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
												}

												log.error("tDBOutput_2 - " + (e.getMessage()));
												System.err.println(e.getMessage());

											}
											return counter;
										}

										public int limitBytePart2(int counter,
												java.sql.PreparedStatement pstmt_tDBOutput_2) throws Exception {
											try {

												if (log.isDebugEnabled())
													log.debug("tDBOutput_2 - " + ("Executing the ") + ("INSERT")
															+ (" batch."));
												for (int countEach_tDBOutput_2 : pstmt_tDBOutput_2.executeBatch()) {
													if (countEach_tDBOutput_2 == -2 || countEach_tDBOutput_2 == -3) {
														break;
													}
													counter += countEach_tDBOutput_2;
												}

												if (log.isDebugEnabled())
													log.debug("tDBOutput_2 - " + ("The ") + ("INSERT")
															+ (" batch execution has succeeded."));
											} catch (java.sql.BatchUpdateException e) {
												globalMap.put("tDBOutput_2_ERROR_MESSAGE", e.getMessage());

												for (int countEach_tDBOutput_2 : e.getUpdateCounts()) {
													counter += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
												}

												log.error("tDBOutput_2 - " + (e.getMessage()));
												System.err.println(e.getMessage());

											}
											return counter;
										}
									}
									if ((batchSize_tDBOutput_2 > 0)
											&& (batchSize_tDBOutput_2 <= batchSizeCounter_tDBOutput_2)) {

										insertedCount_tDBOutput_2 = new LimitBytesHelper_tDBOutput_2()
												.limitBytePart1(insertedCount_tDBOutput_2, pstmt_tDBOutput_2);
										rowsToCommitCount_tDBOutput_2 = insertedCount_tDBOutput_2;

										batchSizeCounter_tDBOutput_2 = 0;
									}

									//////////// commit every////////////

									commitCounter_tDBOutput_2++;
									if (commitEvery_tDBOutput_2 <= commitCounter_tDBOutput_2) {
										if ((batchSize_tDBOutput_2 > 0) && (batchSizeCounter_tDBOutput_2 > 0)) {

											insertedCount_tDBOutput_2 = new LimitBytesHelper_tDBOutput_2()
													.limitBytePart1(insertedCount_tDBOutput_2, pstmt_tDBOutput_2);

											batchSizeCounter_tDBOutput_2 = 0;
										}
										if (rowsToCommitCount_tDBOutput_2 != 0) {

											if (log.isDebugEnabled())
												log.debug("tDBOutput_2 - " + ("Connection starting to commit ")
														+ (rowsToCommitCount_tDBOutput_2) + (" record(s)."));
										}
										conn_tDBOutput_2.commit();
										if (rowsToCommitCount_tDBOutput_2 != 0) {

											if (log.isDebugEnabled())
												log.debug("tDBOutput_2 - " + ("Connection commit has succeeded."));
											rowsToCommitCount_tDBOutput_2 = 0;
										}
										commitCounter_tDBOutput_2 = 0;
									}

									tos_count_tDBOutput_2++;

									/**
									 * [tDBOutput_2 main ] stop
									 */

									/**
									 * [tDBOutput_2 process_data_begin ] start
									 */

									currentComponent = "tDBOutput_2";

									/**
									 * [tDBOutput_2 process_data_begin ] stop
									 */

									/**
									 * [tDBOutput_2 process_data_end ] start
									 */

									currentComponent = "tDBOutput_2";

									/**
									 * [tDBOutput_2 process_data_end ] stop
									 */

								} // End of branch "Person_Injury1"

								/**
								 * [tMap_3 process_data_end ] start
								 */

								currentComponent = "tMap_3";

								/**
								 * [tMap_3 process_data_end ] stop
								 */

							} // End of branch "row3"

							/**
							 * [tUniqRow_2 process_data_end ] start
							 */

							currentComponent = "tUniqRow_2";

							/**
							 * [tUniqRow_2 process_data_end ] stop
							 */

						} // End of branch "Person_Injury"

// Start of branch "Emotional_Status"
						if (Emotional_Status != null) {

							/**
							 * [tUniqRow_3 main ] start
							 */

							currentComponent = "tUniqRow_3";

							if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

									, "Emotional_Status", "tMap_1", "tMap_1", "tMap", "tUniqRow_3", "tUniqRow_3",
									"tUniqRow"

							)) {
								talendJobLogProcess(globalMap);
							}

							if (log.isTraceEnabled()) {
								log.trace("Emotional_Status - "
										+ (Emotional_Status == null ? "" : Emotional_Status.toLogString()));
							}

							row4 = null;
							if (Emotional_Status.EMOTIONAL_STATUS == null) {
								finder_tUniqRow_3.EMOTIONAL_STATUS = null;
							} else {
								finder_tUniqRow_3.EMOTIONAL_STATUS = Emotional_Status.EMOTIONAL_STATUS.toLowerCase();
							}
							finder_tUniqRow_3.hashCodeDirty = true;
							if (!keystUniqRow_3.contains(finder_tUniqRow_3)) {
								KeyStruct_tUniqRow_3 new_tUniqRow_3 = new KeyStruct_tUniqRow_3();

								if (Emotional_Status.EMOTIONAL_STATUS == null) {
									new_tUniqRow_3.EMOTIONAL_STATUS = null;
								} else {
									new_tUniqRow_3.EMOTIONAL_STATUS = Emotional_Status.EMOTIONAL_STATUS.toLowerCase();
								}

								keystUniqRow_3.add(new_tUniqRow_3);
								if (row4 == null) {

									log.trace("tUniqRow_3 - Writing the unique record " + (nb_uniques_tUniqRow_3 + 1)
											+ " into row4.");

									row4 = new row4Struct();
								}
								row4.EMOTIONAL_STATUS = Emotional_Status.EMOTIONAL_STATUS;
								nb_uniques_tUniqRow_3++;
							} else {
								nb_duplicates_tUniqRow_3++;
							}

							tos_count_tUniqRow_3++;

							/**
							 * [tUniqRow_3 main ] stop
							 */

							/**
							 * [tUniqRow_3 process_data_begin ] start
							 */

							currentComponent = "tUniqRow_3";

							/**
							 * [tUniqRow_3 process_data_begin ] stop
							 */
// Start of branch "row4"
							if (row4 != null) {

								/**
								 * [tMap_4 main ] start
								 */

								currentComponent = "tMap_4";

								if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

										, "row4", "tUniqRow_3", "tUniqRow_3", "tUniqRow", "tMap_4", "tMap_4", "tMap"

								)) {
									talendJobLogProcess(globalMap);
								}

								if (log.isTraceEnabled()) {
									log.trace("row4 - " + (row4 == null ? "" : row4.toLogString()));
								}

								boolean hasCasePrimitiveKeyWithNull_tMap_4 = false;

								// ###############################
								// # Input tables (lookups)
								boolean rejectedInnerJoin_tMap_4 = false;
								boolean mainRowRejected_tMap_4 = false;

								// ###############################
								{ // start of Var scope

									// ###############################
									// # Vars tables

									Var__tMap_4__Struct Var = Var__tMap_4;// ###############################
									// ###############################
									// # Output tables

									Load3 = null;

// # Output table : 'Load3'
									count_Load3_tMap_4++;

									Load3_tmp.EMOTIONAL_STATUS_SK = null;
									Load3_tmp.EMOTIONAL_STATUS = row4.EMOTIONAL_STATUS;
									Load3_tmp.DI_Create_Date = TalendDate.getCurrentDate();
									Load3_tmp.DI_PID = "MVC_LOAD";
									Load3 = Load3_tmp;
									log.debug("tMap_4 - Outputting the record " + count_Load3_tMap_4
											+ " of the output table 'Load3'.");

// ###############################

								} // end of Var scope

								rejectedInnerJoin_tMap_4 = false;

								tos_count_tMap_4++;

								/**
								 * [tMap_4 main ] stop
								 */

								/**
								 * [tMap_4 process_data_begin ] start
								 */

								currentComponent = "tMap_4";

								/**
								 * [tMap_4 process_data_begin ] stop
								 */
// Start of branch "Load3"
								if (Load3 != null) {

									/**
									 * [tDBOutput_3 main ] start
									 */

									currentComponent = "tDBOutput_3";

									if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

											, "Load3", "tMap_4", "tMap_4", "tMap", "tDBOutput_3", "__TABLE__",
											"tMSSqlOutput"

									)) {
										talendJobLogProcess(globalMap);
									}

									if (log.isTraceEnabled()) {
										log.trace("Load3 - " + (Load3 == null ? "" : Load3.toLogString()));
									}

									whetherReject_tDBOutput_3 = false;
									if (Load3.EMOTIONAL_STATUS_SK == null) {
										pstmt_tDBOutput_3.setNull(1, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_3.setString(1, Load3.EMOTIONAL_STATUS_SK);
									}

									if (Load3.EMOTIONAL_STATUS == null) {
										pstmt_tDBOutput_3.setNull(2, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_3.setString(2, Load3.EMOTIONAL_STATUS);
									}

									if (Load3.DI_Create_Date != null) {
										pstmt_tDBOutput_3.setTimestamp(3,
												new java.sql.Timestamp(Load3.DI_Create_Date.getTime()));
									} else {
										pstmt_tDBOutput_3.setNull(3, java.sql.Types.TIMESTAMP);
									}

									if (Load3.DI_PID == null) {
										pstmt_tDBOutput_3.setNull(4, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_3.setString(4, Load3.DI_PID);
									}

									pstmt_tDBOutput_3.addBatch();
									nb_line_tDBOutput_3++;

									if (log.isDebugEnabled())
										log.debug("tDBOutput_3 - " + ("Adding the record ") + (nb_line_tDBOutput_3)
												+ (" to the ") + ("INSERT") + (" batch."));
									batchSizeCounter_tDBOutput_3++;

									////////// batch execute by batch size///////
									class LimitBytesHelper_tDBOutput_3 {
										public int limitBytePart1(int counter,
												java.sql.PreparedStatement pstmt_tDBOutput_3) throws Exception {
											try {

												if (log.isDebugEnabled())
													log.debug("tDBOutput_3 - " + ("Executing the ") + ("INSERT")
															+ (" batch."));
												for (int countEach_tDBOutput_3 : pstmt_tDBOutput_3.executeBatch()) {
													if (countEach_tDBOutput_3 == -2 || countEach_tDBOutput_3 == -3) {
														break;
													}
													counter += countEach_tDBOutput_3;
												}

												if (log.isDebugEnabled())
													log.debug("tDBOutput_3 - " + ("The ") + ("INSERT")
															+ (" batch execution has succeeded."));
											} catch (java.sql.BatchUpdateException e) {
												globalMap.put("tDBOutput_3_ERROR_MESSAGE", e.getMessage());

												int countSum_tDBOutput_3 = 0;
												for (int countEach_tDBOutput_3 : e.getUpdateCounts()) {
													counter += (countEach_tDBOutput_3 < 0 ? 0 : countEach_tDBOutput_3);
												}

												log.error("tDBOutput_3 - " + (e.getMessage()));
												System.err.println(e.getMessage());

											}
											return counter;
										}

										public int limitBytePart2(int counter,
												java.sql.PreparedStatement pstmt_tDBOutput_3) throws Exception {
											try {

												if (log.isDebugEnabled())
													log.debug("tDBOutput_3 - " + ("Executing the ") + ("INSERT")
															+ (" batch."));
												for (int countEach_tDBOutput_3 : pstmt_tDBOutput_3.executeBatch()) {
													if (countEach_tDBOutput_3 == -2 || countEach_tDBOutput_3 == -3) {
														break;
													}
													counter += countEach_tDBOutput_3;
												}

												if (log.isDebugEnabled())
													log.debug("tDBOutput_3 - " + ("The ") + ("INSERT")
															+ (" batch execution has succeeded."));
											} catch (java.sql.BatchUpdateException e) {
												globalMap.put("tDBOutput_3_ERROR_MESSAGE", e.getMessage());

												for (int countEach_tDBOutput_3 : e.getUpdateCounts()) {
													counter += (countEach_tDBOutput_3 < 0 ? 0 : countEach_tDBOutput_3);
												}

												log.error("tDBOutput_3 - " + (e.getMessage()));
												System.err.println(e.getMessage());

											}
											return counter;
										}
									}
									if ((batchSize_tDBOutput_3 > 0)
											&& (batchSize_tDBOutput_3 <= batchSizeCounter_tDBOutput_3)) {

										insertedCount_tDBOutput_3 = new LimitBytesHelper_tDBOutput_3()
												.limitBytePart1(insertedCount_tDBOutput_3, pstmt_tDBOutput_3);
										rowsToCommitCount_tDBOutput_3 = insertedCount_tDBOutput_3;

										batchSizeCounter_tDBOutput_3 = 0;
									}

									//////////// commit every////////////

									commitCounter_tDBOutput_3++;
									if (commitEvery_tDBOutput_3 <= commitCounter_tDBOutput_3) {
										if ((batchSize_tDBOutput_3 > 0) && (batchSizeCounter_tDBOutput_3 > 0)) {

											insertedCount_tDBOutput_3 = new LimitBytesHelper_tDBOutput_3()
													.limitBytePart1(insertedCount_tDBOutput_3, pstmt_tDBOutput_3);

											batchSizeCounter_tDBOutput_3 = 0;
										}
										if (rowsToCommitCount_tDBOutput_3 != 0) {

											if (log.isDebugEnabled())
												log.debug("tDBOutput_3 - " + ("Connection starting to commit ")
														+ (rowsToCommitCount_tDBOutput_3) + (" record(s)."));
										}
										conn_tDBOutput_3.commit();
										if (rowsToCommitCount_tDBOutput_3 != 0) {

											if (log.isDebugEnabled())
												log.debug("tDBOutput_3 - " + ("Connection commit has succeeded."));
											rowsToCommitCount_tDBOutput_3 = 0;
										}
										commitCounter_tDBOutput_3 = 0;
									}

									tos_count_tDBOutput_3++;

									/**
									 * [tDBOutput_3 main ] stop
									 */

									/**
									 * [tDBOutput_3 process_data_begin ] start
									 */

									currentComponent = "tDBOutput_3";

									/**
									 * [tDBOutput_3 process_data_begin ] stop
									 */

									/**
									 * [tDBOutput_3 process_data_end ] start
									 */

									currentComponent = "tDBOutput_3";

									/**
									 * [tDBOutput_3 process_data_end ] stop
									 */

								} // End of branch "Load3"

								/**
								 * [tMap_4 process_data_end ] start
								 */

								currentComponent = "tMap_4";

								/**
								 * [tMap_4 process_data_end ] stop
								 */

							} // End of branch "row4"

							/**
							 * [tUniqRow_3 process_data_end ] start
							 */

							currentComponent = "tUniqRow_3";

							/**
							 * [tUniqRow_3 process_data_end ] stop
							 */

						} // End of branch "Emotional_Status"

// Start of branch "Ejection"
						if (Ejection != null) {

							/**
							 * [tUniqRow_5 main ] start
							 */

							currentComponent = "tUniqRow_5";

							if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

									, "Ejection", "tMap_1", "tMap_1", "tMap", "tUniqRow_5", "tUniqRow_5", "tUniqRow"

							)) {
								talendJobLogProcess(globalMap);
							}

							if (log.isTraceEnabled()) {
								log.trace("Ejection - " + (Ejection == null ? "" : Ejection.toLogString()));
							}

							row5 = null;
							if (Ejection.EJECTION == null) {
								finder_tUniqRow_5.EJECTION = null;
							} else {
								finder_tUniqRow_5.EJECTION = Ejection.EJECTION.toLowerCase();
							}
							finder_tUniqRow_5.hashCodeDirty = true;
							if (!keystUniqRow_5.contains(finder_tUniqRow_5)) {
								KeyStruct_tUniqRow_5 new_tUniqRow_5 = new KeyStruct_tUniqRow_5();

								if (Ejection.EJECTION == null) {
									new_tUniqRow_5.EJECTION = null;
								} else {
									new_tUniqRow_5.EJECTION = Ejection.EJECTION.toLowerCase();
								}

								keystUniqRow_5.add(new_tUniqRow_5);
								if (row5 == null) {

									log.trace("tUniqRow_5 - Writing the unique record " + (nb_uniques_tUniqRow_5 + 1)
											+ " into row5.");

									row5 = new row5Struct();
								}
								row5.EJECTION = Ejection.EJECTION;
								nb_uniques_tUniqRow_5++;
							} else {
								nb_duplicates_tUniqRow_5++;
							}

							tos_count_tUniqRow_5++;

							/**
							 * [tUniqRow_5 main ] stop
							 */

							/**
							 * [tUniqRow_5 process_data_begin ] start
							 */

							currentComponent = "tUniqRow_5";

							/**
							 * [tUniqRow_5 process_data_begin ] stop
							 */
// Start of branch "row5"
							if (row5 != null) {

								/**
								 * [tMap_6 main ] start
								 */

								currentComponent = "tMap_6";

								if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

										, "row5", "tUniqRow_5", "tUniqRow_5", "tUniqRow", "tMap_6", "tMap_6", "tMap"

								)) {
									talendJobLogProcess(globalMap);
								}

								if (log.isTraceEnabled()) {
									log.trace("row5 - " + (row5 == null ? "" : row5.toLogString()));
								}

								boolean hasCasePrimitiveKeyWithNull_tMap_6 = false;

								// ###############################
								// # Input tables (lookups)
								boolean rejectedInnerJoin_tMap_6 = false;
								boolean mainRowRejected_tMap_6 = false;

								// ###############################
								{ // start of Var scope

									// ###############################
									// # Vars tables

									Var__tMap_6__Struct Var = Var__tMap_6;// ###############################
									// ###############################
									// # Output tables

									Ejection_Load = null;

// # Output table : 'Ejection_Load'
									count_Ejection_Load_tMap_6++;

									Ejection_Load_tmp.EJECTION_SK = null;
									Ejection_Load_tmp.EJECTION = row5.EJECTION;
									Ejection_Load_tmp.DI_PID = "MVC_LOAD";
									Ejection_Load_tmp.DI_Create_Date = TalendDate.getCurrentDate();
									Ejection_Load = Ejection_Load_tmp;
									log.debug("tMap_6 - Outputting the record " + count_Ejection_Load_tMap_6
											+ " of the output table 'Ejection_Load'.");

// ###############################

								} // end of Var scope

								rejectedInnerJoin_tMap_6 = false;

								tos_count_tMap_6++;

								/**
								 * [tMap_6 main ] stop
								 */

								/**
								 * [tMap_6 process_data_begin ] start
								 */

								currentComponent = "tMap_6";

								/**
								 * [tMap_6 process_data_begin ] stop
								 */
// Start of branch "Ejection_Load"
								if (Ejection_Load != null) {

									/**
									 * [tDBOutput_4 main ] start
									 */

									currentComponent = "tDBOutput_4";

									if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

											, "Ejection_Load", "tMap_6", "tMap_6", "tMap", "tDBOutput_4", "__TABLE__",
											"tMSSqlOutput"

									)) {
										talendJobLogProcess(globalMap);
									}

									if (log.isTraceEnabled()) {
										log.trace("Ejection_Load - "
												+ (Ejection_Load == null ? "" : Ejection_Load.toLogString()));
									}

									whetherReject_tDBOutput_4 = false;
									if (Ejection_Load.EJECTION_SK == null) {
										pstmt_tDBOutput_4.setNull(1, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_4.setString(1, Ejection_Load.EJECTION_SK);
									}

									if (Ejection_Load.EJECTION == null) {
										pstmt_tDBOutput_4.setNull(2, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_4.setString(2, Ejection_Load.EJECTION);
									}

									if (Ejection_Load.DI_PID == null) {
										pstmt_tDBOutput_4.setNull(3, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_4.setString(3, Ejection_Load.DI_PID);
									}

									if (Ejection_Load.DI_Create_Date != null) {
										pstmt_tDBOutput_4.setTimestamp(4,
												new java.sql.Timestamp(Ejection_Load.DI_Create_Date.getTime()));
									} else {
										pstmt_tDBOutput_4.setNull(4, java.sql.Types.TIMESTAMP);
									}

									pstmt_tDBOutput_4.addBatch();
									nb_line_tDBOutput_4++;

									if (log.isDebugEnabled())
										log.debug("tDBOutput_4 - " + ("Adding the record ") + (nb_line_tDBOutput_4)
												+ (" to the ") + ("INSERT") + (" batch."));
									batchSizeCounter_tDBOutput_4++;

									////////// batch execute by batch size///////
									class LimitBytesHelper_tDBOutput_4 {
										public int limitBytePart1(int counter,
												java.sql.PreparedStatement pstmt_tDBOutput_4) throws Exception {
											try {

												if (log.isDebugEnabled())
													log.debug("tDBOutput_4 - " + ("Executing the ") + ("INSERT")
															+ (" batch."));
												for (int countEach_tDBOutput_4 : pstmt_tDBOutput_4.executeBatch()) {
													if (countEach_tDBOutput_4 == -2 || countEach_tDBOutput_4 == -3) {
														break;
													}
													counter += countEach_tDBOutput_4;
												}

												if (log.isDebugEnabled())
													log.debug("tDBOutput_4 - " + ("The ") + ("INSERT")
															+ (" batch execution has succeeded."));
											} catch (java.sql.BatchUpdateException e) {
												globalMap.put("tDBOutput_4_ERROR_MESSAGE", e.getMessage());

												int countSum_tDBOutput_4 = 0;
												for (int countEach_tDBOutput_4 : e.getUpdateCounts()) {
													counter += (countEach_tDBOutput_4 < 0 ? 0 : countEach_tDBOutput_4);
												}

												log.error("tDBOutput_4 - " + (e.getMessage()));
												System.err.println(e.getMessage());

											}
											return counter;
										}

										public int limitBytePart2(int counter,
												java.sql.PreparedStatement pstmt_tDBOutput_4) throws Exception {
											try {

												if (log.isDebugEnabled())
													log.debug("tDBOutput_4 - " + ("Executing the ") + ("INSERT")
															+ (" batch."));
												for (int countEach_tDBOutput_4 : pstmt_tDBOutput_4.executeBatch()) {
													if (countEach_tDBOutput_4 == -2 || countEach_tDBOutput_4 == -3) {
														break;
													}
													counter += countEach_tDBOutput_4;
												}

												if (log.isDebugEnabled())
													log.debug("tDBOutput_4 - " + ("The ") + ("INSERT")
															+ (" batch execution has succeeded."));
											} catch (java.sql.BatchUpdateException e) {
												globalMap.put("tDBOutput_4_ERROR_MESSAGE", e.getMessage());

												for (int countEach_tDBOutput_4 : e.getUpdateCounts()) {
													counter += (countEach_tDBOutput_4 < 0 ? 0 : countEach_tDBOutput_4);
												}

												log.error("tDBOutput_4 - " + (e.getMessage()));
												System.err.println(e.getMessage());

											}
											return counter;
										}
									}
									if ((batchSize_tDBOutput_4 > 0)
											&& (batchSize_tDBOutput_4 <= batchSizeCounter_tDBOutput_4)) {

										insertedCount_tDBOutput_4 = new LimitBytesHelper_tDBOutput_4()
												.limitBytePart1(insertedCount_tDBOutput_4, pstmt_tDBOutput_4);
										rowsToCommitCount_tDBOutput_4 = insertedCount_tDBOutput_4;

										batchSizeCounter_tDBOutput_4 = 0;
									}

									//////////// commit every////////////

									commitCounter_tDBOutput_4++;
									if (commitEvery_tDBOutput_4 <= commitCounter_tDBOutput_4) {
										if ((batchSize_tDBOutput_4 > 0) && (batchSizeCounter_tDBOutput_4 > 0)) {

											insertedCount_tDBOutput_4 = new LimitBytesHelper_tDBOutput_4()
													.limitBytePart1(insertedCount_tDBOutput_4, pstmt_tDBOutput_4);

											batchSizeCounter_tDBOutput_4 = 0;
										}
										if (rowsToCommitCount_tDBOutput_4 != 0) {

											if (log.isDebugEnabled())
												log.debug("tDBOutput_4 - " + ("Connection starting to commit ")
														+ (rowsToCommitCount_tDBOutput_4) + (" record(s)."));
										}
										conn_tDBOutput_4.commit();
										if (rowsToCommitCount_tDBOutput_4 != 0) {

											if (log.isDebugEnabled())
												log.debug("tDBOutput_4 - " + ("Connection commit has succeeded."));
											rowsToCommitCount_tDBOutput_4 = 0;
										}
										commitCounter_tDBOutput_4 = 0;
									}

									tos_count_tDBOutput_4++;

									/**
									 * [tDBOutput_4 main ] stop
									 */

									/**
									 * [tDBOutput_4 process_data_begin ] start
									 */

									currentComponent = "tDBOutput_4";

									/**
									 * [tDBOutput_4 process_data_begin ] stop
									 */

									/**
									 * [tDBOutput_4 process_data_end ] start
									 */

									currentComponent = "tDBOutput_4";

									/**
									 * [tDBOutput_4 process_data_end ] stop
									 */

								} // End of branch "Ejection_Load"

								/**
								 * [tMap_6 process_data_end ] start
								 */

								currentComponent = "tMap_6";

								/**
								 * [tMap_6 process_data_end ] stop
								 */

							} // End of branch "row5"

							/**
							 * [tUniqRow_5 process_data_end ] start
							 */

							currentComponent = "tUniqRow_5";

							/**
							 * [tUniqRow_5 process_data_end ] stop
							 */

						} // End of branch "Ejection"

// Start of branch "Bodily_Injury"
						if (Bodily_Injury != null) {

							/**
							 * [tUniqRow_7 main ] start
							 */

							currentComponent = "tUniqRow_7";

							if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

									, "Bodily_Injury", "tMap_1", "tMap_1", "tMap", "tUniqRow_7", "tUniqRow_7",
									"tUniqRow"

							)) {
								talendJobLogProcess(globalMap);
							}

							if (log.isTraceEnabled()) {
								log.trace("Bodily_Injury - "
										+ (Bodily_Injury == null ? "" : Bodily_Injury.toLogString()));
							}

							row6 = null;
							if (Bodily_Injury.BODILY_INJURY == null) {
								finder_tUniqRow_7.BODILY_INJURY = null;
							} else {
								finder_tUniqRow_7.BODILY_INJURY = Bodily_Injury.BODILY_INJURY.toLowerCase();
							}
							finder_tUniqRow_7.hashCodeDirty = true;
							if (!keystUniqRow_7.contains(finder_tUniqRow_7)) {
								KeyStruct_tUniqRow_7 new_tUniqRow_7 = new KeyStruct_tUniqRow_7();

								if (Bodily_Injury.BODILY_INJURY == null) {
									new_tUniqRow_7.BODILY_INJURY = null;
								} else {
									new_tUniqRow_7.BODILY_INJURY = Bodily_Injury.BODILY_INJURY.toLowerCase();
								}

								keystUniqRow_7.add(new_tUniqRow_7);
								if (row6 == null) {

									log.trace("tUniqRow_7 - Writing the unique record " + (nb_uniques_tUniqRow_7 + 1)
											+ " into row6.");

									row6 = new row6Struct();
								}
								row6.BODILY_INJURY = Bodily_Injury.BODILY_INJURY;
								nb_uniques_tUniqRow_7++;
							} else {
								nb_duplicates_tUniqRow_7++;
							}

							tos_count_tUniqRow_7++;

							/**
							 * [tUniqRow_7 main ] stop
							 */

							/**
							 * [tUniqRow_7 process_data_begin ] start
							 */

							currentComponent = "tUniqRow_7";

							/**
							 * [tUniqRow_7 process_data_begin ] stop
							 */
// Start of branch "row6"
							if (row6 != null) {

								/**
								 * [tMap_7 main ] start
								 */

								currentComponent = "tMap_7";

								if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

										, "row6", "tUniqRow_7", "tUniqRow_7", "tUniqRow", "tMap_7", "tMap_7", "tMap"

								)) {
									talendJobLogProcess(globalMap);
								}

								if (log.isTraceEnabled()) {
									log.trace("row6 - " + (row6 == null ? "" : row6.toLogString()));
								}

								boolean hasCasePrimitiveKeyWithNull_tMap_7 = false;

								// ###############################
								// # Input tables (lookups)
								boolean rejectedInnerJoin_tMap_7 = false;
								boolean mainRowRejected_tMap_7 = false;

								// ###############################
								{ // start of Var scope

									// ###############################
									// # Vars tables

									Var__tMap_7__Struct Var = Var__tMap_7;// ###############################
									// ###############################
									// # Output tables

									Bodily_load = null;

// # Output table : 'Bodily_load'
									count_Bodily_load_tMap_7++;

									Bodily_load_tmp.BODILY_INJURY_SK = null;
									Bodily_load_tmp.BODILY_INJURY = row6.BODILY_INJURY;
									Bodily_load_tmp.DI_PID = "MVC_LOAD";
									Bodily_load_tmp.DI_Create_Date = TalendDate.getCurrentDate();
									Bodily_load = Bodily_load_tmp;
									log.debug("tMap_7 - Outputting the record " + count_Bodily_load_tMap_7
											+ " of the output table 'Bodily_load'.");

// ###############################

								} // end of Var scope

								rejectedInnerJoin_tMap_7 = false;

								tos_count_tMap_7++;

								/**
								 * [tMap_7 main ] stop
								 */

								/**
								 * [tMap_7 process_data_begin ] start
								 */

								currentComponent = "tMap_7";

								/**
								 * [tMap_7 process_data_begin ] stop
								 */
// Start of branch "Bodily_load"
								if (Bodily_load != null) {

									/**
									 * [tDBOutput_5 main ] start
									 */

									currentComponent = "tDBOutput_5";

									if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

											, "Bodily_load", "tMap_7", "tMap_7", "tMap", "tDBOutput_5", "__TABLE__",
											"tMSSqlOutput"

									)) {
										talendJobLogProcess(globalMap);
									}

									if (log.isTraceEnabled()) {
										log.trace("Bodily_load - "
												+ (Bodily_load == null ? "" : Bodily_load.toLogString()));
									}

									whetherReject_tDBOutput_5 = false;
									if (Bodily_load.BODILY_INJURY_SK == null) {
										pstmt_tDBOutput_5.setNull(1, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_5.setString(1, Bodily_load.BODILY_INJURY_SK);
									}

									if (Bodily_load.BODILY_INJURY == null) {
										pstmt_tDBOutput_5.setNull(2, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_5.setString(2, Bodily_load.BODILY_INJURY);
									}

									if (Bodily_load.DI_PID == null) {
										pstmt_tDBOutput_5.setNull(3, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_5.setString(3, Bodily_load.DI_PID);
									}

									if (Bodily_load.DI_Create_Date != null) {
										pstmt_tDBOutput_5.setTimestamp(4,
												new java.sql.Timestamp(Bodily_load.DI_Create_Date.getTime()));
									} else {
										pstmt_tDBOutput_5.setNull(4, java.sql.Types.TIMESTAMP);
									}

									pstmt_tDBOutput_5.addBatch();
									nb_line_tDBOutput_5++;

									if (log.isDebugEnabled())
										log.debug("tDBOutput_5 - " + ("Adding the record ") + (nb_line_tDBOutput_5)
												+ (" to the ") + ("INSERT") + (" batch."));
									batchSizeCounter_tDBOutput_5++;

									////////// batch execute by batch size///////
									class LimitBytesHelper_tDBOutput_5 {
										public int limitBytePart1(int counter,
												java.sql.PreparedStatement pstmt_tDBOutput_5) throws Exception {
											try {

												if (log.isDebugEnabled())
													log.debug("tDBOutput_5 - " + ("Executing the ") + ("INSERT")
															+ (" batch."));
												for (int countEach_tDBOutput_5 : pstmt_tDBOutput_5.executeBatch()) {
													if (countEach_tDBOutput_5 == -2 || countEach_tDBOutput_5 == -3) {
														break;
													}
													counter += countEach_tDBOutput_5;
												}

												if (log.isDebugEnabled())
													log.debug("tDBOutput_5 - " + ("The ") + ("INSERT")
															+ (" batch execution has succeeded."));
											} catch (java.sql.BatchUpdateException e) {
												globalMap.put("tDBOutput_5_ERROR_MESSAGE", e.getMessage());

												int countSum_tDBOutput_5 = 0;
												for (int countEach_tDBOutput_5 : e.getUpdateCounts()) {
													counter += (countEach_tDBOutput_5 < 0 ? 0 : countEach_tDBOutput_5);
												}

												log.error("tDBOutput_5 - " + (e.getMessage()));
												System.err.println(e.getMessage());

											}
											return counter;
										}

										public int limitBytePart2(int counter,
												java.sql.PreparedStatement pstmt_tDBOutput_5) throws Exception {
											try {

												if (log.isDebugEnabled())
													log.debug("tDBOutput_5 - " + ("Executing the ") + ("INSERT")
															+ (" batch."));
												for (int countEach_tDBOutput_5 : pstmt_tDBOutput_5.executeBatch()) {
													if (countEach_tDBOutput_5 == -2 || countEach_tDBOutput_5 == -3) {
														break;
													}
													counter += countEach_tDBOutput_5;
												}

												if (log.isDebugEnabled())
													log.debug("tDBOutput_5 - " + ("The ") + ("INSERT")
															+ (" batch execution has succeeded."));
											} catch (java.sql.BatchUpdateException e) {
												globalMap.put("tDBOutput_5_ERROR_MESSAGE", e.getMessage());

												for (int countEach_tDBOutput_5 : e.getUpdateCounts()) {
													counter += (countEach_tDBOutput_5 < 0 ? 0 : countEach_tDBOutput_5);
												}

												log.error("tDBOutput_5 - " + (e.getMessage()));
												System.err.println(e.getMessage());

											}
											return counter;
										}
									}
									if ((batchSize_tDBOutput_5 > 0)
											&& (batchSize_tDBOutput_5 <= batchSizeCounter_tDBOutput_5)) {

										insertedCount_tDBOutput_5 = new LimitBytesHelper_tDBOutput_5()
												.limitBytePart1(insertedCount_tDBOutput_5, pstmt_tDBOutput_5);
										rowsToCommitCount_tDBOutput_5 = insertedCount_tDBOutput_5;

										batchSizeCounter_tDBOutput_5 = 0;
									}

									//////////// commit every////////////

									commitCounter_tDBOutput_5++;
									if (commitEvery_tDBOutput_5 <= commitCounter_tDBOutput_5) {
										if ((batchSize_tDBOutput_5 > 0) && (batchSizeCounter_tDBOutput_5 > 0)) {

											insertedCount_tDBOutput_5 = new LimitBytesHelper_tDBOutput_5()
													.limitBytePart1(insertedCount_tDBOutput_5, pstmt_tDBOutput_5);

											batchSizeCounter_tDBOutput_5 = 0;
										}
										if (rowsToCommitCount_tDBOutput_5 != 0) {

											if (log.isDebugEnabled())
												log.debug("tDBOutput_5 - " + ("Connection starting to commit ")
														+ (rowsToCommitCount_tDBOutput_5) + (" record(s)."));
										}
										conn_tDBOutput_5.commit();
										if (rowsToCommitCount_tDBOutput_5 != 0) {

											if (log.isDebugEnabled())
												log.debug("tDBOutput_5 - " + ("Connection commit has succeeded."));
											rowsToCommitCount_tDBOutput_5 = 0;
										}
										commitCounter_tDBOutput_5 = 0;
									}

									tos_count_tDBOutput_5++;

									/**
									 * [tDBOutput_5 main ] stop
									 */

									/**
									 * [tDBOutput_5 process_data_begin ] start
									 */

									currentComponent = "tDBOutput_5";

									/**
									 * [tDBOutput_5 process_data_begin ] stop
									 */

									/**
									 * [tDBOutput_5 process_data_end ] start
									 */

									currentComponent = "tDBOutput_5";

									/**
									 * [tDBOutput_5 process_data_end ] stop
									 */

								} // End of branch "Bodily_load"

								/**
								 * [tMap_7 process_data_end ] start
								 */

								currentComponent = "tMap_7";

								/**
								 * [tMap_7 process_data_end ] stop
								 */

							} // End of branch "row6"

							/**
							 * [tUniqRow_7 process_data_end ] start
							 */

							currentComponent = "tUniqRow_7";

							/**
							 * [tUniqRow_7 process_data_end ] stop
							 */

						} // End of branch "Bodily_Injury"

// Start of branch "Position_In_vehicle"
						if (Position_In_vehicle != null) {

							/**
							 * [tUniqRow_4 main ] start
							 */

							currentComponent = "tUniqRow_4";

							if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

									, "Position_In_vehicle", "tMap_1", "tMap_1", "tMap", "tUniqRow_4", "tUniqRow_4",
									"tUniqRow"

							)) {
								talendJobLogProcess(globalMap);
							}

							if (log.isTraceEnabled()) {
								log.trace("Position_In_vehicle - "
										+ (Position_In_vehicle == null ? "" : Position_In_vehicle.toLogString()));
							}

							row7 = null;
							if (Position_In_vehicle.POSITION_IN_VEHICLE == null) {
								finder_tUniqRow_4.POSITION_IN_VEHICLE = null;
							} else {
								finder_tUniqRow_4.POSITION_IN_VEHICLE = Position_In_vehicle.POSITION_IN_VEHICLE
										.toLowerCase();
							}
							finder_tUniqRow_4.hashCodeDirty = true;
							if (!keystUniqRow_4.contains(finder_tUniqRow_4)) {
								KeyStruct_tUniqRow_4 new_tUniqRow_4 = new KeyStruct_tUniqRow_4();

								if (Position_In_vehicle.POSITION_IN_VEHICLE == null) {
									new_tUniqRow_4.POSITION_IN_VEHICLE = null;
								} else {
									new_tUniqRow_4.POSITION_IN_VEHICLE = Position_In_vehicle.POSITION_IN_VEHICLE
											.toLowerCase();
								}

								keystUniqRow_4.add(new_tUniqRow_4);
								if (row7 == null) {

									log.trace("tUniqRow_4 - Writing the unique record " + (nb_uniques_tUniqRow_4 + 1)
											+ " into row7.");

									row7 = new row7Struct();
								}
								row7.POSITION_IN_VEHICLE = Position_In_vehicle.POSITION_IN_VEHICLE;
								nb_uniques_tUniqRow_4++;
							} else {
								nb_duplicates_tUniqRow_4++;
							}

							tos_count_tUniqRow_4++;

							/**
							 * [tUniqRow_4 main ] stop
							 */

							/**
							 * [tUniqRow_4 process_data_begin ] start
							 */

							currentComponent = "tUniqRow_4";

							/**
							 * [tUniqRow_4 process_data_begin ] stop
							 */
// Start of branch "row7"
							if (row7 != null) {

								/**
								 * [tMap_9 main ] start
								 */

								currentComponent = "tMap_9";

								if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

										, "row7", "tUniqRow_4", "tUniqRow_4", "tUniqRow", "tMap_9", "tMap_9", "tMap"

								)) {
									talendJobLogProcess(globalMap);
								}

								if (log.isTraceEnabled()) {
									log.trace("row7 - " + (row7 == null ? "" : row7.toLogString()));
								}

								boolean hasCasePrimitiveKeyWithNull_tMap_9 = false;

								// ###############################
								// # Input tables (lookups)
								boolean rejectedInnerJoin_tMap_9 = false;
								boolean mainRowRejected_tMap_9 = false;

								// ###############################
								{ // start of Var scope

									// ###############################
									// # Vars tables

									Var__tMap_9__Struct Var = Var__tMap_9;// ###############################
									// ###############################
									// # Output tables

									Position_In_Vehicle1 = null;

// # Output table : 'Position_In_Vehicle1'
									count_Position_In_Vehicle1_tMap_9++;

									Position_In_Vehicle1_tmp.POSITION_IN_VEHICLE_SK = null;
									Position_In_Vehicle1_tmp.POSITION_IN_VEHICLE = row7.POSITION_IN_VEHICLE;
									Position_In_Vehicle1_tmp.DI_PID = "MVC_LOAD";
									Position_In_Vehicle1_tmp.DI_Create_Date = TalendDate.getCurrentDate();
									Position_In_Vehicle1 = Position_In_Vehicle1_tmp;
									log.debug("tMap_9 - Outputting the record " + count_Position_In_Vehicle1_tMap_9
											+ " of the output table 'Position_In_Vehicle1'.");

// ###############################

								} // end of Var scope

								rejectedInnerJoin_tMap_9 = false;

								tos_count_tMap_9++;

								/**
								 * [tMap_9 main ] stop
								 */

								/**
								 * [tMap_9 process_data_begin ] start
								 */

								currentComponent = "tMap_9";

								/**
								 * [tMap_9 process_data_begin ] stop
								 */
// Start of branch "Position_In_Vehicle1"
								if (Position_In_Vehicle1 != null) {

									/**
									 * [tDBOutput_6 main ] start
									 */

									currentComponent = "tDBOutput_6";

									if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

											, "Position_In_Vehicle1", "tMap_9", "tMap_9", "tMap", "tDBOutput_6",
											"__TABLE__", "tMSSqlOutput"

									)) {
										talendJobLogProcess(globalMap);
									}

									if (log.isTraceEnabled()) {
										log.trace("Position_In_Vehicle1 - " + (Position_In_Vehicle1 == null ? ""
												: Position_In_Vehicle1.toLogString()));
									}

									whetherReject_tDBOutput_6 = false;
									if (Position_In_Vehicle1.POSITION_IN_VEHICLE_SK == null) {
										pstmt_tDBOutput_6.setNull(1, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_6.setString(1, Position_In_Vehicle1.POSITION_IN_VEHICLE_SK);
									}

									if (Position_In_Vehicle1.POSITION_IN_VEHICLE == null) {
										pstmt_tDBOutput_6.setNull(2, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_6.setString(2, Position_In_Vehicle1.POSITION_IN_VEHICLE);
									}

									if (Position_In_Vehicle1.DI_PID == null) {
										pstmt_tDBOutput_6.setNull(3, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_6.setString(3, Position_In_Vehicle1.DI_PID);
									}

									if (Position_In_Vehicle1.DI_Create_Date != null) {
										pstmt_tDBOutput_6.setTimestamp(4,
												new java.sql.Timestamp(Position_In_Vehicle1.DI_Create_Date.getTime()));
									} else {
										pstmt_tDBOutput_6.setNull(4, java.sql.Types.TIMESTAMP);
									}

									pstmt_tDBOutput_6.addBatch();
									nb_line_tDBOutput_6++;

									if (log.isDebugEnabled())
										log.debug("tDBOutput_6 - " + ("Adding the record ") + (nb_line_tDBOutput_6)
												+ (" to the ") + ("INSERT") + (" batch."));
									batchSizeCounter_tDBOutput_6++;

									////////// batch execute by batch size///////
									class LimitBytesHelper_tDBOutput_6 {
										public int limitBytePart1(int counter,
												java.sql.PreparedStatement pstmt_tDBOutput_6) throws Exception {
											try {

												if (log.isDebugEnabled())
													log.debug("tDBOutput_6 - " + ("Executing the ") + ("INSERT")
															+ (" batch."));
												for (int countEach_tDBOutput_6 : pstmt_tDBOutput_6.executeBatch()) {
													if (countEach_tDBOutput_6 == -2 || countEach_tDBOutput_6 == -3) {
														break;
													}
													counter += countEach_tDBOutput_6;
												}

												if (log.isDebugEnabled())
													log.debug("tDBOutput_6 - " + ("The ") + ("INSERT")
															+ (" batch execution has succeeded."));
											} catch (java.sql.BatchUpdateException e) {
												globalMap.put("tDBOutput_6_ERROR_MESSAGE", e.getMessage());

												int countSum_tDBOutput_6 = 0;
												for (int countEach_tDBOutput_6 : e.getUpdateCounts()) {
													counter += (countEach_tDBOutput_6 < 0 ? 0 : countEach_tDBOutput_6);
												}

												log.error("tDBOutput_6 - " + (e.getMessage()));
												System.err.println(e.getMessage());

											}
											return counter;
										}

										public int limitBytePart2(int counter,
												java.sql.PreparedStatement pstmt_tDBOutput_6) throws Exception {
											try {

												if (log.isDebugEnabled())
													log.debug("tDBOutput_6 - " + ("Executing the ") + ("INSERT")
															+ (" batch."));
												for (int countEach_tDBOutput_6 : pstmt_tDBOutput_6.executeBatch()) {
													if (countEach_tDBOutput_6 == -2 || countEach_tDBOutput_6 == -3) {
														break;
													}
													counter += countEach_tDBOutput_6;
												}

												if (log.isDebugEnabled())
													log.debug("tDBOutput_6 - " + ("The ") + ("INSERT")
															+ (" batch execution has succeeded."));
											} catch (java.sql.BatchUpdateException e) {
												globalMap.put("tDBOutput_6_ERROR_MESSAGE", e.getMessage());

												for (int countEach_tDBOutput_6 : e.getUpdateCounts()) {
													counter += (countEach_tDBOutput_6 < 0 ? 0 : countEach_tDBOutput_6);
												}

												log.error("tDBOutput_6 - " + (e.getMessage()));
												System.err.println(e.getMessage());

											}
											return counter;
										}
									}
									if ((batchSize_tDBOutput_6 > 0)
											&& (batchSize_tDBOutput_6 <= batchSizeCounter_tDBOutput_6)) {

										insertedCount_tDBOutput_6 = new LimitBytesHelper_tDBOutput_6()
												.limitBytePart1(insertedCount_tDBOutput_6, pstmt_tDBOutput_6);
										rowsToCommitCount_tDBOutput_6 = insertedCount_tDBOutput_6;

										batchSizeCounter_tDBOutput_6 = 0;
									}

									//////////// commit every////////////

									commitCounter_tDBOutput_6++;
									if (commitEvery_tDBOutput_6 <= commitCounter_tDBOutput_6) {
										if ((batchSize_tDBOutput_6 > 0) && (batchSizeCounter_tDBOutput_6 > 0)) {

											insertedCount_tDBOutput_6 = new LimitBytesHelper_tDBOutput_6()
													.limitBytePart1(insertedCount_tDBOutput_6, pstmt_tDBOutput_6);

											batchSizeCounter_tDBOutput_6 = 0;
										}
										if (rowsToCommitCount_tDBOutput_6 != 0) {

											if (log.isDebugEnabled())
												log.debug("tDBOutput_6 - " + ("Connection starting to commit ")
														+ (rowsToCommitCount_tDBOutput_6) + (" record(s)."));
										}
										conn_tDBOutput_6.commit();
										if (rowsToCommitCount_tDBOutput_6 != 0) {

											if (log.isDebugEnabled())
												log.debug("tDBOutput_6 - " + ("Connection commit has succeeded."));
											rowsToCommitCount_tDBOutput_6 = 0;
										}
										commitCounter_tDBOutput_6 = 0;
									}

									tos_count_tDBOutput_6++;

									/**
									 * [tDBOutput_6 main ] stop
									 */

									/**
									 * [tDBOutput_6 process_data_begin ] start
									 */

									currentComponent = "tDBOutput_6";

									/**
									 * [tDBOutput_6 process_data_begin ] stop
									 */

									/**
									 * [tDBOutput_6 process_data_end ] start
									 */

									currentComponent = "tDBOutput_6";

									/**
									 * [tDBOutput_6 process_data_end ] stop
									 */

								} // End of branch "Position_In_Vehicle1"

								/**
								 * [tMap_9 process_data_end ] start
								 */

								currentComponent = "tMap_9";

								/**
								 * [tMap_9 process_data_end ] stop
								 */

							} // End of branch "row7"

							/**
							 * [tUniqRow_4 process_data_end ] start
							 */

							currentComponent = "tUniqRow_4";

							/**
							 * [tUniqRow_4 process_data_end ] stop
							 */

						} // End of branch "Position_In_vehicle"

// Start of branch "Safety_Equipment"
						if (Safety_Equipment != null) {

							/**
							 * [tUniqRow_8 main ] start
							 */

							currentComponent = "tUniqRow_8";

							if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

									, "Safety_Equipment", "tMap_1", "tMap_1", "tMap", "tUniqRow_8", "tUniqRow_8",
									"tUniqRow"

							)) {
								talendJobLogProcess(globalMap);
							}

							if (log.isTraceEnabled()) {
								log.trace("Safety_Equipment - "
										+ (Safety_Equipment == null ? "" : Safety_Equipment.toLogString()));
							}

							row8 = null;
							if (Safety_Equipment.SAFETY_EQUIPMENT == null) {
								finder_tUniqRow_8.SAFETY_EQUIPMENT = null;
							} else {
								finder_tUniqRow_8.SAFETY_EQUIPMENT = Safety_Equipment.SAFETY_EQUIPMENT.toLowerCase();
							}
							finder_tUniqRow_8.hashCodeDirty = true;
							if (!keystUniqRow_8.contains(finder_tUniqRow_8)) {
								KeyStruct_tUniqRow_8 new_tUniqRow_8 = new KeyStruct_tUniqRow_8();

								if (Safety_Equipment.SAFETY_EQUIPMENT == null) {
									new_tUniqRow_8.SAFETY_EQUIPMENT = null;
								} else {
									new_tUniqRow_8.SAFETY_EQUIPMENT = Safety_Equipment.SAFETY_EQUIPMENT.toLowerCase();
								}

								keystUniqRow_8.add(new_tUniqRow_8);
								if (row8 == null) {

									log.trace("tUniqRow_8 - Writing the unique record " + (nb_uniques_tUniqRow_8 + 1)
											+ " into row8.");

									row8 = new row8Struct();
								}
								row8.SAFETY_EQUIPMENT = Safety_Equipment.SAFETY_EQUIPMENT;
								nb_uniques_tUniqRow_8++;
							} else {
								nb_duplicates_tUniqRow_8++;
							}

							tos_count_tUniqRow_8++;

							/**
							 * [tUniqRow_8 main ] stop
							 */

							/**
							 * [tUniqRow_8 process_data_begin ] start
							 */

							currentComponent = "tUniqRow_8";

							/**
							 * [tUniqRow_8 process_data_begin ] stop
							 */
// Start of branch "row8"
							if (row8 != null) {

								/**
								 * [tMap_10 main ] start
								 */

								currentComponent = "tMap_10";

								if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

										, "row8", "tUniqRow_8", "tUniqRow_8", "tUniqRow", "tMap_10", "tMap_10", "tMap"

								)) {
									talendJobLogProcess(globalMap);
								}

								if (log.isTraceEnabled()) {
									log.trace("row8 - " + (row8 == null ? "" : row8.toLogString()));
								}

								boolean hasCasePrimitiveKeyWithNull_tMap_10 = false;

								// ###############################
								// # Input tables (lookups)
								boolean rejectedInnerJoin_tMap_10 = false;
								boolean mainRowRejected_tMap_10 = false;

								// ###############################
								{ // start of Var scope

									// ###############################
									// # Vars tables

									Var__tMap_10__Struct Var = Var__tMap_10;// ###############################
									// ###############################
									// # Output tables

									Safety_Equipment1 = null;

// # Output table : 'Safety_Equipment1'
									count_Safety_Equipment1_tMap_10++;

									Safety_Equipment1_tmp.SAFETY_EQUIPMENT = row8.SAFETY_EQUIPMENT;
									Safety_Equipment1_tmp.SAFETY_EQUIPMENT_SK = null;
									Safety_Equipment1_tmp.DI_PID = "MVC_LOAD";
									Safety_Equipment1_tmp.DI_Create_Date = TalendDate.getCurrentDate();
									Safety_Equipment1 = Safety_Equipment1_tmp;
									log.debug("tMap_10 - Outputting the record " + count_Safety_Equipment1_tMap_10
											+ " of the output table 'Safety_Equipment1'.");

// ###############################

								} // end of Var scope

								rejectedInnerJoin_tMap_10 = false;

								tos_count_tMap_10++;

								/**
								 * [tMap_10 main ] stop
								 */

								/**
								 * [tMap_10 process_data_begin ] start
								 */

								currentComponent = "tMap_10";

								/**
								 * [tMap_10 process_data_begin ] stop
								 */
// Start of branch "Safety_Equipment1"
								if (Safety_Equipment1 != null) {

									/**
									 * [tDBOutput_7 main ] start
									 */

									currentComponent = "tDBOutput_7";

									if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

											, "Safety_Equipment1", "tMap_10", "tMap_10", "tMap", "tDBOutput_7",
											"__TABLE__", "tMSSqlOutput"

									)) {
										talendJobLogProcess(globalMap);
									}

									if (log.isTraceEnabled()) {
										log.trace("Safety_Equipment1 - "
												+ (Safety_Equipment1 == null ? "" : Safety_Equipment1.toLogString()));
									}

									whetherReject_tDBOutput_7 = false;
									if (Safety_Equipment1.SAFETY_EQUIPMENT == null) {
										pstmt_tDBOutput_7.setNull(1, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_7.setString(1, Safety_Equipment1.SAFETY_EQUIPMENT);
									}

									if (Safety_Equipment1.SAFETY_EQUIPMENT_SK == null) {
										pstmt_tDBOutput_7.setNull(2, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_7.setString(2, Safety_Equipment1.SAFETY_EQUIPMENT_SK);
									}

									if (Safety_Equipment1.DI_PID == null) {
										pstmt_tDBOutput_7.setNull(3, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_7.setString(3, Safety_Equipment1.DI_PID);
									}

									if (Safety_Equipment1.DI_Create_Date != null) {
										pstmt_tDBOutput_7.setTimestamp(4,
												new java.sql.Timestamp(Safety_Equipment1.DI_Create_Date.getTime()));
									} else {
										pstmt_tDBOutput_7.setNull(4, java.sql.Types.TIMESTAMP);
									}

									pstmt_tDBOutput_7.addBatch();
									nb_line_tDBOutput_7++;

									if (log.isDebugEnabled())
										log.debug("tDBOutput_7 - " + ("Adding the record ") + (nb_line_tDBOutput_7)
												+ (" to the ") + ("INSERT") + (" batch."));
									batchSizeCounter_tDBOutput_7++;

									////////// batch execute by batch size///////
									class LimitBytesHelper_tDBOutput_7 {
										public int limitBytePart1(int counter,
												java.sql.PreparedStatement pstmt_tDBOutput_7) throws Exception {
											try {

												if (log.isDebugEnabled())
													log.debug("tDBOutput_7 - " + ("Executing the ") + ("INSERT")
															+ (" batch."));
												for (int countEach_tDBOutput_7 : pstmt_tDBOutput_7.executeBatch()) {
													if (countEach_tDBOutput_7 == -2 || countEach_tDBOutput_7 == -3) {
														break;
													}
													counter += countEach_tDBOutput_7;
												}

												if (log.isDebugEnabled())
													log.debug("tDBOutput_7 - " + ("The ") + ("INSERT")
															+ (" batch execution has succeeded."));
											} catch (java.sql.BatchUpdateException e) {
												globalMap.put("tDBOutput_7_ERROR_MESSAGE", e.getMessage());

												int countSum_tDBOutput_7 = 0;
												for (int countEach_tDBOutput_7 : e.getUpdateCounts()) {
													counter += (countEach_tDBOutput_7 < 0 ? 0 : countEach_tDBOutput_7);
												}

												log.error("tDBOutput_7 - " + (e.getMessage()));
												System.err.println(e.getMessage());

											}
											return counter;
										}

										public int limitBytePart2(int counter,
												java.sql.PreparedStatement pstmt_tDBOutput_7) throws Exception {
											try {

												if (log.isDebugEnabled())
													log.debug("tDBOutput_7 - " + ("Executing the ") + ("INSERT")
															+ (" batch."));
												for (int countEach_tDBOutput_7 : pstmt_tDBOutput_7.executeBatch()) {
													if (countEach_tDBOutput_7 == -2 || countEach_tDBOutput_7 == -3) {
														break;
													}
													counter += countEach_tDBOutput_7;
												}

												if (log.isDebugEnabled())
													log.debug("tDBOutput_7 - " + ("The ") + ("INSERT")
															+ (" batch execution has succeeded."));
											} catch (java.sql.BatchUpdateException e) {
												globalMap.put("tDBOutput_7_ERROR_MESSAGE", e.getMessage());

												for (int countEach_tDBOutput_7 : e.getUpdateCounts()) {
													counter += (countEach_tDBOutput_7 < 0 ? 0 : countEach_tDBOutput_7);
												}

												log.error("tDBOutput_7 - " + (e.getMessage()));
												System.err.println(e.getMessage());

											}
											return counter;
										}
									}
									if ((batchSize_tDBOutput_7 > 0)
											&& (batchSize_tDBOutput_7 <= batchSizeCounter_tDBOutput_7)) {

										insertedCount_tDBOutput_7 = new LimitBytesHelper_tDBOutput_7()
												.limitBytePart1(insertedCount_tDBOutput_7, pstmt_tDBOutput_7);
										rowsToCommitCount_tDBOutput_7 = insertedCount_tDBOutput_7;

										batchSizeCounter_tDBOutput_7 = 0;
									}

									//////////// commit every////////////

									commitCounter_tDBOutput_7++;
									if (commitEvery_tDBOutput_7 <= commitCounter_tDBOutput_7) {
										if ((batchSize_tDBOutput_7 > 0) && (batchSizeCounter_tDBOutput_7 > 0)) {

											insertedCount_tDBOutput_7 = new LimitBytesHelper_tDBOutput_7()
													.limitBytePart1(insertedCount_tDBOutput_7, pstmt_tDBOutput_7);

											batchSizeCounter_tDBOutput_7 = 0;
										}
										if (rowsToCommitCount_tDBOutput_7 != 0) {

											if (log.isDebugEnabled())
												log.debug("tDBOutput_7 - " + ("Connection starting to commit ")
														+ (rowsToCommitCount_tDBOutput_7) + (" record(s)."));
										}
										conn_tDBOutput_7.commit();
										if (rowsToCommitCount_tDBOutput_7 != 0) {

											if (log.isDebugEnabled())
												log.debug("tDBOutput_7 - " + ("Connection commit has succeeded."));
											rowsToCommitCount_tDBOutput_7 = 0;
										}
										commitCounter_tDBOutput_7 = 0;
									}

									tos_count_tDBOutput_7++;

									/**
									 * [tDBOutput_7 main ] stop
									 */

									/**
									 * [tDBOutput_7 process_data_begin ] start
									 */

									currentComponent = "tDBOutput_7";

									/**
									 * [tDBOutput_7 process_data_begin ] stop
									 */

									/**
									 * [tDBOutput_7 process_data_end ] start
									 */

									currentComponent = "tDBOutput_7";

									/**
									 * [tDBOutput_7 process_data_end ] stop
									 */

								} // End of branch "Safety_Equipment1"

								/**
								 * [tMap_10 process_data_end ] start
								 */

								currentComponent = "tMap_10";

								/**
								 * [tMap_10 process_data_end ] stop
								 */

							} // End of branch "row8"

							/**
							 * [tUniqRow_8 process_data_end ] start
							 */

							currentComponent = "tUniqRow_8";

							/**
							 * [tUniqRow_8 process_data_end ] stop
							 */

						} // End of branch "Safety_Equipment"

// Start of branch "Ped_Location"
						if (Ped_Location != null) {

							/**
							 * [tUniqRow_9 main ] start
							 */

							currentComponent = "tUniqRow_9";

							if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

									, "Ped_Location", "tMap_1", "tMap_1", "tMap", "tUniqRow_9", "tUniqRow_9", "tUniqRow"

							)) {
								talendJobLogProcess(globalMap);
							}

							if (log.isTraceEnabled()) {
								log.trace("Ped_Location - " + (Ped_Location == null ? "" : Ped_Location.toLogString()));
							}

							row9 = null;
							if (Ped_Location.PED_LOCATION == null) {
								finder_tUniqRow_9.PED_LOCATION = null;
							} else {
								finder_tUniqRow_9.PED_LOCATION = Ped_Location.PED_LOCATION.toLowerCase();
							}
							finder_tUniqRow_9.hashCodeDirty = true;
							if (!keystUniqRow_9.contains(finder_tUniqRow_9)) {
								KeyStruct_tUniqRow_9 new_tUniqRow_9 = new KeyStruct_tUniqRow_9();

								if (Ped_Location.PED_LOCATION == null) {
									new_tUniqRow_9.PED_LOCATION = null;
								} else {
									new_tUniqRow_9.PED_LOCATION = Ped_Location.PED_LOCATION.toLowerCase();
								}

								keystUniqRow_9.add(new_tUniqRow_9);
								if (row9 == null) {

									log.trace("tUniqRow_9 - Writing the unique record " + (nb_uniques_tUniqRow_9 + 1)
											+ " into row9.");

									row9 = new row9Struct();
								}
								row9.PED_LOCATION = Ped_Location.PED_LOCATION;
								nb_uniques_tUniqRow_9++;
							} else {
								nb_duplicates_tUniqRow_9++;
							}

							tos_count_tUniqRow_9++;

							/**
							 * [tUniqRow_9 main ] stop
							 */

							/**
							 * [tUniqRow_9 process_data_begin ] start
							 */

							currentComponent = "tUniqRow_9";

							/**
							 * [tUniqRow_9 process_data_begin ] stop
							 */
// Start of branch "row9"
							if (row9 != null) {

								/**
								 * [tMap_11 main ] start
								 */

								currentComponent = "tMap_11";

								if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

										, "row9", "tUniqRow_9", "tUniqRow_9", "tUniqRow", "tMap_11", "tMap_11", "tMap"

								)) {
									talendJobLogProcess(globalMap);
								}

								if (log.isTraceEnabled()) {
									log.trace("row9 - " + (row9 == null ? "" : row9.toLogString()));
								}

								boolean hasCasePrimitiveKeyWithNull_tMap_11 = false;

								// ###############################
								// # Input tables (lookups)
								boolean rejectedInnerJoin_tMap_11 = false;
								boolean mainRowRejected_tMap_11 = false;

								// ###############################
								{ // start of Var scope

									// ###############################
									// # Vars tables

									Var__tMap_11__Struct Var = Var__tMap_11;// ###############################
									// ###############################
									// # Output tables

									Ped_Location_Load = null;

// # Output table : 'Ped_Location_Load'
									count_Ped_Location_Load_tMap_11++;

									Ped_Location_Load_tmp.PED_LOCATION_SK = null;
									Ped_Location_Load_tmp.PED_LOCATION = row9.PED_LOCATION;
									Ped_Location_Load_tmp.DI_PID = "MVC_LOAD";
									Ped_Location_Load_tmp.DI_Create_Date = TalendDate.getCurrentDate();
									Ped_Location_Load = Ped_Location_Load_tmp;
									log.debug("tMap_11 - Outputting the record " + count_Ped_Location_Load_tMap_11
											+ " of the output table 'Ped_Location_Load'.");

// ###############################

								} // end of Var scope

								rejectedInnerJoin_tMap_11 = false;

								tos_count_tMap_11++;

								/**
								 * [tMap_11 main ] stop
								 */

								/**
								 * [tMap_11 process_data_begin ] start
								 */

								currentComponent = "tMap_11";

								/**
								 * [tMap_11 process_data_begin ] stop
								 */
// Start of branch "Ped_Location_Load"
								if (Ped_Location_Load != null) {

									/**
									 * [tDBOutput_8 main ] start
									 */

									currentComponent = "tDBOutput_8";

									if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

											, "Ped_Location_Load", "tMap_11", "tMap_11", "tMap", "tDBOutput_8",
											"__TABLE__", "tMSSqlOutput"

									)) {
										talendJobLogProcess(globalMap);
									}

									if (log.isTraceEnabled()) {
										log.trace("Ped_Location_Load - "
												+ (Ped_Location_Load == null ? "" : Ped_Location_Load.toLogString()));
									}

									whetherReject_tDBOutput_8 = false;
									if (Ped_Location_Load.PED_LOCATION_SK == null) {
										pstmt_tDBOutput_8.setNull(1, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_8.setString(1, Ped_Location_Load.PED_LOCATION_SK);
									}

									if (Ped_Location_Load.PED_LOCATION == null) {
										pstmt_tDBOutput_8.setNull(2, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_8.setString(2, Ped_Location_Load.PED_LOCATION);
									}

									if (Ped_Location_Load.DI_PID == null) {
										pstmt_tDBOutput_8.setNull(3, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_8.setString(3, Ped_Location_Load.DI_PID);
									}

									if (Ped_Location_Load.DI_Create_Date != null) {
										pstmt_tDBOutput_8.setTimestamp(4,
												new java.sql.Timestamp(Ped_Location_Load.DI_Create_Date.getTime()));
									} else {
										pstmt_tDBOutput_8.setNull(4, java.sql.Types.TIMESTAMP);
									}

									pstmt_tDBOutput_8.addBatch();
									nb_line_tDBOutput_8++;

									if (log.isDebugEnabled())
										log.debug("tDBOutput_8 - " + ("Adding the record ") + (nb_line_tDBOutput_8)
												+ (" to the ") + ("INSERT") + (" batch."));
									batchSizeCounter_tDBOutput_8++;

									////////// batch execute by batch size///////
									class LimitBytesHelper_tDBOutput_8 {
										public int limitBytePart1(int counter,
												java.sql.PreparedStatement pstmt_tDBOutput_8) throws Exception {
											try {

												if (log.isDebugEnabled())
													log.debug("tDBOutput_8 - " + ("Executing the ") + ("INSERT")
															+ (" batch."));
												for (int countEach_tDBOutput_8 : pstmt_tDBOutput_8.executeBatch()) {
													if (countEach_tDBOutput_8 == -2 || countEach_tDBOutput_8 == -3) {
														break;
													}
													counter += countEach_tDBOutput_8;
												}

												if (log.isDebugEnabled())
													log.debug("tDBOutput_8 - " + ("The ") + ("INSERT")
															+ (" batch execution has succeeded."));
											} catch (java.sql.BatchUpdateException e) {
												globalMap.put("tDBOutput_8_ERROR_MESSAGE", e.getMessage());

												int countSum_tDBOutput_8 = 0;
												for (int countEach_tDBOutput_8 : e.getUpdateCounts()) {
													counter += (countEach_tDBOutput_8 < 0 ? 0 : countEach_tDBOutput_8);
												}

												log.error("tDBOutput_8 - " + (e.getMessage()));
												System.err.println(e.getMessage());

											}
											return counter;
										}

										public int limitBytePart2(int counter,
												java.sql.PreparedStatement pstmt_tDBOutput_8) throws Exception {
											try {

												if (log.isDebugEnabled())
													log.debug("tDBOutput_8 - " + ("Executing the ") + ("INSERT")
															+ (" batch."));
												for (int countEach_tDBOutput_8 : pstmt_tDBOutput_8.executeBatch()) {
													if (countEach_tDBOutput_8 == -2 || countEach_tDBOutput_8 == -3) {
														break;
													}
													counter += countEach_tDBOutput_8;
												}

												if (log.isDebugEnabled())
													log.debug("tDBOutput_8 - " + ("The ") + ("INSERT")
															+ (" batch execution has succeeded."));
											} catch (java.sql.BatchUpdateException e) {
												globalMap.put("tDBOutput_8_ERROR_MESSAGE", e.getMessage());

												for (int countEach_tDBOutput_8 : e.getUpdateCounts()) {
													counter += (countEach_tDBOutput_8 < 0 ? 0 : countEach_tDBOutput_8);
												}

												log.error("tDBOutput_8 - " + (e.getMessage()));
												System.err.println(e.getMessage());

											}
											return counter;
										}
									}
									if ((batchSize_tDBOutput_8 > 0)
											&& (batchSize_tDBOutput_8 <= batchSizeCounter_tDBOutput_8)) {

										insertedCount_tDBOutput_8 = new LimitBytesHelper_tDBOutput_8()
												.limitBytePart1(insertedCount_tDBOutput_8, pstmt_tDBOutput_8);
										rowsToCommitCount_tDBOutput_8 = insertedCount_tDBOutput_8;

										batchSizeCounter_tDBOutput_8 = 0;
									}

									//////////// commit every////////////

									commitCounter_tDBOutput_8++;
									if (commitEvery_tDBOutput_8 <= commitCounter_tDBOutput_8) {
										if ((batchSize_tDBOutput_8 > 0) && (batchSizeCounter_tDBOutput_8 > 0)) {

											insertedCount_tDBOutput_8 = new LimitBytesHelper_tDBOutput_8()
													.limitBytePart1(insertedCount_tDBOutput_8, pstmt_tDBOutput_8);

											batchSizeCounter_tDBOutput_8 = 0;
										}
										if (rowsToCommitCount_tDBOutput_8 != 0) {

											if (log.isDebugEnabled())
												log.debug("tDBOutput_8 - " + ("Connection starting to commit ")
														+ (rowsToCommitCount_tDBOutput_8) + (" record(s)."));
										}
										conn_tDBOutput_8.commit();
										if (rowsToCommitCount_tDBOutput_8 != 0) {

											if (log.isDebugEnabled())
												log.debug("tDBOutput_8 - " + ("Connection commit has succeeded."));
											rowsToCommitCount_tDBOutput_8 = 0;
										}
										commitCounter_tDBOutput_8 = 0;
									}

									tos_count_tDBOutput_8++;

									/**
									 * [tDBOutput_8 main ] stop
									 */

									/**
									 * [tDBOutput_8 process_data_begin ] start
									 */

									currentComponent = "tDBOutput_8";

									/**
									 * [tDBOutput_8 process_data_begin ] stop
									 */

									/**
									 * [tDBOutput_8 process_data_end ] start
									 */

									currentComponent = "tDBOutput_8";

									/**
									 * [tDBOutput_8 process_data_end ] stop
									 */

								} // End of branch "Ped_Location_Load"

								/**
								 * [tMap_11 process_data_end ] start
								 */

								currentComponent = "tMap_11";

								/**
								 * [tMap_11 process_data_end ] stop
								 */

							} // End of branch "row9"

							/**
							 * [tUniqRow_9 process_data_end ] start
							 */

							currentComponent = "tUniqRow_9";

							/**
							 * [tUniqRow_9 process_data_end ] stop
							 */

						} // End of branch "Ped_Location"

// Start of branch "Ped_Location1"
						if (Ped_Location1 != null) {

							/**
							 * [tUniqRow_10 main ] start
							 */

							currentComponent = "tUniqRow_10";

							if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

									, "Ped_Location1", "tMap_1", "tMap_1", "tMap", "tUniqRow_10", "tUniqRow_10",
									"tUniqRow"

							)) {
								talendJobLogProcess(globalMap);
							}

							if (log.isTraceEnabled()) {
								log.trace("Ped_Location1 - "
										+ (Ped_Location1 == null ? "" : Ped_Location1.toLogString()));
							}

							row10 = null;
							if (Ped_Location1.PED_ACTION == null) {
								finder_tUniqRow_10.PED_ACTION = null;
							} else {
								finder_tUniqRow_10.PED_ACTION = Ped_Location1.PED_ACTION.toLowerCase();
							}
							finder_tUniqRow_10.hashCodeDirty = true;
							if (!keystUniqRow_10.contains(finder_tUniqRow_10)) {
								KeyStruct_tUniqRow_10 new_tUniqRow_10 = new KeyStruct_tUniqRow_10();

								if (Ped_Location1.PED_ACTION == null) {
									new_tUniqRow_10.PED_ACTION = null;
								} else {
									new_tUniqRow_10.PED_ACTION = Ped_Location1.PED_ACTION.toLowerCase();
								}

								keystUniqRow_10.add(new_tUniqRow_10);
								if (row10 == null) {

									log.trace("tUniqRow_10 - Writing the unique record " + (nb_uniques_tUniqRow_10 + 1)
											+ " into row10.");

									row10 = new row10Struct();
								}
								row10.PED_ACTION = Ped_Location1.PED_ACTION;
								nb_uniques_tUniqRow_10++;
							} else {
								nb_duplicates_tUniqRow_10++;
							}

							tos_count_tUniqRow_10++;

							/**
							 * [tUniqRow_10 main ] stop
							 */

							/**
							 * [tUniqRow_10 process_data_begin ] start
							 */

							currentComponent = "tUniqRow_10";

							/**
							 * [tUniqRow_10 process_data_begin ] stop
							 */
// Start of branch "row10"
							if (row10 != null) {

								/**
								 * [tMap_12 main ] start
								 */

								currentComponent = "tMap_12";

								if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

										, "row10", "tUniqRow_10", "tUniqRow_10", "tUniqRow", "tMap_12", "tMap_12",
										"tMap"

								)) {
									talendJobLogProcess(globalMap);
								}

								if (log.isTraceEnabled()) {
									log.trace("row10 - " + (row10 == null ? "" : row10.toLogString()));
								}

								boolean hasCasePrimitiveKeyWithNull_tMap_12 = false;

								// ###############################
								// # Input tables (lookups)
								boolean rejectedInnerJoin_tMap_12 = false;
								boolean mainRowRejected_tMap_12 = false;

								// ###############################
								{ // start of Var scope

									// ###############################
									// # Vars tables

									Var__tMap_12__Struct Var = Var__tMap_12;// ###############################
									// ###############################
									// # Output tables

									Ped_Action = null;

// # Output table : 'Ped_Action'
									count_Ped_Action_tMap_12++;

									Ped_Action_tmp.PED_ACTION = row10.PED_ACTION;
									Ped_Action_tmp.PED_ACTION_SK = null;
									Ped_Action_tmp.DI_PID = "MVC_LOAD";
									Ped_Action_tmp.DI_Create_Date = TalendDate.getCurrentDate();
									Ped_Action = Ped_Action_tmp;
									log.debug("tMap_12 - Outputting the record " + count_Ped_Action_tMap_12
											+ " of the output table 'Ped_Action'.");

// ###############################

								} // end of Var scope

								rejectedInnerJoin_tMap_12 = false;

								tos_count_tMap_12++;

								/**
								 * [tMap_12 main ] stop
								 */

								/**
								 * [tMap_12 process_data_begin ] start
								 */

								currentComponent = "tMap_12";

								/**
								 * [tMap_12 process_data_begin ] stop
								 */
// Start of branch "Ped_Action"
								if (Ped_Action != null) {

									/**
									 * [tDBOutput_9 main ] start
									 */

									currentComponent = "tDBOutput_9";

									if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

											, "Ped_Action", "tMap_12", "tMap_12", "tMap", "tDBOutput_9", "__TABLE__",
											"tMSSqlOutput"

									)) {
										talendJobLogProcess(globalMap);
									}

									if (log.isTraceEnabled()) {
										log.trace(
												"Ped_Action - " + (Ped_Action == null ? "" : Ped_Action.toLogString()));
									}

									whetherReject_tDBOutput_9 = false;
									if (Ped_Action.PED_ACTION == null) {
										pstmt_tDBOutput_9.setNull(1, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_9.setString(1, Ped_Action.PED_ACTION);
									}

									if (Ped_Action.PED_ACTION_SK == null) {
										pstmt_tDBOutput_9.setNull(2, java.sql.Types.INTEGER);
									} else {
										pstmt_tDBOutput_9.setInt(2, Ped_Action.PED_ACTION_SK);
									}

									if (Ped_Action.DI_PID == null) {
										pstmt_tDBOutput_9.setNull(3, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_9.setString(3, Ped_Action.DI_PID);
									}

									if (Ped_Action.DI_Create_Date != null) {
										pstmt_tDBOutput_9.setTimestamp(4,
												new java.sql.Timestamp(Ped_Action.DI_Create_Date.getTime()));
									} else {
										pstmt_tDBOutput_9.setNull(4, java.sql.Types.TIMESTAMP);
									}

									pstmt_tDBOutput_9.addBatch();
									nb_line_tDBOutput_9++;

									if (log.isDebugEnabled())
										log.debug("tDBOutput_9 - " + ("Adding the record ") + (nb_line_tDBOutput_9)
												+ (" to the ") + ("INSERT") + (" batch."));
									batchSizeCounter_tDBOutput_9++;

									////////// batch execute by batch size///////
									class LimitBytesHelper_tDBOutput_9 {
										public int limitBytePart1(int counter,
												java.sql.PreparedStatement pstmt_tDBOutput_9) throws Exception {
											try {

												if (log.isDebugEnabled())
													log.debug("tDBOutput_9 - " + ("Executing the ") + ("INSERT")
															+ (" batch."));
												for (int countEach_tDBOutput_9 : pstmt_tDBOutput_9.executeBatch()) {
													if (countEach_tDBOutput_9 == -2 || countEach_tDBOutput_9 == -3) {
														break;
													}
													counter += countEach_tDBOutput_9;
												}

												if (log.isDebugEnabled())
													log.debug("tDBOutput_9 - " + ("The ") + ("INSERT")
															+ (" batch execution has succeeded."));
											} catch (java.sql.BatchUpdateException e) {
												globalMap.put("tDBOutput_9_ERROR_MESSAGE", e.getMessage());

												int countSum_tDBOutput_9 = 0;
												for (int countEach_tDBOutput_9 : e.getUpdateCounts()) {
													counter += (countEach_tDBOutput_9 < 0 ? 0 : countEach_tDBOutput_9);
												}

												log.error("tDBOutput_9 - " + (e.getMessage()));
												System.err.println(e.getMessage());

											}
											return counter;
										}

										public int limitBytePart2(int counter,
												java.sql.PreparedStatement pstmt_tDBOutput_9) throws Exception {
											try {

												if (log.isDebugEnabled())
													log.debug("tDBOutput_9 - " + ("Executing the ") + ("INSERT")
															+ (" batch."));
												for (int countEach_tDBOutput_9 : pstmt_tDBOutput_9.executeBatch()) {
													if (countEach_tDBOutput_9 == -2 || countEach_tDBOutput_9 == -3) {
														break;
													}
													counter += countEach_tDBOutput_9;
												}

												if (log.isDebugEnabled())
													log.debug("tDBOutput_9 - " + ("The ") + ("INSERT")
															+ (" batch execution has succeeded."));
											} catch (java.sql.BatchUpdateException e) {
												globalMap.put("tDBOutput_9_ERROR_MESSAGE", e.getMessage());

												for (int countEach_tDBOutput_9 : e.getUpdateCounts()) {
													counter += (countEach_tDBOutput_9 < 0 ? 0 : countEach_tDBOutput_9);
												}

												log.error("tDBOutput_9 - " + (e.getMessage()));
												System.err.println(e.getMessage());

											}
											return counter;
										}
									}
									if ((batchSize_tDBOutput_9 > 0)
											&& (batchSize_tDBOutput_9 <= batchSizeCounter_tDBOutput_9)) {

										insertedCount_tDBOutput_9 = new LimitBytesHelper_tDBOutput_9()
												.limitBytePart1(insertedCount_tDBOutput_9, pstmt_tDBOutput_9);
										rowsToCommitCount_tDBOutput_9 = insertedCount_tDBOutput_9;

										batchSizeCounter_tDBOutput_9 = 0;
									}

									//////////// commit every////////////

									commitCounter_tDBOutput_9++;
									if (commitEvery_tDBOutput_9 <= commitCounter_tDBOutput_9) {
										if ((batchSize_tDBOutput_9 > 0) && (batchSizeCounter_tDBOutput_9 > 0)) {

											insertedCount_tDBOutput_9 = new LimitBytesHelper_tDBOutput_9()
													.limitBytePart1(insertedCount_tDBOutput_9, pstmt_tDBOutput_9);

											batchSizeCounter_tDBOutput_9 = 0;
										}
										if (rowsToCommitCount_tDBOutput_9 != 0) {

											if (log.isDebugEnabled())
												log.debug("tDBOutput_9 - " + ("Connection starting to commit ")
														+ (rowsToCommitCount_tDBOutput_9) + (" record(s)."));
										}
										conn_tDBOutput_9.commit();
										if (rowsToCommitCount_tDBOutput_9 != 0) {

											if (log.isDebugEnabled())
												log.debug("tDBOutput_9 - " + ("Connection commit has succeeded."));
											rowsToCommitCount_tDBOutput_9 = 0;
										}
										commitCounter_tDBOutput_9 = 0;
									}

									tos_count_tDBOutput_9++;

									/**
									 * [tDBOutput_9 main ] stop
									 */

									/**
									 * [tDBOutput_9 process_data_begin ] start
									 */

									currentComponent = "tDBOutput_9";

									/**
									 * [tDBOutput_9 process_data_begin ] stop
									 */

									/**
									 * [tDBOutput_9 process_data_end ] start
									 */

									currentComponent = "tDBOutput_9";

									/**
									 * [tDBOutput_9 process_data_end ] stop
									 */

								} // End of branch "Ped_Action"

								/**
								 * [tMap_12 process_data_end ] start
								 */

								currentComponent = "tMap_12";

								/**
								 * [tMap_12 process_data_end ] stop
								 */

							} // End of branch "row10"

							/**
							 * [tUniqRow_10 process_data_end ] start
							 */

							currentComponent = "tUniqRow_10";

							/**
							 * [tUniqRow_10 process_data_end ] stop
							 */

						} // End of branch "Ped_Location1"

// Start of branch "Complaint"
						if (Complaint != null) {

							/**
							 * [tUniqRow_11 main ] start
							 */

							currentComponent = "tUniqRow_11";

							if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

									, "Complaint", "tMap_1", "tMap_1", "tMap", "tUniqRow_11", "tUniqRow_11", "tUniqRow"

							)) {
								talendJobLogProcess(globalMap);
							}

							if (log.isTraceEnabled()) {
								log.trace("Complaint - " + (Complaint == null ? "" : Complaint.toLogString()));
							}

							row11 = null;
							if (Complaint.COMPLAINT == null) {
								finder_tUniqRow_11.COMPLAINT = null;
							} else {
								finder_tUniqRow_11.COMPLAINT = Complaint.COMPLAINT.toLowerCase();
							}
							finder_tUniqRow_11.hashCodeDirty = true;
							if (!keystUniqRow_11.contains(finder_tUniqRow_11)) {
								KeyStruct_tUniqRow_11 new_tUniqRow_11 = new KeyStruct_tUniqRow_11();

								if (Complaint.COMPLAINT == null) {
									new_tUniqRow_11.COMPLAINT = null;
								} else {
									new_tUniqRow_11.COMPLAINT = Complaint.COMPLAINT.toLowerCase();
								}

								keystUniqRow_11.add(new_tUniqRow_11);
								if (row11 == null) {

									log.trace("tUniqRow_11 - Writing the unique record " + (nb_uniques_tUniqRow_11 + 1)
											+ " into row11.");

									row11 = new row11Struct();
								}
								row11.COMPLAINT = Complaint.COMPLAINT;
								nb_uniques_tUniqRow_11++;
							} else {
								nb_duplicates_tUniqRow_11++;
							}

							tos_count_tUniqRow_11++;

							/**
							 * [tUniqRow_11 main ] stop
							 */

							/**
							 * [tUniqRow_11 process_data_begin ] start
							 */

							currentComponent = "tUniqRow_11";

							/**
							 * [tUniqRow_11 process_data_begin ] stop
							 */
// Start of branch "row11"
							if (row11 != null) {

								/**
								 * [tMap_13 main ] start
								 */

								currentComponent = "tMap_13";

								if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

										, "row11", "tUniqRow_11", "tUniqRow_11", "tUniqRow", "tMap_13", "tMap_13",
										"tMap"

								)) {
									talendJobLogProcess(globalMap);
								}

								if (log.isTraceEnabled()) {
									log.trace("row11 - " + (row11 == null ? "" : row11.toLogString()));
								}

								boolean hasCasePrimitiveKeyWithNull_tMap_13 = false;

								// ###############################
								// # Input tables (lookups)
								boolean rejectedInnerJoin_tMap_13 = false;
								boolean mainRowRejected_tMap_13 = false;

								// ###############################
								{ // start of Var scope

									// ###############################
									// # Vars tables

									Var__tMap_13__Struct Var = Var__tMap_13;// ###############################
									// ###############################
									// # Output tables

									Complain_Load = null;

// # Output table : 'Complain_Load'
									count_Complain_Load_tMap_13++;

									Complain_Load_tmp.COMPLAINT = row11.COMPLAINT;
									Complain_Load_tmp.COMPLAINT_SK = null;
									Complain_Load_tmp.DI_PID = "MVC_LOAD";
									Complain_Load_tmp.DI_Create_Date = TalendDate.getCurrentDate();
									Complain_Load = Complain_Load_tmp;
									log.debug("tMap_13 - Outputting the record " + count_Complain_Load_tMap_13
											+ " of the output table 'Complain_Load'.");

// ###############################

								} // end of Var scope

								rejectedInnerJoin_tMap_13 = false;

								tos_count_tMap_13++;

								/**
								 * [tMap_13 main ] stop
								 */

								/**
								 * [tMap_13 process_data_begin ] start
								 */

								currentComponent = "tMap_13";

								/**
								 * [tMap_13 process_data_begin ] stop
								 */
// Start of branch "Complain_Load"
								if (Complain_Load != null) {

									/**
									 * [tDBOutput_10 main ] start
									 */

									currentComponent = "tDBOutput_10";

									if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

											, "Complain_Load", "tMap_13", "tMap_13", "tMap", "tDBOutput_10",
											"__TABLE__", "tMSSqlOutput"

									)) {
										talendJobLogProcess(globalMap);
									}

									if (log.isTraceEnabled()) {
										log.trace("Complain_Load - "
												+ (Complain_Load == null ? "" : Complain_Load.toLogString()));
									}

									whetherReject_tDBOutput_10 = false;
									if (Complain_Load.COMPLAINT == null) {
										pstmt_tDBOutput_10.setNull(1, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_10.setString(1, Complain_Load.COMPLAINT);
									}

									if (Complain_Load.COMPLAINT_SK == null) {
										pstmt_tDBOutput_10.setNull(2, java.sql.Types.INTEGER);
									} else {
										pstmt_tDBOutput_10.setInt(2, Complain_Load.COMPLAINT_SK);
									}

									if (Complain_Load.DI_PID == null) {
										pstmt_tDBOutput_10.setNull(3, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_10.setString(3, Complain_Load.DI_PID);
									}

									if (Complain_Load.DI_Create_Date != null) {
										pstmt_tDBOutput_10.setTimestamp(4,
												new java.sql.Timestamp(Complain_Load.DI_Create_Date.getTime()));
									} else {
										pstmt_tDBOutput_10.setNull(4, java.sql.Types.TIMESTAMP);
									}

									pstmt_tDBOutput_10.addBatch();
									nb_line_tDBOutput_10++;

									if (log.isDebugEnabled())
										log.debug("tDBOutput_10 - " + ("Adding the record ") + (nb_line_tDBOutput_10)
												+ (" to the ") + ("INSERT") + (" batch."));
									batchSizeCounter_tDBOutput_10++;

									////////// batch execute by batch size///////
									class LimitBytesHelper_tDBOutput_10 {
										public int limitBytePart1(int counter,
												java.sql.PreparedStatement pstmt_tDBOutput_10) throws Exception {
											try {

												if (log.isDebugEnabled())
													log.debug("tDBOutput_10 - " + ("Executing the ") + ("INSERT")
															+ (" batch."));
												for (int countEach_tDBOutput_10 : pstmt_tDBOutput_10.executeBatch()) {
													if (countEach_tDBOutput_10 == -2 || countEach_tDBOutput_10 == -3) {
														break;
													}
													counter += countEach_tDBOutput_10;
												}

												if (log.isDebugEnabled())
													log.debug("tDBOutput_10 - " + ("The ") + ("INSERT")
															+ (" batch execution has succeeded."));
											} catch (java.sql.BatchUpdateException e) {
												globalMap.put("tDBOutput_10_ERROR_MESSAGE", e.getMessage());

												int countSum_tDBOutput_10 = 0;
												for (int countEach_tDBOutput_10 : e.getUpdateCounts()) {
													counter += (countEach_tDBOutput_10 < 0 ? 0
															: countEach_tDBOutput_10);
												}

												log.error("tDBOutput_10 - " + (e.getMessage()));
												System.err.println(e.getMessage());

											}
											return counter;
										}

										public int limitBytePart2(int counter,
												java.sql.PreparedStatement pstmt_tDBOutput_10) throws Exception {
											try {

												if (log.isDebugEnabled())
													log.debug("tDBOutput_10 - " + ("Executing the ") + ("INSERT")
															+ (" batch."));
												for (int countEach_tDBOutput_10 : pstmt_tDBOutput_10.executeBatch()) {
													if (countEach_tDBOutput_10 == -2 || countEach_tDBOutput_10 == -3) {
														break;
													}
													counter += countEach_tDBOutput_10;
												}

												if (log.isDebugEnabled())
													log.debug("tDBOutput_10 - " + ("The ") + ("INSERT")
															+ (" batch execution has succeeded."));
											} catch (java.sql.BatchUpdateException e) {
												globalMap.put("tDBOutput_10_ERROR_MESSAGE", e.getMessage());

												for (int countEach_tDBOutput_10 : e.getUpdateCounts()) {
													counter += (countEach_tDBOutput_10 < 0 ? 0
															: countEach_tDBOutput_10);
												}

												log.error("tDBOutput_10 - " + (e.getMessage()));
												System.err.println(e.getMessage());

											}
											return counter;
										}
									}
									if ((batchSize_tDBOutput_10 > 0)
											&& (batchSize_tDBOutput_10 <= batchSizeCounter_tDBOutput_10)) {

										insertedCount_tDBOutput_10 = new LimitBytesHelper_tDBOutput_10()
												.limitBytePart1(insertedCount_tDBOutput_10, pstmt_tDBOutput_10);
										rowsToCommitCount_tDBOutput_10 = insertedCount_tDBOutput_10;

										batchSizeCounter_tDBOutput_10 = 0;
									}

									//////////// commit every////////////

									commitCounter_tDBOutput_10++;
									if (commitEvery_tDBOutput_10 <= commitCounter_tDBOutput_10) {
										if ((batchSize_tDBOutput_10 > 0) && (batchSizeCounter_tDBOutput_10 > 0)) {

											insertedCount_tDBOutput_10 = new LimitBytesHelper_tDBOutput_10()
													.limitBytePart1(insertedCount_tDBOutput_10, pstmt_tDBOutput_10);

											batchSizeCounter_tDBOutput_10 = 0;
										}
										if (rowsToCommitCount_tDBOutput_10 != 0) {

											if (log.isDebugEnabled())
												log.debug("tDBOutput_10 - " + ("Connection starting to commit ")
														+ (rowsToCommitCount_tDBOutput_10) + (" record(s)."));
										}
										conn_tDBOutput_10.commit();
										if (rowsToCommitCount_tDBOutput_10 != 0) {

											if (log.isDebugEnabled())
												log.debug("tDBOutput_10 - " + ("Connection commit has succeeded."));
											rowsToCommitCount_tDBOutput_10 = 0;
										}
										commitCounter_tDBOutput_10 = 0;
									}

									tos_count_tDBOutput_10++;

									/**
									 * [tDBOutput_10 main ] stop
									 */

									/**
									 * [tDBOutput_10 process_data_begin ] start
									 */

									currentComponent = "tDBOutput_10";

									/**
									 * [tDBOutput_10 process_data_begin ] stop
									 */

									/**
									 * [tDBOutput_10 process_data_end ] start
									 */

									currentComponent = "tDBOutput_10";

									/**
									 * [tDBOutput_10 process_data_end ] stop
									 */

								} // End of branch "Complain_Load"

								/**
								 * [tMap_13 process_data_end ] start
								 */

								currentComponent = "tMap_13";

								/**
								 * [tMap_13 process_data_end ] stop
								 */

							} // End of branch "row11"

							/**
							 * [tUniqRow_11 process_data_end ] start
							 */

							currentComponent = "tUniqRow_11";

							/**
							 * [tUniqRow_11 process_data_end ] stop
							 */

						} // End of branch "Complaint"

// Start of branch "Ped_Role"
						if (Ped_Role != null) {

							/**
							 * [tUniqRow_12 main ] start
							 */

							currentComponent = "tUniqRow_12";

							if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

									, "Ped_Role", "tMap_1", "tMap_1", "tMap", "tUniqRow_12", "tUniqRow_12", "tUniqRow"

							)) {
								talendJobLogProcess(globalMap);
							}

							if (log.isTraceEnabled()) {
								log.trace("Ped_Role - " + (Ped_Role == null ? "" : Ped_Role.toLogString()));
							}

							row12 = null;
							if (Ped_Role.PED_ROLE == null) {
								finder_tUniqRow_12.PED_ROLE = null;
							} else {
								finder_tUniqRow_12.PED_ROLE = Ped_Role.PED_ROLE.toLowerCase();
							}
							finder_tUniqRow_12.hashCodeDirty = true;
							if (!keystUniqRow_12.contains(finder_tUniqRow_12)) {
								KeyStruct_tUniqRow_12 new_tUniqRow_12 = new KeyStruct_tUniqRow_12();

								if (Ped_Role.PED_ROLE == null) {
									new_tUniqRow_12.PED_ROLE = null;
								} else {
									new_tUniqRow_12.PED_ROLE = Ped_Role.PED_ROLE.toLowerCase();
								}

								keystUniqRow_12.add(new_tUniqRow_12);
								if (row12 == null) {

									log.trace("tUniqRow_12 - Writing the unique record " + (nb_uniques_tUniqRow_12 + 1)
											+ " into row12.");

									row12 = new row12Struct();
								}
								row12.PED_ROLE = Ped_Role.PED_ROLE;
								nb_uniques_tUniqRow_12++;
							} else {
								nb_duplicates_tUniqRow_12++;
							}

							tos_count_tUniqRow_12++;

							/**
							 * [tUniqRow_12 main ] stop
							 */

							/**
							 * [tUniqRow_12 process_data_begin ] start
							 */

							currentComponent = "tUniqRow_12";

							/**
							 * [tUniqRow_12 process_data_begin ] stop
							 */
// Start of branch "row12"
							if (row12 != null) {

								/**
								 * [tMap_14 main ] start
								 */

								currentComponent = "tMap_14";

								if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

										, "row12", "tUniqRow_12", "tUniqRow_12", "tUniqRow", "tMap_14", "tMap_14",
										"tMap"

								)) {
									talendJobLogProcess(globalMap);
								}

								if (log.isTraceEnabled()) {
									log.trace("row12 - " + (row12 == null ? "" : row12.toLogString()));
								}

								boolean hasCasePrimitiveKeyWithNull_tMap_14 = false;

								// ###############################
								// # Input tables (lookups)
								boolean rejectedInnerJoin_tMap_14 = false;
								boolean mainRowRejected_tMap_14 = false;

								// ###############################
								{ // start of Var scope

									// ###############################
									// # Vars tables

									Var__tMap_14__Struct Var = Var__tMap_14;// ###############################
									// ###############################
									// # Output tables

									Ped_Role_Load = null;

// # Output table : 'Ped_Role_Load'
									count_Ped_Role_Load_tMap_14++;

									Ped_Role_Load_tmp.PED_ROLE_SK = null;
									Ped_Role_Load_tmp.PED_ROLE = row12.PED_ROLE;
									Ped_Role_Load_tmp.DI_PID = "MVC_LOAD";
									Ped_Role_Load_tmp.DI_Create_Date = TalendDate.getCurrentDate();
									Ped_Role_Load = Ped_Role_Load_tmp;
									log.debug("tMap_14 - Outputting the record " + count_Ped_Role_Load_tMap_14
											+ " of the output table 'Ped_Role_Load'.");

// ###############################

								} // end of Var scope

								rejectedInnerJoin_tMap_14 = false;

								tos_count_tMap_14++;

								/**
								 * [tMap_14 main ] stop
								 */

								/**
								 * [tMap_14 process_data_begin ] start
								 */

								currentComponent = "tMap_14";

								/**
								 * [tMap_14 process_data_begin ] stop
								 */
// Start of branch "Ped_Role_Load"
								if (Ped_Role_Load != null) {

									/**
									 * [tDBOutput_11 main ] start
									 */

									currentComponent = "tDBOutput_11";

									if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

											, "Ped_Role_Load", "tMap_14", "tMap_14", "tMap", "tDBOutput_11",
											"__TABLE__", "tMSSqlOutput"

									)) {
										talendJobLogProcess(globalMap);
									}

									if (log.isTraceEnabled()) {
										log.trace("Ped_Role_Load - "
												+ (Ped_Role_Load == null ? "" : Ped_Role_Load.toLogString()));
									}

									whetherReject_tDBOutput_11 = false;
									if (Ped_Role_Load.PED_ROLE_SK == null) {
										pstmt_tDBOutput_11.setNull(1, java.sql.Types.INTEGER);
									} else {
										pstmt_tDBOutput_11.setInt(1, Ped_Role_Load.PED_ROLE_SK);
									}

									if (Ped_Role_Load.PED_ROLE == null) {
										pstmt_tDBOutput_11.setNull(2, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_11.setString(2, Ped_Role_Load.PED_ROLE);
									}

									if (Ped_Role_Load.DI_PID == null) {
										pstmt_tDBOutput_11.setNull(3, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_11.setString(3, Ped_Role_Load.DI_PID);
									}

									if (Ped_Role_Load.DI_Create_Date != null) {
										pstmt_tDBOutput_11.setTimestamp(4,
												new java.sql.Timestamp(Ped_Role_Load.DI_Create_Date.getTime()));
									} else {
										pstmt_tDBOutput_11.setNull(4, java.sql.Types.TIMESTAMP);
									}

									pstmt_tDBOutput_11.addBatch();
									nb_line_tDBOutput_11++;

									if (log.isDebugEnabled())
										log.debug("tDBOutput_11 - " + ("Adding the record ") + (nb_line_tDBOutput_11)
												+ (" to the ") + ("INSERT") + (" batch."));
									batchSizeCounter_tDBOutput_11++;

									////////// batch execute by batch size///////
									class LimitBytesHelper_tDBOutput_11 {
										public int limitBytePart1(int counter,
												java.sql.PreparedStatement pstmt_tDBOutput_11) throws Exception {
											try {

												if (log.isDebugEnabled())
													log.debug("tDBOutput_11 - " + ("Executing the ") + ("INSERT")
															+ (" batch."));
												for (int countEach_tDBOutput_11 : pstmt_tDBOutput_11.executeBatch()) {
													if (countEach_tDBOutput_11 == -2 || countEach_tDBOutput_11 == -3) {
														break;
													}
													counter += countEach_tDBOutput_11;
												}

												if (log.isDebugEnabled())
													log.debug("tDBOutput_11 - " + ("The ") + ("INSERT")
															+ (" batch execution has succeeded."));
											} catch (java.sql.BatchUpdateException e) {
												globalMap.put("tDBOutput_11_ERROR_MESSAGE", e.getMessage());

												int countSum_tDBOutput_11 = 0;
												for (int countEach_tDBOutput_11 : e.getUpdateCounts()) {
													counter += (countEach_tDBOutput_11 < 0 ? 0
															: countEach_tDBOutput_11);
												}

												log.error("tDBOutput_11 - " + (e.getMessage()));
												System.err.println(e.getMessage());

											}
											return counter;
										}

										public int limitBytePart2(int counter,
												java.sql.PreparedStatement pstmt_tDBOutput_11) throws Exception {
											try {

												if (log.isDebugEnabled())
													log.debug("tDBOutput_11 - " + ("Executing the ") + ("INSERT")
															+ (" batch."));
												for (int countEach_tDBOutput_11 : pstmt_tDBOutput_11.executeBatch()) {
													if (countEach_tDBOutput_11 == -2 || countEach_tDBOutput_11 == -3) {
														break;
													}
													counter += countEach_tDBOutput_11;
												}

												if (log.isDebugEnabled())
													log.debug("tDBOutput_11 - " + ("The ") + ("INSERT")
															+ (" batch execution has succeeded."));
											} catch (java.sql.BatchUpdateException e) {
												globalMap.put("tDBOutput_11_ERROR_MESSAGE", e.getMessage());

												for (int countEach_tDBOutput_11 : e.getUpdateCounts()) {
													counter += (countEach_tDBOutput_11 < 0 ? 0
															: countEach_tDBOutput_11);
												}

												log.error("tDBOutput_11 - " + (e.getMessage()));
												System.err.println(e.getMessage());

											}
											return counter;
										}
									}
									if ((batchSize_tDBOutput_11 > 0)
											&& (batchSize_tDBOutput_11 <= batchSizeCounter_tDBOutput_11)) {

										insertedCount_tDBOutput_11 = new LimitBytesHelper_tDBOutput_11()
												.limitBytePart1(insertedCount_tDBOutput_11, pstmt_tDBOutput_11);
										rowsToCommitCount_tDBOutput_11 = insertedCount_tDBOutput_11;

										batchSizeCounter_tDBOutput_11 = 0;
									}

									//////////// commit every////////////

									commitCounter_tDBOutput_11++;
									if (commitEvery_tDBOutput_11 <= commitCounter_tDBOutput_11) {
										if ((batchSize_tDBOutput_11 > 0) && (batchSizeCounter_tDBOutput_11 > 0)) {

											insertedCount_tDBOutput_11 = new LimitBytesHelper_tDBOutput_11()
													.limitBytePart1(insertedCount_tDBOutput_11, pstmt_tDBOutput_11);

											batchSizeCounter_tDBOutput_11 = 0;
										}
										if (rowsToCommitCount_tDBOutput_11 != 0) {

											if (log.isDebugEnabled())
												log.debug("tDBOutput_11 - " + ("Connection starting to commit ")
														+ (rowsToCommitCount_tDBOutput_11) + (" record(s)."));
										}
										conn_tDBOutput_11.commit();
										if (rowsToCommitCount_tDBOutput_11 != 0) {

											if (log.isDebugEnabled())
												log.debug("tDBOutput_11 - " + ("Connection commit has succeeded."));
											rowsToCommitCount_tDBOutput_11 = 0;
										}
										commitCounter_tDBOutput_11 = 0;
									}

									tos_count_tDBOutput_11++;

									/**
									 * [tDBOutput_11 main ] stop
									 */

									/**
									 * [tDBOutput_11 process_data_begin ] start
									 */

									currentComponent = "tDBOutput_11";

									/**
									 * [tDBOutput_11 process_data_begin ] stop
									 */

									/**
									 * [tDBOutput_11 process_data_end ] start
									 */

									currentComponent = "tDBOutput_11";

									/**
									 * [tDBOutput_11 process_data_end ] stop
									 */

								} // End of branch "Ped_Role_Load"

								/**
								 * [tMap_14 process_data_end ] start
								 */

								currentComponent = "tMap_14";

								/**
								 * [tMap_14 process_data_end ] stop
								 */

							} // End of branch "row12"

							/**
							 * [tUniqRow_12 process_data_end ] start
							 */

							currentComponent = "tUniqRow_12";

							/**
							 * [tUniqRow_12 process_data_end ] stop
							 */

						} // End of branch "Ped_Role"

// Start of branch "Person_Sex"
						if (Person_Sex != null) {

							/**
							 * [tUniqRow_13 main ] start
							 */

							currentComponent = "tUniqRow_13";

							if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

									, "Person_Sex", "tMap_1", "tMap_1", "tMap", "tUniqRow_13", "tUniqRow_13", "tUniqRow"

							)) {
								talendJobLogProcess(globalMap);
							}

							if (log.isTraceEnabled()) {
								log.trace("Person_Sex - " + (Person_Sex == null ? "" : Person_Sex.toLogString()));
							}

							row13 = null;
							if (Person_Sex.PERSON_SEX == null) {
								finder_tUniqRow_13.PERSON_SEX = null;
							} else {
								finder_tUniqRow_13.PERSON_SEX = Person_Sex.PERSON_SEX.toLowerCase();
							}
							finder_tUniqRow_13.hashCodeDirty = true;
							if (!keystUniqRow_13.contains(finder_tUniqRow_13)) {
								KeyStruct_tUniqRow_13 new_tUniqRow_13 = new KeyStruct_tUniqRow_13();

								if (Person_Sex.PERSON_SEX == null) {
									new_tUniqRow_13.PERSON_SEX = null;
								} else {
									new_tUniqRow_13.PERSON_SEX = Person_Sex.PERSON_SEX.toLowerCase();
								}

								keystUniqRow_13.add(new_tUniqRow_13);
								if (row13 == null) {

									log.trace("tUniqRow_13 - Writing the unique record " + (nb_uniques_tUniqRow_13 + 1)
											+ " into row13.");

									row13 = new row13Struct();
								}
								row13.PERSON_SEX = Person_Sex.PERSON_SEX;
								nb_uniques_tUniqRow_13++;
							} else {
								nb_duplicates_tUniqRow_13++;
							}

							tos_count_tUniqRow_13++;

							/**
							 * [tUniqRow_13 main ] stop
							 */

							/**
							 * [tUniqRow_13 process_data_begin ] start
							 */

							currentComponent = "tUniqRow_13";

							/**
							 * [tUniqRow_13 process_data_begin ] stop
							 */
// Start of branch "row13"
							if (row13 != null) {

								/**
								 * [tMap_15 main ] start
								 */

								currentComponent = "tMap_15";

								if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

										, "row13", "tUniqRow_13", "tUniqRow_13", "tUniqRow", "tMap_15", "tMap_15",
										"tMap"

								)) {
									talendJobLogProcess(globalMap);
								}

								if (log.isTraceEnabled()) {
									log.trace("row13 - " + (row13 == null ? "" : row13.toLogString()));
								}

								boolean hasCasePrimitiveKeyWithNull_tMap_15 = false;

								// ###############################
								// # Input tables (lookups)
								boolean rejectedInnerJoin_tMap_15 = false;
								boolean mainRowRejected_tMap_15 = false;

								// ###############################
								{ // start of Var scope

									// ###############################
									// # Vars tables

									Var__tMap_15__Struct Var = Var__tMap_15;// ###############################
									// ###############################
									// # Output tables

									Person_Sex1 = null;

// # Output table : 'Person_Sex1'
									count_Person_Sex1_tMap_15++;

									Person_Sex1_tmp.PERSON_SEX_SK = row13.PERSON_SEX.equals("NoValueProvided")
											? new Integer("-99")
											: Numeric.sequence("s1", 1, 1);
									Person_Sex1_tmp.PERSON_SEX = row13.PERSON_SEX;
									Person_Sex1_tmp.DI_PID = "MVC_LOAD";
									Person_Sex1_tmp.DI_Create_Date = TalendDate.getCurrentDate();
									Person_Sex1 = Person_Sex1_tmp;
									log.debug("tMap_15 - Outputting the record " + count_Person_Sex1_tMap_15
											+ " of the output table 'Person_Sex1'.");

// ###############################

								} // end of Var scope

								rejectedInnerJoin_tMap_15 = false;

								tos_count_tMap_15++;

								/**
								 * [tMap_15 main ] stop
								 */

								/**
								 * [tMap_15 process_data_begin ] start
								 */

								currentComponent = "tMap_15";

								/**
								 * [tMap_15 process_data_begin ] stop
								 */
// Start of branch "Person_Sex1"
								if (Person_Sex1 != null) {

									/**
									 * [tDBOutput_12 main ] start
									 */

									currentComponent = "tDBOutput_12";

									if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

											, "Person_Sex1", "tMap_15", "tMap_15", "tMap", "tDBOutput_12", "__TABLE__",
											"tMSSqlOutput"

									)) {
										talendJobLogProcess(globalMap);
									}

									if (log.isTraceEnabled()) {
										log.trace("Person_Sex1 - "
												+ (Person_Sex1 == null ? "" : Person_Sex1.toLogString()));
									}

									whetherReject_tDBOutput_12 = false;
									if (Person_Sex1.PERSON_SEX_SK == null) {
										pstmt_tDBOutput_12.setNull(1, java.sql.Types.INTEGER);
									} else {
										pstmt_tDBOutput_12.setInt(1, Person_Sex1.PERSON_SEX_SK);
									}

									if (Person_Sex1.PERSON_SEX == null) {
										pstmt_tDBOutput_12.setNull(2, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_12.setString(2, Person_Sex1.PERSON_SEX);
									}

									if (Person_Sex1.DI_PID == null) {
										pstmt_tDBOutput_12.setNull(3, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_12.setString(3, Person_Sex1.DI_PID);
									}

									if (Person_Sex1.DI_Create_Date != null) {
										pstmt_tDBOutput_12.setTimestamp(4,
												new java.sql.Timestamp(Person_Sex1.DI_Create_Date.getTime()));
									} else {
										pstmt_tDBOutput_12.setNull(4, java.sql.Types.TIMESTAMP);
									}

									pstmt_tDBOutput_12.addBatch();
									nb_line_tDBOutput_12++;

									if (log.isDebugEnabled())
										log.debug("tDBOutput_12 - " + ("Adding the record ") + (nb_line_tDBOutput_12)
												+ (" to the ") + ("INSERT") + (" batch."));
									batchSizeCounter_tDBOutput_12++;

									////////// batch execute by batch size///////
									class LimitBytesHelper_tDBOutput_12 {
										public int limitBytePart1(int counter,
												java.sql.PreparedStatement pstmt_tDBOutput_12) throws Exception {
											try {

												if (log.isDebugEnabled())
													log.debug("tDBOutput_12 - " + ("Executing the ") + ("INSERT")
															+ (" batch."));
												for (int countEach_tDBOutput_12 : pstmt_tDBOutput_12.executeBatch()) {
													if (countEach_tDBOutput_12 == -2 || countEach_tDBOutput_12 == -3) {
														break;
													}
													counter += countEach_tDBOutput_12;
												}

												if (log.isDebugEnabled())
													log.debug("tDBOutput_12 - " + ("The ") + ("INSERT")
															+ (" batch execution has succeeded."));
											} catch (java.sql.BatchUpdateException e) {
												globalMap.put("tDBOutput_12_ERROR_MESSAGE", e.getMessage());

												int countSum_tDBOutput_12 = 0;
												for (int countEach_tDBOutput_12 : e.getUpdateCounts()) {
													counter += (countEach_tDBOutput_12 < 0 ? 0
															: countEach_tDBOutput_12);
												}

												log.error("tDBOutput_12 - " + (e.getMessage()));
												System.err.println(e.getMessage());

											}
											return counter;
										}

										public int limitBytePart2(int counter,
												java.sql.PreparedStatement pstmt_tDBOutput_12) throws Exception {
											try {

												if (log.isDebugEnabled())
													log.debug("tDBOutput_12 - " + ("Executing the ") + ("INSERT")
															+ (" batch."));
												for (int countEach_tDBOutput_12 : pstmt_tDBOutput_12.executeBatch()) {
													if (countEach_tDBOutput_12 == -2 || countEach_tDBOutput_12 == -3) {
														break;
													}
													counter += countEach_tDBOutput_12;
												}

												if (log.isDebugEnabled())
													log.debug("tDBOutput_12 - " + ("The ") + ("INSERT")
															+ (" batch execution has succeeded."));
											} catch (java.sql.BatchUpdateException e) {
												globalMap.put("tDBOutput_12_ERROR_MESSAGE", e.getMessage());

												for (int countEach_tDBOutput_12 : e.getUpdateCounts()) {
													counter += (countEach_tDBOutput_12 < 0 ? 0
															: countEach_tDBOutput_12);
												}

												log.error("tDBOutput_12 - " + (e.getMessage()));
												System.err.println(e.getMessage());

											}
											return counter;
										}
									}
									if ((batchSize_tDBOutput_12 > 0)
											&& (batchSize_tDBOutput_12 <= batchSizeCounter_tDBOutput_12)) {

										insertedCount_tDBOutput_12 = new LimitBytesHelper_tDBOutput_12()
												.limitBytePart1(insertedCount_tDBOutput_12, pstmt_tDBOutput_12);
										rowsToCommitCount_tDBOutput_12 = insertedCount_tDBOutput_12;

										batchSizeCounter_tDBOutput_12 = 0;
									}

									//////////// commit every////////////

									commitCounter_tDBOutput_12++;
									if (commitEvery_tDBOutput_12 <= commitCounter_tDBOutput_12) {
										if ((batchSize_tDBOutput_12 > 0) && (batchSizeCounter_tDBOutput_12 > 0)) {

											insertedCount_tDBOutput_12 = new LimitBytesHelper_tDBOutput_12()
													.limitBytePart1(insertedCount_tDBOutput_12, pstmt_tDBOutput_12);

											batchSizeCounter_tDBOutput_12 = 0;
										}
										if (rowsToCommitCount_tDBOutput_12 != 0) {

											if (log.isDebugEnabled())
												log.debug("tDBOutput_12 - " + ("Connection starting to commit ")
														+ (rowsToCommitCount_tDBOutput_12) + (" record(s)."));
										}
										conn_tDBOutput_12.commit();
										if (rowsToCommitCount_tDBOutput_12 != 0) {

											if (log.isDebugEnabled())
												log.debug("tDBOutput_12 - " + ("Connection commit has succeeded."));
											rowsToCommitCount_tDBOutput_12 = 0;
										}
										commitCounter_tDBOutput_12 = 0;
									}

									tos_count_tDBOutput_12++;

									/**
									 * [tDBOutput_12 main ] stop
									 */

									/**
									 * [tDBOutput_12 process_data_begin ] start
									 */

									currentComponent = "tDBOutput_12";

									/**
									 * [tDBOutput_12 process_data_begin ] stop
									 */

									/**
									 * [tDBOutput_12 process_data_end ] start
									 */

									currentComponent = "tDBOutput_12";

									/**
									 * [tDBOutput_12 process_data_end ] stop
									 */

								} // End of branch "Person_Sex1"

								/**
								 * [tMap_15 process_data_end ] start
								 */

								currentComponent = "tMap_15";

								/**
								 * [tMap_15 process_data_end ] stop
								 */

							} // End of branch "row13"

							/**
							 * [tUniqRow_13 process_data_end ] start
							 */

							currentComponent = "tUniqRow_13";

							/**
							 * [tUniqRow_13 process_data_end ] stop
							 */

						} // End of branch "Person_Sex"

						/**
						 * [tMap_1 process_data_end ] start
						 */

						currentComponent = "tMap_1";

						/**
						 * [tMap_1 process_data_end ] stop
						 */

						/**
						 * [tDBInput_1 process_data_end ] start
						 */

						currentComponent = "tDBInput_1";

						/**
						 * [tDBInput_1 process_data_end ] stop
						 */

						/**
						 * [tDBInput_1 end ] start
						 */

						currentComponent = "tDBInput_1";

					}
				} finally {
					if (rs_tDBInput_1 != null) {
						rs_tDBInput_1.close();
					}
					if (stmt_tDBInput_1 != null) {
						stmt_tDBInput_1.close();
					}
					if (conn_tDBInput_1 != null && !conn_tDBInput_1.isClosed()) {

						log.debug("tDBInput_1 - Closing the connection to the database.");

						conn_tDBInput_1.close();

						if ("com.mysql.cj.jdbc.Driver".equals((String) globalMap.get("driverClass_"))
								&& routines.system.BundleUtils.inOSGi()) {
							Class.forName("com.mysql.cj.jdbc.AbandonedConnectionCleanupThread")
									.getMethod("checkedShutdown").invoke(null, (Object[]) null);
						}

						log.debug("tDBInput_1 - Connection to the database closed.");

					}
				}
				globalMap.put("tDBInput_1_NB_LINE", nb_line_tDBInput_1);
				log.debug("tDBInput_1 - Retrieved records count: " + nb_line_tDBInput_1 + " .");

				if (log.isDebugEnabled())
					log.debug("tDBInput_1 - " + ("Done."));

				ok_Hash.put("tDBInput_1", true);
				end_Hash.put("tDBInput_1", System.currentTimeMillis());

				/**
				 * [tDBInput_1 end ] stop
				 */

				/**
				 * [tMap_1 end ] start
				 */

				currentComponent = "tMap_1";

// ###############################
// # Lookup hashes releasing
// ###############################      
				log.debug(
						"tMap_1 - Written records count in the table 'Person_type': " + count_Person_type_tMap_1 + ".");
				log.debug("tMap_1 - Written records count in the table 'Person_Injury': " + count_Person_Injury_tMap_1
						+ ".");
				log.debug("tMap_1 - Written records count in the table 'Emotional_Status': "
						+ count_Emotional_Status_tMap_1 + ".");
				log.debug("tMap_1 - Written records count in the table 'Ejection': " + count_Ejection_tMap_1 + ".");
				log.debug("tMap_1 - Written records count in the table 'Bodily_Injury': " + count_Bodily_Injury_tMap_1
						+ ".");
				log.debug("tMap_1 - Written records count in the table 'Position_In_vehicle': "
						+ count_Position_In_vehicle_tMap_1 + ".");
				log.debug("tMap_1 - Written records count in the table 'Safety_Equipment': "
						+ count_Safety_Equipment_tMap_1 + ".");
				log.debug("tMap_1 - Written records count in the table 'Ped_Location': " + count_Ped_Location_tMap_1
						+ ".");
				log.debug("tMap_1 - Written records count in the table 'Ped_Location1': " + count_Ped_Location1_tMap_1
						+ ".");
				log.debug("tMap_1 - Written records count in the table 'Complaint': " + count_Complaint_tMap_1 + ".");
				log.debug("tMap_1 - Written records count in the table 'Ped_Role': " + count_Ped_Role_tMap_1 + ".");
				log.debug("tMap_1 - Written records count in the table 'Person_Sex': " + count_Person_Sex_tMap_1 + ".");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "row1", 2, 0,
						"tDBInput_1", "__TABLE__", "tMSSqlInput", "tMap_1", "tMap_1", "tMap", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tMap_1 - " + ("Done."));

				ok_Hash.put("tMap_1", true);
				end_Hash.put("tMap_1", System.currentTimeMillis());

				/**
				 * [tMap_1 end ] stop
				 */

				/**
				 * [tUniqRow_1 end ] start
				 */

				currentComponent = "tUniqRow_1";

				globalMap.put("tUniqRow_1_NB_UNIQUES", nb_uniques_tUniqRow_1);
				globalMap.put("tUniqRow_1_NB_DUPLICATES", nb_duplicates_tUniqRow_1);
				log.info("tUniqRow_1 - Unique records count: " + (nb_uniques_tUniqRow_1) + " .");
				log.info("tUniqRow_1 - Duplicate records count: " + (nb_duplicates_tUniqRow_1) + " .");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "Person_type", 2, 0,
						"tMap_1", "tMap_1", "tMap", "tUniqRow_1", "tUniqRow_1", "tUniqRow", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tUniqRow_1 - " + ("Done."));

				ok_Hash.put("tUniqRow_1", true);
				end_Hash.put("tUniqRow_1", System.currentTimeMillis());

				/**
				 * [tUniqRow_1 end ] stop
				 */

				/**
				 * [tMap_2 end ] start
				 */

				currentComponent = "tMap_2";

// ###############################
// # Lookup hashes releasing
// ###############################      
				log.debug("tMap_2 - Written records count in the table 'Person_Type_Formula': "
						+ count_Person_Type_Formula_tMap_2 + ".");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "row2", 2, 0,
						"tUniqRow_1", "tUniqRow_1", "tUniqRow", "tMap_2", "tMap_2", "tMap", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tMap_2 - " + ("Done."));

				ok_Hash.put("tMap_2", true);
				end_Hash.put("tMap_2", System.currentTimeMillis());

				/**
				 * [tMap_2 end ] stop
				 */

				/**
				 * [tDBOutput_1 end ] start
				 */

				currentComponent = "tDBOutput_1";

				try {
					int countSum_tDBOutput_1 = 0;
					if (pstmt_tDBOutput_1 != null && batchSizeCounter_tDBOutput_1 > 0) {

						if (log.isDebugEnabled())
							log.debug("tDBOutput_1 - " + ("Executing the ") + ("INSERT") + (" batch."));
						for (int countEach_tDBOutput_1 : pstmt_tDBOutput_1.executeBatch()) {
							if (countEach_tDBOutput_1 == -2 || countEach_tDBOutput_1 == -3) {
								break;
							}
							countSum_tDBOutput_1 += countEach_tDBOutput_1;
						}
						rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;

						if (log.isDebugEnabled())
							log.debug("tDBOutput_1 - " + ("The ") + ("INSERT") + (" batch execution has succeeded."));
					}

					insertedCount_tDBOutput_1 += countSum_tDBOutput_1;

				} catch (java.sql.BatchUpdateException e) {
					globalMap.put("tDBOutput_1_ERROR_MESSAGE", e.getMessage());

					int countSum_tDBOutput_1 = 0;
					for (int countEach_tDBOutput_1 : e.getUpdateCounts()) {
						countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
					}
					rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;

					insertedCount_tDBOutput_1 += countSum_tDBOutput_1;

					log.error("tDBOutput_1 - " + (e.getMessage()));
					System.err.println(e.getMessage());

				}
				if (pstmt_tDBOutput_1 != null) {

					pstmt_tDBOutput_1.close();
					resourceMap.remove("pstmt_tDBOutput_1");

				}
				resourceMap.put("statementClosed_tDBOutput_1", true);
				if (rowsToCommitCount_tDBOutput_1 != 0) {

					if (log.isDebugEnabled())
						log.debug("tDBOutput_1 - " + ("Connection starting to commit ")
								+ (rowsToCommitCount_tDBOutput_1) + (" record(s)."));
				}
				conn_tDBOutput_1.commit();
				if (rowsToCommitCount_tDBOutput_1 != 0) {

					if (log.isDebugEnabled())
						log.debug("tDBOutput_1 - " + ("Connection commit has succeeded."));
					rowsToCommitCount_tDBOutput_1 = 0;
				}
				commitCounter_tDBOutput_1 = 0;
				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Closing the connection to the database."));
				conn_tDBOutput_1.close();
				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Connection to the database has closed."));
				resourceMap.put("finish_tDBOutput_1", true);

				nb_line_deleted_tDBOutput_1 = nb_line_deleted_tDBOutput_1 + deletedCount_tDBOutput_1;
				nb_line_update_tDBOutput_1 = nb_line_update_tDBOutput_1 + updatedCount_tDBOutput_1;
				nb_line_inserted_tDBOutput_1 = nb_line_inserted_tDBOutput_1 + insertedCount_tDBOutput_1;
				nb_line_rejected_tDBOutput_1 = nb_line_rejected_tDBOutput_1 + rejectedCount_tDBOutput_1;

				globalMap.put("tDBOutput_1_NB_LINE", nb_line_tDBOutput_1);
				globalMap.put("tDBOutput_1_NB_LINE_UPDATED", nb_line_update_tDBOutput_1);
				globalMap.put("tDBOutput_1_NB_LINE_INSERTED", nb_line_inserted_tDBOutput_1);
				globalMap.put("tDBOutput_1_NB_LINE_DELETED", nb_line_deleted_tDBOutput_1);
				globalMap.put("tDBOutput_1_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_1);

				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Has ") + ("inserted") + (" ") + (nb_line_inserted_tDBOutput_1)
							+ (" record(s)."));

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "Person_Type_Formula", 2,
						0, "tMap_2", "tMap_2", "tMap", "tDBOutput_1", "__TABLE__", "tMSSqlOutput", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Done."));

				ok_Hash.put("tDBOutput_1", true);
				end_Hash.put("tDBOutput_1", System.currentTimeMillis());

				/**
				 * [tDBOutput_1 end ] stop
				 */

				/**
				 * [tUniqRow_2 end ] start
				 */

				currentComponent = "tUniqRow_2";

				globalMap.put("tUniqRow_2_NB_UNIQUES", nb_uniques_tUniqRow_2);
				globalMap.put("tUniqRow_2_NB_DUPLICATES", nb_duplicates_tUniqRow_2);
				log.info("tUniqRow_2 - Unique records count: " + (nb_uniques_tUniqRow_2) + " .");
				log.info("tUniqRow_2 - Duplicate records count: " + (nb_duplicates_tUniqRow_2) + " .");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "Person_Injury", 2, 0,
						"tMap_1", "tMap_1", "tMap", "tUniqRow_2", "tUniqRow_2", "tUniqRow", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tUniqRow_2 - " + ("Done."));

				ok_Hash.put("tUniqRow_2", true);
				end_Hash.put("tUniqRow_2", System.currentTimeMillis());

				/**
				 * [tUniqRow_2 end ] stop
				 */

				/**
				 * [tMap_3 end ] start
				 */

				currentComponent = "tMap_3";

// ###############################
// # Lookup hashes releasing
// ###############################      
				log.debug("tMap_3 - Written records count in the table 'Person_Injury1': " + count_Person_Injury1_tMap_3
						+ ".");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "row3", 2, 0,
						"tUniqRow_2", "tUniqRow_2", "tUniqRow", "tMap_3", "tMap_3", "tMap", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tMap_3 - " + ("Done."));

				ok_Hash.put("tMap_3", true);
				end_Hash.put("tMap_3", System.currentTimeMillis());

				/**
				 * [tMap_3 end ] stop
				 */

				/**
				 * [tDBOutput_2 end ] start
				 */

				currentComponent = "tDBOutput_2";

				try {
					int countSum_tDBOutput_2 = 0;
					if (pstmt_tDBOutput_2 != null && batchSizeCounter_tDBOutput_2 > 0) {

						if (log.isDebugEnabled())
							log.debug("tDBOutput_2 - " + ("Executing the ") + ("INSERT") + (" batch."));
						for (int countEach_tDBOutput_2 : pstmt_tDBOutput_2.executeBatch()) {
							if (countEach_tDBOutput_2 == -2 || countEach_tDBOutput_2 == -3) {
								break;
							}
							countSum_tDBOutput_2 += countEach_tDBOutput_2;
						}
						rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;

						if (log.isDebugEnabled())
							log.debug("tDBOutput_2 - " + ("The ") + ("INSERT") + (" batch execution has succeeded."));
					}

					insertedCount_tDBOutput_2 += countSum_tDBOutput_2;

				} catch (java.sql.BatchUpdateException e) {
					globalMap.put("tDBOutput_2_ERROR_MESSAGE", e.getMessage());

					int countSum_tDBOutput_2 = 0;
					for (int countEach_tDBOutput_2 : e.getUpdateCounts()) {
						countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
					}
					rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;

					insertedCount_tDBOutput_2 += countSum_tDBOutput_2;

					log.error("tDBOutput_2 - " + (e.getMessage()));
					System.err.println(e.getMessage());

				}
				if (pstmt_tDBOutput_2 != null) {

					pstmt_tDBOutput_2.close();
					resourceMap.remove("pstmt_tDBOutput_2");

				}
				resourceMap.put("statementClosed_tDBOutput_2", true);
				if (rowsToCommitCount_tDBOutput_2 != 0) {

					if (log.isDebugEnabled())
						log.debug("tDBOutput_2 - " + ("Connection starting to commit ")
								+ (rowsToCommitCount_tDBOutput_2) + (" record(s)."));
				}
				conn_tDBOutput_2.commit();
				if (rowsToCommitCount_tDBOutput_2 != 0) {

					if (log.isDebugEnabled())
						log.debug("tDBOutput_2 - " + ("Connection commit has succeeded."));
					rowsToCommitCount_tDBOutput_2 = 0;
				}
				commitCounter_tDBOutput_2 = 0;
				if (log.isDebugEnabled())
					log.debug("tDBOutput_2 - " + ("Closing the connection to the database."));
				conn_tDBOutput_2.close();
				if (log.isDebugEnabled())
					log.debug("tDBOutput_2 - " + ("Connection to the database has closed."));
				resourceMap.put("finish_tDBOutput_2", true);

				nb_line_deleted_tDBOutput_2 = nb_line_deleted_tDBOutput_2 + deletedCount_tDBOutput_2;
				nb_line_update_tDBOutput_2 = nb_line_update_tDBOutput_2 + updatedCount_tDBOutput_2;
				nb_line_inserted_tDBOutput_2 = nb_line_inserted_tDBOutput_2 + insertedCount_tDBOutput_2;
				nb_line_rejected_tDBOutput_2 = nb_line_rejected_tDBOutput_2 + rejectedCount_tDBOutput_2;

				globalMap.put("tDBOutput_2_NB_LINE", nb_line_tDBOutput_2);
				globalMap.put("tDBOutput_2_NB_LINE_UPDATED", nb_line_update_tDBOutput_2);
				globalMap.put("tDBOutput_2_NB_LINE_INSERTED", nb_line_inserted_tDBOutput_2);
				globalMap.put("tDBOutput_2_NB_LINE_DELETED", nb_line_deleted_tDBOutput_2);
				globalMap.put("tDBOutput_2_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_2);

				if (log.isDebugEnabled())
					log.debug("tDBOutput_2 - " + ("Has ") + ("inserted") + (" ") + (nb_line_inserted_tDBOutput_2)
							+ (" record(s)."));

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "Person_Injury1", 2, 0,
						"tMap_3", "tMap_3", "tMap", "tDBOutput_2", "__TABLE__", "tMSSqlOutput", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tDBOutput_2 - " + ("Done."));

				ok_Hash.put("tDBOutput_2", true);
				end_Hash.put("tDBOutput_2", System.currentTimeMillis());

				/**
				 * [tDBOutput_2 end ] stop
				 */

				/**
				 * [tUniqRow_3 end ] start
				 */

				currentComponent = "tUniqRow_3";

				globalMap.put("tUniqRow_3_NB_UNIQUES", nb_uniques_tUniqRow_3);
				globalMap.put("tUniqRow_3_NB_DUPLICATES", nb_duplicates_tUniqRow_3);
				log.info("tUniqRow_3 - Unique records count: " + (nb_uniques_tUniqRow_3) + " .");
				log.info("tUniqRow_3 - Duplicate records count: " + (nb_duplicates_tUniqRow_3) + " .");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "Emotional_Status", 2, 0,
						"tMap_1", "tMap_1", "tMap", "tUniqRow_3", "tUniqRow_3", "tUniqRow", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tUniqRow_3 - " + ("Done."));

				ok_Hash.put("tUniqRow_3", true);
				end_Hash.put("tUniqRow_3", System.currentTimeMillis());

				/**
				 * [tUniqRow_3 end ] stop
				 */

				/**
				 * [tMap_4 end ] start
				 */

				currentComponent = "tMap_4";

// ###############################
// # Lookup hashes releasing
// ###############################      
				log.debug("tMap_4 - Written records count in the table 'Load3': " + count_Load3_tMap_4 + ".");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "row4", 2, 0,
						"tUniqRow_3", "tUniqRow_3", "tUniqRow", "tMap_4", "tMap_4", "tMap", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tMap_4 - " + ("Done."));

				ok_Hash.put("tMap_4", true);
				end_Hash.put("tMap_4", System.currentTimeMillis());

				/**
				 * [tMap_4 end ] stop
				 */

				/**
				 * [tDBOutput_3 end ] start
				 */

				currentComponent = "tDBOutput_3";

				try {
					int countSum_tDBOutput_3 = 0;
					if (pstmt_tDBOutput_3 != null && batchSizeCounter_tDBOutput_3 > 0) {

						if (log.isDebugEnabled())
							log.debug("tDBOutput_3 - " + ("Executing the ") + ("INSERT") + (" batch."));
						for (int countEach_tDBOutput_3 : pstmt_tDBOutput_3.executeBatch()) {
							if (countEach_tDBOutput_3 == -2 || countEach_tDBOutput_3 == -3) {
								break;
							}
							countSum_tDBOutput_3 += countEach_tDBOutput_3;
						}
						rowsToCommitCount_tDBOutput_3 += countSum_tDBOutput_3;

						if (log.isDebugEnabled())
							log.debug("tDBOutput_3 - " + ("The ") + ("INSERT") + (" batch execution has succeeded."));
					}

					insertedCount_tDBOutput_3 += countSum_tDBOutput_3;

				} catch (java.sql.BatchUpdateException e) {
					globalMap.put("tDBOutput_3_ERROR_MESSAGE", e.getMessage());

					int countSum_tDBOutput_3 = 0;
					for (int countEach_tDBOutput_3 : e.getUpdateCounts()) {
						countSum_tDBOutput_3 += (countEach_tDBOutput_3 < 0 ? 0 : countEach_tDBOutput_3);
					}
					rowsToCommitCount_tDBOutput_3 += countSum_tDBOutput_3;

					insertedCount_tDBOutput_3 += countSum_tDBOutput_3;

					log.error("tDBOutput_3 - " + (e.getMessage()));
					System.err.println(e.getMessage());

				}
				if (pstmt_tDBOutput_3 != null) {

					pstmt_tDBOutput_3.close();
					resourceMap.remove("pstmt_tDBOutput_3");

				}
				resourceMap.put("statementClosed_tDBOutput_3", true);
				if (rowsToCommitCount_tDBOutput_3 != 0) {

					if (log.isDebugEnabled())
						log.debug("tDBOutput_3 - " + ("Connection starting to commit ")
								+ (rowsToCommitCount_tDBOutput_3) + (" record(s)."));
				}
				conn_tDBOutput_3.commit();
				if (rowsToCommitCount_tDBOutput_3 != 0) {

					if (log.isDebugEnabled())
						log.debug("tDBOutput_3 - " + ("Connection commit has succeeded."));
					rowsToCommitCount_tDBOutput_3 = 0;
				}
				commitCounter_tDBOutput_3 = 0;
				if (log.isDebugEnabled())
					log.debug("tDBOutput_3 - " + ("Closing the connection to the database."));
				conn_tDBOutput_3.close();
				if (log.isDebugEnabled())
					log.debug("tDBOutput_3 - " + ("Connection to the database has closed."));
				resourceMap.put("finish_tDBOutput_3", true);

				nb_line_deleted_tDBOutput_3 = nb_line_deleted_tDBOutput_3 + deletedCount_tDBOutput_3;
				nb_line_update_tDBOutput_3 = nb_line_update_tDBOutput_3 + updatedCount_tDBOutput_3;
				nb_line_inserted_tDBOutput_3 = nb_line_inserted_tDBOutput_3 + insertedCount_tDBOutput_3;
				nb_line_rejected_tDBOutput_3 = nb_line_rejected_tDBOutput_3 + rejectedCount_tDBOutput_3;

				globalMap.put("tDBOutput_3_NB_LINE", nb_line_tDBOutput_3);
				globalMap.put("tDBOutput_3_NB_LINE_UPDATED", nb_line_update_tDBOutput_3);
				globalMap.put("tDBOutput_3_NB_LINE_INSERTED", nb_line_inserted_tDBOutput_3);
				globalMap.put("tDBOutput_3_NB_LINE_DELETED", nb_line_deleted_tDBOutput_3);
				globalMap.put("tDBOutput_3_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_3);

				if (log.isDebugEnabled())
					log.debug("tDBOutput_3 - " + ("Has ") + ("inserted") + (" ") + (nb_line_inserted_tDBOutput_3)
							+ (" record(s)."));

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "Load3", 2, 0, "tMap_4",
						"tMap_4", "tMap", "tDBOutput_3", "__TABLE__", "tMSSqlOutput", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tDBOutput_3 - " + ("Done."));

				ok_Hash.put("tDBOutput_3", true);
				end_Hash.put("tDBOutput_3", System.currentTimeMillis());

				/**
				 * [tDBOutput_3 end ] stop
				 */

				/**
				 * [tUniqRow_5 end ] start
				 */

				currentComponent = "tUniqRow_5";

				globalMap.put("tUniqRow_5_NB_UNIQUES", nb_uniques_tUniqRow_5);
				globalMap.put("tUniqRow_5_NB_DUPLICATES", nb_duplicates_tUniqRow_5);
				log.info("tUniqRow_5 - Unique records count: " + (nb_uniques_tUniqRow_5) + " .");
				log.info("tUniqRow_5 - Duplicate records count: " + (nb_duplicates_tUniqRow_5) + " .");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "Ejection", 2, 0,
						"tMap_1", "tMap_1", "tMap", "tUniqRow_5", "tUniqRow_5", "tUniqRow", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tUniqRow_5 - " + ("Done."));

				ok_Hash.put("tUniqRow_5", true);
				end_Hash.put("tUniqRow_5", System.currentTimeMillis());

				/**
				 * [tUniqRow_5 end ] stop
				 */

				/**
				 * [tMap_6 end ] start
				 */

				currentComponent = "tMap_6";

// ###############################
// # Lookup hashes releasing
// ###############################      
				log.debug("tMap_6 - Written records count in the table 'Ejection_Load': " + count_Ejection_Load_tMap_6
						+ ".");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "row5", 2, 0,
						"tUniqRow_5", "tUniqRow_5", "tUniqRow", "tMap_6", "tMap_6", "tMap", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tMap_6 - " + ("Done."));

				ok_Hash.put("tMap_6", true);
				end_Hash.put("tMap_6", System.currentTimeMillis());

				/**
				 * [tMap_6 end ] stop
				 */

				/**
				 * [tDBOutput_4 end ] start
				 */

				currentComponent = "tDBOutput_4";

				try {
					int countSum_tDBOutput_4 = 0;
					if (pstmt_tDBOutput_4 != null && batchSizeCounter_tDBOutput_4 > 0) {

						if (log.isDebugEnabled())
							log.debug("tDBOutput_4 - " + ("Executing the ") + ("INSERT") + (" batch."));
						for (int countEach_tDBOutput_4 : pstmt_tDBOutput_4.executeBatch()) {
							if (countEach_tDBOutput_4 == -2 || countEach_tDBOutput_4 == -3) {
								break;
							}
							countSum_tDBOutput_4 += countEach_tDBOutput_4;
						}
						rowsToCommitCount_tDBOutput_4 += countSum_tDBOutput_4;

						if (log.isDebugEnabled())
							log.debug("tDBOutput_4 - " + ("The ") + ("INSERT") + (" batch execution has succeeded."));
					}

					insertedCount_tDBOutput_4 += countSum_tDBOutput_4;

				} catch (java.sql.BatchUpdateException e) {
					globalMap.put("tDBOutput_4_ERROR_MESSAGE", e.getMessage());

					int countSum_tDBOutput_4 = 0;
					for (int countEach_tDBOutput_4 : e.getUpdateCounts()) {
						countSum_tDBOutput_4 += (countEach_tDBOutput_4 < 0 ? 0 : countEach_tDBOutput_4);
					}
					rowsToCommitCount_tDBOutput_4 += countSum_tDBOutput_4;

					insertedCount_tDBOutput_4 += countSum_tDBOutput_4;

					log.error("tDBOutput_4 - " + (e.getMessage()));
					System.err.println(e.getMessage());

				}
				if (pstmt_tDBOutput_4 != null) {

					pstmt_tDBOutput_4.close();
					resourceMap.remove("pstmt_tDBOutput_4");

				}
				resourceMap.put("statementClosed_tDBOutput_4", true);
				if (rowsToCommitCount_tDBOutput_4 != 0) {

					if (log.isDebugEnabled())
						log.debug("tDBOutput_4 - " + ("Connection starting to commit ")
								+ (rowsToCommitCount_tDBOutput_4) + (" record(s)."));
				}
				conn_tDBOutput_4.commit();
				if (rowsToCommitCount_tDBOutput_4 != 0) {

					if (log.isDebugEnabled())
						log.debug("tDBOutput_4 - " + ("Connection commit has succeeded."));
					rowsToCommitCount_tDBOutput_4 = 0;
				}
				commitCounter_tDBOutput_4 = 0;
				if (log.isDebugEnabled())
					log.debug("tDBOutput_4 - " + ("Closing the connection to the database."));
				conn_tDBOutput_4.close();
				if (log.isDebugEnabled())
					log.debug("tDBOutput_4 - " + ("Connection to the database has closed."));
				resourceMap.put("finish_tDBOutput_4", true);

				nb_line_deleted_tDBOutput_4 = nb_line_deleted_tDBOutput_4 + deletedCount_tDBOutput_4;
				nb_line_update_tDBOutput_4 = nb_line_update_tDBOutput_4 + updatedCount_tDBOutput_4;
				nb_line_inserted_tDBOutput_4 = nb_line_inserted_tDBOutput_4 + insertedCount_tDBOutput_4;
				nb_line_rejected_tDBOutput_4 = nb_line_rejected_tDBOutput_4 + rejectedCount_tDBOutput_4;

				globalMap.put("tDBOutput_4_NB_LINE", nb_line_tDBOutput_4);
				globalMap.put("tDBOutput_4_NB_LINE_UPDATED", nb_line_update_tDBOutput_4);
				globalMap.put("tDBOutput_4_NB_LINE_INSERTED", nb_line_inserted_tDBOutput_4);
				globalMap.put("tDBOutput_4_NB_LINE_DELETED", nb_line_deleted_tDBOutput_4);
				globalMap.put("tDBOutput_4_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_4);

				if (log.isDebugEnabled())
					log.debug("tDBOutput_4 - " + ("Has ") + ("inserted") + (" ") + (nb_line_inserted_tDBOutput_4)
							+ (" record(s)."));

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "Ejection_Load", 2, 0,
						"tMap_6", "tMap_6", "tMap", "tDBOutput_4", "__TABLE__", "tMSSqlOutput", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tDBOutput_4 - " + ("Done."));

				ok_Hash.put("tDBOutput_4", true);
				end_Hash.put("tDBOutput_4", System.currentTimeMillis());

				/**
				 * [tDBOutput_4 end ] stop
				 */

				/**
				 * [tUniqRow_7 end ] start
				 */

				currentComponent = "tUniqRow_7";

				globalMap.put("tUniqRow_7_NB_UNIQUES", nb_uniques_tUniqRow_7);
				globalMap.put("tUniqRow_7_NB_DUPLICATES", nb_duplicates_tUniqRow_7);
				log.info("tUniqRow_7 - Unique records count: " + (nb_uniques_tUniqRow_7) + " .");
				log.info("tUniqRow_7 - Duplicate records count: " + (nb_duplicates_tUniqRow_7) + " .");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "Bodily_Injury", 2, 0,
						"tMap_1", "tMap_1", "tMap", "tUniqRow_7", "tUniqRow_7", "tUniqRow", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tUniqRow_7 - " + ("Done."));

				ok_Hash.put("tUniqRow_7", true);
				end_Hash.put("tUniqRow_7", System.currentTimeMillis());

				/**
				 * [tUniqRow_7 end ] stop
				 */

				/**
				 * [tMap_7 end ] start
				 */

				currentComponent = "tMap_7";

// ###############################
// # Lookup hashes releasing
// ###############################      
				log.debug(
						"tMap_7 - Written records count in the table 'Bodily_load': " + count_Bodily_load_tMap_7 + ".");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "row6", 2, 0,
						"tUniqRow_7", "tUniqRow_7", "tUniqRow", "tMap_7", "tMap_7", "tMap", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tMap_7 - " + ("Done."));

				ok_Hash.put("tMap_7", true);
				end_Hash.put("tMap_7", System.currentTimeMillis());

				/**
				 * [tMap_7 end ] stop
				 */

				/**
				 * [tDBOutput_5 end ] start
				 */

				currentComponent = "tDBOutput_5";

				try {
					int countSum_tDBOutput_5 = 0;
					if (pstmt_tDBOutput_5 != null && batchSizeCounter_tDBOutput_5 > 0) {

						if (log.isDebugEnabled())
							log.debug("tDBOutput_5 - " + ("Executing the ") + ("INSERT") + (" batch."));
						for (int countEach_tDBOutput_5 : pstmt_tDBOutput_5.executeBatch()) {
							if (countEach_tDBOutput_5 == -2 || countEach_tDBOutput_5 == -3) {
								break;
							}
							countSum_tDBOutput_5 += countEach_tDBOutput_5;
						}
						rowsToCommitCount_tDBOutput_5 += countSum_tDBOutput_5;

						if (log.isDebugEnabled())
							log.debug("tDBOutput_5 - " + ("The ") + ("INSERT") + (" batch execution has succeeded."));
					}

					insertedCount_tDBOutput_5 += countSum_tDBOutput_5;

				} catch (java.sql.BatchUpdateException e) {
					globalMap.put("tDBOutput_5_ERROR_MESSAGE", e.getMessage());

					int countSum_tDBOutput_5 = 0;
					for (int countEach_tDBOutput_5 : e.getUpdateCounts()) {
						countSum_tDBOutput_5 += (countEach_tDBOutput_5 < 0 ? 0 : countEach_tDBOutput_5);
					}
					rowsToCommitCount_tDBOutput_5 += countSum_tDBOutput_5;

					insertedCount_tDBOutput_5 += countSum_tDBOutput_5;

					log.error("tDBOutput_5 - " + (e.getMessage()));
					System.err.println(e.getMessage());

				}
				if (pstmt_tDBOutput_5 != null) {

					pstmt_tDBOutput_5.close();
					resourceMap.remove("pstmt_tDBOutput_5");

				}
				resourceMap.put("statementClosed_tDBOutput_5", true);
				if (rowsToCommitCount_tDBOutput_5 != 0) {

					if (log.isDebugEnabled())
						log.debug("tDBOutput_5 - " + ("Connection starting to commit ")
								+ (rowsToCommitCount_tDBOutput_5) + (" record(s)."));
				}
				conn_tDBOutput_5.commit();
				if (rowsToCommitCount_tDBOutput_5 != 0) {

					if (log.isDebugEnabled())
						log.debug("tDBOutput_5 - " + ("Connection commit has succeeded."));
					rowsToCommitCount_tDBOutput_5 = 0;
				}
				commitCounter_tDBOutput_5 = 0;
				if (log.isDebugEnabled())
					log.debug("tDBOutput_5 - " + ("Closing the connection to the database."));
				conn_tDBOutput_5.close();
				if (log.isDebugEnabled())
					log.debug("tDBOutput_5 - " + ("Connection to the database has closed."));
				resourceMap.put("finish_tDBOutput_5", true);

				nb_line_deleted_tDBOutput_5 = nb_line_deleted_tDBOutput_5 + deletedCount_tDBOutput_5;
				nb_line_update_tDBOutput_5 = nb_line_update_tDBOutput_5 + updatedCount_tDBOutput_5;
				nb_line_inserted_tDBOutput_5 = nb_line_inserted_tDBOutput_5 + insertedCount_tDBOutput_5;
				nb_line_rejected_tDBOutput_5 = nb_line_rejected_tDBOutput_5 + rejectedCount_tDBOutput_5;

				globalMap.put("tDBOutput_5_NB_LINE", nb_line_tDBOutput_5);
				globalMap.put("tDBOutput_5_NB_LINE_UPDATED", nb_line_update_tDBOutput_5);
				globalMap.put("tDBOutput_5_NB_LINE_INSERTED", nb_line_inserted_tDBOutput_5);
				globalMap.put("tDBOutput_5_NB_LINE_DELETED", nb_line_deleted_tDBOutput_5);
				globalMap.put("tDBOutput_5_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_5);

				if (log.isDebugEnabled())
					log.debug("tDBOutput_5 - " + ("Has ") + ("inserted") + (" ") + (nb_line_inserted_tDBOutput_5)
							+ (" record(s)."));

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "Bodily_load", 2, 0,
						"tMap_7", "tMap_7", "tMap", "tDBOutput_5", "__TABLE__", "tMSSqlOutput", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tDBOutput_5 - " + ("Done."));

				ok_Hash.put("tDBOutput_5", true);
				end_Hash.put("tDBOutput_5", System.currentTimeMillis());

				/**
				 * [tDBOutput_5 end ] stop
				 */

				/**
				 * [tUniqRow_4 end ] start
				 */

				currentComponent = "tUniqRow_4";

				globalMap.put("tUniqRow_4_NB_UNIQUES", nb_uniques_tUniqRow_4);
				globalMap.put("tUniqRow_4_NB_DUPLICATES", nb_duplicates_tUniqRow_4);
				log.info("tUniqRow_4 - Unique records count: " + (nb_uniques_tUniqRow_4) + " .");
				log.info("tUniqRow_4 - Duplicate records count: " + (nb_duplicates_tUniqRow_4) + " .");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "Position_In_vehicle", 2,
						0, "tMap_1", "tMap_1", "tMap", "tUniqRow_4", "tUniqRow_4", "tUniqRow", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tUniqRow_4 - " + ("Done."));

				ok_Hash.put("tUniqRow_4", true);
				end_Hash.put("tUniqRow_4", System.currentTimeMillis());

				/**
				 * [tUniqRow_4 end ] stop
				 */

				/**
				 * [tMap_9 end ] start
				 */

				currentComponent = "tMap_9";

// ###############################
// # Lookup hashes releasing
// ###############################      
				log.debug("tMap_9 - Written records count in the table 'Position_In_Vehicle1': "
						+ count_Position_In_Vehicle1_tMap_9 + ".");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "row7", 2, 0,
						"tUniqRow_4", "tUniqRow_4", "tUniqRow", "tMap_9", "tMap_9", "tMap", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tMap_9 - " + ("Done."));

				ok_Hash.put("tMap_9", true);
				end_Hash.put("tMap_9", System.currentTimeMillis());

				/**
				 * [tMap_9 end ] stop
				 */

				/**
				 * [tDBOutput_6 end ] start
				 */

				currentComponent = "tDBOutput_6";

				try {
					int countSum_tDBOutput_6 = 0;
					if (pstmt_tDBOutput_6 != null && batchSizeCounter_tDBOutput_6 > 0) {

						if (log.isDebugEnabled())
							log.debug("tDBOutput_6 - " + ("Executing the ") + ("INSERT") + (" batch."));
						for (int countEach_tDBOutput_6 : pstmt_tDBOutput_6.executeBatch()) {
							if (countEach_tDBOutput_6 == -2 || countEach_tDBOutput_6 == -3) {
								break;
							}
							countSum_tDBOutput_6 += countEach_tDBOutput_6;
						}
						rowsToCommitCount_tDBOutput_6 += countSum_tDBOutput_6;

						if (log.isDebugEnabled())
							log.debug("tDBOutput_6 - " + ("The ") + ("INSERT") + (" batch execution has succeeded."));
					}

					insertedCount_tDBOutput_6 += countSum_tDBOutput_6;

				} catch (java.sql.BatchUpdateException e) {
					globalMap.put("tDBOutput_6_ERROR_MESSAGE", e.getMessage());

					int countSum_tDBOutput_6 = 0;
					for (int countEach_tDBOutput_6 : e.getUpdateCounts()) {
						countSum_tDBOutput_6 += (countEach_tDBOutput_6 < 0 ? 0 : countEach_tDBOutput_6);
					}
					rowsToCommitCount_tDBOutput_6 += countSum_tDBOutput_6;

					insertedCount_tDBOutput_6 += countSum_tDBOutput_6;

					log.error("tDBOutput_6 - " + (e.getMessage()));
					System.err.println(e.getMessage());

				}
				if (pstmt_tDBOutput_6 != null) {

					pstmt_tDBOutput_6.close();
					resourceMap.remove("pstmt_tDBOutput_6");

				}
				resourceMap.put("statementClosed_tDBOutput_6", true);
				if (rowsToCommitCount_tDBOutput_6 != 0) {

					if (log.isDebugEnabled())
						log.debug("tDBOutput_6 - " + ("Connection starting to commit ")
								+ (rowsToCommitCount_tDBOutput_6) + (" record(s)."));
				}
				conn_tDBOutput_6.commit();
				if (rowsToCommitCount_tDBOutput_6 != 0) {

					if (log.isDebugEnabled())
						log.debug("tDBOutput_6 - " + ("Connection commit has succeeded."));
					rowsToCommitCount_tDBOutput_6 = 0;
				}
				commitCounter_tDBOutput_6 = 0;
				if (log.isDebugEnabled())
					log.debug("tDBOutput_6 - " + ("Closing the connection to the database."));
				conn_tDBOutput_6.close();
				if (log.isDebugEnabled())
					log.debug("tDBOutput_6 - " + ("Connection to the database has closed."));
				resourceMap.put("finish_tDBOutput_6", true);

				nb_line_deleted_tDBOutput_6 = nb_line_deleted_tDBOutput_6 + deletedCount_tDBOutput_6;
				nb_line_update_tDBOutput_6 = nb_line_update_tDBOutput_6 + updatedCount_tDBOutput_6;
				nb_line_inserted_tDBOutput_6 = nb_line_inserted_tDBOutput_6 + insertedCount_tDBOutput_6;
				nb_line_rejected_tDBOutput_6 = nb_line_rejected_tDBOutput_6 + rejectedCount_tDBOutput_6;

				globalMap.put("tDBOutput_6_NB_LINE", nb_line_tDBOutput_6);
				globalMap.put("tDBOutput_6_NB_LINE_UPDATED", nb_line_update_tDBOutput_6);
				globalMap.put("tDBOutput_6_NB_LINE_INSERTED", nb_line_inserted_tDBOutput_6);
				globalMap.put("tDBOutput_6_NB_LINE_DELETED", nb_line_deleted_tDBOutput_6);
				globalMap.put("tDBOutput_6_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_6);

				if (log.isDebugEnabled())
					log.debug("tDBOutput_6 - " + ("Has ") + ("inserted") + (" ") + (nb_line_inserted_tDBOutput_6)
							+ (" record(s)."));

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "Position_In_Vehicle1",
						2, 0, "tMap_9", "tMap_9", "tMap", "tDBOutput_6", "__TABLE__", "tMSSqlOutput", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tDBOutput_6 - " + ("Done."));

				ok_Hash.put("tDBOutput_6", true);
				end_Hash.put("tDBOutput_6", System.currentTimeMillis());

				/**
				 * [tDBOutput_6 end ] stop
				 */

				/**
				 * [tUniqRow_8 end ] start
				 */

				currentComponent = "tUniqRow_8";

				globalMap.put("tUniqRow_8_NB_UNIQUES", nb_uniques_tUniqRow_8);
				globalMap.put("tUniqRow_8_NB_DUPLICATES", nb_duplicates_tUniqRow_8);
				log.info("tUniqRow_8 - Unique records count: " + (nb_uniques_tUniqRow_8) + " .");
				log.info("tUniqRow_8 - Duplicate records count: " + (nb_duplicates_tUniqRow_8) + " .");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "Safety_Equipment", 2, 0,
						"tMap_1", "tMap_1", "tMap", "tUniqRow_8", "tUniqRow_8", "tUniqRow", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tUniqRow_8 - " + ("Done."));

				ok_Hash.put("tUniqRow_8", true);
				end_Hash.put("tUniqRow_8", System.currentTimeMillis());

				/**
				 * [tUniqRow_8 end ] stop
				 */

				/**
				 * [tMap_10 end ] start
				 */

				currentComponent = "tMap_10";

// ###############################
// # Lookup hashes releasing
// ###############################      
				log.debug("tMap_10 - Written records count in the table 'Safety_Equipment1': "
						+ count_Safety_Equipment1_tMap_10 + ".");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "row8", 2, 0,
						"tUniqRow_8", "tUniqRow_8", "tUniqRow", "tMap_10", "tMap_10", "tMap", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tMap_10 - " + ("Done."));

				ok_Hash.put("tMap_10", true);
				end_Hash.put("tMap_10", System.currentTimeMillis());

				/**
				 * [tMap_10 end ] stop
				 */

				/**
				 * [tDBOutput_7 end ] start
				 */

				currentComponent = "tDBOutput_7";

				try {
					int countSum_tDBOutput_7 = 0;
					if (pstmt_tDBOutput_7 != null && batchSizeCounter_tDBOutput_7 > 0) {

						if (log.isDebugEnabled())
							log.debug("tDBOutput_7 - " + ("Executing the ") + ("INSERT") + (" batch."));
						for (int countEach_tDBOutput_7 : pstmt_tDBOutput_7.executeBatch()) {
							if (countEach_tDBOutput_7 == -2 || countEach_tDBOutput_7 == -3) {
								break;
							}
							countSum_tDBOutput_7 += countEach_tDBOutput_7;
						}
						rowsToCommitCount_tDBOutput_7 += countSum_tDBOutput_7;

						if (log.isDebugEnabled())
							log.debug("tDBOutput_7 - " + ("The ") + ("INSERT") + (" batch execution has succeeded."));
					}

					insertedCount_tDBOutput_7 += countSum_tDBOutput_7;

				} catch (java.sql.BatchUpdateException e) {
					globalMap.put("tDBOutput_7_ERROR_MESSAGE", e.getMessage());

					int countSum_tDBOutput_7 = 0;
					for (int countEach_tDBOutput_7 : e.getUpdateCounts()) {
						countSum_tDBOutput_7 += (countEach_tDBOutput_7 < 0 ? 0 : countEach_tDBOutput_7);
					}
					rowsToCommitCount_tDBOutput_7 += countSum_tDBOutput_7;

					insertedCount_tDBOutput_7 += countSum_tDBOutput_7;

					log.error("tDBOutput_7 - " + (e.getMessage()));
					System.err.println(e.getMessage());

				}
				if (pstmt_tDBOutput_7 != null) {

					pstmt_tDBOutput_7.close();
					resourceMap.remove("pstmt_tDBOutput_7");

				}
				resourceMap.put("statementClosed_tDBOutput_7", true);
				if (rowsToCommitCount_tDBOutput_7 != 0) {

					if (log.isDebugEnabled())
						log.debug("tDBOutput_7 - " + ("Connection starting to commit ")
								+ (rowsToCommitCount_tDBOutput_7) + (" record(s)."));
				}
				conn_tDBOutput_7.commit();
				if (rowsToCommitCount_tDBOutput_7 != 0) {

					if (log.isDebugEnabled())
						log.debug("tDBOutput_7 - " + ("Connection commit has succeeded."));
					rowsToCommitCount_tDBOutput_7 = 0;
				}
				commitCounter_tDBOutput_7 = 0;
				if (log.isDebugEnabled())
					log.debug("tDBOutput_7 - " + ("Closing the connection to the database."));
				conn_tDBOutput_7.close();
				if (log.isDebugEnabled())
					log.debug("tDBOutput_7 - " + ("Connection to the database has closed."));
				resourceMap.put("finish_tDBOutput_7", true);

				nb_line_deleted_tDBOutput_7 = nb_line_deleted_tDBOutput_7 + deletedCount_tDBOutput_7;
				nb_line_update_tDBOutput_7 = nb_line_update_tDBOutput_7 + updatedCount_tDBOutput_7;
				nb_line_inserted_tDBOutput_7 = nb_line_inserted_tDBOutput_7 + insertedCount_tDBOutput_7;
				nb_line_rejected_tDBOutput_7 = nb_line_rejected_tDBOutput_7 + rejectedCount_tDBOutput_7;

				globalMap.put("tDBOutput_7_NB_LINE", nb_line_tDBOutput_7);
				globalMap.put("tDBOutput_7_NB_LINE_UPDATED", nb_line_update_tDBOutput_7);
				globalMap.put("tDBOutput_7_NB_LINE_INSERTED", nb_line_inserted_tDBOutput_7);
				globalMap.put("tDBOutput_7_NB_LINE_DELETED", nb_line_deleted_tDBOutput_7);
				globalMap.put("tDBOutput_7_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_7);

				if (log.isDebugEnabled())
					log.debug("tDBOutput_7 - " + ("Has ") + ("inserted") + (" ") + (nb_line_inserted_tDBOutput_7)
							+ (" record(s)."));

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "Safety_Equipment1", 2,
						0, "tMap_10", "tMap_10", "tMap", "tDBOutput_7", "__TABLE__", "tMSSqlOutput", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tDBOutput_7 - " + ("Done."));

				ok_Hash.put("tDBOutput_7", true);
				end_Hash.put("tDBOutput_7", System.currentTimeMillis());

				/**
				 * [tDBOutput_7 end ] stop
				 */

				/**
				 * [tUniqRow_9 end ] start
				 */

				currentComponent = "tUniqRow_9";

				globalMap.put("tUniqRow_9_NB_UNIQUES", nb_uniques_tUniqRow_9);
				globalMap.put("tUniqRow_9_NB_DUPLICATES", nb_duplicates_tUniqRow_9);
				log.info("tUniqRow_9 - Unique records count: " + (nb_uniques_tUniqRow_9) + " .");
				log.info("tUniqRow_9 - Duplicate records count: " + (nb_duplicates_tUniqRow_9) + " .");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "Ped_Location", 2, 0,
						"tMap_1", "tMap_1", "tMap", "tUniqRow_9", "tUniqRow_9", "tUniqRow", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tUniqRow_9 - " + ("Done."));

				ok_Hash.put("tUniqRow_9", true);
				end_Hash.put("tUniqRow_9", System.currentTimeMillis());

				/**
				 * [tUniqRow_9 end ] stop
				 */

				/**
				 * [tMap_11 end ] start
				 */

				currentComponent = "tMap_11";

// ###############################
// # Lookup hashes releasing
// ###############################      
				log.debug("tMap_11 - Written records count in the table 'Ped_Location_Load': "
						+ count_Ped_Location_Load_tMap_11 + ".");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "row9", 2, 0,
						"tUniqRow_9", "tUniqRow_9", "tUniqRow", "tMap_11", "tMap_11", "tMap", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tMap_11 - " + ("Done."));

				ok_Hash.put("tMap_11", true);
				end_Hash.put("tMap_11", System.currentTimeMillis());

				/**
				 * [tMap_11 end ] stop
				 */

				/**
				 * [tDBOutput_8 end ] start
				 */

				currentComponent = "tDBOutput_8";

				try {
					int countSum_tDBOutput_8 = 0;
					if (pstmt_tDBOutput_8 != null && batchSizeCounter_tDBOutput_8 > 0) {

						if (log.isDebugEnabled())
							log.debug("tDBOutput_8 - " + ("Executing the ") + ("INSERT") + (" batch."));
						for (int countEach_tDBOutput_8 : pstmt_tDBOutput_8.executeBatch()) {
							if (countEach_tDBOutput_8 == -2 || countEach_tDBOutput_8 == -3) {
								break;
							}
							countSum_tDBOutput_8 += countEach_tDBOutput_8;
						}
						rowsToCommitCount_tDBOutput_8 += countSum_tDBOutput_8;

						if (log.isDebugEnabled())
							log.debug("tDBOutput_8 - " + ("The ") + ("INSERT") + (" batch execution has succeeded."));
					}

					insertedCount_tDBOutput_8 += countSum_tDBOutput_8;

				} catch (java.sql.BatchUpdateException e) {
					globalMap.put("tDBOutput_8_ERROR_MESSAGE", e.getMessage());

					int countSum_tDBOutput_8 = 0;
					for (int countEach_tDBOutput_8 : e.getUpdateCounts()) {
						countSum_tDBOutput_8 += (countEach_tDBOutput_8 < 0 ? 0 : countEach_tDBOutput_8);
					}
					rowsToCommitCount_tDBOutput_8 += countSum_tDBOutput_8;

					insertedCount_tDBOutput_8 += countSum_tDBOutput_8;

					log.error("tDBOutput_8 - " + (e.getMessage()));
					System.err.println(e.getMessage());

				}
				if (pstmt_tDBOutput_8 != null) {

					pstmt_tDBOutput_8.close();
					resourceMap.remove("pstmt_tDBOutput_8");

				}
				resourceMap.put("statementClosed_tDBOutput_8", true);
				if (rowsToCommitCount_tDBOutput_8 != 0) {

					if (log.isDebugEnabled())
						log.debug("tDBOutput_8 - " + ("Connection starting to commit ")
								+ (rowsToCommitCount_tDBOutput_8) + (" record(s)."));
				}
				conn_tDBOutput_8.commit();
				if (rowsToCommitCount_tDBOutput_8 != 0) {

					if (log.isDebugEnabled())
						log.debug("tDBOutput_8 - " + ("Connection commit has succeeded."));
					rowsToCommitCount_tDBOutput_8 = 0;
				}
				commitCounter_tDBOutput_8 = 0;
				if (log.isDebugEnabled())
					log.debug("tDBOutput_8 - " + ("Closing the connection to the database."));
				conn_tDBOutput_8.close();
				if (log.isDebugEnabled())
					log.debug("tDBOutput_8 - " + ("Connection to the database has closed."));
				resourceMap.put("finish_tDBOutput_8", true);

				nb_line_deleted_tDBOutput_8 = nb_line_deleted_tDBOutput_8 + deletedCount_tDBOutput_8;
				nb_line_update_tDBOutput_8 = nb_line_update_tDBOutput_8 + updatedCount_tDBOutput_8;
				nb_line_inserted_tDBOutput_8 = nb_line_inserted_tDBOutput_8 + insertedCount_tDBOutput_8;
				nb_line_rejected_tDBOutput_8 = nb_line_rejected_tDBOutput_8 + rejectedCount_tDBOutput_8;

				globalMap.put("tDBOutput_8_NB_LINE", nb_line_tDBOutput_8);
				globalMap.put("tDBOutput_8_NB_LINE_UPDATED", nb_line_update_tDBOutput_8);
				globalMap.put("tDBOutput_8_NB_LINE_INSERTED", nb_line_inserted_tDBOutput_8);
				globalMap.put("tDBOutput_8_NB_LINE_DELETED", nb_line_deleted_tDBOutput_8);
				globalMap.put("tDBOutput_8_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_8);

				if (log.isDebugEnabled())
					log.debug("tDBOutput_8 - " + ("Has ") + ("inserted") + (" ") + (nb_line_inserted_tDBOutput_8)
							+ (" record(s)."));

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "Ped_Location_Load", 2,
						0, "tMap_11", "tMap_11", "tMap", "tDBOutput_8", "__TABLE__", "tMSSqlOutput", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tDBOutput_8 - " + ("Done."));

				ok_Hash.put("tDBOutput_8", true);
				end_Hash.put("tDBOutput_8", System.currentTimeMillis());

				/**
				 * [tDBOutput_8 end ] stop
				 */

				/**
				 * [tUniqRow_10 end ] start
				 */

				currentComponent = "tUniqRow_10";

				globalMap.put("tUniqRow_10_NB_UNIQUES", nb_uniques_tUniqRow_10);
				globalMap.put("tUniqRow_10_NB_DUPLICATES", nb_duplicates_tUniqRow_10);
				log.info("tUniqRow_10 - Unique records count: " + (nb_uniques_tUniqRow_10) + " .");
				log.info("tUniqRow_10 - Duplicate records count: " + (nb_duplicates_tUniqRow_10) + " .");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "Ped_Location1", 2, 0,
						"tMap_1", "tMap_1", "tMap", "tUniqRow_10", "tUniqRow_10", "tUniqRow", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tUniqRow_10 - " + ("Done."));

				ok_Hash.put("tUniqRow_10", true);
				end_Hash.put("tUniqRow_10", System.currentTimeMillis());

				/**
				 * [tUniqRow_10 end ] stop
				 */

				/**
				 * [tMap_12 end ] start
				 */

				currentComponent = "tMap_12";

// ###############################
// # Lookup hashes releasing
// ###############################      
				log.debug(
						"tMap_12 - Written records count in the table 'Ped_Action': " + count_Ped_Action_tMap_12 + ".");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "row10", 2, 0,
						"tUniqRow_10", "tUniqRow_10", "tUniqRow", "tMap_12", "tMap_12", "tMap", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tMap_12 - " + ("Done."));

				ok_Hash.put("tMap_12", true);
				end_Hash.put("tMap_12", System.currentTimeMillis());

				/**
				 * [tMap_12 end ] stop
				 */

				/**
				 * [tDBOutput_9 end ] start
				 */

				currentComponent = "tDBOutput_9";

				try {
					int countSum_tDBOutput_9 = 0;
					if (pstmt_tDBOutput_9 != null && batchSizeCounter_tDBOutput_9 > 0) {

						if (log.isDebugEnabled())
							log.debug("tDBOutput_9 - " + ("Executing the ") + ("INSERT") + (" batch."));
						for (int countEach_tDBOutput_9 : pstmt_tDBOutput_9.executeBatch()) {
							if (countEach_tDBOutput_9 == -2 || countEach_tDBOutput_9 == -3) {
								break;
							}
							countSum_tDBOutput_9 += countEach_tDBOutput_9;
						}
						rowsToCommitCount_tDBOutput_9 += countSum_tDBOutput_9;

						if (log.isDebugEnabled())
							log.debug("tDBOutput_9 - " + ("The ") + ("INSERT") + (" batch execution has succeeded."));
					}

					insertedCount_tDBOutput_9 += countSum_tDBOutput_9;

				} catch (java.sql.BatchUpdateException e) {
					globalMap.put("tDBOutput_9_ERROR_MESSAGE", e.getMessage());

					int countSum_tDBOutput_9 = 0;
					for (int countEach_tDBOutput_9 : e.getUpdateCounts()) {
						countSum_tDBOutput_9 += (countEach_tDBOutput_9 < 0 ? 0 : countEach_tDBOutput_9);
					}
					rowsToCommitCount_tDBOutput_9 += countSum_tDBOutput_9;

					insertedCount_tDBOutput_9 += countSum_tDBOutput_9;

					log.error("tDBOutput_9 - " + (e.getMessage()));
					System.err.println(e.getMessage());

				}
				if (pstmt_tDBOutput_9 != null) {

					pstmt_tDBOutput_9.close();
					resourceMap.remove("pstmt_tDBOutput_9");

				}
				resourceMap.put("statementClosed_tDBOutput_9", true);
				if (rowsToCommitCount_tDBOutput_9 != 0) {

					if (log.isDebugEnabled())
						log.debug("tDBOutput_9 - " + ("Connection starting to commit ")
								+ (rowsToCommitCount_tDBOutput_9) + (" record(s)."));
				}
				conn_tDBOutput_9.commit();
				if (rowsToCommitCount_tDBOutput_9 != 0) {

					if (log.isDebugEnabled())
						log.debug("tDBOutput_9 - " + ("Connection commit has succeeded."));
					rowsToCommitCount_tDBOutput_9 = 0;
				}
				commitCounter_tDBOutput_9 = 0;
				if (log.isDebugEnabled())
					log.debug("tDBOutput_9 - " + ("Closing the connection to the database."));
				conn_tDBOutput_9.close();
				if (log.isDebugEnabled())
					log.debug("tDBOutput_9 - " + ("Connection to the database has closed."));
				resourceMap.put("finish_tDBOutput_9", true);

				nb_line_deleted_tDBOutput_9 = nb_line_deleted_tDBOutput_9 + deletedCount_tDBOutput_9;
				nb_line_update_tDBOutput_9 = nb_line_update_tDBOutput_9 + updatedCount_tDBOutput_9;
				nb_line_inserted_tDBOutput_9 = nb_line_inserted_tDBOutput_9 + insertedCount_tDBOutput_9;
				nb_line_rejected_tDBOutput_9 = nb_line_rejected_tDBOutput_9 + rejectedCount_tDBOutput_9;

				globalMap.put("tDBOutput_9_NB_LINE", nb_line_tDBOutput_9);
				globalMap.put("tDBOutput_9_NB_LINE_UPDATED", nb_line_update_tDBOutput_9);
				globalMap.put("tDBOutput_9_NB_LINE_INSERTED", nb_line_inserted_tDBOutput_9);
				globalMap.put("tDBOutput_9_NB_LINE_DELETED", nb_line_deleted_tDBOutput_9);
				globalMap.put("tDBOutput_9_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_9);

				if (log.isDebugEnabled())
					log.debug("tDBOutput_9 - " + ("Has ") + ("inserted") + (" ") + (nb_line_inserted_tDBOutput_9)
							+ (" record(s)."));

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "Ped_Action", 2, 0,
						"tMap_12", "tMap_12", "tMap", "tDBOutput_9", "__TABLE__", "tMSSqlOutput", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tDBOutput_9 - " + ("Done."));

				ok_Hash.put("tDBOutput_9", true);
				end_Hash.put("tDBOutput_9", System.currentTimeMillis());

				/**
				 * [tDBOutput_9 end ] stop
				 */

				/**
				 * [tUniqRow_11 end ] start
				 */

				currentComponent = "tUniqRow_11";

				globalMap.put("tUniqRow_11_NB_UNIQUES", nb_uniques_tUniqRow_11);
				globalMap.put("tUniqRow_11_NB_DUPLICATES", nb_duplicates_tUniqRow_11);
				log.info("tUniqRow_11 - Unique records count: " + (nb_uniques_tUniqRow_11) + " .");
				log.info("tUniqRow_11 - Duplicate records count: " + (nb_duplicates_tUniqRow_11) + " .");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "Complaint", 2, 0,
						"tMap_1", "tMap_1", "tMap", "tUniqRow_11", "tUniqRow_11", "tUniqRow", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tUniqRow_11 - " + ("Done."));

				ok_Hash.put("tUniqRow_11", true);
				end_Hash.put("tUniqRow_11", System.currentTimeMillis());

				/**
				 * [tUniqRow_11 end ] stop
				 */

				/**
				 * [tMap_13 end ] start
				 */

				currentComponent = "tMap_13";

// ###############################
// # Lookup hashes releasing
// ###############################      
				log.debug("tMap_13 - Written records count in the table 'Complain_Load': " + count_Complain_Load_tMap_13
						+ ".");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "row11", 2, 0,
						"tUniqRow_11", "tUniqRow_11", "tUniqRow", "tMap_13", "tMap_13", "tMap", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tMap_13 - " + ("Done."));

				ok_Hash.put("tMap_13", true);
				end_Hash.put("tMap_13", System.currentTimeMillis());

				/**
				 * [tMap_13 end ] stop
				 */

				/**
				 * [tDBOutput_10 end ] start
				 */

				currentComponent = "tDBOutput_10";

				try {
					int countSum_tDBOutput_10 = 0;
					if (pstmt_tDBOutput_10 != null && batchSizeCounter_tDBOutput_10 > 0) {

						if (log.isDebugEnabled())
							log.debug("tDBOutput_10 - " + ("Executing the ") + ("INSERT") + (" batch."));
						for (int countEach_tDBOutput_10 : pstmt_tDBOutput_10.executeBatch()) {
							if (countEach_tDBOutput_10 == -2 || countEach_tDBOutput_10 == -3) {
								break;
							}
							countSum_tDBOutput_10 += countEach_tDBOutput_10;
						}
						rowsToCommitCount_tDBOutput_10 += countSum_tDBOutput_10;

						if (log.isDebugEnabled())
							log.debug("tDBOutput_10 - " + ("The ") + ("INSERT") + (" batch execution has succeeded."));
					}

					insertedCount_tDBOutput_10 += countSum_tDBOutput_10;

				} catch (java.sql.BatchUpdateException e) {
					globalMap.put("tDBOutput_10_ERROR_MESSAGE", e.getMessage());

					int countSum_tDBOutput_10 = 0;
					for (int countEach_tDBOutput_10 : e.getUpdateCounts()) {
						countSum_tDBOutput_10 += (countEach_tDBOutput_10 < 0 ? 0 : countEach_tDBOutput_10);
					}
					rowsToCommitCount_tDBOutput_10 += countSum_tDBOutput_10;

					insertedCount_tDBOutput_10 += countSum_tDBOutput_10;

					log.error("tDBOutput_10 - " + (e.getMessage()));
					System.err.println(e.getMessage());

				}
				if (pstmt_tDBOutput_10 != null) {

					pstmt_tDBOutput_10.close();
					resourceMap.remove("pstmt_tDBOutput_10");

				}
				resourceMap.put("statementClosed_tDBOutput_10", true);
				if (rowsToCommitCount_tDBOutput_10 != 0) {

					if (log.isDebugEnabled())
						log.debug("tDBOutput_10 - " + ("Connection starting to commit ")
								+ (rowsToCommitCount_tDBOutput_10) + (" record(s)."));
				}
				conn_tDBOutput_10.commit();
				if (rowsToCommitCount_tDBOutput_10 != 0) {

					if (log.isDebugEnabled())
						log.debug("tDBOutput_10 - " + ("Connection commit has succeeded."));
					rowsToCommitCount_tDBOutput_10 = 0;
				}
				commitCounter_tDBOutput_10 = 0;
				if (log.isDebugEnabled())
					log.debug("tDBOutput_10 - " + ("Closing the connection to the database."));
				conn_tDBOutput_10.close();
				if (log.isDebugEnabled())
					log.debug("tDBOutput_10 - " + ("Connection to the database has closed."));
				resourceMap.put("finish_tDBOutput_10", true);

				nb_line_deleted_tDBOutput_10 = nb_line_deleted_tDBOutput_10 + deletedCount_tDBOutput_10;
				nb_line_update_tDBOutput_10 = nb_line_update_tDBOutput_10 + updatedCount_tDBOutput_10;
				nb_line_inserted_tDBOutput_10 = nb_line_inserted_tDBOutput_10 + insertedCount_tDBOutput_10;
				nb_line_rejected_tDBOutput_10 = nb_line_rejected_tDBOutput_10 + rejectedCount_tDBOutput_10;

				globalMap.put("tDBOutput_10_NB_LINE", nb_line_tDBOutput_10);
				globalMap.put("tDBOutput_10_NB_LINE_UPDATED", nb_line_update_tDBOutput_10);
				globalMap.put("tDBOutput_10_NB_LINE_INSERTED", nb_line_inserted_tDBOutput_10);
				globalMap.put("tDBOutput_10_NB_LINE_DELETED", nb_line_deleted_tDBOutput_10);
				globalMap.put("tDBOutput_10_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_10);

				if (log.isDebugEnabled())
					log.debug("tDBOutput_10 - " + ("Has ") + ("inserted") + (" ") + (nb_line_inserted_tDBOutput_10)
							+ (" record(s)."));

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "Complain_Load", 2, 0,
						"tMap_13", "tMap_13", "tMap", "tDBOutput_10", "__TABLE__", "tMSSqlOutput", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tDBOutput_10 - " + ("Done."));

				ok_Hash.put("tDBOutput_10", true);
				end_Hash.put("tDBOutput_10", System.currentTimeMillis());

				/**
				 * [tDBOutput_10 end ] stop
				 */

				/**
				 * [tUniqRow_12 end ] start
				 */

				currentComponent = "tUniqRow_12";

				globalMap.put("tUniqRow_12_NB_UNIQUES", nb_uniques_tUniqRow_12);
				globalMap.put("tUniqRow_12_NB_DUPLICATES", nb_duplicates_tUniqRow_12);
				log.info("tUniqRow_12 - Unique records count: " + (nb_uniques_tUniqRow_12) + " .");
				log.info("tUniqRow_12 - Duplicate records count: " + (nb_duplicates_tUniqRow_12) + " .");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "Ped_Role", 2, 0,
						"tMap_1", "tMap_1", "tMap", "tUniqRow_12", "tUniqRow_12", "tUniqRow", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tUniqRow_12 - " + ("Done."));

				ok_Hash.put("tUniqRow_12", true);
				end_Hash.put("tUniqRow_12", System.currentTimeMillis());

				/**
				 * [tUniqRow_12 end ] stop
				 */

				/**
				 * [tMap_14 end ] start
				 */

				currentComponent = "tMap_14";

// ###############################
// # Lookup hashes releasing
// ###############################      
				log.debug("tMap_14 - Written records count in the table 'Ped_Role_Load': " + count_Ped_Role_Load_tMap_14
						+ ".");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "row12", 2, 0,
						"tUniqRow_12", "tUniqRow_12", "tUniqRow", "tMap_14", "tMap_14", "tMap", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tMap_14 - " + ("Done."));

				ok_Hash.put("tMap_14", true);
				end_Hash.put("tMap_14", System.currentTimeMillis());

				/**
				 * [tMap_14 end ] stop
				 */

				/**
				 * [tDBOutput_11 end ] start
				 */

				currentComponent = "tDBOutput_11";

				try {
					int countSum_tDBOutput_11 = 0;
					if (pstmt_tDBOutput_11 != null && batchSizeCounter_tDBOutput_11 > 0) {

						if (log.isDebugEnabled())
							log.debug("tDBOutput_11 - " + ("Executing the ") + ("INSERT") + (" batch."));
						for (int countEach_tDBOutput_11 : pstmt_tDBOutput_11.executeBatch()) {
							if (countEach_tDBOutput_11 == -2 || countEach_tDBOutput_11 == -3) {
								break;
							}
							countSum_tDBOutput_11 += countEach_tDBOutput_11;
						}
						rowsToCommitCount_tDBOutput_11 += countSum_tDBOutput_11;

						if (log.isDebugEnabled())
							log.debug("tDBOutput_11 - " + ("The ") + ("INSERT") + (" batch execution has succeeded."));
					}

					insertedCount_tDBOutput_11 += countSum_tDBOutput_11;

				} catch (java.sql.BatchUpdateException e) {
					globalMap.put("tDBOutput_11_ERROR_MESSAGE", e.getMessage());

					int countSum_tDBOutput_11 = 0;
					for (int countEach_tDBOutput_11 : e.getUpdateCounts()) {
						countSum_tDBOutput_11 += (countEach_tDBOutput_11 < 0 ? 0 : countEach_tDBOutput_11);
					}
					rowsToCommitCount_tDBOutput_11 += countSum_tDBOutput_11;

					insertedCount_tDBOutput_11 += countSum_tDBOutput_11;

					log.error("tDBOutput_11 - " + (e.getMessage()));
					System.err.println(e.getMessage());

				}
				if (pstmt_tDBOutput_11 != null) {

					pstmt_tDBOutput_11.close();
					resourceMap.remove("pstmt_tDBOutput_11");

				}
				resourceMap.put("statementClosed_tDBOutput_11", true);
				if (rowsToCommitCount_tDBOutput_11 != 0) {

					if (log.isDebugEnabled())
						log.debug("tDBOutput_11 - " + ("Connection starting to commit ")
								+ (rowsToCommitCount_tDBOutput_11) + (" record(s)."));
				}
				conn_tDBOutput_11.commit();
				if (rowsToCommitCount_tDBOutput_11 != 0) {

					if (log.isDebugEnabled())
						log.debug("tDBOutput_11 - " + ("Connection commit has succeeded."));
					rowsToCommitCount_tDBOutput_11 = 0;
				}
				commitCounter_tDBOutput_11 = 0;
				if (log.isDebugEnabled())
					log.debug("tDBOutput_11 - " + ("Closing the connection to the database."));
				conn_tDBOutput_11.close();
				if (log.isDebugEnabled())
					log.debug("tDBOutput_11 - " + ("Connection to the database has closed."));
				resourceMap.put("finish_tDBOutput_11", true);

				nb_line_deleted_tDBOutput_11 = nb_line_deleted_tDBOutput_11 + deletedCount_tDBOutput_11;
				nb_line_update_tDBOutput_11 = nb_line_update_tDBOutput_11 + updatedCount_tDBOutput_11;
				nb_line_inserted_tDBOutput_11 = nb_line_inserted_tDBOutput_11 + insertedCount_tDBOutput_11;
				nb_line_rejected_tDBOutput_11 = nb_line_rejected_tDBOutput_11 + rejectedCount_tDBOutput_11;

				globalMap.put("tDBOutput_11_NB_LINE", nb_line_tDBOutput_11);
				globalMap.put("tDBOutput_11_NB_LINE_UPDATED", nb_line_update_tDBOutput_11);
				globalMap.put("tDBOutput_11_NB_LINE_INSERTED", nb_line_inserted_tDBOutput_11);
				globalMap.put("tDBOutput_11_NB_LINE_DELETED", nb_line_deleted_tDBOutput_11);
				globalMap.put("tDBOutput_11_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_11);

				if (log.isDebugEnabled())
					log.debug("tDBOutput_11 - " + ("Has ") + ("inserted") + (" ") + (nb_line_inserted_tDBOutput_11)
							+ (" record(s)."));

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "Ped_Role_Load", 2, 0,
						"tMap_14", "tMap_14", "tMap", "tDBOutput_11", "__TABLE__", "tMSSqlOutput", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tDBOutput_11 - " + ("Done."));

				ok_Hash.put("tDBOutput_11", true);
				end_Hash.put("tDBOutput_11", System.currentTimeMillis());

				/**
				 * [tDBOutput_11 end ] stop
				 */

				/**
				 * [tUniqRow_13 end ] start
				 */

				currentComponent = "tUniqRow_13";

				globalMap.put("tUniqRow_13_NB_UNIQUES", nb_uniques_tUniqRow_13);
				globalMap.put("tUniqRow_13_NB_DUPLICATES", nb_duplicates_tUniqRow_13);
				log.info("tUniqRow_13 - Unique records count: " + (nb_uniques_tUniqRow_13) + " .");
				log.info("tUniqRow_13 - Duplicate records count: " + (nb_duplicates_tUniqRow_13) + " .");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "Person_Sex", 2, 0,
						"tMap_1", "tMap_1", "tMap", "tUniqRow_13", "tUniqRow_13", "tUniqRow", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tUniqRow_13 - " + ("Done."));

				ok_Hash.put("tUniqRow_13", true);
				end_Hash.put("tUniqRow_13", System.currentTimeMillis());

				/**
				 * [tUniqRow_13 end ] stop
				 */

				/**
				 * [tMap_15 end ] start
				 */

				currentComponent = "tMap_15";

// ###############################
// # Lookup hashes releasing
// ###############################      
				log.debug("tMap_15 - Written records count in the table 'Person_Sex1': " + count_Person_Sex1_tMap_15
						+ ".");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "row13", 2, 0,
						"tUniqRow_13", "tUniqRow_13", "tUniqRow", "tMap_15", "tMap_15", "tMap", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tMap_15 - " + ("Done."));

				ok_Hash.put("tMap_15", true);
				end_Hash.put("tMap_15", System.currentTimeMillis());

				/**
				 * [tMap_15 end ] stop
				 */

				/**
				 * [tDBOutput_12 end ] start
				 */

				currentComponent = "tDBOutput_12";

				try {
					int countSum_tDBOutput_12 = 0;
					if (pstmt_tDBOutput_12 != null && batchSizeCounter_tDBOutput_12 > 0) {

						if (log.isDebugEnabled())
							log.debug("tDBOutput_12 - " + ("Executing the ") + ("INSERT") + (" batch."));
						for (int countEach_tDBOutput_12 : pstmt_tDBOutput_12.executeBatch()) {
							if (countEach_tDBOutput_12 == -2 || countEach_tDBOutput_12 == -3) {
								break;
							}
							countSum_tDBOutput_12 += countEach_tDBOutput_12;
						}
						rowsToCommitCount_tDBOutput_12 += countSum_tDBOutput_12;

						if (log.isDebugEnabled())
							log.debug("tDBOutput_12 - " + ("The ") + ("INSERT") + (" batch execution has succeeded."));
					}

					insertedCount_tDBOutput_12 += countSum_tDBOutput_12;

				} catch (java.sql.BatchUpdateException e) {
					globalMap.put("tDBOutput_12_ERROR_MESSAGE", e.getMessage());

					int countSum_tDBOutput_12 = 0;
					for (int countEach_tDBOutput_12 : e.getUpdateCounts()) {
						countSum_tDBOutput_12 += (countEach_tDBOutput_12 < 0 ? 0 : countEach_tDBOutput_12);
					}
					rowsToCommitCount_tDBOutput_12 += countSum_tDBOutput_12;

					insertedCount_tDBOutput_12 += countSum_tDBOutput_12;

					log.error("tDBOutput_12 - " + (e.getMessage()));
					System.err.println(e.getMessage());

				}
				if (pstmt_tDBOutput_12 != null) {

					pstmt_tDBOutput_12.close();
					resourceMap.remove("pstmt_tDBOutput_12");

				}
				resourceMap.put("statementClosed_tDBOutput_12", true);
				if (rowsToCommitCount_tDBOutput_12 != 0) {

					if (log.isDebugEnabled())
						log.debug("tDBOutput_12 - " + ("Connection starting to commit ")
								+ (rowsToCommitCount_tDBOutput_12) + (" record(s)."));
				}
				conn_tDBOutput_12.commit();
				if (rowsToCommitCount_tDBOutput_12 != 0) {

					if (log.isDebugEnabled())
						log.debug("tDBOutput_12 - " + ("Connection commit has succeeded."));
					rowsToCommitCount_tDBOutput_12 = 0;
				}
				commitCounter_tDBOutput_12 = 0;
				if (log.isDebugEnabled())
					log.debug("tDBOutput_12 - " + ("Closing the connection to the database."));
				conn_tDBOutput_12.close();
				if (log.isDebugEnabled())
					log.debug("tDBOutput_12 - " + ("Connection to the database has closed."));
				resourceMap.put("finish_tDBOutput_12", true);

				nb_line_deleted_tDBOutput_12 = nb_line_deleted_tDBOutput_12 + deletedCount_tDBOutput_12;
				nb_line_update_tDBOutput_12 = nb_line_update_tDBOutput_12 + updatedCount_tDBOutput_12;
				nb_line_inserted_tDBOutput_12 = nb_line_inserted_tDBOutput_12 + insertedCount_tDBOutput_12;
				nb_line_rejected_tDBOutput_12 = nb_line_rejected_tDBOutput_12 + rejectedCount_tDBOutput_12;

				globalMap.put("tDBOutput_12_NB_LINE", nb_line_tDBOutput_12);
				globalMap.put("tDBOutput_12_NB_LINE_UPDATED", nb_line_update_tDBOutput_12);
				globalMap.put("tDBOutput_12_NB_LINE_INSERTED", nb_line_inserted_tDBOutput_12);
				globalMap.put("tDBOutput_12_NB_LINE_DELETED", nb_line_deleted_tDBOutput_12);
				globalMap.put("tDBOutput_12_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_12);

				if (log.isDebugEnabled())
					log.debug("tDBOutput_12 - " + ("Has ") + ("inserted") + (" ") + (nb_line_inserted_tDBOutput_12)
							+ (" record(s)."));

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "Person_Sex1", 2, 0,
						"tMap_15", "tMap_15", "tMap", "tDBOutput_12", "__TABLE__", "tMSSqlOutput", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tDBOutput_12 - " + ("Done."));

				ok_Hash.put("tDBOutput_12", true);
				end_Hash.put("tDBOutput_12", System.currentTimeMillis());

				/**
				 * [tDBOutput_12 end ] stop
				 */

			} // end the resume

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage(), e);
			}

			TalendException te = new TalendException(e, currentComponent, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [tDBInput_1 finally ] start
				 */

				currentComponent = "tDBInput_1";

				/**
				 * [tDBInput_1 finally ] stop
				 */

				/**
				 * [tMap_1 finally ] start
				 */

				currentComponent = "tMap_1";

				/**
				 * [tMap_1 finally ] stop
				 */

				/**
				 * [tUniqRow_1 finally ] start
				 */

				currentComponent = "tUniqRow_1";

				/**
				 * [tUniqRow_1 finally ] stop
				 */

				/**
				 * [tMap_2 finally ] start
				 */

				currentComponent = "tMap_2";

				/**
				 * [tMap_2 finally ] stop
				 */

				/**
				 * [tDBOutput_1 finally ] start
				 */

				currentComponent = "tDBOutput_1";

				try {
					if (resourceMap.get("statementClosed_tDBOutput_1") == null) {
						java.sql.PreparedStatement pstmtToClose_tDBOutput_1 = null;
						if ((pstmtToClose_tDBOutput_1 = (java.sql.PreparedStatement) resourceMap
								.remove("pstmt_tDBOutput_1")) != null) {
							pstmtToClose_tDBOutput_1.close();
						}
					}
				} finally {
					if (resourceMap.get("finish_tDBOutput_1") == null) {
						java.sql.Connection ctn_tDBOutput_1 = null;
						if ((ctn_tDBOutput_1 = (java.sql.Connection) resourceMap.get("conn_tDBOutput_1")) != null) {
							try {
								if (log.isDebugEnabled())
									log.debug("tDBOutput_1 - " + ("Closing the connection to the database."));
								ctn_tDBOutput_1.close();
								if (log.isDebugEnabled())
									log.debug("tDBOutput_1 - " + ("Connection to the database has closed."));
							} catch (java.sql.SQLException sqlEx_tDBOutput_1) {
								String errorMessage_tDBOutput_1 = "failed to close the connection in tDBOutput_1 :"
										+ sqlEx_tDBOutput_1.getMessage();
								log.error("tDBOutput_1 - " + (errorMessage_tDBOutput_1));
								System.err.println(errorMessage_tDBOutput_1);
							}
						}
					}
				}

				/**
				 * [tDBOutput_1 finally ] stop
				 */

				/**
				 * [tUniqRow_2 finally ] start
				 */

				currentComponent = "tUniqRow_2";

				/**
				 * [tUniqRow_2 finally ] stop
				 */

				/**
				 * [tMap_3 finally ] start
				 */

				currentComponent = "tMap_3";

				/**
				 * [tMap_3 finally ] stop
				 */

				/**
				 * [tDBOutput_2 finally ] start
				 */

				currentComponent = "tDBOutput_2";

				try {
					if (resourceMap.get("statementClosed_tDBOutput_2") == null) {
						java.sql.PreparedStatement pstmtToClose_tDBOutput_2 = null;
						if ((pstmtToClose_tDBOutput_2 = (java.sql.PreparedStatement) resourceMap
								.remove("pstmt_tDBOutput_2")) != null) {
							pstmtToClose_tDBOutput_2.close();
						}
					}
				} finally {
					if (resourceMap.get("finish_tDBOutput_2") == null) {
						java.sql.Connection ctn_tDBOutput_2 = null;
						if ((ctn_tDBOutput_2 = (java.sql.Connection) resourceMap.get("conn_tDBOutput_2")) != null) {
							try {
								if (log.isDebugEnabled())
									log.debug("tDBOutput_2 - " + ("Closing the connection to the database."));
								ctn_tDBOutput_2.close();
								if (log.isDebugEnabled())
									log.debug("tDBOutput_2 - " + ("Connection to the database has closed."));
							} catch (java.sql.SQLException sqlEx_tDBOutput_2) {
								String errorMessage_tDBOutput_2 = "failed to close the connection in tDBOutput_2 :"
										+ sqlEx_tDBOutput_2.getMessage();
								log.error("tDBOutput_2 - " + (errorMessage_tDBOutput_2));
								System.err.println(errorMessage_tDBOutput_2);
							}
						}
					}
				}

				/**
				 * [tDBOutput_2 finally ] stop
				 */

				/**
				 * [tUniqRow_3 finally ] start
				 */

				currentComponent = "tUniqRow_3";

				/**
				 * [tUniqRow_3 finally ] stop
				 */

				/**
				 * [tMap_4 finally ] start
				 */

				currentComponent = "tMap_4";

				/**
				 * [tMap_4 finally ] stop
				 */

				/**
				 * [tDBOutput_3 finally ] start
				 */

				currentComponent = "tDBOutput_3";

				try {
					if (resourceMap.get("statementClosed_tDBOutput_3") == null) {
						java.sql.PreparedStatement pstmtToClose_tDBOutput_3 = null;
						if ((pstmtToClose_tDBOutput_3 = (java.sql.PreparedStatement) resourceMap
								.remove("pstmt_tDBOutput_3")) != null) {
							pstmtToClose_tDBOutput_3.close();
						}
					}
				} finally {
					if (resourceMap.get("finish_tDBOutput_3") == null) {
						java.sql.Connection ctn_tDBOutput_3 = null;
						if ((ctn_tDBOutput_3 = (java.sql.Connection) resourceMap.get("conn_tDBOutput_3")) != null) {
							try {
								if (log.isDebugEnabled())
									log.debug("tDBOutput_3 - " + ("Closing the connection to the database."));
								ctn_tDBOutput_3.close();
								if (log.isDebugEnabled())
									log.debug("tDBOutput_3 - " + ("Connection to the database has closed."));
							} catch (java.sql.SQLException sqlEx_tDBOutput_3) {
								String errorMessage_tDBOutput_3 = "failed to close the connection in tDBOutput_3 :"
										+ sqlEx_tDBOutput_3.getMessage();
								log.error("tDBOutput_3 - " + (errorMessage_tDBOutput_3));
								System.err.println(errorMessage_tDBOutput_3);
							}
						}
					}
				}

				/**
				 * [tDBOutput_3 finally ] stop
				 */

				/**
				 * [tUniqRow_5 finally ] start
				 */

				currentComponent = "tUniqRow_5";

				/**
				 * [tUniqRow_5 finally ] stop
				 */

				/**
				 * [tMap_6 finally ] start
				 */

				currentComponent = "tMap_6";

				/**
				 * [tMap_6 finally ] stop
				 */

				/**
				 * [tDBOutput_4 finally ] start
				 */

				currentComponent = "tDBOutput_4";

				try {
					if (resourceMap.get("statementClosed_tDBOutput_4") == null) {
						java.sql.PreparedStatement pstmtToClose_tDBOutput_4 = null;
						if ((pstmtToClose_tDBOutput_4 = (java.sql.PreparedStatement) resourceMap
								.remove("pstmt_tDBOutput_4")) != null) {
							pstmtToClose_tDBOutput_4.close();
						}
					}
				} finally {
					if (resourceMap.get("finish_tDBOutput_4") == null) {
						java.sql.Connection ctn_tDBOutput_4 = null;
						if ((ctn_tDBOutput_4 = (java.sql.Connection) resourceMap.get("conn_tDBOutput_4")) != null) {
							try {
								if (log.isDebugEnabled())
									log.debug("tDBOutput_4 - " + ("Closing the connection to the database."));
								ctn_tDBOutput_4.close();
								if (log.isDebugEnabled())
									log.debug("tDBOutput_4 - " + ("Connection to the database has closed."));
							} catch (java.sql.SQLException sqlEx_tDBOutput_4) {
								String errorMessage_tDBOutput_4 = "failed to close the connection in tDBOutput_4 :"
										+ sqlEx_tDBOutput_4.getMessage();
								log.error("tDBOutput_4 - " + (errorMessage_tDBOutput_4));
								System.err.println(errorMessage_tDBOutput_4);
							}
						}
					}
				}

				/**
				 * [tDBOutput_4 finally ] stop
				 */

				/**
				 * [tUniqRow_7 finally ] start
				 */

				currentComponent = "tUniqRow_7";

				/**
				 * [tUniqRow_7 finally ] stop
				 */

				/**
				 * [tMap_7 finally ] start
				 */

				currentComponent = "tMap_7";

				/**
				 * [tMap_7 finally ] stop
				 */

				/**
				 * [tDBOutput_5 finally ] start
				 */

				currentComponent = "tDBOutput_5";

				try {
					if (resourceMap.get("statementClosed_tDBOutput_5") == null) {
						java.sql.PreparedStatement pstmtToClose_tDBOutput_5 = null;
						if ((pstmtToClose_tDBOutput_5 = (java.sql.PreparedStatement) resourceMap
								.remove("pstmt_tDBOutput_5")) != null) {
							pstmtToClose_tDBOutput_5.close();
						}
					}
				} finally {
					if (resourceMap.get("finish_tDBOutput_5") == null) {
						java.sql.Connection ctn_tDBOutput_5 = null;
						if ((ctn_tDBOutput_5 = (java.sql.Connection) resourceMap.get("conn_tDBOutput_5")) != null) {
							try {
								if (log.isDebugEnabled())
									log.debug("tDBOutput_5 - " + ("Closing the connection to the database."));
								ctn_tDBOutput_5.close();
								if (log.isDebugEnabled())
									log.debug("tDBOutput_5 - " + ("Connection to the database has closed."));
							} catch (java.sql.SQLException sqlEx_tDBOutput_5) {
								String errorMessage_tDBOutput_5 = "failed to close the connection in tDBOutput_5 :"
										+ sqlEx_tDBOutput_5.getMessage();
								log.error("tDBOutput_5 - " + (errorMessage_tDBOutput_5));
								System.err.println(errorMessage_tDBOutput_5);
							}
						}
					}
				}

				/**
				 * [tDBOutput_5 finally ] stop
				 */

				/**
				 * [tUniqRow_4 finally ] start
				 */

				currentComponent = "tUniqRow_4";

				/**
				 * [tUniqRow_4 finally ] stop
				 */

				/**
				 * [tMap_9 finally ] start
				 */

				currentComponent = "tMap_9";

				/**
				 * [tMap_9 finally ] stop
				 */

				/**
				 * [tDBOutput_6 finally ] start
				 */

				currentComponent = "tDBOutput_6";

				try {
					if (resourceMap.get("statementClosed_tDBOutput_6") == null) {
						java.sql.PreparedStatement pstmtToClose_tDBOutput_6 = null;
						if ((pstmtToClose_tDBOutput_6 = (java.sql.PreparedStatement) resourceMap
								.remove("pstmt_tDBOutput_6")) != null) {
							pstmtToClose_tDBOutput_6.close();
						}
					}
				} finally {
					if (resourceMap.get("finish_tDBOutput_6") == null) {
						java.sql.Connection ctn_tDBOutput_6 = null;
						if ((ctn_tDBOutput_6 = (java.sql.Connection) resourceMap.get("conn_tDBOutput_6")) != null) {
							try {
								if (log.isDebugEnabled())
									log.debug("tDBOutput_6 - " + ("Closing the connection to the database."));
								ctn_tDBOutput_6.close();
								if (log.isDebugEnabled())
									log.debug("tDBOutput_6 - " + ("Connection to the database has closed."));
							} catch (java.sql.SQLException sqlEx_tDBOutput_6) {
								String errorMessage_tDBOutput_6 = "failed to close the connection in tDBOutput_6 :"
										+ sqlEx_tDBOutput_6.getMessage();
								log.error("tDBOutput_6 - " + (errorMessage_tDBOutput_6));
								System.err.println(errorMessage_tDBOutput_6);
							}
						}
					}
				}

				/**
				 * [tDBOutput_6 finally ] stop
				 */

				/**
				 * [tUniqRow_8 finally ] start
				 */

				currentComponent = "tUniqRow_8";

				/**
				 * [tUniqRow_8 finally ] stop
				 */

				/**
				 * [tMap_10 finally ] start
				 */

				currentComponent = "tMap_10";

				/**
				 * [tMap_10 finally ] stop
				 */

				/**
				 * [tDBOutput_7 finally ] start
				 */

				currentComponent = "tDBOutput_7";

				try {
					if (resourceMap.get("statementClosed_tDBOutput_7") == null) {
						java.sql.PreparedStatement pstmtToClose_tDBOutput_7 = null;
						if ((pstmtToClose_tDBOutput_7 = (java.sql.PreparedStatement) resourceMap
								.remove("pstmt_tDBOutput_7")) != null) {
							pstmtToClose_tDBOutput_7.close();
						}
					}
				} finally {
					if (resourceMap.get("finish_tDBOutput_7") == null) {
						java.sql.Connection ctn_tDBOutput_7 = null;
						if ((ctn_tDBOutput_7 = (java.sql.Connection) resourceMap.get("conn_tDBOutput_7")) != null) {
							try {
								if (log.isDebugEnabled())
									log.debug("tDBOutput_7 - " + ("Closing the connection to the database."));
								ctn_tDBOutput_7.close();
								if (log.isDebugEnabled())
									log.debug("tDBOutput_7 - " + ("Connection to the database has closed."));
							} catch (java.sql.SQLException sqlEx_tDBOutput_7) {
								String errorMessage_tDBOutput_7 = "failed to close the connection in tDBOutput_7 :"
										+ sqlEx_tDBOutput_7.getMessage();
								log.error("tDBOutput_7 - " + (errorMessage_tDBOutput_7));
								System.err.println(errorMessage_tDBOutput_7);
							}
						}
					}
				}

				/**
				 * [tDBOutput_7 finally ] stop
				 */

				/**
				 * [tUniqRow_9 finally ] start
				 */

				currentComponent = "tUniqRow_9";

				/**
				 * [tUniqRow_9 finally ] stop
				 */

				/**
				 * [tMap_11 finally ] start
				 */

				currentComponent = "tMap_11";

				/**
				 * [tMap_11 finally ] stop
				 */

				/**
				 * [tDBOutput_8 finally ] start
				 */

				currentComponent = "tDBOutput_8";

				try {
					if (resourceMap.get("statementClosed_tDBOutput_8") == null) {
						java.sql.PreparedStatement pstmtToClose_tDBOutput_8 = null;
						if ((pstmtToClose_tDBOutput_8 = (java.sql.PreparedStatement) resourceMap
								.remove("pstmt_tDBOutput_8")) != null) {
							pstmtToClose_tDBOutput_8.close();
						}
					}
				} finally {
					if (resourceMap.get("finish_tDBOutput_8") == null) {
						java.sql.Connection ctn_tDBOutput_8 = null;
						if ((ctn_tDBOutput_8 = (java.sql.Connection) resourceMap.get("conn_tDBOutput_8")) != null) {
							try {
								if (log.isDebugEnabled())
									log.debug("tDBOutput_8 - " + ("Closing the connection to the database."));
								ctn_tDBOutput_8.close();
								if (log.isDebugEnabled())
									log.debug("tDBOutput_8 - " + ("Connection to the database has closed."));
							} catch (java.sql.SQLException sqlEx_tDBOutput_8) {
								String errorMessage_tDBOutput_8 = "failed to close the connection in tDBOutput_8 :"
										+ sqlEx_tDBOutput_8.getMessage();
								log.error("tDBOutput_8 - " + (errorMessage_tDBOutput_8));
								System.err.println(errorMessage_tDBOutput_8);
							}
						}
					}
				}

				/**
				 * [tDBOutput_8 finally ] stop
				 */

				/**
				 * [tUniqRow_10 finally ] start
				 */

				currentComponent = "tUniqRow_10";

				/**
				 * [tUniqRow_10 finally ] stop
				 */

				/**
				 * [tMap_12 finally ] start
				 */

				currentComponent = "tMap_12";

				/**
				 * [tMap_12 finally ] stop
				 */

				/**
				 * [tDBOutput_9 finally ] start
				 */

				currentComponent = "tDBOutput_9";

				try {
					if (resourceMap.get("statementClosed_tDBOutput_9") == null) {
						java.sql.PreparedStatement pstmtToClose_tDBOutput_9 = null;
						if ((pstmtToClose_tDBOutput_9 = (java.sql.PreparedStatement) resourceMap
								.remove("pstmt_tDBOutput_9")) != null) {
							pstmtToClose_tDBOutput_9.close();
						}
					}
				} finally {
					if (resourceMap.get("finish_tDBOutput_9") == null) {
						java.sql.Connection ctn_tDBOutput_9 = null;
						if ((ctn_tDBOutput_9 = (java.sql.Connection) resourceMap.get("conn_tDBOutput_9")) != null) {
							try {
								if (log.isDebugEnabled())
									log.debug("tDBOutput_9 - " + ("Closing the connection to the database."));
								ctn_tDBOutput_9.close();
								if (log.isDebugEnabled())
									log.debug("tDBOutput_9 - " + ("Connection to the database has closed."));
							} catch (java.sql.SQLException sqlEx_tDBOutput_9) {
								String errorMessage_tDBOutput_9 = "failed to close the connection in tDBOutput_9 :"
										+ sqlEx_tDBOutput_9.getMessage();
								log.error("tDBOutput_9 - " + (errorMessage_tDBOutput_9));
								System.err.println(errorMessage_tDBOutput_9);
							}
						}
					}
				}

				/**
				 * [tDBOutput_9 finally ] stop
				 */

				/**
				 * [tUniqRow_11 finally ] start
				 */

				currentComponent = "tUniqRow_11";

				/**
				 * [tUniqRow_11 finally ] stop
				 */

				/**
				 * [tMap_13 finally ] start
				 */

				currentComponent = "tMap_13";

				/**
				 * [tMap_13 finally ] stop
				 */

				/**
				 * [tDBOutput_10 finally ] start
				 */

				currentComponent = "tDBOutput_10";

				try {
					if (resourceMap.get("statementClosed_tDBOutput_10") == null) {
						java.sql.PreparedStatement pstmtToClose_tDBOutput_10 = null;
						if ((pstmtToClose_tDBOutput_10 = (java.sql.PreparedStatement) resourceMap
								.remove("pstmt_tDBOutput_10")) != null) {
							pstmtToClose_tDBOutput_10.close();
						}
					}
				} finally {
					if (resourceMap.get("finish_tDBOutput_10") == null) {
						java.sql.Connection ctn_tDBOutput_10 = null;
						if ((ctn_tDBOutput_10 = (java.sql.Connection) resourceMap.get("conn_tDBOutput_10")) != null) {
							try {
								if (log.isDebugEnabled())
									log.debug("tDBOutput_10 - " + ("Closing the connection to the database."));
								ctn_tDBOutput_10.close();
								if (log.isDebugEnabled())
									log.debug("tDBOutput_10 - " + ("Connection to the database has closed."));
							} catch (java.sql.SQLException sqlEx_tDBOutput_10) {
								String errorMessage_tDBOutput_10 = "failed to close the connection in tDBOutput_10 :"
										+ sqlEx_tDBOutput_10.getMessage();
								log.error("tDBOutput_10 - " + (errorMessage_tDBOutput_10));
								System.err.println(errorMessage_tDBOutput_10);
							}
						}
					}
				}

				/**
				 * [tDBOutput_10 finally ] stop
				 */

				/**
				 * [tUniqRow_12 finally ] start
				 */

				currentComponent = "tUniqRow_12";

				/**
				 * [tUniqRow_12 finally ] stop
				 */

				/**
				 * [tMap_14 finally ] start
				 */

				currentComponent = "tMap_14";

				/**
				 * [tMap_14 finally ] stop
				 */

				/**
				 * [tDBOutput_11 finally ] start
				 */

				currentComponent = "tDBOutput_11";

				try {
					if (resourceMap.get("statementClosed_tDBOutput_11") == null) {
						java.sql.PreparedStatement pstmtToClose_tDBOutput_11 = null;
						if ((pstmtToClose_tDBOutput_11 = (java.sql.PreparedStatement) resourceMap
								.remove("pstmt_tDBOutput_11")) != null) {
							pstmtToClose_tDBOutput_11.close();
						}
					}
				} finally {
					if (resourceMap.get("finish_tDBOutput_11") == null) {
						java.sql.Connection ctn_tDBOutput_11 = null;
						if ((ctn_tDBOutput_11 = (java.sql.Connection) resourceMap.get("conn_tDBOutput_11")) != null) {
							try {
								if (log.isDebugEnabled())
									log.debug("tDBOutput_11 - " + ("Closing the connection to the database."));
								ctn_tDBOutput_11.close();
								if (log.isDebugEnabled())
									log.debug("tDBOutput_11 - " + ("Connection to the database has closed."));
							} catch (java.sql.SQLException sqlEx_tDBOutput_11) {
								String errorMessage_tDBOutput_11 = "failed to close the connection in tDBOutput_11 :"
										+ sqlEx_tDBOutput_11.getMessage();
								log.error("tDBOutput_11 - " + (errorMessage_tDBOutput_11));
								System.err.println(errorMessage_tDBOutput_11);
							}
						}
					}
				}

				/**
				 * [tDBOutput_11 finally ] stop
				 */

				/**
				 * [tUniqRow_13 finally ] start
				 */

				currentComponent = "tUniqRow_13";

				/**
				 * [tUniqRow_13 finally ] stop
				 */

				/**
				 * [tMap_15 finally ] start
				 */

				currentComponent = "tMap_15";

				/**
				 * [tMap_15 finally ] stop
				 */

				/**
				 * [tDBOutput_12 finally ] start
				 */

				currentComponent = "tDBOutput_12";

				try {
					if (resourceMap.get("statementClosed_tDBOutput_12") == null) {
						java.sql.PreparedStatement pstmtToClose_tDBOutput_12 = null;
						if ((pstmtToClose_tDBOutput_12 = (java.sql.PreparedStatement) resourceMap
								.remove("pstmt_tDBOutput_12")) != null) {
							pstmtToClose_tDBOutput_12.close();
						}
					}
				} finally {
					if (resourceMap.get("finish_tDBOutput_12") == null) {
						java.sql.Connection ctn_tDBOutput_12 = null;
						if ((ctn_tDBOutput_12 = (java.sql.Connection) resourceMap.get("conn_tDBOutput_12")) != null) {
							try {
								if (log.isDebugEnabled())
									log.debug("tDBOutput_12 - " + ("Closing the connection to the database."));
								ctn_tDBOutput_12.close();
								if (log.isDebugEnabled())
									log.debug("tDBOutput_12 - " + ("Connection to the database has closed."));
							} catch (java.sql.SQLException sqlEx_tDBOutput_12) {
								String errorMessage_tDBOutput_12 = "failed to close the connection in tDBOutput_12 :"
										+ sqlEx_tDBOutput_12.getMessage();
								log.error("tDBOutput_12 - " + (errorMessage_tDBOutput_12));
								System.err.println(errorMessage_tDBOutput_12);
							}
						}
					}
				}

				/**
				 * [tDBOutput_12 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tDBInput_1_SUBPROCESS_STATE", 1);
	}

	public void talendJobLogProcess(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("talendJobLog_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				/**
				 * [talendJobLog begin ] start
				 */

				ok_Hash.put("talendJobLog", false);
				start_Hash.put("talendJobLog", System.currentTimeMillis());

				currentComponent = "talendJobLog";

				int tos_count_talendJobLog = 0;

				for (JobStructureCatcherUtils.JobStructureCatcherMessage jcm : talendJobLog.getMessages()) {
					org.talend.job.audit.JobContextBuilder builder_talendJobLog = org.talend.job.audit.JobContextBuilder
							.create().jobName(jcm.job_name).jobId(jcm.job_id).jobVersion(jcm.job_version)
							.custom("process_id", jcm.pid).custom("thread_id", jcm.tid).custom("pid", pid)
							.custom("father_pid", fatherPid).custom("root_pid", rootPid);
					org.talend.logging.audit.Context log_context_talendJobLog = null;

					if (jcm.log_type == JobStructureCatcherUtils.LogType.PERFORMANCE) {
						long timeMS = jcm.end_time - jcm.start_time;
						String duration = String.valueOf(timeMS);

						log_context_talendJobLog = builder_talendJobLog.sourceId(jcm.sourceId)
								.sourceLabel(jcm.sourceLabel).sourceConnectorType(jcm.sourceComponentName)
								.targetId(jcm.targetId).targetLabel(jcm.targetLabel)
								.targetConnectorType(jcm.targetComponentName).connectionName(jcm.current_connector)
								.rows(jcm.row_count).duration(duration).build();
						auditLogger_talendJobLog.flowExecution(log_context_talendJobLog);
					} else if (jcm.log_type == JobStructureCatcherUtils.LogType.JOBSTART) {
						log_context_talendJobLog = builder_talendJobLog.timestamp(jcm.moment).build();
						auditLogger_talendJobLog.jobstart(log_context_talendJobLog);
					} else if (jcm.log_type == JobStructureCatcherUtils.LogType.JOBEND) {
						long timeMS = jcm.end_time - jcm.start_time;
						String duration = String.valueOf(timeMS);

						log_context_talendJobLog = builder_talendJobLog.timestamp(jcm.moment).duration(duration)
								.status(jcm.status).build();
						auditLogger_talendJobLog.jobstop(log_context_talendJobLog);
					} else if (jcm.log_type == JobStructureCatcherUtils.LogType.RUNCOMPONENT) {
						log_context_talendJobLog = builder_talendJobLog.timestamp(jcm.moment)
								.connectorType(jcm.component_name).connectorId(jcm.component_id)
								.connectorLabel(jcm.component_label).build();
						auditLogger_talendJobLog.runcomponent(log_context_talendJobLog);
					} else if (jcm.log_type == JobStructureCatcherUtils.LogType.FLOWINPUT) {// log current component
																							// input line
						long timeMS = jcm.end_time - jcm.start_time;
						String duration = String.valueOf(timeMS);

						log_context_talendJobLog = builder_talendJobLog.connectorType(jcm.component_name)
								.connectorId(jcm.component_id).connectorLabel(jcm.component_label)
								.connectionName(jcm.current_connector).connectionType(jcm.current_connector_type)
								.rows(jcm.total_row_number).duration(duration).build();
						auditLogger_talendJobLog.flowInput(log_context_talendJobLog);
					} else if (jcm.log_type == JobStructureCatcherUtils.LogType.FLOWOUTPUT) {// log current component
																								// output/reject line
						long timeMS = jcm.end_time - jcm.start_time;
						String duration = String.valueOf(timeMS);

						log_context_talendJobLog = builder_talendJobLog.connectorType(jcm.component_name)
								.connectorId(jcm.component_id).connectorLabel(jcm.component_label)
								.connectionName(jcm.current_connector).connectionType(jcm.current_connector_type)
								.rows(jcm.total_row_number).duration(duration).build();
						auditLogger_talendJobLog.flowOutput(log_context_talendJobLog);
					}

				}

				/**
				 * [talendJobLog begin ] stop
				 */

				/**
				 * [talendJobLog main ] start
				 */

				currentComponent = "talendJobLog";

				tos_count_talendJobLog++;

				/**
				 * [talendJobLog main ] stop
				 */

				/**
				 * [talendJobLog process_data_begin ] start
				 */

				currentComponent = "talendJobLog";

				/**
				 * [talendJobLog process_data_begin ] stop
				 */

				/**
				 * [talendJobLog process_data_end ] start
				 */

				currentComponent = "talendJobLog";

				/**
				 * [talendJobLog process_data_end ] stop
				 */

				/**
				 * [talendJobLog end ] start
				 */

				currentComponent = "talendJobLog";

				ok_Hash.put("talendJobLog", true);
				end_Hash.put("talendJobLog", System.currentTimeMillis());

				/**
				 * [talendJobLog end ] stop
				 */
			} // end the resume

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage(), e);
			}

			TalendException te = new TalendException(e, currentComponent, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [talendJobLog finally ] start
				 */

				currentComponent = "talendJobLog";

				/**
				 * [talendJobLog finally ] stop
				 */
			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("talendJobLog_SUBPROCESS_STATE", 1);
	}

	public String resuming_logs_dir_path = null;
	public String resuming_checkpoint_path = null;
	public String parent_part_launcher = null;
	private String resumeEntryMethodName = null;
	private boolean globalResumeTicket = false;

	public boolean watch = false;
	// portStats is null, it means don't execute the statistics
	public Integer portStats = null;
	public int portTraces = 4334;
	public String clientHost;
	public String defaultClientHost = "localhost";
	public String contextStr = "Default";
	public boolean isDefaultContext = true;
	public String pid = "0";
	public String rootPid = null;
	public String fatherPid = null;
	public String fatherNode = null;
	public long startTime = 0;
	public boolean isChildJob = false;
	public String log4jLevel = "";

	private boolean enableLogStash;

	private boolean execStat = true;

	private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
		protected java.util.Map<String, String> initialValue() {
			java.util.Map<String, String> threadRunResultMap = new java.util.HashMap<String, String>();
			threadRunResultMap.put("errorCode", null);
			threadRunResultMap.put("status", "");
			return threadRunResultMap;
		};
	};

	protected PropertiesWithType context_param = new PropertiesWithType();
	public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

	public String status = "";

	public static void main(String[] args) {
		final Loading_Dimension Loading_DimensionClass = new Loading_Dimension();

		int exitCode = Loading_DimensionClass.runJobInTOS(args);
		if (exitCode == 0) {
			log.info("TalendJob: 'Loading_Dimension' - Done.");
		}

		System.exit(exitCode);
	}

	public String[][] runJob(String[] args) {

		int exitCode = runJobInTOS(args);
		String[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };

		return bufferValue;
	}

	public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;

		return hastBufferOutput;
	}

	public int runJobInTOS(String[] args) {
		// reset status
		status = "";

		String lastStr = "";
		for (String arg : args) {
			if (arg.equalsIgnoreCase("--context_param")) {
				lastStr = arg;
			} else if (lastStr.equals("")) {
				evalParam(arg);
			} else {
				evalParam(lastStr + " " + arg);
				lastStr = "";
			}
		}
		enableLogStash = "true".equalsIgnoreCase(System.getProperty("audit.enabled"));

		if (!"".equals(log4jLevel)) {

			if ("trace".equalsIgnoreCase(log4jLevel)) {
				org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(),
						org.apache.logging.log4j.Level.TRACE);
			} else if ("debug".equalsIgnoreCase(log4jLevel)) {
				org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(),
						org.apache.logging.log4j.Level.DEBUG);
			} else if ("info".equalsIgnoreCase(log4jLevel)) {
				org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(),
						org.apache.logging.log4j.Level.INFO);
			} else if ("warn".equalsIgnoreCase(log4jLevel)) {
				org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(),
						org.apache.logging.log4j.Level.WARN);
			} else if ("error".equalsIgnoreCase(log4jLevel)) {
				org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(),
						org.apache.logging.log4j.Level.ERROR);
			} else if ("fatal".equalsIgnoreCase(log4jLevel)) {
				org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(),
						org.apache.logging.log4j.Level.FATAL);
			} else if ("off".equalsIgnoreCase(log4jLevel)) {
				org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(),
						org.apache.logging.log4j.Level.OFF);
			}
			org.apache.logging.log4j.core.config.Configurator
					.setLevel(org.apache.logging.log4j.LogManager.getRootLogger().getName(), log.getLevel());

		}
		log.info("TalendJob: 'Loading_Dimension' - Start.");

		if (enableLogStash) {
			java.util.Properties properties_talendJobLog = new java.util.Properties();
			properties_talendJobLog.setProperty("root.logger", "audit");
			properties_talendJobLog.setProperty("encoding", "UTF-8");
			properties_talendJobLog.setProperty("application.name", "Talend Studio");
			properties_talendJobLog.setProperty("service.name", "Talend Studio Job");
			properties_talendJobLog.setProperty("instance.name", "Talend Studio Job Instance");
			properties_talendJobLog.setProperty("propagate.appender.exceptions", "none");
			properties_talendJobLog.setProperty("log.appender", "file");
			properties_talendJobLog.setProperty("appender.file.path", "audit.json");
			properties_talendJobLog.setProperty("appender.file.maxsize", "52428800");
			properties_talendJobLog.setProperty("appender.file.maxbackup", "20");
			properties_talendJobLog.setProperty("host", "false");

			System.getProperties().stringPropertyNames().stream().filter(it -> it.startsWith("audit.logger."))
					.forEach(key -> properties_talendJobLog.setProperty(key.substring("audit.logger.".length()),
							System.getProperty(key)));

			org.apache.logging.log4j.core.config.Configurator
					.setLevel(properties_talendJobLog.getProperty("root.logger"), org.apache.logging.log4j.Level.DEBUG);

			auditLogger_talendJobLog = org.talend.job.audit.JobEventAuditLoggerFactory
					.createJobAuditLogger(properties_talendJobLog);
		}

		if (clientHost == null) {
			clientHost = defaultClientHost;
		}

		if (pid == null || "0".equals(pid)) {
			pid = TalendString.getAsciiRandomString(6);
		}

		if (rootPid == null) {
			rootPid = pid;
		}
		if (fatherPid == null) {
			fatherPid = pid;
		} else {
			isChildJob = true;
		}

		if (portStats != null) {
			// portStats = -1; //for testing
			if (portStats < 0 || portStats > 65535) {
				// issue:10869, the portStats is invalid, so this client socket can't open
				System.err.println("The statistics socket port " + portStats + " is invalid.");
				execStat = false;
			}
		} else {
			execStat = false;
		}
		boolean inOSGi = routines.system.BundleUtils.inOSGi();

		if (inOSGi) {
			java.util.Dictionary<String, Object> jobProperties = routines.system.BundleUtils.getJobProperties(jobName);

			if (jobProperties != null && jobProperties.get("context") != null) {
				contextStr = (String) jobProperties.get("context");
			}
		}

		try {
			// call job/subjob with an existing context, like: --context=production. if
			// without this parameter, there will use the default context instead.
			java.io.InputStream inContext = Loading_Dimension.class.getClassLoader()
					.getResourceAsStream("mvc_talend/loading_dimension_0_1/contexts/" + contextStr + ".properties");
			if (inContext == null) {
				inContext = Loading_Dimension.class.getClassLoader()
						.getResourceAsStream("config/contexts/" + contextStr + ".properties");
			}
			if (inContext != null) {
				try {
					// defaultProps is in order to keep the original context value
					if (context != null && context.isEmpty()) {
						defaultProps.load(inContext);
						context = new ContextProperties(defaultProps);
					}
				} finally {
					inContext.close();
				}
			} else if (!isDefaultContext) {
				// print info and job continue to run, for case: context_param is not empty.
				System.err.println("Could not find the context " + contextStr);
			}

			if (!context_param.isEmpty()) {
				context.putAll(context_param);
				// set types for params from parentJobs
				for (Object key : context_param.keySet()) {
					String context_key = key.toString();
					String context_type = context_param.getContextType(context_key);
					context.setContextType(context_key, context_type);

				}
			}
			class ContextProcessing {
				private void processContext_0() {
				}

				public void processAllContext() {
					processContext_0();
				}
			}

			new ContextProcessing().processAllContext();
		} catch (java.io.IOException ie) {
			System.err.println("Could not load context " + contextStr);
			ie.printStackTrace();
		}

		// get context value from parent directly
		if (parentContextMap != null && !parentContextMap.isEmpty()) {
		}

		// Resume: init the resumeUtil
		resumeEntryMethodName = ResumeUtil.getResumeEntryMethodName(resuming_checkpoint_path);
		resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
		resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName, jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
		// Resume: jobStart
		resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "",
				"", "", "", "", resumeUtil.convertToJsonText(context, parametersToEncrypt));

		if (execStat) {
			try {
				runStat.openSocket(!isChildJob);
				runStat.setAllPID(rootPid, fatherPid, pid, jobName);
				runStat.startThreadStat(clientHost, portStats);
				runStat.updateStatOnJob(RunStat.JOBSTART, fatherNode);
			} catch (java.io.IOException ioException) {
				ioException.printStackTrace();
			}
		}

		java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
		globalMap.put("concurrentHashMap", concurrentHashMap);

		long startUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
		long endUsedMemory = 0;
		long end = 0;

		startTime = System.currentTimeMillis();

		this.globalResumeTicket = true;// to run tPreJob

		if (enableLogStash) {
			talendJobLog.addJobStartMessage();
			try {
				talendJobLogProcess(globalMap);
			} catch (java.lang.Exception e) {
				e.printStackTrace();
			}
		}

		this.globalResumeTicket = false;// to run others jobs

		try {
			errorCode = null;
			tDBInput_1Process(globalMap);
			if (!"failure".equals(status)) {
				status = "end";
			}
		} catch (TalendException e_tDBInput_1) {
			globalMap.put("tDBInput_1_SUBPROCESS_STATE", -1);

			e_tDBInput_1.printStackTrace();

		}

		this.globalResumeTicket = true;// to run tPostJob

		end = System.currentTimeMillis();

		if (watch) {
			System.out.println((end - startTime) + " milliseconds");
		}

		endUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
		if (false) {
			System.out.println(
					(endUsedMemory - startUsedMemory) + " bytes memory increase when running : Loading_Dimension");
		}
		if (enableLogStash) {
			talendJobLog.addJobEndMessage(startTime, end, status);
			try {
				talendJobLogProcess(globalMap);
			} catch (java.lang.Exception e) {
				e.printStackTrace();
			}
		}

		if (execStat) {
			runStat.updateStatOnJob(RunStat.JOBEND, fatherNode);
			runStat.stopThreadStat();
		}
		int returnCode = 0;

		if (errorCode == null) {
			returnCode = status != null && status.equals("failure") ? 1 : 0;
		} else {
			returnCode = errorCode.intValue();
		}
		resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "",
				"" + returnCode, "", "", "");

		return returnCode;

	}

	// only for OSGi env
	public void destroy() {

	}

	private java.util.Map<String, Object> getSharedConnections4REST() {
		java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();

		return connections;
	}

	private void evalParam(String arg) {
		if (arg.startsWith("--resuming_logs_dir_path")) {
			resuming_logs_dir_path = arg.substring(25);
		} else if (arg.startsWith("--resuming_checkpoint_path")) {
			resuming_checkpoint_path = arg.substring(27);
		} else if (arg.startsWith("--parent_part_launcher")) {
			parent_part_launcher = arg.substring(23);
		} else if (arg.startsWith("--watch")) {
			watch = true;
		} else if (arg.startsWith("--stat_port=")) {
			String portStatsStr = arg.substring(12);
			if (portStatsStr != null && !portStatsStr.equals("null")) {
				portStats = Integer.parseInt(portStatsStr);
			}
		} else if (arg.startsWith("--trace_port=")) {
			portTraces = Integer.parseInt(arg.substring(13));
		} else if (arg.startsWith("--client_host=")) {
			clientHost = arg.substring(14);
		} else if (arg.startsWith("--context=")) {
			contextStr = arg.substring(10);
			isDefaultContext = false;
		} else if (arg.startsWith("--father_pid=")) {
			fatherPid = arg.substring(13);
		} else if (arg.startsWith("--root_pid=")) {
			rootPid = arg.substring(11);
		} else if (arg.startsWith("--father_node=")) {
			fatherNode = arg.substring(14);
		} else if (arg.startsWith("--pid=")) {
			pid = arg.substring(6);
		} else if (arg.startsWith("--context_type")) {
			String keyValue = arg.substring(15);
			int index = -1;
			if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
				if (fatherPid == null) {
					context_param.setContextType(keyValue.substring(0, index),
							replaceEscapeChars(keyValue.substring(index + 1)));
				} else { // the subjob won't escape the especial chars
					context_param.setContextType(keyValue.substring(0, index), keyValue.substring(index + 1));
				}

			}

		} else if (arg.startsWith("--context_param")) {
			String keyValue = arg.substring(16);
			int index = -1;
			if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
				if (fatherPid == null) {
					context_param.put(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
				} else { // the subjob won't escape the especial chars
					context_param.put(keyValue.substring(0, index), keyValue.substring(index + 1));
				}
			}
		} else if (arg.startsWith("--log4jLevel=")) {
			log4jLevel = arg.substring(13);
		} else if (arg.startsWith("--audit.enabled") && arg.contains("=")) {// for trunjob call
			final int equal = arg.indexOf('=');
			final String key = arg.substring("--".length(), equal);
			System.setProperty(key, arg.substring(equal + 1));
		}
	}

	private static final String NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY = "<TALEND_NULL>";

	private final String[][] escapeChars = { { "\\\\", "\\" }, { "\\n", "\n" }, { "\\'", "\'" }, { "\\r", "\r" },
			{ "\\f", "\f" }, { "\\b", "\b" }, { "\\t", "\t" } };

	private String replaceEscapeChars(String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0], currIndex);
				if (index >= 0) {

					result.append(keyValue.substring(currIndex, index + strArray[0].length()).replace(strArray[0],
							strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left into the
			// result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
	}

	public Integer getErrorCode() {
		return errorCode;
	}

	public String getStatus() {
		return status;
	}

	ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 * 736613 characters generated by Talend Real-time Big Data Platform on the
 * April 20, 2023 at 11:15:00 PM EDT
 ************************************************************************************************/