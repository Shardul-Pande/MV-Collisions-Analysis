
package mvc_talend.loading_dimension_part2_0_1;

import routines.Numeric;
import routines.DataOperation;
import routines.TalendDataGenerator;
import routines.TalendStringUtil;
import routines.TalendString;
import routines.StringHandling;
import routines.Relational;
import routines.TalendDate;
import routines.Mathematical;
import routines.SQLike;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;

@SuppressWarnings("unused")

/**
 * Job: Loading_Dimension_Part2 Purpose: <br>
 * Description: <br>
 * 
 * @author chokshi.ra@northeastern.edu
 * @version 8.0.1.20211109_1610
 * @status
 */
public class Loading_Dimension_Part2 implements TalendJob {
	static {
		System.setProperty("TalendJob.log", "Loading_Dimension_Part2.log");
	}

	private static org.apache.logging.log4j.Logger log = org.apache.logging.log4j.LogManager
			.getLogger(Loading_Dimension_Part2.class);

	protected static void logIgnoredError(String message, Throwable cause) {
		log.error(message, cause);

	}

	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}

	private final static String defaultCharset = java.nio.charset.Charset.defaultCharset().name();

	private final static String utf8Charset = "UTF-8";

	// contains type for every context property
	public class PropertiesWithType extends java.util.Properties {
		private static final long serialVersionUID = 1L;
		private java.util.Map<String, String> propertyTypes = new java.util.HashMap<>();

		public PropertiesWithType(java.util.Properties properties) {
			super(properties);
		}

		public PropertiesWithType() {
			super();
		}

		public void setContextType(String key, String type) {
			propertyTypes.put(key, type);
		}

		public String getContextType(String key) {
			return propertyTypes.get(key);
		}
	}

	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();

	// create application properties with default
	public class ContextProperties extends PropertiesWithType {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties) {
			super(properties);
		}

		public ContextProperties() {
			super();
		}

		public void synchronizeContext() {

		}

		// if the stored or passed value is "<TALEND_NULL>" string, it mean null
		public String getStringValue(String key) {
			String origin_value = this.getProperty(key);
			if (NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY.equals(origin_value)) {
				return null;
			}
			return origin_value;
		}

	}

	protected ContextProperties context = new ContextProperties(); // will be instanciated by MS.

	public ContextProperties getContext() {
		return this.context;
	}

	private final String jobVersion = "0.1";
	private final String jobName = "Loading_Dimension_Part2";
	private final String projectName = "MVC_TALEND";
	public Integer errorCode = null;
	private String currentComponent = "";

	private final java.util.Map<String, Object> globalMap = new java.util.HashMap<String, Object>();
	private final static java.util.Map<String, Object> junitGlobalMap = new java.util.HashMap<String, Object>();

	private final java.util.Map<String, Long> start_Hash = new java.util.HashMap<String, Long>();
	private final java.util.Map<String, Long> end_Hash = new java.util.HashMap<String, Long>();
	private final java.util.Map<String, Boolean> ok_Hash = new java.util.HashMap<String, Boolean>();
	public final java.util.List<String[]> globalBuffer = new java.util.ArrayList<String[]>();

	private final JobStructureCatcherUtils talendJobLog = new JobStructureCatcherUtils(jobName,
			"_a-WeUN_SEe2NrsDbiwC3aA", "0.1");
	private org.talend.job.audit.JobAuditLogger auditLogger_talendJobLog = null;

	private RunStat runStat = new RunStat(talendJobLog, System.getProperty("audit.interval"));

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";

	private final static String KEY_DB_DATASOURCES_RAW = "KEY_DB_DATASOURCES_RAW";

	public void setDataSources(java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources.entrySet()) {
			talendDataSources.put(dataSourceEntry.getKey(),
					new routines.system.TalendDataSource(dataSourceEntry.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}

	public void setDataSourceReferences(List serviceReferences) throws Exception {

		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		java.util.Map<String, javax.sql.DataSource> dataSources = new java.util.HashMap<String, javax.sql.DataSource>();

		for (java.util.Map.Entry<String, javax.sql.DataSource> entry : BundleUtils
				.getServices(serviceReferences, javax.sql.DataSource.class).entrySet()) {
			dataSources.put(entry.getKey(), entry.getValue());
			talendDataSources.put(entry.getKey(), new routines.system.TalendDataSource(entry.getValue()));
		}

		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}

	private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
	private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(new java.io.BufferedOutputStream(baos));

	public String getExceptionStackTrace() {
		if ("failure".equals(this.getStatus())) {
			errorMessagePS.flush();
			return baos.toString();
		}
		return null;
	}

	private Exception exception;

	public Exception getException() {
		if ("failure".equals(this.getStatus())) {
			return this.exception;
		}
		return null;
	}

	private class TalendException extends Exception {

		private static final long serialVersionUID = 1L;

		private java.util.Map<String, Object> globalMap = null;
		private Exception e = null;
		private String currentComponent = null;
		private String virtualComponentName = null;

		public void setVirtualComponentName(String virtualComponentName) {
			this.virtualComponentName = virtualComponentName;
		}

		private TalendException(Exception e, String errorComponent, final java.util.Map<String, Object> globalMap) {
			this.currentComponent = errorComponent;
			this.globalMap = globalMap;
			this.e = e;
		}

		public Exception getException() {
			return this.e;
		}

		public String getCurrentComponent() {
			return this.currentComponent;
		}

		public String getExceptionCauseMessage(Exception e) {
			Throwable cause = e;
			String message = null;
			int i = 10;
			while (null != cause && 0 < i--) {
				message = cause.getMessage();
				if (null == message) {
					cause = cause.getCause();
				} else {
					break;
				}
			}
			if (null == message) {
				message = e.getClass().getName();
			}
			return message;
		}

		@Override
		public void printStackTrace() {
			if (!(e instanceof TalendException || e instanceof TDieException)) {
				if (virtualComponentName != null && currentComponent.indexOf(virtualComponentName + "_") == 0) {
					globalMap.put(virtualComponentName + "_ERROR_MESSAGE", getExceptionCauseMessage(e));
				}
				globalMap.put(currentComponent + "_ERROR_MESSAGE", getExceptionCauseMessage(e));
				System.err.println("Exception in component " + currentComponent + " (" + jobName + ")");
			}
			if (!(e instanceof TDieException)) {
				if (e instanceof TalendException) {
					e.printStackTrace();
				} else {
					e.printStackTrace();
					e.printStackTrace(errorMessagePS);
					Loading_Dimension_Part2.this.exception = e;
				}
			}
			if (!(e instanceof TalendException)) {
				try {
					for (java.lang.reflect.Method m : this.getClass().getEnclosingClass().getMethods()) {
						if (m.getName().compareTo(currentComponent + "_error") == 0) {
							m.invoke(Loading_Dimension_Part2.this, new Object[] { e, currentComponent, globalMap });
							break;
						}
					}

					if (!(e instanceof TDieException)) {
					}
				} catch (Exception e) {
					this.e.printStackTrace();
				}
			}
		}
	}

	public void tDBInput_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMap_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tUniqRow_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMap_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBOutput_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tUniqRow_2_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMap_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBOutput_2_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tUniqRow_3_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMap_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBOutput_3_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tUniqRow_4_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMap_5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBOutput_4_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tUniqRow_5_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMap_6_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBOutput_5_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tUniqRow_6_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMap_7_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBOutput_6_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tUniqRow_7_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMap_8_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBOutput_7_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tUniqRow_8_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMap_9_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBOutput_8_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tUniqRow_9_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMap_10_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBOutput_9_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tUniqRow_10_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMap_11_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBOutput_10_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void talendJobLog_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		talendJobLog_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBInput_1_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void talendJobLog_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public static class PublicPropertyDamage2Struct
			implements routines.system.IPersistableRow<PublicPropertyDamage2Struct> {
		final static byte[] commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2 = new byte[0];
		static byte[] commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public int PUBLIC_PROPERTY_DAMAGE_SK;

		public int getPUBLIC_PROPERTY_DAMAGE_SK() {
			return this.PUBLIC_PROPERTY_DAMAGE_SK;
		}

		public String PUBLIC_PROPERTY_DAMAGE;

		public String getPUBLIC_PROPERTY_DAMAGE() {
			return this.PUBLIC_PROPERTY_DAMAGE;
		}

		public String DI_PID;

		public String getDI_PID() {
			return this.DI_PID;
		}

		public java.util.Date DI_Create_Date;

		public java.util.Date getDI_Create_Date() {
			return this.DI_Create_Date;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + (int) this.PUBLIC_PROPERTY_DAMAGE_SK;

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final PublicPropertyDamage2Struct other = (PublicPropertyDamage2Struct) obj;

			if (this.PUBLIC_PROPERTY_DAMAGE_SK != other.PUBLIC_PROPERTY_DAMAGE_SK)
				return false;

			return true;
		}

		public void copyDataTo(PublicPropertyDamage2Struct other) {

			other.PUBLIC_PROPERTY_DAMAGE_SK = this.PUBLIC_PROPERTY_DAMAGE_SK;
			other.PUBLIC_PROPERTY_DAMAGE = this.PUBLIC_PROPERTY_DAMAGE;
			other.DI_PID = this.DI_PID;
			other.DI_Create_Date = this.DI_Create_Date;

		}

		public void copyKeysDataTo(PublicPropertyDamage2Struct other) {

			other.PUBLIC_PROPERTY_DAMAGE_SK = this.PUBLIC_PROPERTY_DAMAGE_SK;

		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2) {

				try {

					int length = 0;

					this.PUBLIC_PROPERTY_DAMAGE_SK = dis.readInt();

					this.PUBLIC_PROPERTY_DAMAGE = readString(dis);

					this.DI_PID = readString(dis);

					this.DI_Create_Date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2) {

				try {

					int length = 0;

					this.PUBLIC_PROPERTY_DAMAGE_SK = dis.readInt();

					this.PUBLIC_PROPERTY_DAMAGE = readString(dis);

					this.DI_PID = readString(dis);

					this.DI_Create_Date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// int

				dos.writeInt(this.PUBLIC_PROPERTY_DAMAGE_SK);

				// String

				writeString(this.PUBLIC_PROPERTY_DAMAGE, dos);

				// String

				writeString(this.DI_PID, dos);

				// java.util.Date

				writeDate(this.DI_Create_Date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// int

				dos.writeInt(this.PUBLIC_PROPERTY_DAMAGE_SK);

				// String

				writeString(this.PUBLIC_PROPERTY_DAMAGE, dos);

				// String

				writeString(this.DI_PID, dos);

				// java.util.Date

				writeDate(this.DI_Create_Date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("PUBLIC_PROPERTY_DAMAGE_SK=" + String.valueOf(PUBLIC_PROPERTY_DAMAGE_SK));
			sb.append(",PUBLIC_PROPERTY_DAMAGE=" + PUBLIC_PROPERTY_DAMAGE);
			sb.append(",DI_PID=" + DI_PID);
			sb.append(",DI_Create_Date=" + String.valueOf(DI_Create_Date));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			sb.append(PUBLIC_PROPERTY_DAMAGE_SK);

			sb.append("|");

			if (PUBLIC_PROPERTY_DAMAGE == null) {
				sb.append("<null>");
			} else {
				sb.append(PUBLIC_PROPERTY_DAMAGE);
			}

			sb.append("|");

			if (DI_PID == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_PID);
			}

			sb.append("|");

			if (DI_Create_Date == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_Create_Date);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(PublicPropertyDamage2Struct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.PUBLIC_PROPERTY_DAMAGE_SK, other.PUBLIC_PROPERTY_DAMAGE_SK);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row11Struct implements routines.system.IPersistableRow<row11Struct> {
		final static byte[] commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2 = new byte[0];
		static byte[] commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[0];

		public String PUBLIC_PROPERTY_DAMAGE;

		public String getPUBLIC_PROPERTY_DAMAGE() {
			return this.PUBLIC_PROPERTY_DAMAGE;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2) {

				try {

					int length = 0;

					this.PUBLIC_PROPERTY_DAMAGE = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2) {

				try {

					int length = 0;

					this.PUBLIC_PROPERTY_DAMAGE = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.PUBLIC_PROPERTY_DAMAGE, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.PUBLIC_PROPERTY_DAMAGE, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("PUBLIC_PROPERTY_DAMAGE=" + PUBLIC_PROPERTY_DAMAGE);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (PUBLIC_PROPERTY_DAMAGE == null) {
				sb.append("<null>");
			} else {
				sb.append(PUBLIC_PROPERTY_DAMAGE);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row11Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class PointOFImpact2Struct implements routines.system.IPersistableRow<PointOFImpact2Struct> {
		final static byte[] commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2 = new byte[0];
		static byte[] commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public int POINT_OF_IMPACT_SK;

		public int getPOINT_OF_IMPACT_SK() {
			return this.POINT_OF_IMPACT_SK;
		}

		public String POINT_OF_IMPACT;

		public String getPOINT_OF_IMPACT() {
			return this.POINT_OF_IMPACT;
		}

		public String DI_PID;

		public String getDI_PID() {
			return this.DI_PID;
		}

		public java.util.Date DI_Create_Date;

		public java.util.Date getDI_Create_Date() {
			return this.DI_Create_Date;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + (int) this.POINT_OF_IMPACT_SK;

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final PointOFImpact2Struct other = (PointOFImpact2Struct) obj;

			if (this.POINT_OF_IMPACT_SK != other.POINT_OF_IMPACT_SK)
				return false;

			return true;
		}

		public void copyDataTo(PointOFImpact2Struct other) {

			other.POINT_OF_IMPACT_SK = this.POINT_OF_IMPACT_SK;
			other.POINT_OF_IMPACT = this.POINT_OF_IMPACT;
			other.DI_PID = this.DI_PID;
			other.DI_Create_Date = this.DI_Create_Date;

		}

		public void copyKeysDataTo(PointOFImpact2Struct other) {

			other.POINT_OF_IMPACT_SK = this.POINT_OF_IMPACT_SK;

		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2) {

				try {

					int length = 0;

					this.POINT_OF_IMPACT_SK = dis.readInt();

					this.POINT_OF_IMPACT = readString(dis);

					this.DI_PID = readString(dis);

					this.DI_Create_Date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2) {

				try {

					int length = 0;

					this.POINT_OF_IMPACT_SK = dis.readInt();

					this.POINT_OF_IMPACT = readString(dis);

					this.DI_PID = readString(dis);

					this.DI_Create_Date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// int

				dos.writeInt(this.POINT_OF_IMPACT_SK);

				// String

				writeString(this.POINT_OF_IMPACT, dos);

				// String

				writeString(this.DI_PID, dos);

				// java.util.Date

				writeDate(this.DI_Create_Date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// int

				dos.writeInt(this.POINT_OF_IMPACT_SK);

				// String

				writeString(this.POINT_OF_IMPACT, dos);

				// String

				writeString(this.DI_PID, dos);

				// java.util.Date

				writeDate(this.DI_Create_Date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("POINT_OF_IMPACT_SK=" + String.valueOf(POINT_OF_IMPACT_SK));
			sb.append(",POINT_OF_IMPACT=" + POINT_OF_IMPACT);
			sb.append(",DI_PID=" + DI_PID);
			sb.append(",DI_Create_Date=" + String.valueOf(DI_Create_Date));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			sb.append(POINT_OF_IMPACT_SK);

			sb.append("|");

			if (POINT_OF_IMPACT == null) {
				sb.append("<null>");
			} else {
				sb.append(POINT_OF_IMPACT);
			}

			sb.append("|");

			if (DI_PID == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_PID);
			}

			sb.append("|");

			if (DI_Create_Date == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_Create_Date);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(PointOFImpact2Struct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.POINT_OF_IMPACT_SK, other.POINT_OF_IMPACT_SK);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row10Struct implements routines.system.IPersistableRow<row10Struct> {
		final static byte[] commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2 = new byte[0];
		static byte[] commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[0];

		public String POINT_OF_IMPACT;

		public String getPOINT_OF_IMPACT() {
			return this.POINT_OF_IMPACT;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2) {

				try {

					int length = 0;

					this.POINT_OF_IMPACT = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2) {

				try {

					int length = 0;

					this.POINT_OF_IMPACT = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.POINT_OF_IMPACT, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.POINT_OF_IMPACT, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("POINT_OF_IMPACT=" + POINT_OF_IMPACT);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (POINT_OF_IMPACT == null) {
				sb.append("<null>");
			} else {
				sb.append(POINT_OF_IMPACT);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row10Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class PreCash22Struct implements routines.system.IPersistableRow<PreCash22Struct> {
		final static byte[] commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2 = new byte[0];
		static byte[] commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public int PRE_CRASH_SK;

		public int getPRE_CRASH_SK() {
			return this.PRE_CRASH_SK;
		}

		public String PRE_CRASH;

		public String getPRE_CRASH() {
			return this.PRE_CRASH;
		}

		public String DI_PID;

		public String getDI_PID() {
			return this.DI_PID;
		}

		public java.util.Date DI_Create_Date;

		public java.util.Date getDI_Create_Date() {
			return this.DI_Create_Date;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + (int) this.PRE_CRASH_SK;

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final PreCash22Struct other = (PreCash22Struct) obj;

			if (this.PRE_CRASH_SK != other.PRE_CRASH_SK)
				return false;

			return true;
		}

		public void copyDataTo(PreCash22Struct other) {

			other.PRE_CRASH_SK = this.PRE_CRASH_SK;
			other.PRE_CRASH = this.PRE_CRASH;
			other.DI_PID = this.DI_PID;
			other.DI_Create_Date = this.DI_Create_Date;

		}

		public void copyKeysDataTo(PreCash22Struct other) {

			other.PRE_CRASH_SK = this.PRE_CRASH_SK;

		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2) {

				try {

					int length = 0;

					this.PRE_CRASH_SK = dis.readInt();

					this.PRE_CRASH = readString(dis);

					this.DI_PID = readString(dis);

					this.DI_Create_Date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2) {

				try {

					int length = 0;

					this.PRE_CRASH_SK = dis.readInt();

					this.PRE_CRASH = readString(dis);

					this.DI_PID = readString(dis);

					this.DI_Create_Date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// int

				dos.writeInt(this.PRE_CRASH_SK);

				// String

				writeString(this.PRE_CRASH, dos);

				// String

				writeString(this.DI_PID, dos);

				// java.util.Date

				writeDate(this.DI_Create_Date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// int

				dos.writeInt(this.PRE_CRASH_SK);

				// String

				writeString(this.PRE_CRASH, dos);

				// String

				writeString(this.DI_PID, dos);

				// java.util.Date

				writeDate(this.DI_Create_Date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("PRE_CRASH_SK=" + String.valueOf(PRE_CRASH_SK));
			sb.append(",PRE_CRASH=" + PRE_CRASH);
			sb.append(",DI_PID=" + DI_PID);
			sb.append(",DI_Create_Date=" + String.valueOf(DI_Create_Date));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			sb.append(PRE_CRASH_SK);

			sb.append("|");

			if (PRE_CRASH == null) {
				sb.append("<null>");
			} else {
				sb.append(PRE_CRASH);
			}

			sb.append("|");

			if (DI_PID == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_PID);
			}

			sb.append("|");

			if (DI_Create_Date == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_Create_Date);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(PreCash22Struct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.PRE_CRASH_SK, other.PRE_CRASH_SK);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row9Struct implements routines.system.IPersistableRow<row9Struct> {
		final static byte[] commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2 = new byte[0];
		static byte[] commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[0];

		public String PRE_CRASH;

		public String getPRE_CRASH() {
			return this.PRE_CRASH;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2) {

				try {

					int length = 0;

					this.PRE_CRASH = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2) {

				try {

					int length = 0;

					this.PRE_CRASH = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.PRE_CRASH, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.PRE_CRASH, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("PRE_CRASH=" + PRE_CRASH);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (PRE_CRASH == null) {
				sb.append("<null>");
			} else {
				sb.append(PRE_CRASH);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row9Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class JurisdivStruct implements routines.system.IPersistableRow<JurisdivStruct> {
		final static byte[] commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2 = new byte[0];
		static byte[] commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public int DRIVER_LICENSE_JURISDICTION_SK;

		public int getDRIVER_LICENSE_JURISDICTION_SK() {
			return this.DRIVER_LICENSE_JURISDICTION_SK;
		}

		public String DRIVER_LICENSE_JURISDICTION;

		public String getDRIVER_LICENSE_JURISDICTION() {
			return this.DRIVER_LICENSE_JURISDICTION;
		}

		public String DI_PID;

		public String getDI_PID() {
			return this.DI_PID;
		}

		public java.util.Date DI_Create_Date;

		public java.util.Date getDI_Create_Date() {
			return this.DI_Create_Date;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + (int) this.DRIVER_LICENSE_JURISDICTION_SK;

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final JurisdivStruct other = (JurisdivStruct) obj;

			if (this.DRIVER_LICENSE_JURISDICTION_SK != other.DRIVER_LICENSE_JURISDICTION_SK)
				return false;

			return true;
		}

		public void copyDataTo(JurisdivStruct other) {

			other.DRIVER_LICENSE_JURISDICTION_SK = this.DRIVER_LICENSE_JURISDICTION_SK;
			other.DRIVER_LICENSE_JURISDICTION = this.DRIVER_LICENSE_JURISDICTION;
			other.DI_PID = this.DI_PID;
			other.DI_Create_Date = this.DI_Create_Date;

		}

		public void copyKeysDataTo(JurisdivStruct other) {

			other.DRIVER_LICENSE_JURISDICTION_SK = this.DRIVER_LICENSE_JURISDICTION_SK;

		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2) {

				try {

					int length = 0;

					this.DRIVER_LICENSE_JURISDICTION_SK = dis.readInt();

					this.DRIVER_LICENSE_JURISDICTION = readString(dis);

					this.DI_PID = readString(dis);

					this.DI_Create_Date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2) {

				try {

					int length = 0;

					this.DRIVER_LICENSE_JURISDICTION_SK = dis.readInt();

					this.DRIVER_LICENSE_JURISDICTION = readString(dis);

					this.DI_PID = readString(dis);

					this.DI_Create_Date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// int

				dos.writeInt(this.DRIVER_LICENSE_JURISDICTION_SK);

				// String

				writeString(this.DRIVER_LICENSE_JURISDICTION, dos);

				// String

				writeString(this.DI_PID, dos);

				// java.util.Date

				writeDate(this.DI_Create_Date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// int

				dos.writeInt(this.DRIVER_LICENSE_JURISDICTION_SK);

				// String

				writeString(this.DRIVER_LICENSE_JURISDICTION, dos);

				// String

				writeString(this.DI_PID, dos);

				// java.util.Date

				writeDate(this.DI_Create_Date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("DRIVER_LICENSE_JURISDICTION_SK=" + String.valueOf(DRIVER_LICENSE_JURISDICTION_SK));
			sb.append(",DRIVER_LICENSE_JURISDICTION=" + DRIVER_LICENSE_JURISDICTION);
			sb.append(",DI_PID=" + DI_PID);
			sb.append(",DI_Create_Date=" + String.valueOf(DI_Create_Date));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			sb.append(DRIVER_LICENSE_JURISDICTION_SK);

			sb.append("|");

			if (DRIVER_LICENSE_JURISDICTION == null) {
				sb.append("<null>");
			} else {
				sb.append(DRIVER_LICENSE_JURISDICTION);
			}

			sb.append("|");

			if (DI_PID == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_PID);
			}

			sb.append("|");

			if (DI_Create_Date == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_Create_Date);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(JurisdivStruct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.DRIVER_LICENSE_JURISDICTION_SK,
					other.DRIVER_LICENSE_JURISDICTION_SK);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row8Struct implements routines.system.IPersistableRow<row8Struct> {
		final static byte[] commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2 = new byte[0];
		static byte[] commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[0];

		public String DRIVER_LICENSE_JURISDICTION;

		public String getDRIVER_LICENSE_JURISDICTION() {
			return this.DRIVER_LICENSE_JURISDICTION;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2) {

				try {

					int length = 0;

					this.DRIVER_LICENSE_JURISDICTION = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2) {

				try {

					int length = 0;

					this.DRIVER_LICENSE_JURISDICTION = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.DRIVER_LICENSE_JURISDICTION, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.DRIVER_LICENSE_JURISDICTION, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("DRIVER_LICENSE_JURISDICTION=" + DRIVER_LICENSE_JURISDICTION);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (DRIVER_LICENSE_JURISDICTION == null) {
				sb.append("<null>");
			} else {
				sb.append(DRIVER_LICENSE_JURISDICTION);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row8Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class Driver_License_Status_2Struct
			implements routines.system.IPersistableRow<Driver_License_Status_2Struct> {
		final static byte[] commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2 = new byte[0];
		static byte[] commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public int DRIVER_LICENSE_STATUS_SK;

		public int getDRIVER_LICENSE_STATUS_SK() {
			return this.DRIVER_LICENSE_STATUS_SK;
		}

		public String DRIVER_LICENSE_STATUS;

		public String getDRIVER_LICENSE_STATUS() {
			return this.DRIVER_LICENSE_STATUS;
		}

		public String DI_PID;

		public String getDI_PID() {
			return this.DI_PID;
		}

		public java.util.Date DI_Create_Date;

		public java.util.Date getDI_Create_Date() {
			return this.DI_Create_Date;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + (int) this.DRIVER_LICENSE_STATUS_SK;

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final Driver_License_Status_2Struct other = (Driver_License_Status_2Struct) obj;

			if (this.DRIVER_LICENSE_STATUS_SK != other.DRIVER_LICENSE_STATUS_SK)
				return false;

			return true;
		}

		public void copyDataTo(Driver_License_Status_2Struct other) {

			other.DRIVER_LICENSE_STATUS_SK = this.DRIVER_LICENSE_STATUS_SK;
			other.DRIVER_LICENSE_STATUS = this.DRIVER_LICENSE_STATUS;
			other.DI_PID = this.DI_PID;
			other.DI_Create_Date = this.DI_Create_Date;

		}

		public void copyKeysDataTo(Driver_License_Status_2Struct other) {

			other.DRIVER_LICENSE_STATUS_SK = this.DRIVER_LICENSE_STATUS_SK;

		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2) {

				try {

					int length = 0;

					this.DRIVER_LICENSE_STATUS_SK = dis.readInt();

					this.DRIVER_LICENSE_STATUS = readString(dis);

					this.DI_PID = readString(dis);

					this.DI_Create_Date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2) {

				try {

					int length = 0;

					this.DRIVER_LICENSE_STATUS_SK = dis.readInt();

					this.DRIVER_LICENSE_STATUS = readString(dis);

					this.DI_PID = readString(dis);

					this.DI_Create_Date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// int

				dos.writeInt(this.DRIVER_LICENSE_STATUS_SK);

				// String

				writeString(this.DRIVER_LICENSE_STATUS, dos);

				// String

				writeString(this.DI_PID, dos);

				// java.util.Date

				writeDate(this.DI_Create_Date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// int

				dos.writeInt(this.DRIVER_LICENSE_STATUS_SK);

				// String

				writeString(this.DRIVER_LICENSE_STATUS, dos);

				// String

				writeString(this.DI_PID, dos);

				// java.util.Date

				writeDate(this.DI_Create_Date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("DRIVER_LICENSE_STATUS_SK=" + String.valueOf(DRIVER_LICENSE_STATUS_SK));
			sb.append(",DRIVER_LICENSE_STATUS=" + DRIVER_LICENSE_STATUS);
			sb.append(",DI_PID=" + DI_PID);
			sb.append(",DI_Create_Date=" + String.valueOf(DI_Create_Date));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			sb.append(DRIVER_LICENSE_STATUS_SK);

			sb.append("|");

			if (DRIVER_LICENSE_STATUS == null) {
				sb.append("<null>");
			} else {
				sb.append(DRIVER_LICENSE_STATUS);
			}

			sb.append("|");

			if (DI_PID == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_PID);
			}

			sb.append("|");

			if (DI_Create_Date == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_Create_Date);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(Driver_License_Status_2Struct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.DRIVER_LICENSE_STATUS_SK, other.DRIVER_LICENSE_STATUS_SK);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row7Struct implements routines.system.IPersistableRow<row7Struct> {
		final static byte[] commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2 = new byte[0];
		static byte[] commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[0];

		public String DRIVER_LICENSE_STATUS;

		public String getDRIVER_LICENSE_STATUS() {
			return this.DRIVER_LICENSE_STATUS;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2) {

				try {

					int length = 0;

					this.DRIVER_LICENSE_STATUS = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2) {

				try {

					int length = 0;

					this.DRIVER_LICENSE_STATUS = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.DRIVER_LICENSE_STATUS, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.DRIVER_LICENSE_STATUS, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("DRIVER_LICENSE_STATUS=" + DRIVER_LICENSE_STATUS);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (DRIVER_LICENSE_STATUS == null) {
				sb.append("<null>");
			} else {
				sb.append(DRIVER_LICENSE_STATUS);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row7Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class Travel_Direction_LoaddStruct
			implements routines.system.IPersistableRow<Travel_Direction_LoaddStruct> {
		final static byte[] commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2 = new byte[0];
		static byte[] commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public int TRAVEL_DIRECTION_SK;

		public int getTRAVEL_DIRECTION_SK() {
			return this.TRAVEL_DIRECTION_SK;
		}

		public String TRAVEL_DIRECTION;

		public String getTRAVEL_DIRECTION() {
			return this.TRAVEL_DIRECTION;
		}

		public String DI_PID;

		public String getDI_PID() {
			return this.DI_PID;
		}

		public java.util.Date DI_Create_Date;

		public java.util.Date getDI_Create_Date() {
			return this.DI_Create_Date;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + (int) this.TRAVEL_DIRECTION_SK;

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final Travel_Direction_LoaddStruct other = (Travel_Direction_LoaddStruct) obj;

			if (this.TRAVEL_DIRECTION_SK != other.TRAVEL_DIRECTION_SK)
				return false;

			return true;
		}

		public void copyDataTo(Travel_Direction_LoaddStruct other) {

			other.TRAVEL_DIRECTION_SK = this.TRAVEL_DIRECTION_SK;
			other.TRAVEL_DIRECTION = this.TRAVEL_DIRECTION;
			other.DI_PID = this.DI_PID;
			other.DI_Create_Date = this.DI_Create_Date;

		}

		public void copyKeysDataTo(Travel_Direction_LoaddStruct other) {

			other.TRAVEL_DIRECTION_SK = this.TRAVEL_DIRECTION_SK;

		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2) {

				try {

					int length = 0;

					this.TRAVEL_DIRECTION_SK = dis.readInt();

					this.TRAVEL_DIRECTION = readString(dis);

					this.DI_PID = readString(dis);

					this.DI_Create_Date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2) {

				try {

					int length = 0;

					this.TRAVEL_DIRECTION_SK = dis.readInt();

					this.TRAVEL_DIRECTION = readString(dis);

					this.DI_PID = readString(dis);

					this.DI_Create_Date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// int

				dos.writeInt(this.TRAVEL_DIRECTION_SK);

				// String

				writeString(this.TRAVEL_DIRECTION, dos);

				// String

				writeString(this.DI_PID, dos);

				// java.util.Date

				writeDate(this.DI_Create_Date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// int

				dos.writeInt(this.TRAVEL_DIRECTION_SK);

				// String

				writeString(this.TRAVEL_DIRECTION, dos);

				// String

				writeString(this.DI_PID, dos);

				// java.util.Date

				writeDate(this.DI_Create_Date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("TRAVEL_DIRECTION_SK=" + String.valueOf(TRAVEL_DIRECTION_SK));
			sb.append(",TRAVEL_DIRECTION=" + TRAVEL_DIRECTION);
			sb.append(",DI_PID=" + DI_PID);
			sb.append(",DI_Create_Date=" + String.valueOf(DI_Create_Date));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			sb.append(TRAVEL_DIRECTION_SK);

			sb.append("|");

			if (TRAVEL_DIRECTION == null) {
				sb.append("<null>");
			} else {
				sb.append(TRAVEL_DIRECTION);
			}

			sb.append("|");

			if (DI_PID == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_PID);
			}

			sb.append("|");

			if (DI_Create_Date == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_Create_Date);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(Travel_Direction_LoaddStruct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.TRAVEL_DIRECTION_SK, other.TRAVEL_DIRECTION_SK);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row6Struct implements routines.system.IPersistableRow<row6Struct> {
		final static byte[] commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2 = new byte[0];
		static byte[] commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[0];

		public String TRAVEL_DIRECTION;

		public String getTRAVEL_DIRECTION() {
			return this.TRAVEL_DIRECTION;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2) {

				try {

					int length = 0;

					this.TRAVEL_DIRECTION = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2) {

				try {

					int length = 0;

					this.TRAVEL_DIRECTION = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.TRAVEL_DIRECTION, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.TRAVEL_DIRECTION, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("TRAVEL_DIRECTION=" + TRAVEL_DIRECTION);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (TRAVEL_DIRECTION == null) {
				sb.append("<null>");
			} else {
				sb.append(TRAVEL_DIRECTION);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row6Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class Vehicle_Model1Struct implements routines.system.IPersistableRow<Vehicle_Model1Struct> {
		final static byte[] commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2 = new byte[0];
		static byte[] commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public int VEHICLE_MODEL_SK;

		public int getVEHICLE_MODEL_SK() {
			return this.VEHICLE_MODEL_SK;
		}

		public String VEHICLE_MODEL;

		public String getVEHICLE_MODEL() {
			return this.VEHICLE_MODEL;
		}

		public String DI_PID;

		public String getDI_PID() {
			return this.DI_PID;
		}

		public java.util.Date DI_Create_Date;

		public java.util.Date getDI_Create_Date() {
			return this.DI_Create_Date;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + (int) this.VEHICLE_MODEL_SK;

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final Vehicle_Model1Struct other = (Vehicle_Model1Struct) obj;

			if (this.VEHICLE_MODEL_SK != other.VEHICLE_MODEL_SK)
				return false;

			return true;
		}

		public void copyDataTo(Vehicle_Model1Struct other) {

			other.VEHICLE_MODEL_SK = this.VEHICLE_MODEL_SK;
			other.VEHICLE_MODEL = this.VEHICLE_MODEL;
			other.DI_PID = this.DI_PID;
			other.DI_Create_Date = this.DI_Create_Date;

		}

		public void copyKeysDataTo(Vehicle_Model1Struct other) {

			other.VEHICLE_MODEL_SK = this.VEHICLE_MODEL_SK;

		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2) {

				try {

					int length = 0;

					this.VEHICLE_MODEL_SK = dis.readInt();

					this.VEHICLE_MODEL = readString(dis);

					this.DI_PID = readString(dis);

					this.DI_Create_Date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2) {

				try {

					int length = 0;

					this.VEHICLE_MODEL_SK = dis.readInt();

					this.VEHICLE_MODEL = readString(dis);

					this.DI_PID = readString(dis);

					this.DI_Create_Date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// int

				dos.writeInt(this.VEHICLE_MODEL_SK);

				// String

				writeString(this.VEHICLE_MODEL, dos);

				// String

				writeString(this.DI_PID, dos);

				// java.util.Date

				writeDate(this.DI_Create_Date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// int

				dos.writeInt(this.VEHICLE_MODEL_SK);

				// String

				writeString(this.VEHICLE_MODEL, dos);

				// String

				writeString(this.DI_PID, dos);

				// java.util.Date

				writeDate(this.DI_Create_Date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("VEHICLE_MODEL_SK=" + String.valueOf(VEHICLE_MODEL_SK));
			sb.append(",VEHICLE_MODEL=" + VEHICLE_MODEL);
			sb.append(",DI_PID=" + DI_PID);
			sb.append(",DI_Create_Date=" + String.valueOf(DI_Create_Date));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			sb.append(VEHICLE_MODEL_SK);

			sb.append("|");

			if (VEHICLE_MODEL == null) {
				sb.append("<null>");
			} else {
				sb.append(VEHICLE_MODEL);
			}

			sb.append("|");

			if (DI_PID == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_PID);
			}

			sb.append("|");

			if (DI_Create_Date == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_Create_Date);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(Vehicle_Model1Struct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.VEHICLE_MODEL_SK, other.VEHICLE_MODEL_SK);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row5Struct implements routines.system.IPersistableRow<row5Struct> {
		final static byte[] commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2 = new byte[0];
		static byte[] commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[0];

		public String VEHICLE_MODEL;

		public String getVEHICLE_MODEL() {
			return this.VEHICLE_MODEL;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2) {

				try {

					int length = 0;

					this.VEHICLE_MODEL = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2) {

				try {

					int length = 0;

					this.VEHICLE_MODEL = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.VEHICLE_MODEL, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.VEHICLE_MODEL, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("VEHICLE_MODEL=" + VEHICLE_MODEL);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (VEHICLE_MODEL == null) {
				sb.append("<null>");
			} else {
				sb.append(VEHICLE_MODEL);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row5Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class Vehicle_Make2Struct implements routines.system.IPersistableRow<Vehicle_Make2Struct> {
		final static byte[] commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2 = new byte[0];
		static byte[] commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public int VEHICLE_MAKE_SK;

		public int getVEHICLE_MAKE_SK() {
			return this.VEHICLE_MAKE_SK;
		}

		public String VEHICLE_MAKE;

		public String getVEHICLE_MAKE() {
			return this.VEHICLE_MAKE;
		}

		public String DI_PID;

		public String getDI_PID() {
			return this.DI_PID;
		}

		public java.util.Date DI_Create_Date;

		public java.util.Date getDI_Create_Date() {
			return this.DI_Create_Date;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + (int) this.VEHICLE_MAKE_SK;

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final Vehicle_Make2Struct other = (Vehicle_Make2Struct) obj;

			if (this.VEHICLE_MAKE_SK != other.VEHICLE_MAKE_SK)
				return false;

			return true;
		}

		public void copyDataTo(Vehicle_Make2Struct other) {

			other.VEHICLE_MAKE_SK = this.VEHICLE_MAKE_SK;
			other.VEHICLE_MAKE = this.VEHICLE_MAKE;
			other.DI_PID = this.DI_PID;
			other.DI_Create_Date = this.DI_Create_Date;

		}

		public void copyKeysDataTo(Vehicle_Make2Struct other) {

			other.VEHICLE_MAKE_SK = this.VEHICLE_MAKE_SK;

		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2) {

				try {

					int length = 0;

					this.VEHICLE_MAKE_SK = dis.readInt();

					this.VEHICLE_MAKE = readString(dis);

					this.DI_PID = readString(dis);

					this.DI_Create_Date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2) {

				try {

					int length = 0;

					this.VEHICLE_MAKE_SK = dis.readInt();

					this.VEHICLE_MAKE = readString(dis);

					this.DI_PID = readString(dis);

					this.DI_Create_Date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// int

				dos.writeInt(this.VEHICLE_MAKE_SK);

				// String

				writeString(this.VEHICLE_MAKE, dos);

				// String

				writeString(this.DI_PID, dos);

				// java.util.Date

				writeDate(this.DI_Create_Date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// int

				dos.writeInt(this.VEHICLE_MAKE_SK);

				// String

				writeString(this.VEHICLE_MAKE, dos);

				// String

				writeString(this.DI_PID, dos);

				// java.util.Date

				writeDate(this.DI_Create_Date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("VEHICLE_MAKE_SK=" + String.valueOf(VEHICLE_MAKE_SK));
			sb.append(",VEHICLE_MAKE=" + VEHICLE_MAKE);
			sb.append(",DI_PID=" + DI_PID);
			sb.append(",DI_Create_Date=" + String.valueOf(DI_Create_Date));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			sb.append(VEHICLE_MAKE_SK);

			sb.append("|");

			if (VEHICLE_MAKE == null) {
				sb.append("<null>");
			} else {
				sb.append(VEHICLE_MAKE);
			}

			sb.append("|");

			if (DI_PID == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_PID);
			}

			sb.append("|");

			if (DI_Create_Date == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_Create_Date);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(Vehicle_Make2Struct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.VEHICLE_MAKE_SK, other.VEHICLE_MAKE_SK);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row4Struct implements routines.system.IPersistableRow<row4Struct> {
		final static byte[] commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2 = new byte[0];
		static byte[] commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[0];

		public String VEHICLE_MAKE;

		public String getVEHICLE_MAKE() {
			return this.VEHICLE_MAKE;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2) {

				try {

					int length = 0;

					this.VEHICLE_MAKE = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2) {

				try {

					int length = 0;

					this.VEHICLE_MAKE = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.VEHICLE_MAKE, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.VEHICLE_MAKE, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("VEHICLE_MAKE=" + VEHICLE_MAKE);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (VEHICLE_MAKE == null) {
				sb.append("<null>");
			} else {
				sb.append(VEHICLE_MAKE);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row4Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class Vehicle_Type2Struct implements routines.system.IPersistableRow<Vehicle_Type2Struct> {
		final static byte[] commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2 = new byte[0];
		static byte[] commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public Integer VEHICLE_TYPE_SK;

		public Integer getVEHICLE_TYPE_SK() {
			return this.VEHICLE_TYPE_SK;
		}

		public String VEHICLE_TYPE;

		public String getVEHICLE_TYPE() {
			return this.VEHICLE_TYPE;
		}

		public String DI_PID;

		public String getDI_PID() {
			return this.DI_PID;
		}

		public java.util.Date DI_Create_Date;

		public java.util.Date getDI_Create_Date() {
			return this.DI_Create_Date;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + ((this.VEHICLE_TYPE_SK == null) ? 0 : this.VEHICLE_TYPE_SK.hashCode());

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final Vehicle_Type2Struct other = (Vehicle_Type2Struct) obj;

			if (this.VEHICLE_TYPE_SK == null) {
				if (other.VEHICLE_TYPE_SK != null)
					return false;

			} else if (!this.VEHICLE_TYPE_SK.equals(other.VEHICLE_TYPE_SK))

				return false;

			return true;
		}

		public void copyDataTo(Vehicle_Type2Struct other) {

			other.VEHICLE_TYPE_SK = this.VEHICLE_TYPE_SK;
			other.VEHICLE_TYPE = this.VEHICLE_TYPE;
			other.DI_PID = this.DI_PID;
			other.DI_Create_Date = this.DI_Create_Date;

		}

		public void copyKeysDataTo(Vehicle_Type2Struct other) {

			other.VEHICLE_TYPE_SK = this.VEHICLE_TYPE_SK;

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2) {

				try {

					int length = 0;

					this.VEHICLE_TYPE_SK = readInteger(dis);

					this.VEHICLE_TYPE = readString(dis);

					this.DI_PID = readString(dis);

					this.DI_Create_Date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2) {

				try {

					int length = 0;

					this.VEHICLE_TYPE_SK = readInteger(dis);

					this.VEHICLE_TYPE = readString(dis);

					this.DI_PID = readString(dis);

					this.DI_Create_Date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.VEHICLE_TYPE_SK, dos);

				// String

				writeString(this.VEHICLE_TYPE, dos);

				// String

				writeString(this.DI_PID, dos);

				// java.util.Date

				writeDate(this.DI_Create_Date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.VEHICLE_TYPE_SK, dos);

				// String

				writeString(this.VEHICLE_TYPE, dos);

				// String

				writeString(this.DI_PID, dos);

				// java.util.Date

				writeDate(this.DI_Create_Date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("VEHICLE_TYPE_SK=" + String.valueOf(VEHICLE_TYPE_SK));
			sb.append(",VEHICLE_TYPE=" + VEHICLE_TYPE);
			sb.append(",DI_PID=" + DI_PID);
			sb.append(",DI_Create_Date=" + String.valueOf(DI_Create_Date));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (VEHICLE_TYPE_SK == null) {
				sb.append("<null>");
			} else {
				sb.append(VEHICLE_TYPE_SK);
			}

			sb.append("|");

			if (VEHICLE_TYPE == null) {
				sb.append("<null>");
			} else {
				sb.append(VEHICLE_TYPE);
			}

			sb.append("|");

			if (DI_PID == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_PID);
			}

			sb.append("|");

			if (DI_Create_Date == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_Create_Date);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(Vehicle_Type2Struct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.VEHICLE_TYPE_SK, other.VEHICLE_TYPE_SK);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row3Struct implements routines.system.IPersistableRow<row3Struct> {
		final static byte[] commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2 = new byte[0];
		static byte[] commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[0];

		public String VEHICLE_TYPE;

		public String getVEHICLE_TYPE() {
			return this.VEHICLE_TYPE;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2) {

				try {

					int length = 0;

					this.VEHICLE_TYPE = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2) {

				try {

					int length = 0;

					this.VEHICLE_TYPE = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.VEHICLE_TYPE, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.VEHICLE_TYPE, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("VEHICLE_TYPE=" + VEHICLE_TYPE);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (VEHICLE_TYPE == null) {
				sb.append("<null>");
			} else {
				sb.append(VEHICLE_TYPE);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row3Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class State_Reg2Struct implements routines.system.IPersistableRow<State_Reg2Struct> {
		final static byte[] commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2 = new byte[0];
		static byte[] commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public Integer STATE_REGISTRATION_SK;

		public Integer getSTATE_REGISTRATION_SK() {
			return this.STATE_REGISTRATION_SK;
		}

		public String STATE_REGISTRATION;

		public String getSTATE_REGISTRATION() {
			return this.STATE_REGISTRATION;
		}

		public String DI_PID;

		public String getDI_PID() {
			return this.DI_PID;
		}

		public java.util.Date DI_Create_Date;

		public java.util.Date getDI_Create_Date() {
			return this.DI_Create_Date;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result
						+ ((this.STATE_REGISTRATION_SK == null) ? 0 : this.STATE_REGISTRATION_SK.hashCode());

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final State_Reg2Struct other = (State_Reg2Struct) obj;

			if (this.STATE_REGISTRATION_SK == null) {
				if (other.STATE_REGISTRATION_SK != null)
					return false;

			} else if (!this.STATE_REGISTRATION_SK.equals(other.STATE_REGISTRATION_SK))

				return false;

			return true;
		}

		public void copyDataTo(State_Reg2Struct other) {

			other.STATE_REGISTRATION_SK = this.STATE_REGISTRATION_SK;
			other.STATE_REGISTRATION = this.STATE_REGISTRATION;
			other.DI_PID = this.DI_PID;
			other.DI_Create_Date = this.DI_Create_Date;

		}

		public void copyKeysDataTo(State_Reg2Struct other) {

			other.STATE_REGISTRATION_SK = this.STATE_REGISTRATION_SK;

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2) {

				try {

					int length = 0;

					this.STATE_REGISTRATION_SK = readInteger(dis);

					this.STATE_REGISTRATION = readString(dis);

					this.DI_PID = readString(dis);

					this.DI_Create_Date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2) {

				try {

					int length = 0;

					this.STATE_REGISTRATION_SK = readInteger(dis);

					this.STATE_REGISTRATION = readString(dis);

					this.DI_PID = readString(dis);

					this.DI_Create_Date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.STATE_REGISTRATION_SK, dos);

				// String

				writeString(this.STATE_REGISTRATION, dos);

				// String

				writeString(this.DI_PID, dos);

				// java.util.Date

				writeDate(this.DI_Create_Date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.STATE_REGISTRATION_SK, dos);

				// String

				writeString(this.STATE_REGISTRATION, dos);

				// String

				writeString(this.DI_PID, dos);

				// java.util.Date

				writeDate(this.DI_Create_Date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("STATE_REGISTRATION_SK=" + String.valueOf(STATE_REGISTRATION_SK));
			sb.append(",STATE_REGISTRATION=" + STATE_REGISTRATION);
			sb.append(",DI_PID=" + DI_PID);
			sb.append(",DI_Create_Date=" + String.valueOf(DI_Create_Date));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (STATE_REGISTRATION_SK == null) {
				sb.append("<null>");
			} else {
				sb.append(STATE_REGISTRATION_SK);
			}

			sb.append("|");

			if (STATE_REGISTRATION == null) {
				sb.append("<null>");
			} else {
				sb.append(STATE_REGISTRATION);
			}

			sb.append("|");

			if (DI_PID == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_PID);
			}

			sb.append("|");

			if (DI_Create_Date == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_Create_Date);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(State_Reg2Struct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.STATE_REGISTRATION_SK, other.STATE_REGISTRATION_SK);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row2Struct implements routines.system.IPersistableRow<row2Struct> {
		final static byte[] commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2 = new byte[0];
		static byte[] commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[0];

		public String STATE_REGISTRATION;

		public String getSTATE_REGISTRATION() {
			return this.STATE_REGISTRATION;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2) {

				try {

					int length = 0;

					this.STATE_REGISTRATION = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2) {

				try {

					int length = 0;

					this.STATE_REGISTRATION = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.STATE_REGISTRATION, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.STATE_REGISTRATION, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("STATE_REGISTRATION=" + STATE_REGISTRATION);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (STATE_REGISTRATION == null) {
				sb.append("<null>");
			} else {
				sb.append(STATE_REGISTRATION);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row2Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class State_Registration_SkStruct
			implements routines.system.IPersistableRow<State_Registration_SkStruct> {
		final static byte[] commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2 = new byte[0];
		static byte[] commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[0];

		public String STATE_REGISTRATION;

		public String getSTATE_REGISTRATION() {
			return this.STATE_REGISTRATION;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2) {

				try {

					int length = 0;

					this.STATE_REGISTRATION = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2) {

				try {

					int length = 0;

					this.STATE_REGISTRATION = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.STATE_REGISTRATION, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.STATE_REGISTRATION, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("STATE_REGISTRATION=" + STATE_REGISTRATION);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (STATE_REGISTRATION == null) {
				sb.append("<null>");
			} else {
				sb.append(STATE_REGISTRATION);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(State_Registration_SkStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class Vehicle_typeStruct implements routines.system.IPersistableRow<Vehicle_typeStruct> {
		final static byte[] commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2 = new byte[0];
		static byte[] commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[0];

		public String VEHICLE_TYPE;

		public String getVEHICLE_TYPE() {
			return this.VEHICLE_TYPE;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2) {

				try {

					int length = 0;

					this.VEHICLE_TYPE = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2) {

				try {

					int length = 0;

					this.VEHICLE_TYPE = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.VEHICLE_TYPE, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.VEHICLE_TYPE, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("VEHICLE_TYPE=" + VEHICLE_TYPE);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (VEHICLE_TYPE == null) {
				sb.append("<null>");
			} else {
				sb.append(VEHICLE_TYPE);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(Vehicle_typeStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class Vehicle_MakeStruct implements routines.system.IPersistableRow<Vehicle_MakeStruct> {
		final static byte[] commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2 = new byte[0];
		static byte[] commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[0];

		public String VEHICLE_MAKE;

		public String getVEHICLE_MAKE() {
			return this.VEHICLE_MAKE;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2) {

				try {

					int length = 0;

					this.VEHICLE_MAKE = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2) {

				try {

					int length = 0;

					this.VEHICLE_MAKE = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.VEHICLE_MAKE, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.VEHICLE_MAKE, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("VEHICLE_MAKE=" + VEHICLE_MAKE);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (VEHICLE_MAKE == null) {
				sb.append("<null>");
			} else {
				sb.append(VEHICLE_MAKE);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(Vehicle_MakeStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class Vehicle_ModelStruct implements routines.system.IPersistableRow<Vehicle_ModelStruct> {
		final static byte[] commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2 = new byte[0];
		static byte[] commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[0];

		public String VEHICLE_MODEL;

		public String getVEHICLE_MODEL() {
			return this.VEHICLE_MODEL;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2) {

				try {

					int length = 0;

					this.VEHICLE_MODEL = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2) {

				try {

					int length = 0;

					this.VEHICLE_MODEL = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.VEHICLE_MODEL, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.VEHICLE_MODEL, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("VEHICLE_MODEL=" + VEHICLE_MODEL);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (VEHICLE_MODEL == null) {
				sb.append("<null>");
			} else {
				sb.append(VEHICLE_MODEL);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(Vehicle_ModelStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class Travel_DirectionStruct implements routines.system.IPersistableRow<Travel_DirectionStruct> {
		final static byte[] commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2 = new byte[0];
		static byte[] commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[0];

		public String TRAVEL_DIRECTION;

		public String getTRAVEL_DIRECTION() {
			return this.TRAVEL_DIRECTION;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2) {

				try {

					int length = 0;

					this.TRAVEL_DIRECTION = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2) {

				try {

					int length = 0;

					this.TRAVEL_DIRECTION = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.TRAVEL_DIRECTION, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.TRAVEL_DIRECTION, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("TRAVEL_DIRECTION=" + TRAVEL_DIRECTION);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (TRAVEL_DIRECTION == null) {
				sb.append("<null>");
			} else {
				sb.append(TRAVEL_DIRECTION);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(Travel_DirectionStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class Driver_License_StatusStruct
			implements routines.system.IPersistableRow<Driver_License_StatusStruct> {
		final static byte[] commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2 = new byte[0];
		static byte[] commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[0];

		public String DRIVER_LICENSE_STATUS;

		public String getDRIVER_LICENSE_STATUS() {
			return this.DRIVER_LICENSE_STATUS;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2) {

				try {

					int length = 0;

					this.DRIVER_LICENSE_STATUS = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2) {

				try {

					int length = 0;

					this.DRIVER_LICENSE_STATUS = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.DRIVER_LICENSE_STATUS, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.DRIVER_LICENSE_STATUS, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("DRIVER_LICENSE_STATUS=" + DRIVER_LICENSE_STATUS);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (DRIVER_LICENSE_STATUS == null) {
				sb.append("<null>");
			} else {
				sb.append(DRIVER_LICENSE_STATUS);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(Driver_License_StatusStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class Driver_License_JusridictionStruct
			implements routines.system.IPersistableRow<Driver_License_JusridictionStruct> {
		final static byte[] commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2 = new byte[0];
		static byte[] commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[0];

		public String DRIVER_LICENSE_JURISDICTION;

		public String getDRIVER_LICENSE_JURISDICTION() {
			return this.DRIVER_LICENSE_JURISDICTION;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2) {

				try {

					int length = 0;

					this.DRIVER_LICENSE_JURISDICTION = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2) {

				try {

					int length = 0;

					this.DRIVER_LICENSE_JURISDICTION = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.DRIVER_LICENSE_JURISDICTION, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.DRIVER_LICENSE_JURISDICTION, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("DRIVER_LICENSE_JURISDICTION=" + DRIVER_LICENSE_JURISDICTION);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (DRIVER_LICENSE_JURISDICTION == null) {
				sb.append("<null>");
			} else {
				sb.append(DRIVER_LICENSE_JURISDICTION);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(Driver_License_JusridictionStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class PreCashStruct implements routines.system.IPersistableRow<PreCashStruct> {
		final static byte[] commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2 = new byte[0];
		static byte[] commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[0];

		public String PRE_CRASH;

		public String getPRE_CRASH() {
			return this.PRE_CRASH;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2) {

				try {

					int length = 0;

					this.PRE_CRASH = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2) {

				try {

					int length = 0;

					this.PRE_CRASH = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.PRE_CRASH, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.PRE_CRASH, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("PRE_CRASH=" + PRE_CRASH);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (PRE_CRASH == null) {
				sb.append("<null>");
			} else {
				sb.append(PRE_CRASH);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(PreCashStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class Point_Of_ImpactStruct implements routines.system.IPersistableRow<Point_Of_ImpactStruct> {
		final static byte[] commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2 = new byte[0];
		static byte[] commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[0];

		public String POINT_OF_IMPACT;

		public String getPOINT_OF_IMPACT() {
			return this.POINT_OF_IMPACT;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2) {

				try {

					int length = 0;

					this.POINT_OF_IMPACT = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2) {

				try {

					int length = 0;

					this.POINT_OF_IMPACT = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.POINT_OF_IMPACT, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.POINT_OF_IMPACT, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("POINT_OF_IMPACT=" + POINT_OF_IMPACT);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (POINT_OF_IMPACT == null) {
				sb.append("<null>");
			} else {
				sb.append(POINT_OF_IMPACT);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(Point_Of_ImpactStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class Public_propertyDamageStruct
			implements routines.system.IPersistableRow<Public_propertyDamageStruct> {
		final static byte[] commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2 = new byte[0];
		static byte[] commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[0];

		public String PUBLIC_PROPERTY_DAMAGE;

		public String getPUBLIC_PROPERTY_DAMAGE() {
			return this.PUBLIC_PROPERTY_DAMAGE;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2) {

				try {

					int length = 0;

					this.PUBLIC_PROPERTY_DAMAGE = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2) {

				try {

					int length = 0;

					this.PUBLIC_PROPERTY_DAMAGE = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.PUBLIC_PROPERTY_DAMAGE, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.PUBLIC_PROPERTY_DAMAGE, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("PUBLIC_PROPERTY_DAMAGE=" + PUBLIC_PROPERTY_DAMAGE);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (PUBLIC_PROPERTY_DAMAGE == null) {
				sb.append("<null>");
			} else {
				sb.append(PUBLIC_PROPERTY_DAMAGE);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(Public_propertyDamageStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row1Struct implements routines.system.IPersistableRow<row1Struct> {
		final static byte[] commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2 = new byte[0];
		static byte[] commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[0];

		public Integer COLLISION_ID;

		public Integer getCOLLISION_ID() {
			return this.COLLISION_ID;
		}

		public String CRASH_DATE;

		public String getCRASH_DATE() {
			return this.CRASH_DATE;
		}

		public String CRASH_TIME;

		public String getCRASH_TIME() {
			return this.CRASH_TIME;
		}

		public String VEHICLE_ID;

		public String getVEHICLE_ID() {
			return this.VEHICLE_ID;
		}

		public String STATE_REGISTRATION;

		public String getSTATE_REGISTRATION() {
			return this.STATE_REGISTRATION;
		}

		public String VEHICLE_TYPE;

		public String getVEHICLE_TYPE() {
			return this.VEHICLE_TYPE;
		}

		public String VEHICLE_MAKE;

		public String getVEHICLE_MAKE() {
			return this.VEHICLE_MAKE;
		}

		public String VEHICLE_MODEL;

		public String getVEHICLE_MODEL() {
			return this.VEHICLE_MODEL;
		}

		public String VEHICLE_YEAR;

		public String getVEHICLE_YEAR() {
			return this.VEHICLE_YEAR;
		}

		public String TRAVEL_DIRECTION;

		public String getTRAVEL_DIRECTION() {
			return this.TRAVEL_DIRECTION;
		}

		public String VEHICLE_OCCUPANTS;

		public String getVEHICLE_OCCUPANTS() {
			return this.VEHICLE_OCCUPANTS;
		}

		public String DRIVER_SEX;

		public String getDRIVER_SEX() {
			return this.DRIVER_SEX;
		}

		public String DRIVER_LICENSE_STATUS;

		public String getDRIVER_LICENSE_STATUS() {
			return this.DRIVER_LICENSE_STATUS;
		}

		public String DRIVER_LICENSE_JURISDICTION;

		public String getDRIVER_LICENSE_JURISDICTION() {
			return this.DRIVER_LICENSE_JURISDICTION;
		}

		public String PRE_CRASH;

		public String getPRE_CRASH() {
			return this.PRE_CRASH;
		}

		public String POINT_OF_IMPACT;

		public String getPOINT_OF_IMPACT() {
			return this.POINT_OF_IMPACT;
		}

		public String VEHICLE_DAMAGE;

		public String getVEHICLE_DAMAGE() {
			return this.VEHICLE_DAMAGE;
		}

		public String VEHICLE_DAMAGE_1;

		public String getVEHICLE_DAMAGE_1() {
			return this.VEHICLE_DAMAGE_1;
		}

		public String VEHICLE_DAMAGE_2;

		public String getVEHICLE_DAMAGE_2() {
			return this.VEHICLE_DAMAGE_2;
		}

		public String VEHICLE_DAMAGE_3;

		public String getVEHICLE_DAMAGE_3() {
			return this.VEHICLE_DAMAGE_3;
		}

		public String PUBLIC_PROPERTY_DAMAGE;

		public String getPUBLIC_PROPERTY_DAMAGE() {
			return this.PUBLIC_PROPERTY_DAMAGE;
		}

		public String PUBLIC_PROPERTY_DAMAGE_TYPE;

		public String getPUBLIC_PROPERTY_DAMAGE_TYPE() {
			return this.PUBLIC_PROPERTY_DAMAGE_TYPE;
		}

		public String CONTRIBUTING_FACTOR_1;

		public String getCONTRIBUTING_FACTOR_1() {
			return this.CONTRIBUTING_FACTOR_1;
		}

		public String CONTRIBUTING_FACTOR_2;

		public String getCONTRIBUTING_FACTOR_2() {
			return this.CONTRIBUTING_FACTOR_2;
		}

		public Integer UNIQUE_ID;

		public Integer getUNIQUE_ID() {
			return this.UNIQUE_ID;
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length) {
					if (length < 1024 && commonByteArray_MVC_TALEND_Loading_Dimension_Part2.length == 0) {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[1024];
					} else {
						commonByteArray_MVC_TALEND_Loading_Dimension_Part2 = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length);
				strReturn = new String(commonByteArray_MVC_TALEND_Loading_Dimension_Part2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2) {

				try {

					int length = 0;

					this.COLLISION_ID = readInteger(dis);

					this.CRASH_DATE = readString(dis);

					this.CRASH_TIME = readString(dis);

					this.VEHICLE_ID = readString(dis);

					this.STATE_REGISTRATION = readString(dis);

					this.VEHICLE_TYPE = readString(dis);

					this.VEHICLE_MAKE = readString(dis);

					this.VEHICLE_MODEL = readString(dis);

					this.VEHICLE_YEAR = readString(dis);

					this.TRAVEL_DIRECTION = readString(dis);

					this.VEHICLE_OCCUPANTS = readString(dis);

					this.DRIVER_SEX = readString(dis);

					this.DRIVER_LICENSE_STATUS = readString(dis);

					this.DRIVER_LICENSE_JURISDICTION = readString(dis);

					this.PRE_CRASH = readString(dis);

					this.POINT_OF_IMPACT = readString(dis);

					this.VEHICLE_DAMAGE = readString(dis);

					this.VEHICLE_DAMAGE_1 = readString(dis);

					this.VEHICLE_DAMAGE_2 = readString(dis);

					this.VEHICLE_DAMAGE_3 = readString(dis);

					this.PUBLIC_PROPERTY_DAMAGE = readString(dis);

					this.PUBLIC_PROPERTY_DAMAGE_TYPE = readString(dis);

					this.CONTRIBUTING_FACTOR_1 = readString(dis);

					this.CONTRIBUTING_FACTOR_2 = readString(dis);

					this.UNIQUE_ID = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MVC_TALEND_Loading_Dimension_Part2) {

				try {

					int length = 0;

					this.COLLISION_ID = readInteger(dis);

					this.CRASH_DATE = readString(dis);

					this.CRASH_TIME = readString(dis);

					this.VEHICLE_ID = readString(dis);

					this.STATE_REGISTRATION = readString(dis);

					this.VEHICLE_TYPE = readString(dis);

					this.VEHICLE_MAKE = readString(dis);

					this.VEHICLE_MODEL = readString(dis);

					this.VEHICLE_YEAR = readString(dis);

					this.TRAVEL_DIRECTION = readString(dis);

					this.VEHICLE_OCCUPANTS = readString(dis);

					this.DRIVER_SEX = readString(dis);

					this.DRIVER_LICENSE_STATUS = readString(dis);

					this.DRIVER_LICENSE_JURISDICTION = readString(dis);

					this.PRE_CRASH = readString(dis);

					this.POINT_OF_IMPACT = readString(dis);

					this.VEHICLE_DAMAGE = readString(dis);

					this.VEHICLE_DAMAGE_1 = readString(dis);

					this.VEHICLE_DAMAGE_2 = readString(dis);

					this.VEHICLE_DAMAGE_3 = readString(dis);

					this.PUBLIC_PROPERTY_DAMAGE = readString(dis);

					this.PUBLIC_PROPERTY_DAMAGE_TYPE = readString(dis);

					this.CONTRIBUTING_FACTOR_1 = readString(dis);

					this.CONTRIBUTING_FACTOR_2 = readString(dis);

					this.UNIQUE_ID = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.COLLISION_ID, dos);

				// String

				writeString(this.CRASH_DATE, dos);

				// String

				writeString(this.CRASH_TIME, dos);

				// String

				writeString(this.VEHICLE_ID, dos);

				// String

				writeString(this.STATE_REGISTRATION, dos);

				// String

				writeString(this.VEHICLE_TYPE, dos);

				// String

				writeString(this.VEHICLE_MAKE, dos);

				// String

				writeString(this.VEHICLE_MODEL, dos);

				// String

				writeString(this.VEHICLE_YEAR, dos);

				// String

				writeString(this.TRAVEL_DIRECTION, dos);

				// String

				writeString(this.VEHICLE_OCCUPANTS, dos);

				// String

				writeString(this.DRIVER_SEX, dos);

				// String

				writeString(this.DRIVER_LICENSE_STATUS, dos);

				// String

				writeString(this.DRIVER_LICENSE_JURISDICTION, dos);

				// String

				writeString(this.PRE_CRASH, dos);

				// String

				writeString(this.POINT_OF_IMPACT, dos);

				// String

				writeString(this.VEHICLE_DAMAGE, dos);

				// String

				writeString(this.VEHICLE_DAMAGE_1, dos);

				// String

				writeString(this.VEHICLE_DAMAGE_2, dos);

				// String

				writeString(this.VEHICLE_DAMAGE_3, dos);

				// String

				writeString(this.PUBLIC_PROPERTY_DAMAGE, dos);

				// String

				writeString(this.PUBLIC_PROPERTY_DAMAGE_TYPE, dos);

				// String

				writeString(this.CONTRIBUTING_FACTOR_1, dos);

				// String

				writeString(this.CONTRIBUTING_FACTOR_2, dos);

				// Integer

				writeInteger(this.UNIQUE_ID, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.COLLISION_ID, dos);

				// String

				writeString(this.CRASH_DATE, dos);

				// String

				writeString(this.CRASH_TIME, dos);

				// String

				writeString(this.VEHICLE_ID, dos);

				// String

				writeString(this.STATE_REGISTRATION, dos);

				// String

				writeString(this.VEHICLE_TYPE, dos);

				// String

				writeString(this.VEHICLE_MAKE, dos);

				// String

				writeString(this.VEHICLE_MODEL, dos);

				// String

				writeString(this.VEHICLE_YEAR, dos);

				// String

				writeString(this.TRAVEL_DIRECTION, dos);

				// String

				writeString(this.VEHICLE_OCCUPANTS, dos);

				// String

				writeString(this.DRIVER_SEX, dos);

				// String

				writeString(this.DRIVER_LICENSE_STATUS, dos);

				// String

				writeString(this.DRIVER_LICENSE_JURISDICTION, dos);

				// String

				writeString(this.PRE_CRASH, dos);

				// String

				writeString(this.POINT_OF_IMPACT, dos);

				// String

				writeString(this.VEHICLE_DAMAGE, dos);

				// String

				writeString(this.VEHICLE_DAMAGE_1, dos);

				// String

				writeString(this.VEHICLE_DAMAGE_2, dos);

				// String

				writeString(this.VEHICLE_DAMAGE_3, dos);

				// String

				writeString(this.PUBLIC_PROPERTY_DAMAGE, dos);

				// String

				writeString(this.PUBLIC_PROPERTY_DAMAGE_TYPE, dos);

				// String

				writeString(this.CONTRIBUTING_FACTOR_1, dos);

				// String

				writeString(this.CONTRIBUTING_FACTOR_2, dos);

				// Integer

				writeInteger(this.UNIQUE_ID, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("COLLISION_ID=" + String.valueOf(COLLISION_ID));
			sb.append(",CRASH_DATE=" + CRASH_DATE);
			sb.append(",CRASH_TIME=" + CRASH_TIME);
			sb.append(",VEHICLE_ID=" + VEHICLE_ID);
			sb.append(",STATE_REGISTRATION=" + STATE_REGISTRATION);
			sb.append(",VEHICLE_TYPE=" + VEHICLE_TYPE);
			sb.append(",VEHICLE_MAKE=" + VEHICLE_MAKE);
			sb.append(",VEHICLE_MODEL=" + VEHICLE_MODEL);
			sb.append(",VEHICLE_YEAR=" + VEHICLE_YEAR);
			sb.append(",TRAVEL_DIRECTION=" + TRAVEL_DIRECTION);
			sb.append(",VEHICLE_OCCUPANTS=" + VEHICLE_OCCUPANTS);
			sb.append(",DRIVER_SEX=" + DRIVER_SEX);
			sb.append(",DRIVER_LICENSE_STATUS=" + DRIVER_LICENSE_STATUS);
			sb.append(",DRIVER_LICENSE_JURISDICTION=" + DRIVER_LICENSE_JURISDICTION);
			sb.append(",PRE_CRASH=" + PRE_CRASH);
			sb.append(",POINT_OF_IMPACT=" + POINT_OF_IMPACT);
			sb.append(",VEHICLE_DAMAGE=" + VEHICLE_DAMAGE);
			sb.append(",VEHICLE_DAMAGE_1=" + VEHICLE_DAMAGE_1);
			sb.append(",VEHICLE_DAMAGE_2=" + VEHICLE_DAMAGE_2);
			sb.append(",VEHICLE_DAMAGE_3=" + VEHICLE_DAMAGE_3);
			sb.append(",PUBLIC_PROPERTY_DAMAGE=" + PUBLIC_PROPERTY_DAMAGE);
			sb.append(",PUBLIC_PROPERTY_DAMAGE_TYPE=" + PUBLIC_PROPERTY_DAMAGE_TYPE);
			sb.append(",CONTRIBUTING_FACTOR_1=" + CONTRIBUTING_FACTOR_1);
			sb.append(",CONTRIBUTING_FACTOR_2=" + CONTRIBUTING_FACTOR_2);
			sb.append(",UNIQUE_ID=" + String.valueOf(UNIQUE_ID));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (COLLISION_ID == null) {
				sb.append("<null>");
			} else {
				sb.append(COLLISION_ID);
			}

			sb.append("|");

			if (CRASH_DATE == null) {
				sb.append("<null>");
			} else {
				sb.append(CRASH_DATE);
			}

			sb.append("|");

			if (CRASH_TIME == null) {
				sb.append("<null>");
			} else {
				sb.append(CRASH_TIME);
			}

			sb.append("|");

			if (VEHICLE_ID == null) {
				sb.append("<null>");
			} else {
				sb.append(VEHICLE_ID);
			}

			sb.append("|");

			if (STATE_REGISTRATION == null) {
				sb.append("<null>");
			} else {
				sb.append(STATE_REGISTRATION);
			}

			sb.append("|");

			if (VEHICLE_TYPE == null) {
				sb.append("<null>");
			} else {
				sb.append(VEHICLE_TYPE);
			}

			sb.append("|");

			if (VEHICLE_MAKE == null) {
				sb.append("<null>");
			} else {
				sb.append(VEHICLE_MAKE);
			}

			sb.append("|");

			if (VEHICLE_MODEL == null) {
				sb.append("<null>");
			} else {
				sb.append(VEHICLE_MODEL);
			}

			sb.append("|");

			if (VEHICLE_YEAR == null) {
				sb.append("<null>");
			} else {
				sb.append(VEHICLE_YEAR);
			}

			sb.append("|");

			if (TRAVEL_DIRECTION == null) {
				sb.append("<null>");
			} else {
				sb.append(TRAVEL_DIRECTION);
			}

			sb.append("|");

			if (VEHICLE_OCCUPANTS == null) {
				sb.append("<null>");
			} else {
				sb.append(VEHICLE_OCCUPANTS);
			}

			sb.append("|");

			if (DRIVER_SEX == null) {
				sb.append("<null>");
			} else {
				sb.append(DRIVER_SEX);
			}

			sb.append("|");

			if (DRIVER_LICENSE_STATUS == null) {
				sb.append("<null>");
			} else {
				sb.append(DRIVER_LICENSE_STATUS);
			}

			sb.append("|");

			if (DRIVER_LICENSE_JURISDICTION == null) {
				sb.append("<null>");
			} else {
				sb.append(DRIVER_LICENSE_JURISDICTION);
			}

			sb.append("|");

			if (PRE_CRASH == null) {
				sb.append("<null>");
			} else {
				sb.append(PRE_CRASH);
			}

			sb.append("|");

			if (POINT_OF_IMPACT == null) {
				sb.append("<null>");
			} else {
				sb.append(POINT_OF_IMPACT);
			}

			sb.append("|");

			if (VEHICLE_DAMAGE == null) {
				sb.append("<null>");
			} else {
				sb.append(VEHICLE_DAMAGE);
			}

			sb.append("|");

			if (VEHICLE_DAMAGE_1 == null) {
				sb.append("<null>");
			} else {
				sb.append(VEHICLE_DAMAGE_1);
			}

			sb.append("|");

			if (VEHICLE_DAMAGE_2 == null) {
				sb.append("<null>");
			} else {
				sb.append(VEHICLE_DAMAGE_2);
			}

			sb.append("|");

			if (VEHICLE_DAMAGE_3 == null) {
				sb.append("<null>");
			} else {
				sb.append(VEHICLE_DAMAGE_3);
			}

			sb.append("|");

			if (PUBLIC_PROPERTY_DAMAGE == null) {
				sb.append("<null>");
			} else {
				sb.append(PUBLIC_PROPERTY_DAMAGE);
			}

			sb.append("|");

			if (PUBLIC_PROPERTY_DAMAGE_TYPE == null) {
				sb.append("<null>");
			} else {
				sb.append(PUBLIC_PROPERTY_DAMAGE_TYPE);
			}

			sb.append("|");

			if (CONTRIBUTING_FACTOR_1 == null) {
				sb.append("<null>");
			} else {
				sb.append(CONTRIBUTING_FACTOR_1);
			}

			sb.append("|");

			if (CONTRIBUTING_FACTOR_2 == null) {
				sb.append("<null>");
			} else {
				sb.append(CONTRIBUTING_FACTOR_2);
			}

			sb.append("|");

			if (UNIQUE_ID == null) {
				sb.append("<null>");
			} else {
				sb.append(UNIQUE_ID);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row1Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tDBInput_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tDBInput_1_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				row1Struct row1 = new row1Struct();
				State_Registration_SkStruct State_Registration_Sk = new State_Registration_SkStruct();
				row2Struct row2 = new row2Struct();
				State_Reg2Struct State_Reg2 = new State_Reg2Struct();
				Vehicle_typeStruct Vehicle_type = new Vehicle_typeStruct();
				row3Struct row3 = new row3Struct();
				Vehicle_Type2Struct Vehicle_Type2 = new Vehicle_Type2Struct();
				Vehicle_MakeStruct Vehicle_Make = new Vehicle_MakeStruct();
				row4Struct row4 = new row4Struct();
				Vehicle_Make2Struct Vehicle_Make2 = new Vehicle_Make2Struct();
				Vehicle_ModelStruct Vehicle_Model = new Vehicle_ModelStruct();
				row5Struct row5 = new row5Struct();
				Vehicle_Model1Struct Vehicle_Model1 = new Vehicle_Model1Struct();
				Travel_DirectionStruct Travel_Direction = new Travel_DirectionStruct();
				row6Struct row6 = new row6Struct();
				Travel_Direction_LoaddStruct Travel_Direction_Loadd = new Travel_Direction_LoaddStruct();
				Driver_License_StatusStruct Driver_License_Status = new Driver_License_StatusStruct();
				row7Struct row7 = new row7Struct();
				Driver_License_Status_2Struct Driver_License_Status_2 = new Driver_License_Status_2Struct();
				Driver_License_JusridictionStruct Driver_License_Jusridiction = new Driver_License_JusridictionStruct();
				row8Struct row8 = new row8Struct();
				JurisdivStruct Jurisdiv = new JurisdivStruct();
				PreCashStruct PreCash = new PreCashStruct();
				row9Struct row9 = new row9Struct();
				PreCash22Struct PreCash22 = new PreCash22Struct();
				Point_Of_ImpactStruct Point_Of_Impact = new Point_Of_ImpactStruct();
				row10Struct row10 = new row10Struct();
				PointOFImpact2Struct PointOFImpact2 = new PointOFImpact2Struct();
				Public_propertyDamageStruct Public_propertyDamage = new Public_propertyDamageStruct();
				row11Struct row11 = new row11Struct();
				PublicPropertyDamage2Struct PublicPropertyDamage2 = new PublicPropertyDamage2Struct();

				/**
				 * [tDBOutput_1 begin ] start
				 */

				ok_Hash.put("tDBOutput_1", false);
				start_Hash.put("tDBOutput_1", System.currentTimeMillis());

				currentComponent = "tDBOutput_1";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "State_Reg2");

				int tos_count_tDBOutput_1 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tDBOutput_1 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tDBOutput_1 = new StringBuilder();
							log4jParamters_tDBOutput_1.append("Parameters:");
							log4jParamters_tDBOutput_1.append("USE_EXISTING_CONNECTION" + " = " + "false");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("DRIVER" + " = " + "JTDS");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("HOST" + " = " + "\"localhost\"");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("PORT" + " = " + "\"1433\"");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("DB_SCHEMA" + " = " + "\"\"");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("DBNAME" + " = " + "\"MVC_Stage\"");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("USER" + " = " + "\"\"");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("PASS" + " = "
									+ String.valueOf(
											"enc:routine.encryption.key.v1:xgl3E/YtlluuldURRSY5+ULBtNNSoD29klahLQ==")
											.substring(0, 4)
									+ "...");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("TABLE" + " = " + "\"Dim_STATE_REGISTRATION\"");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("TABLE_ACTION" + " = " + "NONE");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("IDENTITY_INSERT" + " = " + "false");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("DATA_ACTION" + " = " + "INSERT");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("DIE_ON_ERROR" + " = " + "false");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("PROPERTIES" + " = " + "\"\"");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("COMMIT_EVERY" + " = " + "10000");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("ADD_COLS" + " = " + "[]");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("USE_FIELD_OPTIONS" + " = " + "false");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("IGNORE_DATE_OUTOF_RANGE" + " = " + "false");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("ENABLE_DEBUG_MODE" + " = " + "false");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("SUPPORT_NULL_WHERE" + " = " + "false");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("USE_BATCH_SIZE" + " = " + "true");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("BATCH_SIZE" + " = " + "10000");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("UNIFIED_COMPONENTS" + " = " + "tMSSqlOutput");
							log4jParamters_tDBOutput_1.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tDBOutput_1 - " + (log4jParamters_tDBOutput_1));
						}
					}
					new BytesLimit65535_tDBOutput_1().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tDBOutput_1", "__TABLE__", "tMSSqlOutput");
					talendJobLogProcess(globalMap);
				}

				int nb_line_tDBOutput_1 = 0;
				int nb_line_update_tDBOutput_1 = 0;
				int nb_line_inserted_tDBOutput_1 = 0;
				int nb_line_deleted_tDBOutput_1 = 0;
				int nb_line_rejected_tDBOutput_1 = 0;

				int deletedCount_tDBOutput_1 = 0;
				int updatedCount_tDBOutput_1 = 0;
				int insertedCount_tDBOutput_1 = 0;
				int rowsToCommitCount_tDBOutput_1 = 0;
				int rejectedCount_tDBOutput_1 = 0;
				String dbschema_tDBOutput_1 = null;
				String tableName_tDBOutput_1 = null;
				boolean whetherReject_tDBOutput_1 = false;

				java.util.Calendar calendar_tDBOutput_1 = java.util.Calendar.getInstance();
				long year1_tDBOutput_1 = TalendDate.parseDate("yyyy-MM-dd", "0001-01-01").getTime();
				long year2_tDBOutput_1 = TalendDate.parseDate("yyyy-MM-dd", "1753-01-01").getTime();
				long year10000_tDBOutput_1 = TalendDate.parseDate("yyyy-MM-dd HH:mm:ss", "9999-12-31 24:00:00")
						.getTime();
				long date_tDBOutput_1;

				java.util.Calendar calendar_datetimeoffset_tDBOutput_1 = java.util.Calendar
						.getInstance(java.util.TimeZone.getTimeZone("UTC"));

				java.sql.Connection conn_tDBOutput_1 = null;
				String dbUser_tDBOutput_1 = null;
				dbschema_tDBOutput_1 = "";
				String driverClass_tDBOutput_1 = "net.sourceforge.jtds.jdbc.Driver";

				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Driver ClassName: ") + (driverClass_tDBOutput_1) + ("."));
				java.lang.Class.forName(driverClass_tDBOutput_1);
				String port_tDBOutput_1 = "1433";
				String dbname_tDBOutput_1 = "MVC_Stage";
				String url_tDBOutput_1 = "jdbc:jtds:sqlserver://" + "localhost";
				if (!"".equals(port_tDBOutput_1)) {
					url_tDBOutput_1 += ":" + "1433";
				}
				if (!"".equals(dbname_tDBOutput_1)) {
					url_tDBOutput_1 += "//" + "MVC_Stage";

				}
				url_tDBOutput_1 += ";appName=" + projectName + ";" + "";
				dbUser_tDBOutput_1 = "";

				final String decryptedPassword_tDBOutput_1 = routines.system.PasswordEncryptUtil
						.decryptPassword("enc:routine.encryption.key.v1:zH7D+jHsPa4/Gp6Ll3h0HbQ51/mBzXAedktrZg==");

				String dbPwd_tDBOutput_1 = decryptedPassword_tDBOutput_1;
				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Connection attempts to '") + (url_tDBOutput_1)
							+ ("' with the username '") + (dbUser_tDBOutput_1) + ("'."));
				conn_tDBOutput_1 = java.sql.DriverManager.getConnection(url_tDBOutput_1, dbUser_tDBOutput_1,
						dbPwd_tDBOutput_1);
				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Connection to '") + (url_tDBOutput_1) + ("' has succeeded."));

				resourceMap.put("conn_tDBOutput_1", conn_tDBOutput_1);

				conn_tDBOutput_1.setAutoCommit(false);
				int commitEvery_tDBOutput_1 = 10000;
				int commitCounter_tDBOutput_1 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Connection is set auto commit to '")
							+ (conn_tDBOutput_1.getAutoCommit()) + ("'."));
				int batchSize_tDBOutput_1 = 10000;
				int batchSizeCounter_tDBOutput_1 = 0;

				if (dbschema_tDBOutput_1 == null || dbschema_tDBOutput_1.trim().length() == 0) {
					tableName_tDBOutput_1 = "Dim_STATE_REGISTRATION";
				} else {
					tableName_tDBOutput_1 = dbschema_tDBOutput_1 + "].[" + "Dim_STATE_REGISTRATION";
				}
				int count_tDBOutput_1 = 0;

				String insert_tDBOutput_1 = "INSERT INTO [" + tableName_tDBOutput_1
						+ "] ([STATE_REGISTRATION_SK],[STATE_REGISTRATION],[DI_PID],[DI_Create_Date]) VALUES (?,?,?,?)";
				java.sql.PreparedStatement pstmt_tDBOutput_1 = conn_tDBOutput_1.prepareStatement(insert_tDBOutput_1);
				resourceMap.put("pstmt_tDBOutput_1", pstmt_tDBOutput_1);

				/**
				 * [tDBOutput_1 begin ] stop
				 */

				/**
				 * [tMap_2 begin ] start
				 */

				ok_Hash.put("tMap_2", false);
				start_Hash.put("tMap_2", System.currentTimeMillis());

				currentComponent = "tMap_2";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "row2");

				int tos_count_tMap_2 = 0;

				if (log.isDebugEnabled())
					log.debug("tMap_2 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tMap_2 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tMap_2 = new StringBuilder();
							log4jParamters_tMap_2.append("Parameters:");
							log4jParamters_tMap_2.append("LINK_STYLE" + " = " + "AUTO");
							log4jParamters_tMap_2.append(" | ");
							log4jParamters_tMap_2.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
							log4jParamters_tMap_2.append(" | ");
							log4jParamters_tMap_2.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
							log4jParamters_tMap_2.append(" | ");
							log4jParamters_tMap_2.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "true");
							log4jParamters_tMap_2.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tMap_2 - " + (log4jParamters_tMap_2));
						}
					}
					new BytesLimit65535_tMap_2().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tMap_2", "tMap_2", "tMap");
					talendJobLogProcess(globalMap);
				}

// ###############################
// # Lookup's keys initialization
				int count_row2_tMap_2 = 0;

// ###############################        

// ###############################
// # Vars initialization
				class Var__tMap_2__Struct {
				}
				Var__tMap_2__Struct Var__tMap_2 = new Var__tMap_2__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_State_Reg2_tMap_2 = 0;

				State_Reg2Struct State_Reg2_tmp = new State_Reg2Struct();
// ###############################

				/**
				 * [tMap_2 begin ] stop
				 */

				/**
				 * [tUniqRow_1 begin ] start
				 */

				ok_Hash.put("tUniqRow_1", false);
				start_Hash.put("tUniqRow_1", System.currentTimeMillis());

				currentComponent = "tUniqRow_1";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0,
						"State_Registration_Sk");

				int tos_count_tUniqRow_1 = 0;

				if (log.isDebugEnabled())
					log.debug("tUniqRow_1 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tUniqRow_1 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tUniqRow_1 = new StringBuilder();
							log4jParamters_tUniqRow_1.append("Parameters:");
							log4jParamters_tUniqRow_1
									.append("UNIQUE_KEY" + " = " + "[{CASE_SENSITIVE=" + ("false") + ", KEY_ATTRIBUTE="
											+ ("true") + ", SCHEMA_COLUMN=" + ("STATE_REGISTRATION") + "}]");
							log4jParamters_tUniqRow_1.append(" | ");
							log4jParamters_tUniqRow_1.append("ONLY_ONCE_EACH_DUPLICATED_KEY" + " = " + "false");
							log4jParamters_tUniqRow_1.append(" | ");
							log4jParamters_tUniqRow_1.append("IS_VIRTUAL_COMPONENT" + " = " + "false");
							log4jParamters_tUniqRow_1.append(" | ");
							log4jParamters_tUniqRow_1.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "false");
							log4jParamters_tUniqRow_1.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tUniqRow_1 - " + (log4jParamters_tUniqRow_1));
						}
					}
					new BytesLimit65535_tUniqRow_1().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tUniqRow_1", "tUniqRow_1", "tUniqRow");
					talendJobLogProcess(globalMap);
				}

				class KeyStruct_tUniqRow_1 {

					private static final int DEFAULT_HASHCODE = 1;
					private static final int PRIME = 31;
					private int hashCode = DEFAULT_HASHCODE;
					public boolean hashCodeDirty = true;

					String STATE_REGISTRATION;

					@Override
					public int hashCode() {
						if (this.hashCodeDirty) {
							final int prime = PRIME;
							int result = DEFAULT_HASHCODE;

							result = prime * result
									+ ((this.STATE_REGISTRATION == null) ? 0 : this.STATE_REGISTRATION.hashCode());

							this.hashCode = result;
							this.hashCodeDirty = false;
						}
						return this.hashCode;
					}

					@Override
					public boolean equals(Object obj) {
						if (this == obj)
							return true;
						if (obj == null)
							return false;
						if (getClass() != obj.getClass())
							return false;
						final KeyStruct_tUniqRow_1 other = (KeyStruct_tUniqRow_1) obj;

						if (this.STATE_REGISTRATION == null) {
							if (other.STATE_REGISTRATION != null)
								return false;

						} else if (!this.STATE_REGISTRATION.equals(other.STATE_REGISTRATION))

							return false;

						return true;
					}

				}

				int nb_uniques_tUniqRow_1 = 0;
				int nb_duplicates_tUniqRow_1 = 0;
				log.debug("tUniqRow_1 - Start to process the data from datasource.");
				KeyStruct_tUniqRow_1 finder_tUniqRow_1 = new KeyStruct_tUniqRow_1();
				java.util.Set<KeyStruct_tUniqRow_1> keystUniqRow_1 = new java.util.HashSet<KeyStruct_tUniqRow_1>();

				/**
				 * [tUniqRow_1 begin ] stop
				 */

				/**
				 * [tDBOutput_2 begin ] start
				 */

				ok_Hash.put("tDBOutput_2", false);
				start_Hash.put("tDBOutput_2", System.currentTimeMillis());

				currentComponent = "tDBOutput_2";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "Vehicle_Type2");

				int tos_count_tDBOutput_2 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBOutput_2 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tDBOutput_2 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tDBOutput_2 = new StringBuilder();
							log4jParamters_tDBOutput_2.append("Parameters:");
							log4jParamters_tDBOutput_2.append("USE_EXISTING_CONNECTION" + " = " + "false");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("DRIVER" + " = " + "JTDS");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("HOST" + " = " + "\"localhost\"");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("PORT" + " = " + "\"1433\"");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("DB_SCHEMA" + " = " + "\"\"");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("DBNAME" + " = " + "\"MVC_Stage\"");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("USER" + " = " + "\"\"");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("PASS" + " = "
									+ String.valueOf(
											"enc:routine.encryption.key.v1:YgfUSPLAWcE5Fc533B/to17U2z6+uRJ0xablNQ==")
											.substring(0, 4)
									+ "...");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("TABLE" + " = " + "\"Dim_VEHICLE_TYPE\"");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("TABLE_ACTION" + " = " + "NONE");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("IDENTITY_INSERT" + " = " + "false");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("DATA_ACTION" + " = " + "INSERT");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("DIE_ON_ERROR" + " = " + "false");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("PROPERTIES" + " = " + "\"\"");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("COMMIT_EVERY" + " = " + "10000");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("ADD_COLS" + " = " + "[]");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("USE_FIELD_OPTIONS" + " = " + "false");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("IGNORE_DATE_OUTOF_RANGE" + " = " + "false");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("ENABLE_DEBUG_MODE" + " = " + "false");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("SUPPORT_NULL_WHERE" + " = " + "false");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("USE_BATCH_SIZE" + " = " + "true");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("BATCH_SIZE" + " = " + "10000");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("UNIFIED_COMPONENTS" + " = " + "tMSSqlOutput");
							log4jParamters_tDBOutput_2.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tDBOutput_2 - " + (log4jParamters_tDBOutput_2));
						}
					}
					new BytesLimit65535_tDBOutput_2().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tDBOutput_2", "__TABLE__", "tMSSqlOutput");
					talendJobLogProcess(globalMap);
				}

				int nb_line_tDBOutput_2 = 0;
				int nb_line_update_tDBOutput_2 = 0;
				int nb_line_inserted_tDBOutput_2 = 0;
				int nb_line_deleted_tDBOutput_2 = 0;
				int nb_line_rejected_tDBOutput_2 = 0;

				int deletedCount_tDBOutput_2 = 0;
				int updatedCount_tDBOutput_2 = 0;
				int insertedCount_tDBOutput_2 = 0;
				int rowsToCommitCount_tDBOutput_2 = 0;
				int rejectedCount_tDBOutput_2 = 0;
				String dbschema_tDBOutput_2 = null;
				String tableName_tDBOutput_2 = null;
				boolean whetherReject_tDBOutput_2 = false;

				java.util.Calendar calendar_tDBOutput_2 = java.util.Calendar.getInstance();
				long year1_tDBOutput_2 = TalendDate.parseDate("yyyy-MM-dd", "0001-01-01").getTime();
				long year2_tDBOutput_2 = TalendDate.parseDate("yyyy-MM-dd", "1753-01-01").getTime();
				long year10000_tDBOutput_2 = TalendDate.parseDate("yyyy-MM-dd HH:mm:ss", "9999-12-31 24:00:00")
						.getTime();
				long date_tDBOutput_2;

				java.util.Calendar calendar_datetimeoffset_tDBOutput_2 = java.util.Calendar
						.getInstance(java.util.TimeZone.getTimeZone("UTC"));

				java.sql.Connection conn_tDBOutput_2 = null;
				String dbUser_tDBOutput_2 = null;
				dbschema_tDBOutput_2 = "";
				String driverClass_tDBOutput_2 = "net.sourceforge.jtds.jdbc.Driver";

				if (log.isDebugEnabled())
					log.debug("tDBOutput_2 - " + ("Driver ClassName: ") + (driverClass_tDBOutput_2) + ("."));
				java.lang.Class.forName(driverClass_tDBOutput_2);
				String port_tDBOutput_2 = "1433";
				String dbname_tDBOutput_2 = "MVC_Stage";
				String url_tDBOutput_2 = "jdbc:jtds:sqlserver://" + "localhost";
				if (!"".equals(port_tDBOutput_2)) {
					url_tDBOutput_2 += ":" + "1433";
				}
				if (!"".equals(dbname_tDBOutput_2)) {
					url_tDBOutput_2 += "//" + "MVC_Stage";

				}
				url_tDBOutput_2 += ";appName=" + projectName + ";" + "";
				dbUser_tDBOutput_2 = "";

				final String decryptedPassword_tDBOutput_2 = routines.system.PasswordEncryptUtil
						.decryptPassword("enc:routine.encryption.key.v1:qoJwF7dTYEOgBb4GwB7JsTBUPsBcY312frcPUQ==");

				String dbPwd_tDBOutput_2 = decryptedPassword_tDBOutput_2;
				if (log.isDebugEnabled())
					log.debug("tDBOutput_2 - " + ("Connection attempts to '") + (url_tDBOutput_2)
							+ ("' with the username '") + (dbUser_tDBOutput_2) + ("'."));
				conn_tDBOutput_2 = java.sql.DriverManager.getConnection(url_tDBOutput_2, dbUser_tDBOutput_2,
						dbPwd_tDBOutput_2);
				if (log.isDebugEnabled())
					log.debug("tDBOutput_2 - " + ("Connection to '") + (url_tDBOutput_2) + ("' has succeeded."));

				resourceMap.put("conn_tDBOutput_2", conn_tDBOutput_2);

				conn_tDBOutput_2.setAutoCommit(false);
				int commitEvery_tDBOutput_2 = 10000;
				int commitCounter_tDBOutput_2 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBOutput_2 - " + ("Connection is set auto commit to '")
							+ (conn_tDBOutput_2.getAutoCommit()) + ("'."));
				int batchSize_tDBOutput_2 = 10000;
				int batchSizeCounter_tDBOutput_2 = 0;

				if (dbschema_tDBOutput_2 == null || dbschema_tDBOutput_2.trim().length() == 0) {
					tableName_tDBOutput_2 = "Dim_VEHICLE_TYPE";
				} else {
					tableName_tDBOutput_2 = dbschema_tDBOutput_2 + "].[" + "Dim_VEHICLE_TYPE";
				}
				int count_tDBOutput_2 = 0;

				String insert_tDBOutput_2 = "INSERT INTO [" + tableName_tDBOutput_2
						+ "] ([VEHICLE_TYPE_SK],[VEHICLE_TYPE],[DI_PID],[DI_Create_Date]) VALUES (?,?,?,?)";
				java.sql.PreparedStatement pstmt_tDBOutput_2 = conn_tDBOutput_2.prepareStatement(insert_tDBOutput_2);
				resourceMap.put("pstmt_tDBOutput_2", pstmt_tDBOutput_2);

				/**
				 * [tDBOutput_2 begin ] stop
				 */

				/**
				 * [tMap_3 begin ] start
				 */

				ok_Hash.put("tMap_3", false);
				start_Hash.put("tMap_3", System.currentTimeMillis());

				currentComponent = "tMap_3";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "row3");

				int tos_count_tMap_3 = 0;

				if (log.isDebugEnabled())
					log.debug("tMap_3 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tMap_3 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tMap_3 = new StringBuilder();
							log4jParamters_tMap_3.append("Parameters:");
							log4jParamters_tMap_3.append("LINK_STYLE" + " = " + "AUTO");
							log4jParamters_tMap_3.append(" | ");
							log4jParamters_tMap_3.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
							log4jParamters_tMap_3.append(" | ");
							log4jParamters_tMap_3.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
							log4jParamters_tMap_3.append(" | ");
							log4jParamters_tMap_3.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "true");
							log4jParamters_tMap_3.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tMap_3 - " + (log4jParamters_tMap_3));
						}
					}
					new BytesLimit65535_tMap_3().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tMap_3", "tMap_3", "tMap");
					talendJobLogProcess(globalMap);
				}

// ###############################
// # Lookup's keys initialization
				int count_row3_tMap_3 = 0;

// ###############################        

// ###############################
// # Vars initialization
				class Var__tMap_3__Struct {
				}
				Var__tMap_3__Struct Var__tMap_3 = new Var__tMap_3__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_Vehicle_Type2_tMap_3 = 0;

				Vehicle_Type2Struct Vehicle_Type2_tmp = new Vehicle_Type2Struct();
// ###############################

				/**
				 * [tMap_3 begin ] stop
				 */

				/**
				 * [tUniqRow_2 begin ] start
				 */

				ok_Hash.put("tUniqRow_2", false);
				start_Hash.put("tUniqRow_2", System.currentTimeMillis());

				currentComponent = "tUniqRow_2";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "Vehicle_type");

				int tos_count_tUniqRow_2 = 0;

				if (log.isDebugEnabled())
					log.debug("tUniqRow_2 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tUniqRow_2 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tUniqRow_2 = new StringBuilder();
							log4jParamters_tUniqRow_2.append("Parameters:");
							log4jParamters_tUniqRow_2.append("UNIQUE_KEY" + " = " + "[{CASE_SENSITIVE=" + ("false")
									+ ", KEY_ATTRIBUTE=" + ("true") + ", SCHEMA_COLUMN=" + ("VEHICLE_TYPE") + "}]");
							log4jParamters_tUniqRow_2.append(" | ");
							log4jParamters_tUniqRow_2.append("ONLY_ONCE_EACH_DUPLICATED_KEY" + " = " + "false");
							log4jParamters_tUniqRow_2.append(" | ");
							log4jParamters_tUniqRow_2.append("IS_VIRTUAL_COMPONENT" + " = " + "false");
							log4jParamters_tUniqRow_2.append(" | ");
							log4jParamters_tUniqRow_2.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "false");
							log4jParamters_tUniqRow_2.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tUniqRow_2 - " + (log4jParamters_tUniqRow_2));
						}
					}
					new BytesLimit65535_tUniqRow_2().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tUniqRow_2", "tUniqRow_2", "tUniqRow");
					talendJobLogProcess(globalMap);
				}

				class KeyStruct_tUniqRow_2 {

					private static final int DEFAULT_HASHCODE = 1;
					private static final int PRIME = 31;
					private int hashCode = DEFAULT_HASHCODE;
					public boolean hashCodeDirty = true;

					String VEHICLE_TYPE;

					@Override
					public int hashCode() {
						if (this.hashCodeDirty) {
							final int prime = PRIME;
							int result = DEFAULT_HASHCODE;

							result = prime * result + ((this.VEHICLE_TYPE == null) ? 0 : this.VEHICLE_TYPE.hashCode());

							this.hashCode = result;
							this.hashCodeDirty = false;
						}
						return this.hashCode;
					}

					@Override
					public boolean equals(Object obj) {
						if (this == obj)
							return true;
						if (obj == null)
							return false;
						if (getClass() != obj.getClass())
							return false;
						final KeyStruct_tUniqRow_2 other = (KeyStruct_tUniqRow_2) obj;

						if (this.VEHICLE_TYPE == null) {
							if (other.VEHICLE_TYPE != null)
								return false;

						} else if (!this.VEHICLE_TYPE.equals(other.VEHICLE_TYPE))

							return false;

						return true;
					}

				}

				int nb_uniques_tUniqRow_2 = 0;
				int nb_duplicates_tUniqRow_2 = 0;
				log.debug("tUniqRow_2 - Start to process the data from datasource.");
				KeyStruct_tUniqRow_2 finder_tUniqRow_2 = new KeyStruct_tUniqRow_2();
				java.util.Set<KeyStruct_tUniqRow_2> keystUniqRow_2 = new java.util.HashSet<KeyStruct_tUniqRow_2>();

				/**
				 * [tUniqRow_2 begin ] stop
				 */

				/**
				 * [tDBOutput_3 begin ] start
				 */

				ok_Hash.put("tDBOutput_3", false);
				start_Hash.put("tDBOutput_3", System.currentTimeMillis());

				currentComponent = "tDBOutput_3";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "Vehicle_Make2");

				int tos_count_tDBOutput_3 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBOutput_3 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tDBOutput_3 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tDBOutput_3 = new StringBuilder();
							log4jParamters_tDBOutput_3.append("Parameters:");
							log4jParamters_tDBOutput_3.append("USE_EXISTING_CONNECTION" + " = " + "false");
							log4jParamters_tDBOutput_3.append(" | ");
							log4jParamters_tDBOutput_3.append("DRIVER" + " = " + "JTDS");
							log4jParamters_tDBOutput_3.append(" | ");
							log4jParamters_tDBOutput_3.append("HOST" + " = " + "\"localhost\"");
							log4jParamters_tDBOutput_3.append(" | ");
							log4jParamters_tDBOutput_3.append("PORT" + " = " + "\"1433\"");
							log4jParamters_tDBOutput_3.append(" | ");
							log4jParamters_tDBOutput_3.append("DB_SCHEMA" + " = " + "\"\"");
							log4jParamters_tDBOutput_3.append(" | ");
							log4jParamters_tDBOutput_3.append("DBNAME" + " = " + "\"MVC_Stage\"");
							log4jParamters_tDBOutput_3.append(" | ");
							log4jParamters_tDBOutput_3.append("USER" + " = " + "\"\"");
							log4jParamters_tDBOutput_3.append(" | ");
							log4jParamters_tDBOutput_3.append("PASS" + " = "
									+ String.valueOf(
											"enc:routine.encryption.key.v1:JgohI7AAZ7sFQOiA8sQL1WvUvRHMEdv4pOZwOg==")
											.substring(0, 4)
									+ "...");
							log4jParamters_tDBOutput_3.append(" | ");
							log4jParamters_tDBOutput_3.append("TABLE" + " = " + "\"Dim_VEHICLE_MAKE\"");
							log4jParamters_tDBOutput_3.append(" | ");
							log4jParamters_tDBOutput_3.append("TABLE_ACTION" + " = " + "NONE");
							log4jParamters_tDBOutput_3.append(" | ");
							log4jParamters_tDBOutput_3.append("IDENTITY_INSERT" + " = " + "false");
							log4jParamters_tDBOutput_3.append(" | ");
							log4jParamters_tDBOutput_3.append("DATA_ACTION" + " = " + "INSERT");
							log4jParamters_tDBOutput_3.append(" | ");
							log4jParamters_tDBOutput_3.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
							log4jParamters_tDBOutput_3.append(" | ");
							log4jParamters_tDBOutput_3.append("DIE_ON_ERROR" + " = " + "false");
							log4jParamters_tDBOutput_3.append(" | ");
							log4jParamters_tDBOutput_3.append("PROPERTIES" + " = " + "\"\"");
							log4jParamters_tDBOutput_3.append(" | ");
							log4jParamters_tDBOutput_3.append("COMMIT_EVERY" + " = " + "10000");
							log4jParamters_tDBOutput_3.append(" | ");
							log4jParamters_tDBOutput_3.append("ADD_COLS" + " = " + "[]");
							log4jParamters_tDBOutput_3.append(" | ");
							log4jParamters_tDBOutput_3.append("USE_FIELD_OPTIONS" + " = " + "false");
							log4jParamters_tDBOutput_3.append(" | ");
							log4jParamters_tDBOutput_3.append("IGNORE_DATE_OUTOF_RANGE" + " = " + "false");
							log4jParamters_tDBOutput_3.append(" | ");
							log4jParamters_tDBOutput_3.append("ENABLE_DEBUG_MODE" + " = " + "false");
							log4jParamters_tDBOutput_3.append(" | ");
							log4jParamters_tDBOutput_3.append("SUPPORT_NULL_WHERE" + " = " + "false");
							log4jParamters_tDBOutput_3.append(" | ");
							log4jParamters_tDBOutput_3.append("USE_BATCH_SIZE" + " = " + "true");
							log4jParamters_tDBOutput_3.append(" | ");
							log4jParamters_tDBOutput_3.append("BATCH_SIZE" + " = " + "10000");
							log4jParamters_tDBOutput_3.append(" | ");
							log4jParamters_tDBOutput_3.append("UNIFIED_COMPONENTS" + " = " + "tMSSqlOutput");
							log4jParamters_tDBOutput_3.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tDBOutput_3 - " + (log4jParamters_tDBOutput_3));
						}
					}
					new BytesLimit65535_tDBOutput_3().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tDBOutput_3", "__TABLE__", "tMSSqlOutput");
					talendJobLogProcess(globalMap);
				}

				int nb_line_tDBOutput_3 = 0;
				int nb_line_update_tDBOutput_3 = 0;
				int nb_line_inserted_tDBOutput_3 = 0;
				int nb_line_deleted_tDBOutput_3 = 0;
				int nb_line_rejected_tDBOutput_3 = 0;

				int deletedCount_tDBOutput_3 = 0;
				int updatedCount_tDBOutput_3 = 0;
				int insertedCount_tDBOutput_3 = 0;
				int rowsToCommitCount_tDBOutput_3 = 0;
				int rejectedCount_tDBOutput_3 = 0;
				String dbschema_tDBOutput_3 = null;
				String tableName_tDBOutput_3 = null;
				boolean whetherReject_tDBOutput_3 = false;

				java.util.Calendar calendar_tDBOutput_3 = java.util.Calendar.getInstance();
				long year1_tDBOutput_3 = TalendDate.parseDate("yyyy-MM-dd", "0001-01-01").getTime();
				long year2_tDBOutput_3 = TalendDate.parseDate("yyyy-MM-dd", "1753-01-01").getTime();
				long year10000_tDBOutput_3 = TalendDate.parseDate("yyyy-MM-dd HH:mm:ss", "9999-12-31 24:00:00")
						.getTime();
				long date_tDBOutput_3;

				java.util.Calendar calendar_datetimeoffset_tDBOutput_3 = java.util.Calendar
						.getInstance(java.util.TimeZone.getTimeZone("UTC"));

				java.sql.Connection conn_tDBOutput_3 = null;
				String dbUser_tDBOutput_3 = null;
				dbschema_tDBOutput_3 = "";
				String driverClass_tDBOutput_3 = "net.sourceforge.jtds.jdbc.Driver";

				if (log.isDebugEnabled())
					log.debug("tDBOutput_3 - " + ("Driver ClassName: ") + (driverClass_tDBOutput_3) + ("."));
				java.lang.Class.forName(driverClass_tDBOutput_3);
				String port_tDBOutput_3 = "1433";
				String dbname_tDBOutput_3 = "MVC_Stage";
				String url_tDBOutput_3 = "jdbc:jtds:sqlserver://" + "localhost";
				if (!"".equals(port_tDBOutput_3)) {
					url_tDBOutput_3 += ":" + "1433";
				}
				if (!"".equals(dbname_tDBOutput_3)) {
					url_tDBOutput_3 += "//" + "MVC_Stage";

				}
				url_tDBOutput_3 += ";appName=" + projectName + ";" + "";
				dbUser_tDBOutput_3 = "";

				final String decryptedPassword_tDBOutput_3 = routines.system.PasswordEncryptUtil
						.decryptPassword("enc:routine.encryption.key.v1:4uTRQWg74VmF2fRzN1CC8sH5Yzwwt4olKgGzSQ==");

				String dbPwd_tDBOutput_3 = decryptedPassword_tDBOutput_3;
				if (log.isDebugEnabled())
					log.debug("tDBOutput_3 - " + ("Connection attempts to '") + (url_tDBOutput_3)
							+ ("' with the username '") + (dbUser_tDBOutput_3) + ("'."));
				conn_tDBOutput_3 = java.sql.DriverManager.getConnection(url_tDBOutput_3, dbUser_tDBOutput_3,
						dbPwd_tDBOutput_3);
				if (log.isDebugEnabled())
					log.debug("tDBOutput_3 - " + ("Connection to '") + (url_tDBOutput_3) + ("' has succeeded."));

				resourceMap.put("conn_tDBOutput_3", conn_tDBOutput_3);

				conn_tDBOutput_3.setAutoCommit(false);
				int commitEvery_tDBOutput_3 = 10000;
				int commitCounter_tDBOutput_3 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBOutput_3 - " + ("Connection is set auto commit to '")
							+ (conn_tDBOutput_3.getAutoCommit()) + ("'."));
				int batchSize_tDBOutput_3 = 10000;
				int batchSizeCounter_tDBOutput_3 = 0;

				if (dbschema_tDBOutput_3 == null || dbschema_tDBOutput_3.trim().length() == 0) {
					tableName_tDBOutput_3 = "Dim_VEHICLE_MAKE";
				} else {
					tableName_tDBOutput_3 = dbschema_tDBOutput_3 + "].[" + "Dim_VEHICLE_MAKE";
				}
				int count_tDBOutput_3 = 0;

				String insert_tDBOutput_3 = "INSERT INTO [" + tableName_tDBOutput_3
						+ "] ([VEHICLE_MAKE_SK],[VEHICLE_MAKE],[DI_PID],[DI_Create_Date]) VALUES (?,?,?,?)";
				java.sql.PreparedStatement pstmt_tDBOutput_3 = conn_tDBOutput_3.prepareStatement(insert_tDBOutput_3);
				resourceMap.put("pstmt_tDBOutput_3", pstmt_tDBOutput_3);

				/**
				 * [tDBOutput_3 begin ] stop
				 */

				/**
				 * [tMap_4 begin ] start
				 */

				ok_Hash.put("tMap_4", false);
				start_Hash.put("tMap_4", System.currentTimeMillis());

				currentComponent = "tMap_4";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "row4");

				int tos_count_tMap_4 = 0;

				if (log.isDebugEnabled())
					log.debug("tMap_4 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tMap_4 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tMap_4 = new StringBuilder();
							log4jParamters_tMap_4.append("Parameters:");
							log4jParamters_tMap_4.append("LINK_STYLE" + " = " + "AUTO");
							log4jParamters_tMap_4.append(" | ");
							log4jParamters_tMap_4.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
							log4jParamters_tMap_4.append(" | ");
							log4jParamters_tMap_4.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
							log4jParamters_tMap_4.append(" | ");
							log4jParamters_tMap_4.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "true");
							log4jParamters_tMap_4.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tMap_4 - " + (log4jParamters_tMap_4));
						}
					}
					new BytesLimit65535_tMap_4().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tMap_4", "tMap_4", "tMap");
					talendJobLogProcess(globalMap);
				}

// ###############################
// # Lookup's keys initialization
				int count_row4_tMap_4 = 0;

// ###############################        

// ###############################
// # Vars initialization
				class Var__tMap_4__Struct {
				}
				Var__tMap_4__Struct Var__tMap_4 = new Var__tMap_4__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_Vehicle_Make2_tMap_4 = 0;

				Vehicle_Make2Struct Vehicle_Make2_tmp = new Vehicle_Make2Struct();
// ###############################

				/**
				 * [tMap_4 begin ] stop
				 */

				/**
				 * [tUniqRow_3 begin ] start
				 */

				ok_Hash.put("tUniqRow_3", false);
				start_Hash.put("tUniqRow_3", System.currentTimeMillis());

				currentComponent = "tUniqRow_3";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "Vehicle_Make");

				int tos_count_tUniqRow_3 = 0;

				if (log.isDebugEnabled())
					log.debug("tUniqRow_3 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tUniqRow_3 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tUniqRow_3 = new StringBuilder();
							log4jParamters_tUniqRow_3.append("Parameters:");
							log4jParamters_tUniqRow_3.append("UNIQUE_KEY" + " = " + "[{CASE_SENSITIVE=" + ("false")
									+ ", KEY_ATTRIBUTE=" + ("true") + ", SCHEMA_COLUMN=" + ("VEHICLE_MAKE") + "}]");
							log4jParamters_tUniqRow_3.append(" | ");
							log4jParamters_tUniqRow_3.append("ONLY_ONCE_EACH_DUPLICATED_KEY" + " = " + "false");
							log4jParamters_tUniqRow_3.append(" | ");
							log4jParamters_tUniqRow_3.append("IS_VIRTUAL_COMPONENT" + " = " + "false");
							log4jParamters_tUniqRow_3.append(" | ");
							log4jParamters_tUniqRow_3.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "false");
							log4jParamters_tUniqRow_3.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tUniqRow_3 - " + (log4jParamters_tUniqRow_3));
						}
					}
					new BytesLimit65535_tUniqRow_3().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tUniqRow_3", "tUniqRow_3", "tUniqRow");
					talendJobLogProcess(globalMap);
				}

				class KeyStruct_tUniqRow_3 {

					private static final int DEFAULT_HASHCODE = 1;
					private static final int PRIME = 31;
					private int hashCode = DEFAULT_HASHCODE;
					public boolean hashCodeDirty = true;

					String VEHICLE_MAKE;

					@Override
					public int hashCode() {
						if (this.hashCodeDirty) {
							final int prime = PRIME;
							int result = DEFAULT_HASHCODE;

							result = prime * result + ((this.VEHICLE_MAKE == null) ? 0 : this.VEHICLE_MAKE.hashCode());

							this.hashCode = result;
							this.hashCodeDirty = false;
						}
						return this.hashCode;
					}

					@Override
					public boolean equals(Object obj) {
						if (this == obj)
							return true;
						if (obj == null)
							return false;
						if (getClass() != obj.getClass())
							return false;
						final KeyStruct_tUniqRow_3 other = (KeyStruct_tUniqRow_3) obj;

						if (this.VEHICLE_MAKE == null) {
							if (other.VEHICLE_MAKE != null)
								return false;

						} else if (!this.VEHICLE_MAKE.equals(other.VEHICLE_MAKE))

							return false;

						return true;
					}

				}

				int nb_uniques_tUniqRow_3 = 0;
				int nb_duplicates_tUniqRow_3 = 0;
				log.debug("tUniqRow_3 - Start to process the data from datasource.");
				KeyStruct_tUniqRow_3 finder_tUniqRow_3 = new KeyStruct_tUniqRow_3();
				java.util.Set<KeyStruct_tUniqRow_3> keystUniqRow_3 = new java.util.HashSet<KeyStruct_tUniqRow_3>();

				/**
				 * [tUniqRow_3 begin ] stop
				 */

				/**
				 * [tDBOutput_4 begin ] start
				 */

				ok_Hash.put("tDBOutput_4", false);
				start_Hash.put("tDBOutput_4", System.currentTimeMillis());

				currentComponent = "tDBOutput_4";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "Vehicle_Model1");

				int tos_count_tDBOutput_4 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBOutput_4 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tDBOutput_4 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tDBOutput_4 = new StringBuilder();
							log4jParamters_tDBOutput_4.append("Parameters:");
							log4jParamters_tDBOutput_4.append("USE_EXISTING_CONNECTION" + " = " + "false");
							log4jParamters_tDBOutput_4.append(" | ");
							log4jParamters_tDBOutput_4.append("DRIVER" + " = " + "JTDS");
							log4jParamters_tDBOutput_4.append(" | ");
							log4jParamters_tDBOutput_4.append("HOST" + " = " + "\"localhost\"");
							log4jParamters_tDBOutput_4.append(" | ");
							log4jParamters_tDBOutput_4.append("PORT" + " = " + "\"1433\"");
							log4jParamters_tDBOutput_4.append(" | ");
							log4jParamters_tDBOutput_4.append("DB_SCHEMA" + " = " + "\"\"");
							log4jParamters_tDBOutput_4.append(" | ");
							log4jParamters_tDBOutput_4.append("DBNAME" + " = " + "\"MVC_Stage\"");
							log4jParamters_tDBOutput_4.append(" | ");
							log4jParamters_tDBOutput_4.append("USER" + " = " + "\"\"");
							log4jParamters_tDBOutput_4.append(" | ");
							log4jParamters_tDBOutput_4.append("PASS" + " = "
									+ String.valueOf(
											"enc:routine.encryption.key.v1:OfoO5/LHjZCnHeTcFAdMfHsX5Hx+L+EHLVmfrQ==")
											.substring(0, 4)
									+ "...");
							log4jParamters_tDBOutput_4.append(" | ");
							log4jParamters_tDBOutput_4.append("TABLE" + " = " + "\"Dim_VEHICLE_MODEL\"");
							log4jParamters_tDBOutput_4.append(" | ");
							log4jParamters_tDBOutput_4.append("TABLE_ACTION" + " = " + "NONE");
							log4jParamters_tDBOutput_4.append(" | ");
							log4jParamters_tDBOutput_4.append("IDENTITY_INSERT" + " = " + "false");
							log4jParamters_tDBOutput_4.append(" | ");
							log4jParamters_tDBOutput_4.append("DATA_ACTION" + " = " + "INSERT");
							log4jParamters_tDBOutput_4.append(" | ");
							log4jParamters_tDBOutput_4.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
							log4jParamters_tDBOutput_4.append(" | ");
							log4jParamters_tDBOutput_4.append("DIE_ON_ERROR" + " = " + "false");
							log4jParamters_tDBOutput_4.append(" | ");
							log4jParamters_tDBOutput_4.append("PROPERTIES" + " = " + "\"\"");
							log4jParamters_tDBOutput_4.append(" | ");
							log4jParamters_tDBOutput_4.append("COMMIT_EVERY" + " = " + "10000");
							log4jParamters_tDBOutput_4.append(" | ");
							log4jParamters_tDBOutput_4.append("ADD_COLS" + " = " + "[]");
							log4jParamters_tDBOutput_4.append(" | ");
							log4jParamters_tDBOutput_4.append("USE_FIELD_OPTIONS" + " = " + "false");
							log4jParamters_tDBOutput_4.append(" | ");
							log4jParamters_tDBOutput_4.append("IGNORE_DATE_OUTOF_RANGE" + " = " + "false");
							log4jParamters_tDBOutput_4.append(" | ");
							log4jParamters_tDBOutput_4.append("ENABLE_DEBUG_MODE" + " = " + "false");
							log4jParamters_tDBOutput_4.append(" | ");
							log4jParamters_tDBOutput_4.append("SUPPORT_NULL_WHERE" + " = " + "false");
							log4jParamters_tDBOutput_4.append(" | ");
							log4jParamters_tDBOutput_4.append("USE_BATCH_SIZE" + " = " + "true");
							log4jParamters_tDBOutput_4.append(" | ");
							log4jParamters_tDBOutput_4.append("BATCH_SIZE" + " = " + "10000");
							log4jParamters_tDBOutput_4.append(" | ");
							log4jParamters_tDBOutput_4.append("UNIFIED_COMPONENTS" + " = " + "tMSSqlOutput");
							log4jParamters_tDBOutput_4.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tDBOutput_4 - " + (log4jParamters_tDBOutput_4));
						}
					}
					new BytesLimit65535_tDBOutput_4().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tDBOutput_4", "__TABLE__", "tMSSqlOutput");
					talendJobLogProcess(globalMap);
				}

				int nb_line_tDBOutput_4 = 0;
				int nb_line_update_tDBOutput_4 = 0;
				int nb_line_inserted_tDBOutput_4 = 0;
				int nb_line_deleted_tDBOutput_4 = 0;
				int nb_line_rejected_tDBOutput_4 = 0;

				int deletedCount_tDBOutput_4 = 0;
				int updatedCount_tDBOutput_4 = 0;
				int insertedCount_tDBOutput_4 = 0;
				int rowsToCommitCount_tDBOutput_4 = 0;
				int rejectedCount_tDBOutput_4 = 0;
				String dbschema_tDBOutput_4 = null;
				String tableName_tDBOutput_4 = null;
				boolean whetherReject_tDBOutput_4 = false;

				java.util.Calendar calendar_tDBOutput_4 = java.util.Calendar.getInstance();
				long year1_tDBOutput_4 = TalendDate.parseDate("yyyy-MM-dd", "0001-01-01").getTime();
				long year2_tDBOutput_4 = TalendDate.parseDate("yyyy-MM-dd", "1753-01-01").getTime();
				long year10000_tDBOutput_4 = TalendDate.parseDate("yyyy-MM-dd HH:mm:ss", "9999-12-31 24:00:00")
						.getTime();
				long date_tDBOutput_4;

				java.util.Calendar calendar_datetimeoffset_tDBOutput_4 = java.util.Calendar
						.getInstance(java.util.TimeZone.getTimeZone("UTC"));

				java.sql.Connection conn_tDBOutput_4 = null;
				String dbUser_tDBOutput_4 = null;
				dbschema_tDBOutput_4 = "";
				String driverClass_tDBOutput_4 = "net.sourceforge.jtds.jdbc.Driver";

				if (log.isDebugEnabled())
					log.debug("tDBOutput_4 - " + ("Driver ClassName: ") + (driverClass_tDBOutput_4) + ("."));
				java.lang.Class.forName(driverClass_tDBOutput_4);
				String port_tDBOutput_4 = "1433";
				String dbname_tDBOutput_4 = "MVC_Stage";
				String url_tDBOutput_4 = "jdbc:jtds:sqlserver://" + "localhost";
				if (!"".equals(port_tDBOutput_4)) {
					url_tDBOutput_4 += ":" + "1433";
				}
				if (!"".equals(dbname_tDBOutput_4)) {
					url_tDBOutput_4 += "//" + "MVC_Stage";

				}
				url_tDBOutput_4 += ";appName=" + projectName + ";" + "";
				dbUser_tDBOutput_4 = "";

				final String decryptedPassword_tDBOutput_4 = routines.system.PasswordEncryptUtil
						.decryptPassword("enc:routine.encryption.key.v1:bmNHbvH4bO8lIl2TWXYmYnzOuEWPEknpCFRP0g==");

				String dbPwd_tDBOutput_4 = decryptedPassword_tDBOutput_4;
				if (log.isDebugEnabled())
					log.debug("tDBOutput_4 - " + ("Connection attempts to '") + (url_tDBOutput_4)
							+ ("' with the username '") + (dbUser_tDBOutput_4) + ("'."));
				conn_tDBOutput_4 = java.sql.DriverManager.getConnection(url_tDBOutput_4, dbUser_tDBOutput_4,
						dbPwd_tDBOutput_4);
				if (log.isDebugEnabled())
					log.debug("tDBOutput_4 - " + ("Connection to '") + (url_tDBOutput_4) + ("' has succeeded."));

				resourceMap.put("conn_tDBOutput_4", conn_tDBOutput_4);

				conn_tDBOutput_4.setAutoCommit(false);
				int commitEvery_tDBOutput_4 = 10000;
				int commitCounter_tDBOutput_4 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBOutput_4 - " + ("Connection is set auto commit to '")
							+ (conn_tDBOutput_4.getAutoCommit()) + ("'."));
				int batchSize_tDBOutput_4 = 10000;
				int batchSizeCounter_tDBOutput_4 = 0;

				if (dbschema_tDBOutput_4 == null || dbschema_tDBOutput_4.trim().length() == 0) {
					tableName_tDBOutput_4 = "Dim_VEHICLE_MODEL";
				} else {
					tableName_tDBOutput_4 = dbschema_tDBOutput_4 + "].[" + "Dim_VEHICLE_MODEL";
				}
				int count_tDBOutput_4 = 0;

				String insert_tDBOutput_4 = "INSERT INTO [" + tableName_tDBOutput_4
						+ "] ([VEHICLE_MODEL_SK],[VEHICLE_MODEL],[DI_PID],[DI_Create_Date]) VALUES (?,?,?,?)";
				java.sql.PreparedStatement pstmt_tDBOutput_4 = conn_tDBOutput_4.prepareStatement(insert_tDBOutput_4);
				resourceMap.put("pstmt_tDBOutput_4", pstmt_tDBOutput_4);

				/**
				 * [tDBOutput_4 begin ] stop
				 */

				/**
				 * [tMap_5 begin ] start
				 */

				ok_Hash.put("tMap_5", false);
				start_Hash.put("tMap_5", System.currentTimeMillis());

				currentComponent = "tMap_5";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "row5");

				int tos_count_tMap_5 = 0;

				if (log.isDebugEnabled())
					log.debug("tMap_5 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tMap_5 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tMap_5 = new StringBuilder();
							log4jParamters_tMap_5.append("Parameters:");
							log4jParamters_tMap_5.append("LINK_STYLE" + " = " + "AUTO");
							log4jParamters_tMap_5.append(" | ");
							log4jParamters_tMap_5.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
							log4jParamters_tMap_5.append(" | ");
							log4jParamters_tMap_5.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
							log4jParamters_tMap_5.append(" | ");
							log4jParamters_tMap_5.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "true");
							log4jParamters_tMap_5.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tMap_5 - " + (log4jParamters_tMap_5));
						}
					}
					new BytesLimit65535_tMap_5().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tMap_5", "tMap_5", "tMap");
					talendJobLogProcess(globalMap);
				}

// ###############################
// # Lookup's keys initialization
				int count_row5_tMap_5 = 0;

// ###############################        

// ###############################
// # Vars initialization
				class Var__tMap_5__Struct {
				}
				Var__tMap_5__Struct Var__tMap_5 = new Var__tMap_5__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_Vehicle_Model1_tMap_5 = 0;

				Vehicle_Model1Struct Vehicle_Model1_tmp = new Vehicle_Model1Struct();
// ###############################

				/**
				 * [tMap_5 begin ] stop
				 */

				/**
				 * [tUniqRow_4 begin ] start
				 */

				ok_Hash.put("tUniqRow_4", false);
				start_Hash.put("tUniqRow_4", System.currentTimeMillis());

				currentComponent = "tUniqRow_4";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "Vehicle_Model");

				int tos_count_tUniqRow_4 = 0;

				if (log.isDebugEnabled())
					log.debug("tUniqRow_4 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tUniqRow_4 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tUniqRow_4 = new StringBuilder();
							log4jParamters_tUniqRow_4.append("Parameters:");
							log4jParamters_tUniqRow_4.append("UNIQUE_KEY" + " = " + "[{CASE_SENSITIVE=" + ("false")
									+ ", KEY_ATTRIBUTE=" + ("false") + ", SCHEMA_COLUMN=" + ("VEHICLE_MODEL") + "}]");
							log4jParamters_tUniqRow_4.append(" | ");
							log4jParamters_tUniqRow_4.append("ONLY_ONCE_EACH_DUPLICATED_KEY" + " = " + "false");
							log4jParamters_tUniqRow_4.append(" | ");
							log4jParamters_tUniqRow_4.append("IS_VIRTUAL_COMPONENT" + " = " + "false");
							log4jParamters_tUniqRow_4.append(" | ");
							log4jParamters_tUniqRow_4.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "false");
							log4jParamters_tUniqRow_4.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tUniqRow_4 - " + (log4jParamters_tUniqRow_4));
						}
					}
					new BytesLimit65535_tUniqRow_4().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tUniqRow_4", "tUniqRow_4", "tUniqRow");
					talendJobLogProcess(globalMap);
				}

				int nb_uniques_tUniqRow_4 = 0;
				int nb_duplicates_tUniqRow_4 = 0;
				log.debug("tUniqRow_4 - Start to process the data from datasource.");

				/**
				 * [tUniqRow_4 begin ] stop
				 */

				/**
				 * [tDBOutput_5 begin ] start
				 */

				ok_Hash.put("tDBOutput_5", false);
				start_Hash.put("tDBOutput_5", System.currentTimeMillis());

				currentComponent = "tDBOutput_5";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0,
						"Travel_Direction_Loadd");

				int tos_count_tDBOutput_5 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBOutput_5 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tDBOutput_5 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tDBOutput_5 = new StringBuilder();
							log4jParamters_tDBOutput_5.append("Parameters:");
							log4jParamters_tDBOutput_5.append("USE_EXISTING_CONNECTION" + " = " + "false");
							log4jParamters_tDBOutput_5.append(" | ");
							log4jParamters_tDBOutput_5.append("DRIVER" + " = " + "JTDS");
							log4jParamters_tDBOutput_5.append(" | ");
							log4jParamters_tDBOutput_5.append("HOST" + " = " + "\"localhost\"");
							log4jParamters_tDBOutput_5.append(" | ");
							log4jParamters_tDBOutput_5.append("PORT" + " = " + "\"1433\"");
							log4jParamters_tDBOutput_5.append(" | ");
							log4jParamters_tDBOutput_5.append("DB_SCHEMA" + " = " + "\"\"");
							log4jParamters_tDBOutput_5.append(" | ");
							log4jParamters_tDBOutput_5.append("DBNAME" + " = " + "\"MVC_Stage\"");
							log4jParamters_tDBOutput_5.append(" | ");
							log4jParamters_tDBOutput_5.append("USER" + " = " + "\"\"");
							log4jParamters_tDBOutput_5.append(" | ");
							log4jParamters_tDBOutput_5.append("PASS" + " = "
									+ String.valueOf(
											"enc:routine.encryption.key.v1:6Yq0457nKiqT51++Kr06Bc72omAnR92uKTu9Jw==")
											.substring(0, 4)
									+ "...");
							log4jParamters_tDBOutput_5.append(" | ");
							log4jParamters_tDBOutput_5.append("TABLE" + " = " + "\"Dim_TRAVEL_DIRECTION\"");
							log4jParamters_tDBOutput_5.append(" | ");
							log4jParamters_tDBOutput_5.append("TABLE_ACTION" + " = " + "NONE");
							log4jParamters_tDBOutput_5.append(" | ");
							log4jParamters_tDBOutput_5.append("IDENTITY_INSERT" + " = " + "false");
							log4jParamters_tDBOutput_5.append(" | ");
							log4jParamters_tDBOutput_5.append("DATA_ACTION" + " = " + "INSERT");
							log4jParamters_tDBOutput_5.append(" | ");
							log4jParamters_tDBOutput_5.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
							log4jParamters_tDBOutput_5.append(" | ");
							log4jParamters_tDBOutput_5.append("DIE_ON_ERROR" + " = " + "false");
							log4jParamters_tDBOutput_5.append(" | ");
							log4jParamters_tDBOutput_5.append("PROPERTIES" + " = " + "\"\"");
							log4jParamters_tDBOutput_5.append(" | ");
							log4jParamters_tDBOutput_5.append("COMMIT_EVERY" + " = " + "10000");
							log4jParamters_tDBOutput_5.append(" | ");
							log4jParamters_tDBOutput_5.append("ADD_COLS" + " = " + "[]");
							log4jParamters_tDBOutput_5.append(" | ");
							log4jParamters_tDBOutput_5.append("USE_FIELD_OPTIONS" + " = " + "false");
							log4jParamters_tDBOutput_5.append(" | ");
							log4jParamters_tDBOutput_5.append("IGNORE_DATE_OUTOF_RANGE" + " = " + "false");
							log4jParamters_tDBOutput_5.append(" | ");
							log4jParamters_tDBOutput_5.append("ENABLE_DEBUG_MODE" + " = " + "false");
							log4jParamters_tDBOutput_5.append(" | ");
							log4jParamters_tDBOutput_5.append("SUPPORT_NULL_WHERE" + " = " + "false");
							log4jParamters_tDBOutput_5.append(" | ");
							log4jParamters_tDBOutput_5.append("USE_BATCH_SIZE" + " = " + "true");
							log4jParamters_tDBOutput_5.append(" | ");
							log4jParamters_tDBOutput_5.append("BATCH_SIZE" + " = " + "10000");
							log4jParamters_tDBOutput_5.append(" | ");
							log4jParamters_tDBOutput_5.append("UNIFIED_COMPONENTS" + " = " + "tMSSqlOutput");
							log4jParamters_tDBOutput_5.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tDBOutput_5 - " + (log4jParamters_tDBOutput_5));
						}
					}
					new BytesLimit65535_tDBOutput_5().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tDBOutput_5", "__TABLE__", "tMSSqlOutput");
					talendJobLogProcess(globalMap);
				}

				int nb_line_tDBOutput_5 = 0;
				int nb_line_update_tDBOutput_5 = 0;
				int nb_line_inserted_tDBOutput_5 = 0;
				int nb_line_deleted_tDBOutput_5 = 0;
				int nb_line_rejected_tDBOutput_5 = 0;

				int deletedCount_tDBOutput_5 = 0;
				int updatedCount_tDBOutput_5 = 0;
				int insertedCount_tDBOutput_5 = 0;
				int rowsToCommitCount_tDBOutput_5 = 0;
				int rejectedCount_tDBOutput_5 = 0;
				String dbschema_tDBOutput_5 = null;
				String tableName_tDBOutput_5 = null;
				boolean whetherReject_tDBOutput_5 = false;

				java.util.Calendar calendar_tDBOutput_5 = java.util.Calendar.getInstance();
				long year1_tDBOutput_5 = TalendDate.parseDate("yyyy-MM-dd", "0001-01-01").getTime();
				long year2_tDBOutput_5 = TalendDate.parseDate("yyyy-MM-dd", "1753-01-01").getTime();
				long year10000_tDBOutput_5 = TalendDate.parseDate("yyyy-MM-dd HH:mm:ss", "9999-12-31 24:00:00")
						.getTime();
				long date_tDBOutput_5;

				java.util.Calendar calendar_datetimeoffset_tDBOutput_5 = java.util.Calendar
						.getInstance(java.util.TimeZone.getTimeZone("UTC"));

				java.sql.Connection conn_tDBOutput_5 = null;
				String dbUser_tDBOutput_5 = null;
				dbschema_tDBOutput_5 = "";
				String driverClass_tDBOutput_5 = "net.sourceforge.jtds.jdbc.Driver";

				if (log.isDebugEnabled())
					log.debug("tDBOutput_5 - " + ("Driver ClassName: ") + (driverClass_tDBOutput_5) + ("."));
				java.lang.Class.forName(driverClass_tDBOutput_5);
				String port_tDBOutput_5 = "1433";
				String dbname_tDBOutput_5 = "MVC_Stage";
				String url_tDBOutput_5 = "jdbc:jtds:sqlserver://" + "localhost";
				if (!"".equals(port_tDBOutput_5)) {
					url_tDBOutput_5 += ":" + "1433";
				}
				if (!"".equals(dbname_tDBOutput_5)) {
					url_tDBOutput_5 += "//" + "MVC_Stage";

				}
				url_tDBOutput_5 += ";appName=" + projectName + ";" + "";
				dbUser_tDBOutput_5 = "";

				final String decryptedPassword_tDBOutput_5 = routines.system.PasswordEncryptUtil
						.decryptPassword("enc:routine.encryption.key.v1:K9gsOOP1AbRlQg2tFYgI2KctOniAiRZNrZY4ug==");

				String dbPwd_tDBOutput_5 = decryptedPassword_tDBOutput_5;
				if (log.isDebugEnabled())
					log.debug("tDBOutput_5 - " + ("Connection attempts to '") + (url_tDBOutput_5)
							+ ("' with the username '") + (dbUser_tDBOutput_5) + ("'."));
				conn_tDBOutput_5 = java.sql.DriverManager.getConnection(url_tDBOutput_5, dbUser_tDBOutput_5,
						dbPwd_tDBOutput_5);
				if (log.isDebugEnabled())
					log.debug("tDBOutput_5 - " + ("Connection to '") + (url_tDBOutput_5) + ("' has succeeded."));

				resourceMap.put("conn_tDBOutput_5", conn_tDBOutput_5);

				conn_tDBOutput_5.setAutoCommit(false);
				int commitEvery_tDBOutput_5 = 10000;
				int commitCounter_tDBOutput_5 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBOutput_5 - " + ("Connection is set auto commit to '")
							+ (conn_tDBOutput_5.getAutoCommit()) + ("'."));
				int batchSize_tDBOutput_5 = 10000;
				int batchSizeCounter_tDBOutput_5 = 0;

				if (dbschema_tDBOutput_5 == null || dbschema_tDBOutput_5.trim().length() == 0) {
					tableName_tDBOutput_5 = "Dim_TRAVEL_DIRECTION";
				} else {
					tableName_tDBOutput_5 = dbschema_tDBOutput_5 + "].[" + "Dim_TRAVEL_DIRECTION";
				}
				int count_tDBOutput_5 = 0;

				String insert_tDBOutput_5 = "INSERT INTO [" + tableName_tDBOutput_5
						+ "] ([TRAVEL_DIRECTION_SK],[TRAVEL_DIRECTION],[DI_PID],[DI_Create_Date]) VALUES (?,?,?,?)";
				java.sql.PreparedStatement pstmt_tDBOutput_5 = conn_tDBOutput_5.prepareStatement(insert_tDBOutput_5);
				resourceMap.put("pstmt_tDBOutput_5", pstmt_tDBOutput_5);

				/**
				 * [tDBOutput_5 begin ] stop
				 */

				/**
				 * [tMap_6 begin ] start
				 */

				ok_Hash.put("tMap_6", false);
				start_Hash.put("tMap_6", System.currentTimeMillis());

				currentComponent = "tMap_6";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "row6");

				int tos_count_tMap_6 = 0;

				if (log.isDebugEnabled())
					log.debug("tMap_6 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tMap_6 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tMap_6 = new StringBuilder();
							log4jParamters_tMap_6.append("Parameters:");
							log4jParamters_tMap_6.append("LINK_STYLE" + " = " + "AUTO");
							log4jParamters_tMap_6.append(" | ");
							log4jParamters_tMap_6.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
							log4jParamters_tMap_6.append(" | ");
							log4jParamters_tMap_6.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
							log4jParamters_tMap_6.append(" | ");
							log4jParamters_tMap_6.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "true");
							log4jParamters_tMap_6.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tMap_6 - " + (log4jParamters_tMap_6));
						}
					}
					new BytesLimit65535_tMap_6().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tMap_6", "tMap_6", "tMap");
					talendJobLogProcess(globalMap);
				}

// ###############################
// # Lookup's keys initialization
				int count_row6_tMap_6 = 0;

// ###############################        

// ###############################
// # Vars initialization
				class Var__tMap_6__Struct {
				}
				Var__tMap_6__Struct Var__tMap_6 = new Var__tMap_6__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_Travel_Direction_Loadd_tMap_6 = 0;

				Travel_Direction_LoaddStruct Travel_Direction_Loadd_tmp = new Travel_Direction_LoaddStruct();
// ###############################

				/**
				 * [tMap_6 begin ] stop
				 */

				/**
				 * [tUniqRow_5 begin ] start
				 */

				ok_Hash.put("tUniqRow_5", false);
				start_Hash.put("tUniqRow_5", System.currentTimeMillis());

				currentComponent = "tUniqRow_5";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "Travel_Direction");

				int tos_count_tUniqRow_5 = 0;

				if (log.isDebugEnabled())
					log.debug("tUniqRow_5 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tUniqRow_5 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tUniqRow_5 = new StringBuilder();
							log4jParamters_tUniqRow_5.append("Parameters:");
							log4jParamters_tUniqRow_5
									.append("UNIQUE_KEY" + " = " + "[{CASE_SENSITIVE=" + ("false") + ", KEY_ATTRIBUTE="
											+ ("false") + ", SCHEMA_COLUMN=" + ("TRAVEL_DIRECTION") + "}]");
							log4jParamters_tUniqRow_5.append(" | ");
							log4jParamters_tUniqRow_5.append("ONLY_ONCE_EACH_DUPLICATED_KEY" + " = " + "false");
							log4jParamters_tUniqRow_5.append(" | ");
							log4jParamters_tUniqRow_5.append("IS_VIRTUAL_COMPONENT" + " = " + "false");
							log4jParamters_tUniqRow_5.append(" | ");
							log4jParamters_tUniqRow_5.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "false");
							log4jParamters_tUniqRow_5.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tUniqRow_5 - " + (log4jParamters_tUniqRow_5));
						}
					}
					new BytesLimit65535_tUniqRow_5().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tUniqRow_5", "tUniqRow_5", "tUniqRow");
					talendJobLogProcess(globalMap);
				}

				int nb_uniques_tUniqRow_5 = 0;
				int nb_duplicates_tUniqRow_5 = 0;
				log.debug("tUniqRow_5 - Start to process the data from datasource.");

				/**
				 * [tUniqRow_5 begin ] stop
				 */

				/**
				 * [tDBOutput_6 begin ] start
				 */

				ok_Hash.put("tDBOutput_6", false);
				start_Hash.put("tDBOutput_6", System.currentTimeMillis());

				currentComponent = "tDBOutput_6";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0,
						"Driver_License_Status_2");

				int tos_count_tDBOutput_6 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBOutput_6 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tDBOutput_6 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tDBOutput_6 = new StringBuilder();
							log4jParamters_tDBOutput_6.append("Parameters:");
							log4jParamters_tDBOutput_6.append("USE_EXISTING_CONNECTION" + " = " + "false");
							log4jParamters_tDBOutput_6.append(" | ");
							log4jParamters_tDBOutput_6.append("DRIVER" + " = " + "JTDS");
							log4jParamters_tDBOutput_6.append(" | ");
							log4jParamters_tDBOutput_6.append("HOST" + " = " + "\"localhost\"");
							log4jParamters_tDBOutput_6.append(" | ");
							log4jParamters_tDBOutput_6.append("PORT" + " = " + "\"1433\"");
							log4jParamters_tDBOutput_6.append(" | ");
							log4jParamters_tDBOutput_6.append("DB_SCHEMA" + " = " + "\"\"");
							log4jParamters_tDBOutput_6.append(" | ");
							log4jParamters_tDBOutput_6.append("DBNAME" + " = " + "\"MVC_Stage\"");
							log4jParamters_tDBOutput_6.append(" | ");
							log4jParamters_tDBOutput_6.append("USER" + " = " + "\"\"");
							log4jParamters_tDBOutput_6.append(" | ");
							log4jParamters_tDBOutput_6.append("PASS" + " = "
									+ String.valueOf(
											"enc:routine.encryption.key.v1:Lj3iXOXo59Ka//Qhhc9zJLBZ1+aJKa/aoqTLdg==")
											.substring(0, 4)
									+ "...");
							log4jParamters_tDBOutput_6.append(" | ");
							log4jParamters_tDBOutput_6.append("TABLE" + " = " + "\"Dim_DRIVER_LICENSE_STATUS\"");
							log4jParamters_tDBOutput_6.append(" | ");
							log4jParamters_tDBOutput_6.append("TABLE_ACTION" + " = " + "NONE");
							log4jParamters_tDBOutput_6.append(" | ");
							log4jParamters_tDBOutput_6.append("IDENTITY_INSERT" + " = " + "false");
							log4jParamters_tDBOutput_6.append(" | ");
							log4jParamters_tDBOutput_6.append("DATA_ACTION" + " = " + "INSERT");
							log4jParamters_tDBOutput_6.append(" | ");
							log4jParamters_tDBOutput_6.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
							log4jParamters_tDBOutput_6.append(" | ");
							log4jParamters_tDBOutput_6.append("DIE_ON_ERROR" + " = " + "false");
							log4jParamters_tDBOutput_6.append(" | ");
							log4jParamters_tDBOutput_6.append("PROPERTIES" + " = " + "\"\"");
							log4jParamters_tDBOutput_6.append(" | ");
							log4jParamters_tDBOutput_6.append("COMMIT_EVERY" + " = " + "10000");
							log4jParamters_tDBOutput_6.append(" | ");
							log4jParamters_tDBOutput_6.append("ADD_COLS" + " = " + "[]");
							log4jParamters_tDBOutput_6.append(" | ");
							log4jParamters_tDBOutput_6.append("USE_FIELD_OPTIONS" + " = " + "false");
							log4jParamters_tDBOutput_6.append(" | ");
							log4jParamters_tDBOutput_6.append("IGNORE_DATE_OUTOF_RANGE" + " = " + "false");
							log4jParamters_tDBOutput_6.append(" | ");
							log4jParamters_tDBOutput_6.append("ENABLE_DEBUG_MODE" + " = " + "false");
							log4jParamters_tDBOutput_6.append(" | ");
							log4jParamters_tDBOutput_6.append("SUPPORT_NULL_WHERE" + " = " + "false");
							log4jParamters_tDBOutput_6.append(" | ");
							log4jParamters_tDBOutput_6.append("USE_BATCH_SIZE" + " = " + "true");
							log4jParamters_tDBOutput_6.append(" | ");
							log4jParamters_tDBOutput_6.append("BATCH_SIZE" + " = " + "10000");
							log4jParamters_tDBOutput_6.append(" | ");
							log4jParamters_tDBOutput_6.append("UNIFIED_COMPONENTS" + " = " + "tMSSqlOutput");
							log4jParamters_tDBOutput_6.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tDBOutput_6 - " + (log4jParamters_tDBOutput_6));
						}
					}
					new BytesLimit65535_tDBOutput_6().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tDBOutput_6", "__TABLE__", "tMSSqlOutput");
					talendJobLogProcess(globalMap);
				}

				int nb_line_tDBOutput_6 = 0;
				int nb_line_update_tDBOutput_6 = 0;
				int nb_line_inserted_tDBOutput_6 = 0;
				int nb_line_deleted_tDBOutput_6 = 0;
				int nb_line_rejected_tDBOutput_6 = 0;

				int deletedCount_tDBOutput_6 = 0;
				int updatedCount_tDBOutput_6 = 0;
				int insertedCount_tDBOutput_6 = 0;
				int rowsToCommitCount_tDBOutput_6 = 0;
				int rejectedCount_tDBOutput_6 = 0;
				String dbschema_tDBOutput_6 = null;
				String tableName_tDBOutput_6 = null;
				boolean whetherReject_tDBOutput_6 = false;

				java.util.Calendar calendar_tDBOutput_6 = java.util.Calendar.getInstance();
				long year1_tDBOutput_6 = TalendDate.parseDate("yyyy-MM-dd", "0001-01-01").getTime();
				long year2_tDBOutput_6 = TalendDate.parseDate("yyyy-MM-dd", "1753-01-01").getTime();
				long year10000_tDBOutput_6 = TalendDate.parseDate("yyyy-MM-dd HH:mm:ss", "9999-12-31 24:00:00")
						.getTime();
				long date_tDBOutput_6;

				java.util.Calendar calendar_datetimeoffset_tDBOutput_6 = java.util.Calendar
						.getInstance(java.util.TimeZone.getTimeZone("UTC"));

				java.sql.Connection conn_tDBOutput_6 = null;
				String dbUser_tDBOutput_6 = null;
				dbschema_tDBOutput_6 = "";
				String driverClass_tDBOutput_6 = "net.sourceforge.jtds.jdbc.Driver";

				if (log.isDebugEnabled())
					log.debug("tDBOutput_6 - " + ("Driver ClassName: ") + (driverClass_tDBOutput_6) + ("."));
				java.lang.Class.forName(driverClass_tDBOutput_6);
				String port_tDBOutput_6 = "1433";
				String dbname_tDBOutput_6 = "MVC_Stage";
				String url_tDBOutput_6 = "jdbc:jtds:sqlserver://" + "localhost";
				if (!"".equals(port_tDBOutput_6)) {
					url_tDBOutput_6 += ":" + "1433";
				}
				if (!"".equals(dbname_tDBOutput_6)) {
					url_tDBOutput_6 += "//" + "MVC_Stage";

				}
				url_tDBOutput_6 += ";appName=" + projectName + ";" + "";
				dbUser_tDBOutput_6 = "";

				final String decryptedPassword_tDBOutput_6 = routines.system.PasswordEncryptUtil
						.decryptPassword("enc:routine.encryption.key.v1:v6k1V8kGd9xxyzp4LnkWkTK8lwzOmnJApNV2hw==");

				String dbPwd_tDBOutput_6 = decryptedPassword_tDBOutput_6;
				if (log.isDebugEnabled())
					log.debug("tDBOutput_6 - " + ("Connection attempts to '") + (url_tDBOutput_6)
							+ ("' with the username '") + (dbUser_tDBOutput_6) + ("'."));
				conn_tDBOutput_6 = java.sql.DriverManager.getConnection(url_tDBOutput_6, dbUser_tDBOutput_6,
						dbPwd_tDBOutput_6);
				if (log.isDebugEnabled())
					log.debug("tDBOutput_6 - " + ("Connection to '") + (url_tDBOutput_6) + ("' has succeeded."));

				resourceMap.put("conn_tDBOutput_6", conn_tDBOutput_6);

				conn_tDBOutput_6.setAutoCommit(false);
				int commitEvery_tDBOutput_6 = 10000;
				int commitCounter_tDBOutput_6 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBOutput_6 - " + ("Connection is set auto commit to '")
							+ (conn_tDBOutput_6.getAutoCommit()) + ("'."));
				int batchSize_tDBOutput_6 = 10000;
				int batchSizeCounter_tDBOutput_6 = 0;

				if (dbschema_tDBOutput_6 == null || dbschema_tDBOutput_6.trim().length() == 0) {
					tableName_tDBOutput_6 = "Dim_DRIVER_LICENSE_STATUS";
				} else {
					tableName_tDBOutput_6 = dbschema_tDBOutput_6 + "].[" + "Dim_DRIVER_LICENSE_STATUS";
				}
				int count_tDBOutput_6 = 0;

				String insert_tDBOutput_6 = "INSERT INTO [" + tableName_tDBOutput_6
						+ "] ([DRIVER_LICENSE_STATUS_SK],[DRIVER_LICENSE_STATUS],[DI_PID],[DI_Create_Date]) VALUES (?,?,?,?)";
				java.sql.PreparedStatement pstmt_tDBOutput_6 = conn_tDBOutput_6.prepareStatement(insert_tDBOutput_6);
				resourceMap.put("pstmt_tDBOutput_6", pstmt_tDBOutput_6);

				/**
				 * [tDBOutput_6 begin ] stop
				 */

				/**
				 * [tMap_7 begin ] start
				 */

				ok_Hash.put("tMap_7", false);
				start_Hash.put("tMap_7", System.currentTimeMillis());

				currentComponent = "tMap_7";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "row7");

				int tos_count_tMap_7 = 0;

				if (log.isDebugEnabled())
					log.debug("tMap_7 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tMap_7 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tMap_7 = new StringBuilder();
							log4jParamters_tMap_7.append("Parameters:");
							log4jParamters_tMap_7.append("LINK_STYLE" + " = " + "AUTO");
							log4jParamters_tMap_7.append(" | ");
							log4jParamters_tMap_7.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
							log4jParamters_tMap_7.append(" | ");
							log4jParamters_tMap_7.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
							log4jParamters_tMap_7.append(" | ");
							log4jParamters_tMap_7.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "true");
							log4jParamters_tMap_7.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tMap_7 - " + (log4jParamters_tMap_7));
						}
					}
					new BytesLimit65535_tMap_7().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tMap_7", "tMap_7", "tMap");
					talendJobLogProcess(globalMap);
				}

// ###############################
// # Lookup's keys initialization
				int count_row7_tMap_7 = 0;

// ###############################        

// ###############################
// # Vars initialization
				class Var__tMap_7__Struct {
				}
				Var__tMap_7__Struct Var__tMap_7 = new Var__tMap_7__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_Driver_License_Status_2_tMap_7 = 0;

				Driver_License_Status_2Struct Driver_License_Status_2_tmp = new Driver_License_Status_2Struct();
// ###############################

				/**
				 * [tMap_7 begin ] stop
				 */

				/**
				 * [tUniqRow_6 begin ] start
				 */

				ok_Hash.put("tUniqRow_6", false);
				start_Hash.put("tUniqRow_6", System.currentTimeMillis());

				currentComponent = "tUniqRow_6";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0,
						"Driver_License_Status");

				int tos_count_tUniqRow_6 = 0;

				if (log.isDebugEnabled())
					log.debug("tUniqRow_6 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tUniqRow_6 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tUniqRow_6 = new StringBuilder();
							log4jParamters_tUniqRow_6.append("Parameters:");
							log4jParamters_tUniqRow_6
									.append("UNIQUE_KEY" + " = " + "[{CASE_SENSITIVE=" + ("false") + ", KEY_ATTRIBUTE="
											+ ("false") + ", SCHEMA_COLUMN=" + ("DRIVER_LICENSE_STATUS") + "}]");
							log4jParamters_tUniqRow_6.append(" | ");
							log4jParamters_tUniqRow_6.append("ONLY_ONCE_EACH_DUPLICATED_KEY" + " = " + "false");
							log4jParamters_tUniqRow_6.append(" | ");
							log4jParamters_tUniqRow_6.append("IS_VIRTUAL_COMPONENT" + " = " + "false");
							log4jParamters_tUniqRow_6.append(" | ");
							log4jParamters_tUniqRow_6.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "false");
							log4jParamters_tUniqRow_6.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tUniqRow_6 - " + (log4jParamters_tUniqRow_6));
						}
					}
					new BytesLimit65535_tUniqRow_6().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tUniqRow_6", "tUniqRow_6", "tUniqRow");
					talendJobLogProcess(globalMap);
				}

				int nb_uniques_tUniqRow_6 = 0;
				int nb_duplicates_tUniqRow_6 = 0;
				log.debug("tUniqRow_6 - Start to process the data from datasource.");

				/**
				 * [tUniqRow_6 begin ] stop
				 */

				/**
				 * [tDBOutput_7 begin ] start
				 */

				ok_Hash.put("tDBOutput_7", false);
				start_Hash.put("tDBOutput_7", System.currentTimeMillis());

				currentComponent = "tDBOutput_7";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "Jurisdiv");

				int tos_count_tDBOutput_7 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBOutput_7 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tDBOutput_7 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tDBOutput_7 = new StringBuilder();
							log4jParamters_tDBOutput_7.append("Parameters:");
							log4jParamters_tDBOutput_7.append("USE_EXISTING_CONNECTION" + " = " + "false");
							log4jParamters_tDBOutput_7.append(" | ");
							log4jParamters_tDBOutput_7.append("DRIVER" + " = " + "JTDS");
							log4jParamters_tDBOutput_7.append(" | ");
							log4jParamters_tDBOutput_7.append("HOST" + " = " + "\"localhost\"");
							log4jParamters_tDBOutput_7.append(" | ");
							log4jParamters_tDBOutput_7.append("PORT" + " = " + "\"1433\"");
							log4jParamters_tDBOutput_7.append(" | ");
							log4jParamters_tDBOutput_7.append("DB_SCHEMA" + " = " + "\"\"");
							log4jParamters_tDBOutput_7.append(" | ");
							log4jParamters_tDBOutput_7.append("DBNAME" + " = " + "\"MVC_Stage\"");
							log4jParamters_tDBOutput_7.append(" | ");
							log4jParamters_tDBOutput_7.append("USER" + " = " + "\"\"");
							log4jParamters_tDBOutput_7.append(" | ");
							log4jParamters_tDBOutput_7.append("PASS" + " = "
									+ String.valueOf(
											"enc:routine.encryption.key.v1:gGmV4Si3UaBxMcqBrJnH+RYej7QPZtetTvhJyQ==")
											.substring(0, 4)
									+ "...");
							log4jParamters_tDBOutput_7.append(" | ");
							log4jParamters_tDBOutput_7.append("TABLE" + " = " + "\"Dim_DRIVER_LICENSE_JURISDICTION\"");
							log4jParamters_tDBOutput_7.append(" | ");
							log4jParamters_tDBOutput_7.append("TABLE_ACTION" + " = " + "NONE");
							log4jParamters_tDBOutput_7.append(" | ");
							log4jParamters_tDBOutput_7.append("IDENTITY_INSERT" + " = " + "false");
							log4jParamters_tDBOutput_7.append(" | ");
							log4jParamters_tDBOutput_7.append("DATA_ACTION" + " = " + "INSERT");
							log4jParamters_tDBOutput_7.append(" | ");
							log4jParamters_tDBOutput_7.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
							log4jParamters_tDBOutput_7.append(" | ");
							log4jParamters_tDBOutput_7.append("DIE_ON_ERROR" + " = " + "false");
							log4jParamters_tDBOutput_7.append(" | ");
							log4jParamters_tDBOutput_7.append("PROPERTIES" + " = " + "\"\"");
							log4jParamters_tDBOutput_7.append(" | ");
							log4jParamters_tDBOutput_7.append("COMMIT_EVERY" + " = " + "10000");
							log4jParamters_tDBOutput_7.append(" | ");
							log4jParamters_tDBOutput_7.append("ADD_COLS" + " = " + "[]");
							log4jParamters_tDBOutput_7.append(" | ");
							log4jParamters_tDBOutput_7.append("USE_FIELD_OPTIONS" + " = " + "false");
							log4jParamters_tDBOutput_7.append(" | ");
							log4jParamters_tDBOutput_7.append("IGNORE_DATE_OUTOF_RANGE" + " = " + "false");
							log4jParamters_tDBOutput_7.append(" | ");
							log4jParamters_tDBOutput_7.append("ENABLE_DEBUG_MODE" + " = " + "false");
							log4jParamters_tDBOutput_7.append(" | ");
							log4jParamters_tDBOutput_7.append("SUPPORT_NULL_WHERE" + " = " + "false");
							log4jParamters_tDBOutput_7.append(" | ");
							log4jParamters_tDBOutput_7.append("USE_BATCH_SIZE" + " = " + "true");
							log4jParamters_tDBOutput_7.append(" | ");
							log4jParamters_tDBOutput_7.append("BATCH_SIZE" + " = " + "10000");
							log4jParamters_tDBOutput_7.append(" | ");
							log4jParamters_tDBOutput_7.append("UNIFIED_COMPONENTS" + " = " + "tMSSqlOutput");
							log4jParamters_tDBOutput_7.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tDBOutput_7 - " + (log4jParamters_tDBOutput_7));
						}
					}
					new BytesLimit65535_tDBOutput_7().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tDBOutput_7", "__TABLE__", "tMSSqlOutput");
					talendJobLogProcess(globalMap);
				}

				int nb_line_tDBOutput_7 = 0;
				int nb_line_update_tDBOutput_7 = 0;
				int nb_line_inserted_tDBOutput_7 = 0;
				int nb_line_deleted_tDBOutput_7 = 0;
				int nb_line_rejected_tDBOutput_7 = 0;

				int deletedCount_tDBOutput_7 = 0;
				int updatedCount_tDBOutput_7 = 0;
				int insertedCount_tDBOutput_7 = 0;
				int rowsToCommitCount_tDBOutput_7 = 0;
				int rejectedCount_tDBOutput_7 = 0;
				String dbschema_tDBOutput_7 = null;
				String tableName_tDBOutput_7 = null;
				boolean whetherReject_tDBOutput_7 = false;

				java.util.Calendar calendar_tDBOutput_7 = java.util.Calendar.getInstance();
				long year1_tDBOutput_7 = TalendDate.parseDate("yyyy-MM-dd", "0001-01-01").getTime();
				long year2_tDBOutput_7 = TalendDate.parseDate("yyyy-MM-dd", "1753-01-01").getTime();
				long year10000_tDBOutput_7 = TalendDate.parseDate("yyyy-MM-dd HH:mm:ss", "9999-12-31 24:00:00")
						.getTime();
				long date_tDBOutput_7;

				java.util.Calendar calendar_datetimeoffset_tDBOutput_7 = java.util.Calendar
						.getInstance(java.util.TimeZone.getTimeZone("UTC"));

				java.sql.Connection conn_tDBOutput_7 = null;
				String dbUser_tDBOutput_7 = null;
				dbschema_tDBOutput_7 = "";
				String driverClass_tDBOutput_7 = "net.sourceforge.jtds.jdbc.Driver";

				if (log.isDebugEnabled())
					log.debug("tDBOutput_7 - " + ("Driver ClassName: ") + (driverClass_tDBOutput_7) + ("."));
				java.lang.Class.forName(driverClass_tDBOutput_7);
				String port_tDBOutput_7 = "1433";
				String dbname_tDBOutput_7 = "MVC_Stage";
				String url_tDBOutput_7 = "jdbc:jtds:sqlserver://" + "localhost";
				if (!"".equals(port_tDBOutput_7)) {
					url_tDBOutput_7 += ":" + "1433";
				}
				if (!"".equals(dbname_tDBOutput_7)) {
					url_tDBOutput_7 += "//" + "MVC_Stage";

				}
				url_tDBOutput_7 += ";appName=" + projectName + ";" + "";
				dbUser_tDBOutput_7 = "";

				final String decryptedPassword_tDBOutput_7 = routines.system.PasswordEncryptUtil
						.decryptPassword("enc:routine.encryption.key.v1:lqyRpNbG5MJj3PAV1ahFN8h3KXJ8Eiq98aLLng==");

				String dbPwd_tDBOutput_7 = decryptedPassword_tDBOutput_7;
				if (log.isDebugEnabled())
					log.debug("tDBOutput_7 - " + ("Connection attempts to '") + (url_tDBOutput_7)
							+ ("' with the username '") + (dbUser_tDBOutput_7) + ("'."));
				conn_tDBOutput_7 = java.sql.DriverManager.getConnection(url_tDBOutput_7, dbUser_tDBOutput_7,
						dbPwd_tDBOutput_7);
				if (log.isDebugEnabled())
					log.debug("tDBOutput_7 - " + ("Connection to '") + (url_tDBOutput_7) + ("' has succeeded."));

				resourceMap.put("conn_tDBOutput_7", conn_tDBOutput_7);

				conn_tDBOutput_7.setAutoCommit(false);
				int commitEvery_tDBOutput_7 = 10000;
				int commitCounter_tDBOutput_7 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBOutput_7 - " + ("Connection is set auto commit to '")
							+ (conn_tDBOutput_7.getAutoCommit()) + ("'."));
				int batchSize_tDBOutput_7 = 10000;
				int batchSizeCounter_tDBOutput_7 = 0;

				if (dbschema_tDBOutput_7 == null || dbschema_tDBOutput_7.trim().length() == 0) {
					tableName_tDBOutput_7 = "Dim_DRIVER_LICENSE_JURISDICTION";
				} else {
					tableName_tDBOutput_7 = dbschema_tDBOutput_7 + "].[" + "Dim_DRIVER_LICENSE_JURISDICTION";
				}
				int count_tDBOutput_7 = 0;

				String insert_tDBOutput_7 = "INSERT INTO [" + tableName_tDBOutput_7
						+ "] ([DRIVER_LICENSE_JURISDICTION_SK],[DRIVER_LICENSE_JURISDICTION],[DI_PID],[DI_Create_Date]) VALUES (?,?,?,?)";
				java.sql.PreparedStatement pstmt_tDBOutput_7 = conn_tDBOutput_7.prepareStatement(insert_tDBOutput_7);
				resourceMap.put("pstmt_tDBOutput_7", pstmt_tDBOutput_7);

				/**
				 * [tDBOutput_7 begin ] stop
				 */

				/**
				 * [tMap_8 begin ] start
				 */

				ok_Hash.put("tMap_8", false);
				start_Hash.put("tMap_8", System.currentTimeMillis());

				currentComponent = "tMap_8";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "row8");

				int tos_count_tMap_8 = 0;

				if (log.isDebugEnabled())
					log.debug("tMap_8 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tMap_8 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tMap_8 = new StringBuilder();
							log4jParamters_tMap_8.append("Parameters:");
							log4jParamters_tMap_8.append("LINK_STYLE" + " = " + "AUTO");
							log4jParamters_tMap_8.append(" | ");
							log4jParamters_tMap_8.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
							log4jParamters_tMap_8.append(" | ");
							log4jParamters_tMap_8.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
							log4jParamters_tMap_8.append(" | ");
							log4jParamters_tMap_8.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "true");
							log4jParamters_tMap_8.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tMap_8 - " + (log4jParamters_tMap_8));
						}
					}
					new BytesLimit65535_tMap_8().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tMap_8", "tMap_8", "tMap");
					talendJobLogProcess(globalMap);
				}

// ###############################
// # Lookup's keys initialization
				int count_row8_tMap_8 = 0;

// ###############################        

// ###############################
// # Vars initialization
				class Var__tMap_8__Struct {
				}
				Var__tMap_8__Struct Var__tMap_8 = new Var__tMap_8__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_Jurisdiv_tMap_8 = 0;

				JurisdivStruct Jurisdiv_tmp = new JurisdivStruct();
// ###############################

				/**
				 * [tMap_8 begin ] stop
				 */

				/**
				 * [tUniqRow_7 begin ] start
				 */

				ok_Hash.put("tUniqRow_7", false);
				start_Hash.put("tUniqRow_7", System.currentTimeMillis());

				currentComponent = "tUniqRow_7";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0,
						"Driver_License_Jusridiction");

				int tos_count_tUniqRow_7 = 0;

				if (log.isDebugEnabled())
					log.debug("tUniqRow_7 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tUniqRow_7 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tUniqRow_7 = new StringBuilder();
							log4jParamters_tUniqRow_7.append("Parameters:");
							log4jParamters_tUniqRow_7
									.append("UNIQUE_KEY" + " = " + "[{CASE_SENSITIVE=" + ("false") + ", KEY_ATTRIBUTE="
											+ ("false") + ", SCHEMA_COLUMN=" + ("DRIVER_LICENSE_JURISDICTION") + "}]");
							log4jParamters_tUniqRow_7.append(" | ");
							log4jParamters_tUniqRow_7.append("ONLY_ONCE_EACH_DUPLICATED_KEY" + " = " + "false");
							log4jParamters_tUniqRow_7.append(" | ");
							log4jParamters_tUniqRow_7.append("IS_VIRTUAL_COMPONENT" + " = " + "false");
							log4jParamters_tUniqRow_7.append(" | ");
							log4jParamters_tUniqRow_7.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "false");
							log4jParamters_tUniqRow_7.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tUniqRow_7 - " + (log4jParamters_tUniqRow_7));
						}
					}
					new BytesLimit65535_tUniqRow_7().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tUniqRow_7", "tUniqRow_7", "tUniqRow");
					talendJobLogProcess(globalMap);
				}

				int nb_uniques_tUniqRow_7 = 0;
				int nb_duplicates_tUniqRow_7 = 0;
				log.debug("tUniqRow_7 - Start to process the data from datasource.");

				/**
				 * [tUniqRow_7 begin ] stop
				 */

				/**
				 * [tDBOutput_8 begin ] start
				 */

				ok_Hash.put("tDBOutput_8", false);
				start_Hash.put("tDBOutput_8", System.currentTimeMillis());

				currentComponent = "tDBOutput_8";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "PreCash22");

				int tos_count_tDBOutput_8 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBOutput_8 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tDBOutput_8 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tDBOutput_8 = new StringBuilder();
							log4jParamters_tDBOutput_8.append("Parameters:");
							log4jParamters_tDBOutput_8.append("USE_EXISTING_CONNECTION" + " = " + "false");
							log4jParamters_tDBOutput_8.append(" | ");
							log4jParamters_tDBOutput_8.append("DRIVER" + " = " + "JTDS");
							log4jParamters_tDBOutput_8.append(" | ");
							log4jParamters_tDBOutput_8.append("HOST" + " = " + "\"localhost\"");
							log4jParamters_tDBOutput_8.append(" | ");
							log4jParamters_tDBOutput_8.append("PORT" + " = " + "\"1433\"");
							log4jParamters_tDBOutput_8.append(" | ");
							log4jParamters_tDBOutput_8.append("DB_SCHEMA" + " = " + "\"\"");
							log4jParamters_tDBOutput_8.append(" | ");
							log4jParamters_tDBOutput_8.append("DBNAME" + " = " + "\"MVC_Stage\"");
							log4jParamters_tDBOutput_8.append(" | ");
							log4jParamters_tDBOutput_8.append("USER" + " = " + "\"\"");
							log4jParamters_tDBOutput_8.append(" | ");
							log4jParamters_tDBOutput_8.append("PASS" + " = "
									+ String.valueOf(
											"enc:routine.encryption.key.v1:5fqGCFGXTTfmiuLhqJx2I0RDVTQnLd8FcxWqow==")
											.substring(0, 4)
									+ "...");
							log4jParamters_tDBOutput_8.append(" | ");
							log4jParamters_tDBOutput_8.append("TABLE" + " = " + "\"Dim_PRE_CRASH\"");
							log4jParamters_tDBOutput_8.append(" | ");
							log4jParamters_tDBOutput_8.append("TABLE_ACTION" + " = " + "NONE");
							log4jParamters_tDBOutput_8.append(" | ");
							log4jParamters_tDBOutput_8.append("IDENTITY_INSERT" + " = " + "false");
							log4jParamters_tDBOutput_8.append(" | ");
							log4jParamters_tDBOutput_8.append("DATA_ACTION" + " = " + "INSERT");
							log4jParamters_tDBOutput_8.append(" | ");
							log4jParamters_tDBOutput_8.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
							log4jParamters_tDBOutput_8.append(" | ");
							log4jParamters_tDBOutput_8.append("DIE_ON_ERROR" + " = " + "false");
							log4jParamters_tDBOutput_8.append(" | ");
							log4jParamters_tDBOutput_8.append("PROPERTIES" + " = " + "\"\"");
							log4jParamters_tDBOutput_8.append(" | ");
							log4jParamters_tDBOutput_8.append("COMMIT_EVERY" + " = " + "10000");
							log4jParamters_tDBOutput_8.append(" | ");
							log4jParamters_tDBOutput_8.append("ADD_COLS" + " = " + "[]");
							log4jParamters_tDBOutput_8.append(" | ");
							log4jParamters_tDBOutput_8.append("USE_FIELD_OPTIONS" + " = " + "false");
							log4jParamters_tDBOutput_8.append(" | ");
							log4jParamters_tDBOutput_8.append("IGNORE_DATE_OUTOF_RANGE" + " = " + "false");
							log4jParamters_tDBOutput_8.append(" | ");
							log4jParamters_tDBOutput_8.append("ENABLE_DEBUG_MODE" + " = " + "false");
							log4jParamters_tDBOutput_8.append(" | ");
							log4jParamters_tDBOutput_8.append("SUPPORT_NULL_WHERE" + " = " + "false");
							log4jParamters_tDBOutput_8.append(" | ");
							log4jParamters_tDBOutput_8.append("USE_BATCH_SIZE" + " = " + "true");
							log4jParamters_tDBOutput_8.append(" | ");
							log4jParamters_tDBOutput_8.append("BATCH_SIZE" + " = " + "10000");
							log4jParamters_tDBOutput_8.append(" | ");
							log4jParamters_tDBOutput_8.append("UNIFIED_COMPONENTS" + " = " + "tMSSqlOutput");
							log4jParamters_tDBOutput_8.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tDBOutput_8 - " + (log4jParamters_tDBOutput_8));
						}
					}
					new BytesLimit65535_tDBOutput_8().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tDBOutput_8", "__TABLE__", "tMSSqlOutput");
					talendJobLogProcess(globalMap);
				}

				int nb_line_tDBOutput_8 = 0;
				int nb_line_update_tDBOutput_8 = 0;
				int nb_line_inserted_tDBOutput_8 = 0;
				int nb_line_deleted_tDBOutput_8 = 0;
				int nb_line_rejected_tDBOutput_8 = 0;

				int deletedCount_tDBOutput_8 = 0;
				int updatedCount_tDBOutput_8 = 0;
				int insertedCount_tDBOutput_8 = 0;
				int rowsToCommitCount_tDBOutput_8 = 0;
				int rejectedCount_tDBOutput_8 = 0;
				String dbschema_tDBOutput_8 = null;
				String tableName_tDBOutput_8 = null;
				boolean whetherReject_tDBOutput_8 = false;

				java.util.Calendar calendar_tDBOutput_8 = java.util.Calendar.getInstance();
				long year1_tDBOutput_8 = TalendDate.parseDate("yyyy-MM-dd", "0001-01-01").getTime();
				long year2_tDBOutput_8 = TalendDate.parseDate("yyyy-MM-dd", "1753-01-01").getTime();
				long year10000_tDBOutput_8 = TalendDate.parseDate("yyyy-MM-dd HH:mm:ss", "9999-12-31 24:00:00")
						.getTime();
				long date_tDBOutput_8;

				java.util.Calendar calendar_datetimeoffset_tDBOutput_8 = java.util.Calendar
						.getInstance(java.util.TimeZone.getTimeZone("UTC"));

				java.sql.Connection conn_tDBOutput_8 = null;
				String dbUser_tDBOutput_8 = null;
				dbschema_tDBOutput_8 = "";
				String driverClass_tDBOutput_8 = "net.sourceforge.jtds.jdbc.Driver";

				if (log.isDebugEnabled())
					log.debug("tDBOutput_8 - " + ("Driver ClassName: ") + (driverClass_tDBOutput_8) + ("."));
				java.lang.Class.forName(driverClass_tDBOutput_8);
				String port_tDBOutput_8 = "1433";
				String dbname_tDBOutput_8 = "MVC_Stage";
				String url_tDBOutput_8 = "jdbc:jtds:sqlserver://" + "localhost";
				if (!"".equals(port_tDBOutput_8)) {
					url_tDBOutput_8 += ":" + "1433";
				}
				if (!"".equals(dbname_tDBOutput_8)) {
					url_tDBOutput_8 += "//" + "MVC_Stage";

				}
				url_tDBOutput_8 += ";appName=" + projectName + ";" + "";
				dbUser_tDBOutput_8 = "";

				final String decryptedPassword_tDBOutput_8 = routines.system.PasswordEncryptUtil
						.decryptPassword("enc:routine.encryption.key.v1:EI71tV0a9rMTxY78jnTXUiAzMoGghMHwmbq4vw==");

				String dbPwd_tDBOutput_8 = decryptedPassword_tDBOutput_8;
				if (log.isDebugEnabled())
					log.debug("tDBOutput_8 - " + ("Connection attempts to '") + (url_tDBOutput_8)
							+ ("' with the username '") + (dbUser_tDBOutput_8) + ("'."));
				conn_tDBOutput_8 = java.sql.DriverManager.getConnection(url_tDBOutput_8, dbUser_tDBOutput_8,
						dbPwd_tDBOutput_8);
				if (log.isDebugEnabled())
					log.debug("tDBOutput_8 - " + ("Connection to '") + (url_tDBOutput_8) + ("' has succeeded."));

				resourceMap.put("conn_tDBOutput_8", conn_tDBOutput_8);

				conn_tDBOutput_8.setAutoCommit(false);
				int commitEvery_tDBOutput_8 = 10000;
				int commitCounter_tDBOutput_8 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBOutput_8 - " + ("Connection is set auto commit to '")
							+ (conn_tDBOutput_8.getAutoCommit()) + ("'."));
				int batchSize_tDBOutput_8 = 10000;
				int batchSizeCounter_tDBOutput_8 = 0;

				if (dbschema_tDBOutput_8 == null || dbschema_tDBOutput_8.trim().length() == 0) {
					tableName_tDBOutput_8 = "Dim_PRE_CRASH";
				} else {
					tableName_tDBOutput_8 = dbschema_tDBOutput_8 + "].[" + "Dim_PRE_CRASH";
				}
				int count_tDBOutput_8 = 0;

				String insert_tDBOutput_8 = "INSERT INTO [" + tableName_tDBOutput_8
						+ "] ([PRE_CRASH_SK],[PRE_CRASH],[DI_PID],[DI_Create_Date]) VALUES (?,?,?,?)";
				java.sql.PreparedStatement pstmt_tDBOutput_8 = conn_tDBOutput_8.prepareStatement(insert_tDBOutput_8);
				resourceMap.put("pstmt_tDBOutput_8", pstmt_tDBOutput_8);

				/**
				 * [tDBOutput_8 begin ] stop
				 */

				/**
				 * [tMap_9 begin ] start
				 */

				ok_Hash.put("tMap_9", false);
				start_Hash.put("tMap_9", System.currentTimeMillis());

				currentComponent = "tMap_9";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "row9");

				int tos_count_tMap_9 = 0;

				if (log.isDebugEnabled())
					log.debug("tMap_9 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tMap_9 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tMap_9 = new StringBuilder();
							log4jParamters_tMap_9.append("Parameters:");
							log4jParamters_tMap_9.append("LINK_STYLE" + " = " + "AUTO");
							log4jParamters_tMap_9.append(" | ");
							log4jParamters_tMap_9.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
							log4jParamters_tMap_9.append(" | ");
							log4jParamters_tMap_9.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
							log4jParamters_tMap_9.append(" | ");
							log4jParamters_tMap_9.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "true");
							log4jParamters_tMap_9.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tMap_9 - " + (log4jParamters_tMap_9));
						}
					}
					new BytesLimit65535_tMap_9().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tMap_9", "tMap_9", "tMap");
					talendJobLogProcess(globalMap);
				}

// ###############################
// # Lookup's keys initialization
				int count_row9_tMap_9 = 0;

// ###############################        

// ###############################
// # Vars initialization
				class Var__tMap_9__Struct {
				}
				Var__tMap_9__Struct Var__tMap_9 = new Var__tMap_9__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_PreCash22_tMap_9 = 0;

				PreCash22Struct PreCash22_tmp = new PreCash22Struct();
// ###############################

				/**
				 * [tMap_9 begin ] stop
				 */

				/**
				 * [tUniqRow_8 begin ] start
				 */

				ok_Hash.put("tUniqRow_8", false);
				start_Hash.put("tUniqRow_8", System.currentTimeMillis());

				currentComponent = "tUniqRow_8";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "PreCash");

				int tos_count_tUniqRow_8 = 0;

				if (log.isDebugEnabled())
					log.debug("tUniqRow_8 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tUniqRow_8 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tUniqRow_8 = new StringBuilder();
							log4jParamters_tUniqRow_8.append("Parameters:");
							log4jParamters_tUniqRow_8.append("UNIQUE_KEY" + " = " + "[{CASE_SENSITIVE=" + ("false")
									+ ", KEY_ATTRIBUTE=" + ("false") + ", SCHEMA_COLUMN=" + ("PRE_CRASH") + "}]");
							log4jParamters_tUniqRow_8.append(" | ");
							log4jParamters_tUniqRow_8.append("ONLY_ONCE_EACH_DUPLICATED_KEY" + " = " + "false");
							log4jParamters_tUniqRow_8.append(" | ");
							log4jParamters_tUniqRow_8.append("IS_VIRTUAL_COMPONENT" + " = " + "false");
							log4jParamters_tUniqRow_8.append(" | ");
							log4jParamters_tUniqRow_8.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "false");
							log4jParamters_tUniqRow_8.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tUniqRow_8 - " + (log4jParamters_tUniqRow_8));
						}
					}
					new BytesLimit65535_tUniqRow_8().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tUniqRow_8", "tUniqRow_8", "tUniqRow");
					talendJobLogProcess(globalMap);
				}

				int nb_uniques_tUniqRow_8 = 0;
				int nb_duplicates_tUniqRow_8 = 0;
				log.debug("tUniqRow_8 - Start to process the data from datasource.");

				/**
				 * [tUniqRow_8 begin ] stop
				 */

				/**
				 * [tDBOutput_9 begin ] start
				 */

				ok_Hash.put("tDBOutput_9", false);
				start_Hash.put("tDBOutput_9", System.currentTimeMillis());

				currentComponent = "tDBOutput_9";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "PointOFImpact2");

				int tos_count_tDBOutput_9 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBOutput_9 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tDBOutput_9 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tDBOutput_9 = new StringBuilder();
							log4jParamters_tDBOutput_9.append("Parameters:");
							log4jParamters_tDBOutput_9.append("USE_EXISTING_CONNECTION" + " = " + "false");
							log4jParamters_tDBOutput_9.append(" | ");
							log4jParamters_tDBOutput_9.append("DRIVER" + " = " + "JTDS");
							log4jParamters_tDBOutput_9.append(" | ");
							log4jParamters_tDBOutput_9.append("HOST" + " = " + "\"localhost\"");
							log4jParamters_tDBOutput_9.append(" | ");
							log4jParamters_tDBOutput_9.append("PORT" + " = " + "\"1433\"");
							log4jParamters_tDBOutput_9.append(" | ");
							log4jParamters_tDBOutput_9.append("DB_SCHEMA" + " = " + "\"\"");
							log4jParamters_tDBOutput_9.append(" | ");
							log4jParamters_tDBOutput_9.append("DBNAME" + " = " + "\"MVC_Stage\"");
							log4jParamters_tDBOutput_9.append(" | ");
							log4jParamters_tDBOutput_9.append("USER" + " = " + "\"\"");
							log4jParamters_tDBOutput_9.append(" | ");
							log4jParamters_tDBOutput_9.append("PASS" + " = "
									+ String.valueOf(
											"enc:routine.encryption.key.v1:MJO5kU16f/WPAzfpGgOVLbAiLTYue1e4sf1ILw==")
											.substring(0, 4)
									+ "...");
							log4jParamters_tDBOutput_9.append(" | ");
							log4jParamters_tDBOutput_9.append("TABLE" + " = " + "\"Dim_POINT_OF_IMPACT\"");
							log4jParamters_tDBOutput_9.append(" | ");
							log4jParamters_tDBOutput_9.append("TABLE_ACTION" + " = " + "NONE");
							log4jParamters_tDBOutput_9.append(" | ");
							log4jParamters_tDBOutput_9.append("IDENTITY_INSERT" + " = " + "false");
							log4jParamters_tDBOutput_9.append(" | ");
							log4jParamters_tDBOutput_9.append("DATA_ACTION" + " = " + "INSERT");
							log4jParamters_tDBOutput_9.append(" | ");
							log4jParamters_tDBOutput_9.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
							log4jParamters_tDBOutput_9.append(" | ");
							log4jParamters_tDBOutput_9.append("DIE_ON_ERROR" + " = " + "false");
							log4jParamters_tDBOutput_9.append(" | ");
							log4jParamters_tDBOutput_9.append("PROPERTIES" + " = " + "\"\"");
							log4jParamters_tDBOutput_9.append(" | ");
							log4jParamters_tDBOutput_9.append("COMMIT_EVERY" + " = " + "10000");
							log4jParamters_tDBOutput_9.append(" | ");
							log4jParamters_tDBOutput_9.append("ADD_COLS" + " = " + "[]");
							log4jParamters_tDBOutput_9.append(" | ");
							log4jParamters_tDBOutput_9.append("USE_FIELD_OPTIONS" + " = " + "false");
							log4jParamters_tDBOutput_9.append(" | ");
							log4jParamters_tDBOutput_9.append("IGNORE_DATE_OUTOF_RANGE" + " = " + "false");
							log4jParamters_tDBOutput_9.append(" | ");
							log4jParamters_tDBOutput_9.append("ENABLE_DEBUG_MODE" + " = " + "false");
							log4jParamters_tDBOutput_9.append(" | ");
							log4jParamters_tDBOutput_9.append("SUPPORT_NULL_WHERE" + " = " + "false");
							log4jParamters_tDBOutput_9.append(" | ");
							log4jParamters_tDBOutput_9.append("USE_BATCH_SIZE" + " = " + "true");
							log4jParamters_tDBOutput_9.append(" | ");
							log4jParamters_tDBOutput_9.append("BATCH_SIZE" + " = " + "10000");
							log4jParamters_tDBOutput_9.append(" | ");
							log4jParamters_tDBOutput_9.append("UNIFIED_COMPONENTS" + " = " + "tMSSqlOutput");
							log4jParamters_tDBOutput_9.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tDBOutput_9 - " + (log4jParamters_tDBOutput_9));
						}
					}
					new BytesLimit65535_tDBOutput_9().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tDBOutput_9", "__TABLE__", "tMSSqlOutput");
					talendJobLogProcess(globalMap);
				}

				int nb_line_tDBOutput_9 = 0;
				int nb_line_update_tDBOutput_9 = 0;
				int nb_line_inserted_tDBOutput_9 = 0;
				int nb_line_deleted_tDBOutput_9 = 0;
				int nb_line_rejected_tDBOutput_9 = 0;

				int deletedCount_tDBOutput_9 = 0;
				int updatedCount_tDBOutput_9 = 0;
				int insertedCount_tDBOutput_9 = 0;
				int rowsToCommitCount_tDBOutput_9 = 0;
				int rejectedCount_tDBOutput_9 = 0;
				String dbschema_tDBOutput_9 = null;
				String tableName_tDBOutput_9 = null;
				boolean whetherReject_tDBOutput_9 = false;

				java.util.Calendar calendar_tDBOutput_9 = java.util.Calendar.getInstance();
				long year1_tDBOutput_9 = TalendDate.parseDate("yyyy-MM-dd", "0001-01-01").getTime();
				long year2_tDBOutput_9 = TalendDate.parseDate("yyyy-MM-dd", "1753-01-01").getTime();
				long year10000_tDBOutput_9 = TalendDate.parseDate("yyyy-MM-dd HH:mm:ss", "9999-12-31 24:00:00")
						.getTime();
				long date_tDBOutput_9;

				java.util.Calendar calendar_datetimeoffset_tDBOutput_9 = java.util.Calendar
						.getInstance(java.util.TimeZone.getTimeZone("UTC"));

				java.sql.Connection conn_tDBOutput_9 = null;
				String dbUser_tDBOutput_9 = null;
				dbschema_tDBOutput_9 = "";
				String driverClass_tDBOutput_9 = "net.sourceforge.jtds.jdbc.Driver";

				if (log.isDebugEnabled())
					log.debug("tDBOutput_9 - " + ("Driver ClassName: ") + (driverClass_tDBOutput_9) + ("."));
				java.lang.Class.forName(driverClass_tDBOutput_9);
				String port_tDBOutput_9 = "1433";
				String dbname_tDBOutput_9 = "MVC_Stage";
				String url_tDBOutput_9 = "jdbc:jtds:sqlserver://" + "localhost";
				if (!"".equals(port_tDBOutput_9)) {
					url_tDBOutput_9 += ":" + "1433";
				}
				if (!"".equals(dbname_tDBOutput_9)) {
					url_tDBOutput_9 += "//" + "MVC_Stage";

				}
				url_tDBOutput_9 += ";appName=" + projectName + ";" + "";
				dbUser_tDBOutput_9 = "";

				final String decryptedPassword_tDBOutput_9 = routines.system.PasswordEncryptUtil
						.decryptPassword("enc:routine.encryption.key.v1:oBfHiNunEYOLJv+Bf8UykpIqJBXIe4hJR0lSuQ==");

				String dbPwd_tDBOutput_9 = decryptedPassword_tDBOutput_9;
				if (log.isDebugEnabled())
					log.debug("tDBOutput_9 - " + ("Connection attempts to '") + (url_tDBOutput_9)
							+ ("' with the username '") + (dbUser_tDBOutput_9) + ("'."));
				conn_tDBOutput_9 = java.sql.DriverManager.getConnection(url_tDBOutput_9, dbUser_tDBOutput_9,
						dbPwd_tDBOutput_9);
				if (log.isDebugEnabled())
					log.debug("tDBOutput_9 - " + ("Connection to '") + (url_tDBOutput_9) + ("' has succeeded."));

				resourceMap.put("conn_tDBOutput_9", conn_tDBOutput_9);

				conn_tDBOutput_9.setAutoCommit(false);
				int commitEvery_tDBOutput_9 = 10000;
				int commitCounter_tDBOutput_9 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBOutput_9 - " + ("Connection is set auto commit to '")
							+ (conn_tDBOutput_9.getAutoCommit()) + ("'."));
				int batchSize_tDBOutput_9 = 10000;
				int batchSizeCounter_tDBOutput_9 = 0;

				if (dbschema_tDBOutput_9 == null || dbschema_tDBOutput_9.trim().length() == 0) {
					tableName_tDBOutput_9 = "Dim_POINT_OF_IMPACT";
				} else {
					tableName_tDBOutput_9 = dbschema_tDBOutput_9 + "].[" + "Dim_POINT_OF_IMPACT";
				}
				int count_tDBOutput_9 = 0;

				String insert_tDBOutput_9 = "INSERT INTO [" + tableName_tDBOutput_9
						+ "] ([POINT_OF_IMPACT_SK],[POINT_OF_IMPACT],[DI_PID],[DI_Create_Date]) VALUES (?,?,?,?)";
				java.sql.PreparedStatement pstmt_tDBOutput_9 = conn_tDBOutput_9.prepareStatement(insert_tDBOutput_9);
				resourceMap.put("pstmt_tDBOutput_9", pstmt_tDBOutput_9);

				/**
				 * [tDBOutput_9 begin ] stop
				 */

				/**
				 * [tMap_10 begin ] start
				 */

				ok_Hash.put("tMap_10", false);
				start_Hash.put("tMap_10", System.currentTimeMillis());

				currentComponent = "tMap_10";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "row10");

				int tos_count_tMap_10 = 0;

				if (log.isDebugEnabled())
					log.debug("tMap_10 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tMap_10 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tMap_10 = new StringBuilder();
							log4jParamters_tMap_10.append("Parameters:");
							log4jParamters_tMap_10.append("LINK_STYLE" + " = " + "AUTO");
							log4jParamters_tMap_10.append(" | ");
							log4jParamters_tMap_10.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
							log4jParamters_tMap_10.append(" | ");
							log4jParamters_tMap_10.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
							log4jParamters_tMap_10.append(" | ");
							log4jParamters_tMap_10.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "true");
							log4jParamters_tMap_10.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tMap_10 - " + (log4jParamters_tMap_10));
						}
					}
					new BytesLimit65535_tMap_10().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tMap_10", "tMap_10", "tMap");
					talendJobLogProcess(globalMap);
				}

// ###############################
// # Lookup's keys initialization
				int count_row10_tMap_10 = 0;

// ###############################        

// ###############################
// # Vars initialization
				class Var__tMap_10__Struct {
				}
				Var__tMap_10__Struct Var__tMap_10 = new Var__tMap_10__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_PointOFImpact2_tMap_10 = 0;

				PointOFImpact2Struct PointOFImpact2_tmp = new PointOFImpact2Struct();
// ###############################

				/**
				 * [tMap_10 begin ] stop
				 */

				/**
				 * [tUniqRow_9 begin ] start
				 */

				ok_Hash.put("tUniqRow_9", false);
				start_Hash.put("tUniqRow_9", System.currentTimeMillis());

				currentComponent = "tUniqRow_9";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "Point_Of_Impact");

				int tos_count_tUniqRow_9 = 0;

				if (log.isDebugEnabled())
					log.debug("tUniqRow_9 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tUniqRow_9 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tUniqRow_9 = new StringBuilder();
							log4jParamters_tUniqRow_9.append("Parameters:");
							log4jParamters_tUniqRow_9.append("UNIQUE_KEY" + " = " + "[{CASE_SENSITIVE=" + ("false")
									+ ", KEY_ATTRIBUTE=" + ("false") + ", SCHEMA_COLUMN=" + ("POINT_OF_IMPACT") + "}]");
							log4jParamters_tUniqRow_9.append(" | ");
							log4jParamters_tUniqRow_9.append("ONLY_ONCE_EACH_DUPLICATED_KEY" + " = " + "false");
							log4jParamters_tUniqRow_9.append(" | ");
							log4jParamters_tUniqRow_9.append("IS_VIRTUAL_COMPONENT" + " = " + "false");
							log4jParamters_tUniqRow_9.append(" | ");
							log4jParamters_tUniqRow_9.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "false");
							log4jParamters_tUniqRow_9.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tUniqRow_9 - " + (log4jParamters_tUniqRow_9));
						}
					}
					new BytesLimit65535_tUniqRow_9().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tUniqRow_9", "tUniqRow_9", "tUniqRow");
					talendJobLogProcess(globalMap);
				}

				int nb_uniques_tUniqRow_9 = 0;
				int nb_duplicates_tUniqRow_9 = 0;
				log.debug("tUniqRow_9 - Start to process the data from datasource.");

				/**
				 * [tUniqRow_9 begin ] stop
				 */

				/**
				 * [tDBOutput_10 begin ] start
				 */

				ok_Hash.put("tDBOutput_10", false);
				start_Hash.put("tDBOutput_10", System.currentTimeMillis());

				currentComponent = "tDBOutput_10";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0,
						"PublicPropertyDamage2");

				int tos_count_tDBOutput_10 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBOutput_10 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tDBOutput_10 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tDBOutput_10 = new StringBuilder();
							log4jParamters_tDBOutput_10.append("Parameters:");
							log4jParamters_tDBOutput_10.append("USE_EXISTING_CONNECTION" + " = " + "false");
							log4jParamters_tDBOutput_10.append(" | ");
							log4jParamters_tDBOutput_10.append("DRIVER" + " = " + "JTDS");
							log4jParamters_tDBOutput_10.append(" | ");
							log4jParamters_tDBOutput_10.append("HOST" + " = " + "\"localhost\"");
							log4jParamters_tDBOutput_10.append(" | ");
							log4jParamters_tDBOutput_10.append("PORT" + " = " + "\"1433\"");
							log4jParamters_tDBOutput_10.append(" | ");
							log4jParamters_tDBOutput_10.append("DB_SCHEMA" + " = " + "\"\"");
							log4jParamters_tDBOutput_10.append(" | ");
							log4jParamters_tDBOutput_10.append("DBNAME" + " = " + "\"MVC_Stage\"");
							log4jParamters_tDBOutput_10.append(" | ");
							log4jParamters_tDBOutput_10.append("USER" + " = " + "\"\"");
							log4jParamters_tDBOutput_10.append(" | ");
							log4jParamters_tDBOutput_10.append("PASS" + " = "
									+ String.valueOf(
											"enc:routine.encryption.key.v1:ivITAK+8mrNZvT9B0RHhLI/zkq0cmqX1/oKMTA==")
											.substring(0, 4)
									+ "...");
							log4jParamters_tDBOutput_10.append(" | ");
							log4jParamters_tDBOutput_10.append("TABLE" + " = " + "\"Dim_PUBLIC_PROPERTY_DAMAGE\"");
							log4jParamters_tDBOutput_10.append(" | ");
							log4jParamters_tDBOutput_10.append("TABLE_ACTION" + " = " + "NONE");
							log4jParamters_tDBOutput_10.append(" | ");
							log4jParamters_tDBOutput_10.append("IDENTITY_INSERT" + " = " + "false");
							log4jParamters_tDBOutput_10.append(" | ");
							log4jParamters_tDBOutput_10.append("DATA_ACTION" + " = " + "INSERT");
							log4jParamters_tDBOutput_10.append(" | ");
							log4jParamters_tDBOutput_10.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
							log4jParamters_tDBOutput_10.append(" | ");
							log4jParamters_tDBOutput_10.append("DIE_ON_ERROR" + " = " + "false");
							log4jParamters_tDBOutput_10.append(" | ");
							log4jParamters_tDBOutput_10.append("PROPERTIES" + " = " + "\"\"");
							log4jParamters_tDBOutput_10.append(" | ");
							log4jParamters_tDBOutput_10.append("COMMIT_EVERY" + " = " + "10000");
							log4jParamters_tDBOutput_10.append(" | ");
							log4jParamters_tDBOutput_10.append("ADD_COLS" + " = " + "[]");
							log4jParamters_tDBOutput_10.append(" | ");
							log4jParamters_tDBOutput_10.append("USE_FIELD_OPTIONS" + " = " + "false");
							log4jParamters_tDBOutput_10.append(" | ");
							log4jParamters_tDBOutput_10.append("IGNORE_DATE_OUTOF_RANGE" + " = " + "false");
							log4jParamters_tDBOutput_10.append(" | ");
							log4jParamters_tDBOutput_10.append("ENABLE_DEBUG_MODE" + " = " + "false");
							log4jParamters_tDBOutput_10.append(" | ");
							log4jParamters_tDBOutput_10.append("SUPPORT_NULL_WHERE" + " = " + "false");
							log4jParamters_tDBOutput_10.append(" | ");
							log4jParamters_tDBOutput_10.append("USE_BATCH_SIZE" + " = " + "true");
							log4jParamters_tDBOutput_10.append(" | ");
							log4jParamters_tDBOutput_10.append("BATCH_SIZE" + " = " + "10000");
							log4jParamters_tDBOutput_10.append(" | ");
							log4jParamters_tDBOutput_10.append("UNIFIED_COMPONENTS" + " = " + "tMSSqlOutput");
							log4jParamters_tDBOutput_10.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tDBOutput_10 - " + (log4jParamters_tDBOutput_10));
						}
					}
					new BytesLimit65535_tDBOutput_10().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tDBOutput_10", "__TABLE__", "tMSSqlOutput");
					talendJobLogProcess(globalMap);
				}

				int nb_line_tDBOutput_10 = 0;
				int nb_line_update_tDBOutput_10 = 0;
				int nb_line_inserted_tDBOutput_10 = 0;
				int nb_line_deleted_tDBOutput_10 = 0;
				int nb_line_rejected_tDBOutput_10 = 0;

				int deletedCount_tDBOutput_10 = 0;
				int updatedCount_tDBOutput_10 = 0;
				int insertedCount_tDBOutput_10 = 0;
				int rowsToCommitCount_tDBOutput_10 = 0;
				int rejectedCount_tDBOutput_10 = 0;
				String dbschema_tDBOutput_10 = null;
				String tableName_tDBOutput_10 = null;
				boolean whetherReject_tDBOutput_10 = false;

				java.util.Calendar calendar_tDBOutput_10 = java.util.Calendar.getInstance();
				long year1_tDBOutput_10 = TalendDate.parseDate("yyyy-MM-dd", "0001-01-01").getTime();
				long year2_tDBOutput_10 = TalendDate.parseDate("yyyy-MM-dd", "1753-01-01").getTime();
				long year10000_tDBOutput_10 = TalendDate.parseDate("yyyy-MM-dd HH:mm:ss", "9999-12-31 24:00:00")
						.getTime();
				long date_tDBOutput_10;

				java.util.Calendar calendar_datetimeoffset_tDBOutput_10 = java.util.Calendar
						.getInstance(java.util.TimeZone.getTimeZone("UTC"));

				java.sql.Connection conn_tDBOutput_10 = null;
				String dbUser_tDBOutput_10 = null;
				dbschema_tDBOutput_10 = "";
				String driverClass_tDBOutput_10 = "net.sourceforge.jtds.jdbc.Driver";

				if (log.isDebugEnabled())
					log.debug("tDBOutput_10 - " + ("Driver ClassName: ") + (driverClass_tDBOutput_10) + ("."));
				java.lang.Class.forName(driverClass_tDBOutput_10);
				String port_tDBOutput_10 = "1433";
				String dbname_tDBOutput_10 = "MVC_Stage";
				String url_tDBOutput_10 = "jdbc:jtds:sqlserver://" + "localhost";
				if (!"".equals(port_tDBOutput_10)) {
					url_tDBOutput_10 += ":" + "1433";
				}
				if (!"".equals(dbname_tDBOutput_10)) {
					url_tDBOutput_10 += "//" + "MVC_Stage";

				}
				url_tDBOutput_10 += ";appName=" + projectName + ";" + "";
				dbUser_tDBOutput_10 = "";

				final String decryptedPassword_tDBOutput_10 = routines.system.PasswordEncryptUtil
						.decryptPassword("enc:routine.encryption.key.v1:jt6jxLr75B38/UfefXaAN0uUr3WKvE2ZAO6ztQ==");

				String dbPwd_tDBOutput_10 = decryptedPassword_tDBOutput_10;
				if (log.isDebugEnabled())
					log.debug("tDBOutput_10 - " + ("Connection attempts to '") + (url_tDBOutput_10)
							+ ("' with the username '") + (dbUser_tDBOutput_10) + ("'."));
				conn_tDBOutput_10 = java.sql.DriverManager.getConnection(url_tDBOutput_10, dbUser_tDBOutput_10,
						dbPwd_tDBOutput_10);
				if (log.isDebugEnabled())
					log.debug("tDBOutput_10 - " + ("Connection to '") + (url_tDBOutput_10) + ("' has succeeded."));

				resourceMap.put("conn_tDBOutput_10", conn_tDBOutput_10);

				conn_tDBOutput_10.setAutoCommit(false);
				int commitEvery_tDBOutput_10 = 10000;
				int commitCounter_tDBOutput_10 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBOutput_10 - " + ("Connection is set auto commit to '")
							+ (conn_tDBOutput_10.getAutoCommit()) + ("'."));
				int batchSize_tDBOutput_10 = 10000;
				int batchSizeCounter_tDBOutput_10 = 0;

				if (dbschema_tDBOutput_10 == null || dbschema_tDBOutput_10.trim().length() == 0) {
					tableName_tDBOutput_10 = "Dim_PUBLIC_PROPERTY_DAMAGE";
				} else {
					tableName_tDBOutput_10 = dbschema_tDBOutput_10 + "].[" + "Dim_PUBLIC_PROPERTY_DAMAGE";
				}
				int count_tDBOutput_10 = 0;

				String insert_tDBOutput_10 = "INSERT INTO [" + tableName_tDBOutput_10
						+ "] ([PUBLIC_PROPERTY_DAMAGE_SK],[PUBLIC_PROPERTY_DAMAGE],[DI_PID],[DI_Create_Date]) VALUES (?,?,?,?)";
				java.sql.PreparedStatement pstmt_tDBOutput_10 = conn_tDBOutput_10.prepareStatement(insert_tDBOutput_10);
				resourceMap.put("pstmt_tDBOutput_10", pstmt_tDBOutput_10);

				/**
				 * [tDBOutput_10 begin ] stop
				 */

				/**
				 * [tMap_11 begin ] start
				 */

				ok_Hash.put("tMap_11", false);
				start_Hash.put("tMap_11", System.currentTimeMillis());

				currentComponent = "tMap_11";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "row11");

				int tos_count_tMap_11 = 0;

				if (log.isDebugEnabled())
					log.debug("tMap_11 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tMap_11 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tMap_11 = new StringBuilder();
							log4jParamters_tMap_11.append("Parameters:");
							log4jParamters_tMap_11.append("LINK_STYLE" + " = " + "AUTO");
							log4jParamters_tMap_11.append(" | ");
							log4jParamters_tMap_11.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
							log4jParamters_tMap_11.append(" | ");
							log4jParamters_tMap_11.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
							log4jParamters_tMap_11.append(" | ");
							log4jParamters_tMap_11.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "true");
							log4jParamters_tMap_11.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tMap_11 - " + (log4jParamters_tMap_11));
						}
					}
					new BytesLimit65535_tMap_11().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tMap_11", "tMap_11", "tMap");
					talendJobLogProcess(globalMap);
				}

// ###############################
// # Lookup's keys initialization
				int count_row11_tMap_11 = 0;

// ###############################        

// ###############################
// # Vars initialization
				class Var__tMap_11__Struct {
				}
				Var__tMap_11__Struct Var__tMap_11 = new Var__tMap_11__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_PublicPropertyDamage2_tMap_11 = 0;

				PublicPropertyDamage2Struct PublicPropertyDamage2_tmp = new PublicPropertyDamage2Struct();
// ###############################

				/**
				 * [tMap_11 begin ] stop
				 */

				/**
				 * [tUniqRow_10 begin ] start
				 */

				ok_Hash.put("tUniqRow_10", false);
				start_Hash.put("tUniqRow_10", System.currentTimeMillis());

				currentComponent = "tUniqRow_10";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0,
						"Public_propertyDamage");

				int tos_count_tUniqRow_10 = 0;

				if (log.isDebugEnabled())
					log.debug("tUniqRow_10 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tUniqRow_10 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tUniqRow_10 = new StringBuilder();
							log4jParamters_tUniqRow_10.append("Parameters:");
							log4jParamters_tUniqRow_10
									.append("UNIQUE_KEY" + " = " + "[{CASE_SENSITIVE=" + ("false") + ", KEY_ATTRIBUTE="
											+ ("false") + ", SCHEMA_COLUMN=" + ("PUBLIC_PROPERTY_DAMAGE") + "}]");
							log4jParamters_tUniqRow_10.append(" | ");
							log4jParamters_tUniqRow_10.append("ONLY_ONCE_EACH_DUPLICATED_KEY" + " = " + "false");
							log4jParamters_tUniqRow_10.append(" | ");
							log4jParamters_tUniqRow_10.append("IS_VIRTUAL_COMPONENT" + " = " + "false");
							log4jParamters_tUniqRow_10.append(" | ");
							log4jParamters_tUniqRow_10
									.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "false");
							log4jParamters_tUniqRow_10.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tUniqRow_10 - " + (log4jParamters_tUniqRow_10));
						}
					}
					new BytesLimit65535_tUniqRow_10().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tUniqRow_10", "tUniqRow_10", "tUniqRow");
					talendJobLogProcess(globalMap);
				}

				int nb_uniques_tUniqRow_10 = 0;
				int nb_duplicates_tUniqRow_10 = 0;
				log.debug("tUniqRow_10 - Start to process the data from datasource.");

				/**
				 * [tUniqRow_10 begin ] stop
				 */

				/**
				 * [tMap_1 begin ] start
				 */

				ok_Hash.put("tMap_1", false);
				start_Hash.put("tMap_1", System.currentTimeMillis());

				currentComponent = "tMap_1";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "row1");

				int tos_count_tMap_1 = 0;

				if (log.isDebugEnabled())
					log.debug("tMap_1 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tMap_1 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tMap_1 = new StringBuilder();
							log4jParamters_tMap_1.append("Parameters:");
							log4jParamters_tMap_1.append("LINK_STYLE" + " = " + "AUTO");
							log4jParamters_tMap_1.append(" | ");
							log4jParamters_tMap_1.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
							log4jParamters_tMap_1.append(" | ");
							log4jParamters_tMap_1.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
							log4jParamters_tMap_1.append(" | ");
							log4jParamters_tMap_1.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "true");
							log4jParamters_tMap_1.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tMap_1 - " + (log4jParamters_tMap_1));
						}
					}
					new BytesLimit65535_tMap_1().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tMap_1", "tMap_1", "tMap");
					talendJobLogProcess(globalMap);
				}

// ###############################
// # Lookup's keys initialization
				int count_row1_tMap_1 = 0;

// ###############################        

// ###############################
// # Vars initialization
				class Var__tMap_1__Struct {
				}
				Var__tMap_1__Struct Var__tMap_1 = new Var__tMap_1__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_State_Registration_Sk_tMap_1 = 0;

				State_Registration_SkStruct State_Registration_Sk_tmp = new State_Registration_SkStruct();
				int count_Vehicle_type_tMap_1 = 0;

				Vehicle_typeStruct Vehicle_type_tmp = new Vehicle_typeStruct();
				int count_Vehicle_Make_tMap_1 = 0;

				Vehicle_MakeStruct Vehicle_Make_tmp = new Vehicle_MakeStruct();
				int count_Vehicle_Model_tMap_1 = 0;

				Vehicle_ModelStruct Vehicle_Model_tmp = new Vehicle_ModelStruct();
				int count_Travel_Direction_tMap_1 = 0;

				Travel_DirectionStruct Travel_Direction_tmp = new Travel_DirectionStruct();
				int count_Driver_License_Status_tMap_1 = 0;

				Driver_License_StatusStruct Driver_License_Status_tmp = new Driver_License_StatusStruct();
				int count_Driver_License_Jusridiction_tMap_1 = 0;

				Driver_License_JusridictionStruct Driver_License_Jusridiction_tmp = new Driver_License_JusridictionStruct();
				int count_PreCash_tMap_1 = 0;

				PreCashStruct PreCash_tmp = new PreCashStruct();
				int count_Point_Of_Impact_tMap_1 = 0;

				Point_Of_ImpactStruct Point_Of_Impact_tmp = new Point_Of_ImpactStruct();
				int count_Public_propertyDamage_tMap_1 = 0;

				Public_propertyDamageStruct Public_propertyDamage_tmp = new Public_propertyDamageStruct();
// ###############################

				/**
				 * [tMap_1 begin ] stop
				 */

				/**
				 * [tDBInput_1 begin ] start
				 */

				ok_Hash.put("tDBInput_1", false);
				start_Hash.put("tDBInput_1", System.currentTimeMillis());

				currentComponent = "tDBInput_1";

				int tos_count_tDBInput_1 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBInput_1 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tDBInput_1 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tDBInput_1 = new StringBuilder();
							log4jParamters_tDBInput_1.append("Parameters:");
							log4jParamters_tDBInput_1.append("USE_EXISTING_CONNECTION" + " = " + "false");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("HOST" + " = " + "\"localhost\"");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("DRIVER" + " = " + "JTDS");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("PORT" + " = " + "\"1433\"");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("DB_SCHEMA" + " = " + "\"\"");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("DBNAME" + " = " + "\"MVC_Stage\"");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("USER" + " = " + "\"\"");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("PASS" + " = "
									+ String.valueOf(
											"enc:routine.encryption.key.v1:6/7Gi6Akp9kAktiRLkt35yEQSNWS94rC0Juaxg==")
											.substring(0, 4)
									+ "...");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("TABLE" + " = " + "\"MVC_Vehicle_stage\"");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("QUERYSTORE" + " = " + "\"\"");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("QUERY" + " = "
									+ "\"SELECT MVC_Vehicle_stage.COLLISION_ID, 		MVC_Vehicle_stage.CRASH_DATE, 		MVC_Vehicle_stage.CRASH_TIME, 		MVC_Vehicle_stage.VEHICLE_ID, 		MVC_Vehicle_stage.STATE_REGISTRATION, 		MVC_Vehicle_stage.VEHICLE_TYPE, 		MVC_Vehicle_stage.VEHICLE_MAKE, 		MVC_Vehicle_stage.VEHICLE_MODEL, 		MVC_Vehicle_stage.VEHICLE_YEAR, 		MVC_Vehicle_stage.TRAVEL_DIRECTION, 		MVC_Vehicle_stage.VEHICLE_OCCUPANTS, 		MVC_Vehicle_stage.DRIVER_SEX, 		MVC_Vehicle_stage.DRIVER_LICENSE_STATUS, 		MVC_Vehicle_stage.DRIVER_LICENSE_JURISDICTION, 		MVC_Vehicle_stage.PRE_CRASH, 		MVC_Vehicle_stage.POINT_OF_IMPACT, 		MVC_Vehicle_stage.VEHICLE_DAMAGE, 		MVC_Vehicle_stage.VEHICLE_DAMAGE_1, 		MVC_Vehicle_stage.VEHICLE_DAMAGE_2, 		MVC_Vehicle_stage.VEHICLE_DAMAGE_3, 		MVC_Vehicle_stage.PUBLIC_PROPERTY_DAMAGE, 		MVC_Vehicle_stage.PUBLIC_PROPERTY_DAMAGE_TYPE, 		MVC_Vehicle_stage.CONTRIBUTING_FACTOR_1, 		MVC_Vehicle_stage.CONTRIBUTING_FACTOR_2, 		MVC_Vehicle_stage.UNIQUE_ID FROM	MVC_Vehicle_stage\"");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("PROPERTIES" + " = " + "\"\"");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("TRIM_ALL_COLUMN" + " = " + "false");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("TRIM_COLUMN" + " = " + "[{TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("COLLISION_ID") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("CRASH_DATE") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN="
									+ ("CRASH_TIME") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN=" + ("VEHICLE_ID")
									+ "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN=" + ("STATE_REGISTRATION")
									+ "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN=" + ("VEHICLE_TYPE") + "}, {TRIM="
									+ ("false") + ", SCHEMA_COLUMN=" + ("VEHICLE_MAKE") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("VEHICLE_MODEL") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("VEHICLE_YEAR") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("TRAVEL_DIRECTION") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("VEHICLE_OCCUPANTS") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("DRIVER_SEX") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN="
									+ ("DRIVER_LICENSE_STATUS") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN="
									+ ("DRIVER_LICENSE_JURISDICTION") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN="
									+ ("PRE_CRASH") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN=" + ("POINT_OF_IMPACT")
									+ "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN=" + ("VEHICLE_DAMAGE") + "}, {TRIM="
									+ ("false") + ", SCHEMA_COLUMN=" + ("VEHICLE_DAMAGE_1") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("VEHICLE_DAMAGE_2") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("VEHICLE_DAMAGE_3") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("PUBLIC_PROPERTY_DAMAGE") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("PUBLIC_PROPERTY_DAMAGE_TYPE") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("CONTRIBUTING_FACTOR_1") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("CONTRIBUTING_FACTOR_2") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("UNIQUE_ID") + "}]");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("UNIFIED_COMPONENTS" + " = " + "tMSSqlInput");
							log4jParamters_tDBInput_1.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tDBInput_1 - " + (log4jParamters_tDBInput_1));
						}
					}
					new BytesLimit65535_tDBInput_1().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tDBInput_1", "__TABLE__", "tMSSqlInput");
					talendJobLogProcess(globalMap);
				}

				org.talend.designer.components.util.mssql.MSSqlGenerateTimestampUtil mssqlGTU_tDBInput_1 = org.talend.designer.components.util.mssql.MSSqlUtilFactory
						.getMSSqlGenerateTimestampUtil();

				java.util.List<String> talendToDBList_tDBInput_1 = new java.util.ArrayList();
				String[] talendToDBArray_tDBInput_1 = new String[] { "FLOAT", "NUMERIC", "NUMERIC IDENTITY", "DECIMAL",
						"DECIMAL IDENTITY", "REAL" };
				java.util.Collections.addAll(talendToDBList_tDBInput_1, talendToDBArray_tDBInput_1);
				int nb_line_tDBInput_1 = 0;
				java.sql.Connection conn_tDBInput_1 = null;
				String driverClass_tDBInput_1 = "net.sourceforge.jtds.jdbc.Driver";
				java.lang.Class jdbcclazz_tDBInput_1 = java.lang.Class.forName(driverClass_tDBInput_1);
				String dbUser_tDBInput_1 = "";

				final String decryptedPassword_tDBInput_1 = routines.system.PasswordEncryptUtil
						.decryptPassword("enc:routine.encryption.key.v1:8KMCU6OXSgOeW3n3kKQGan71YFjG78LvTTYJ+w==");

				String dbPwd_tDBInput_1 = decryptedPassword_tDBInput_1;

				String port_tDBInput_1 = "1433";
				String dbname_tDBInput_1 = "MVC_Stage";
				String url_tDBInput_1 = "jdbc:jtds:sqlserver://" + "localhost";
				if (!"".equals(port_tDBInput_1)) {
					url_tDBInput_1 += ":" + "1433";
				}
				if (!"".equals(dbname_tDBInput_1)) {
					url_tDBInput_1 += "//" + "MVC_Stage";
				}
				url_tDBInput_1 += ";appName=" + projectName + ";" + "";
				String dbschema_tDBInput_1 = "";

				log.debug("tDBInput_1 - Driver ClassName: " + driverClass_tDBInput_1 + ".");

				log.debug("tDBInput_1 - Connection attempt to '" + url_tDBInput_1 + "' with the username '"
						+ dbUser_tDBInput_1 + "'.");

				conn_tDBInput_1 = java.sql.DriverManager.getConnection(url_tDBInput_1, dbUser_tDBInput_1,
						dbPwd_tDBInput_1);
				log.debug("tDBInput_1 - Connection to '" + url_tDBInput_1 + "' has succeeded.");

				java.sql.Statement stmt_tDBInput_1 = conn_tDBInput_1.createStatement();

				String dbquery_tDBInput_1 = "SELECT MVC_Vehicle_stage.COLLISION_ID,\n		MVC_Vehicle_stage.CRASH_DATE,\n		MVC_Vehicle_stage.CRASH_TIME,\n		MVC_Vehicle_st"
						+ "age.VEHICLE_ID,\n		MVC_Vehicle_stage.STATE_REGISTRATION,\n		MVC_Vehicle_stage.VEHICLE_TYPE,\n		MVC_Vehicle_stage.VEHICLE_MA"
						+ "KE,\n		MVC_Vehicle_stage.VEHICLE_MODEL,\n		MVC_Vehicle_stage.VEHICLE_YEAR,\n		MVC_Vehicle_stage.TRAVEL_DIRECTION,\n		MVC_Veh"
						+ "icle_stage.VEHICLE_OCCUPANTS,\n		MVC_Vehicle_stage.DRIVER_SEX,\n		MVC_Vehicle_stage.DRIVER_LICENSE_STATUS,\n		MVC_Vehicle_s"
						+ "tage.DRIVER_LICENSE_JURISDICTION,\n		MVC_Vehicle_stage.PRE_CRASH,\n		MVC_Vehicle_stage.POINT_OF_IMPACT,\n		MVC_Vehicle_stag"
						+ "e.VEHICLE_DAMAGE,\n		MVC_Vehicle_stage.VEHICLE_DAMAGE_1,\n		MVC_Vehicle_stage.VEHICLE_DAMAGE_2,\n		MVC_Vehicle_stage.VEHICL"
						+ "E_DAMAGE_3,\n		MVC_Vehicle_stage.PUBLIC_PROPERTY_DAMAGE,\n		MVC_Vehicle_stage.PUBLIC_PROPERTY_DAMAGE_TYPE,\n		MVC_Vehicle_s"
						+ "tage.CONTRIBUTING_FACTOR_1,\n		MVC_Vehicle_stage.CONTRIBUTING_FACTOR_2,\n		MVC_Vehicle_stage.UNIQUE_ID\nFROM	MVC_Vehicle_st"
						+ "age";

				log.debug("tDBInput_1 - Executing the query: '" + dbquery_tDBInput_1 + "'.");

				globalMap.put("tDBInput_1_QUERY", dbquery_tDBInput_1);
				java.sql.ResultSet rs_tDBInput_1 = null;

				try {
					rs_tDBInput_1 = stmt_tDBInput_1.executeQuery(dbquery_tDBInput_1);
					java.sql.ResultSetMetaData rsmd_tDBInput_1 = rs_tDBInput_1.getMetaData();
					int colQtyInRs_tDBInput_1 = rsmd_tDBInput_1.getColumnCount();

					String tmpContent_tDBInput_1 = null;

					log.debug("tDBInput_1 - Retrieving records from the database.");

					while (rs_tDBInput_1.next()) {
						nb_line_tDBInput_1++;

						if (colQtyInRs_tDBInput_1 < 1) {
							row1.COLLISION_ID = null;
						} else {

							row1.COLLISION_ID = rs_tDBInput_1.getInt(1);
							if (rs_tDBInput_1.wasNull()) {
								row1.COLLISION_ID = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 2) {
							row1.CRASH_DATE = null;
						} else {

							tmpContent_tDBInput_1 = rs_tDBInput_1.getString(2);
							if (tmpContent_tDBInput_1 != null) {
								if (talendToDBList_tDBInput_1.contains(
										rsmd_tDBInput_1.getColumnTypeName(2).toUpperCase(java.util.Locale.ENGLISH))) {
									row1.CRASH_DATE = FormatterUtils.formatUnwithE(tmpContent_tDBInput_1);
								} else {
									row1.CRASH_DATE = tmpContent_tDBInput_1;
								}
							} else {
								row1.CRASH_DATE = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 3) {
							row1.CRASH_TIME = null;
						} else {

							tmpContent_tDBInput_1 = rs_tDBInput_1.getString(3);
							if (tmpContent_tDBInput_1 != null) {
								if (talendToDBList_tDBInput_1.contains(
										rsmd_tDBInput_1.getColumnTypeName(3).toUpperCase(java.util.Locale.ENGLISH))) {
									row1.CRASH_TIME = FormatterUtils.formatUnwithE(tmpContent_tDBInput_1);
								} else {
									row1.CRASH_TIME = tmpContent_tDBInput_1;
								}
							} else {
								row1.CRASH_TIME = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 4) {
							row1.VEHICLE_ID = null;
						} else {

							tmpContent_tDBInput_1 = rs_tDBInput_1.getString(4);
							if (tmpContent_tDBInput_1 != null) {
								if (talendToDBList_tDBInput_1.contains(
										rsmd_tDBInput_1.getColumnTypeName(4).toUpperCase(java.util.Locale.ENGLISH))) {
									row1.VEHICLE_ID = FormatterUtils.formatUnwithE(tmpContent_tDBInput_1);
								} else {
									row1.VEHICLE_ID = tmpContent_tDBInput_1;
								}
							} else {
								row1.VEHICLE_ID = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 5) {
							row1.STATE_REGISTRATION = null;
						} else {

							tmpContent_tDBInput_1 = rs_tDBInput_1.getString(5);
							if (tmpContent_tDBInput_1 != null) {
								if (talendToDBList_tDBInput_1.contains(
										rsmd_tDBInput_1.getColumnTypeName(5).toUpperCase(java.util.Locale.ENGLISH))) {
									row1.STATE_REGISTRATION = FormatterUtils.formatUnwithE(tmpContent_tDBInput_1);
								} else {
									row1.STATE_REGISTRATION = tmpContent_tDBInput_1;
								}
							} else {
								row1.STATE_REGISTRATION = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 6) {
							row1.VEHICLE_TYPE = null;
						} else {

							tmpContent_tDBInput_1 = rs_tDBInput_1.getString(6);
							if (tmpContent_tDBInput_1 != null) {
								if (talendToDBList_tDBInput_1.contains(
										rsmd_tDBInput_1.getColumnTypeName(6).toUpperCase(java.util.Locale.ENGLISH))) {
									row1.VEHICLE_TYPE = FormatterUtils.formatUnwithE(tmpContent_tDBInput_1);
								} else {
									row1.VEHICLE_TYPE = tmpContent_tDBInput_1;
								}
							} else {
								row1.VEHICLE_TYPE = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 7) {
							row1.VEHICLE_MAKE = null;
						} else {

							tmpContent_tDBInput_1 = rs_tDBInput_1.getString(7);
							if (tmpContent_tDBInput_1 != null) {
								if (talendToDBList_tDBInput_1.contains(
										rsmd_tDBInput_1.getColumnTypeName(7).toUpperCase(java.util.Locale.ENGLISH))) {
									row1.VEHICLE_MAKE = FormatterUtils.formatUnwithE(tmpContent_tDBInput_1);
								} else {
									row1.VEHICLE_MAKE = tmpContent_tDBInput_1;
								}
							} else {
								row1.VEHICLE_MAKE = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 8) {
							row1.VEHICLE_MODEL = null;
						} else {

							tmpContent_tDBInput_1 = rs_tDBInput_1.getString(8);
							if (tmpContent_tDBInput_1 != null) {
								if (talendToDBList_tDBInput_1.contains(
										rsmd_tDBInput_1.getColumnTypeName(8).toUpperCase(java.util.Locale.ENGLISH))) {
									row1.VEHICLE_MODEL = FormatterUtils.formatUnwithE(tmpContent_tDBInput_1);
								} else {
									row1.VEHICLE_MODEL = tmpContent_tDBInput_1;
								}
							} else {
								row1.VEHICLE_MODEL = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 9) {
							row1.VEHICLE_YEAR = null;
						} else {

							tmpContent_tDBInput_1 = rs_tDBInput_1.getString(9);
							if (tmpContent_tDBInput_1 != null) {
								if (talendToDBList_tDBInput_1.contains(
										rsmd_tDBInput_1.getColumnTypeName(9).toUpperCase(java.util.Locale.ENGLISH))) {
									row1.VEHICLE_YEAR = FormatterUtils.formatUnwithE(tmpContent_tDBInput_1);
								} else {
									row1.VEHICLE_YEAR = tmpContent_tDBInput_1;
								}
							} else {
								row1.VEHICLE_YEAR = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 10) {
							row1.TRAVEL_DIRECTION = null;
						} else {

							tmpContent_tDBInput_1 = rs_tDBInput_1.getString(10);
							if (tmpContent_tDBInput_1 != null) {
								if (talendToDBList_tDBInput_1.contains(
										rsmd_tDBInput_1.getColumnTypeName(10).toUpperCase(java.util.Locale.ENGLISH))) {
									row1.TRAVEL_DIRECTION = FormatterUtils.formatUnwithE(tmpContent_tDBInput_1);
								} else {
									row1.TRAVEL_DIRECTION = tmpContent_tDBInput_1;
								}
							} else {
								row1.TRAVEL_DIRECTION = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 11) {
							row1.VEHICLE_OCCUPANTS = null;
						} else {

							tmpContent_tDBInput_1 = rs_tDBInput_1.getString(11);
							if (tmpContent_tDBInput_1 != null) {
								if (talendToDBList_tDBInput_1.contains(
										rsmd_tDBInput_1.getColumnTypeName(11).toUpperCase(java.util.Locale.ENGLISH))) {
									row1.VEHICLE_OCCUPANTS = FormatterUtils.formatUnwithE(tmpContent_tDBInput_1);
								} else {
									row1.VEHICLE_OCCUPANTS = tmpContent_tDBInput_1;
								}
							} else {
								row1.VEHICLE_OCCUPANTS = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 12) {
							row1.DRIVER_SEX = null;
						} else {

							tmpContent_tDBInput_1 = rs_tDBInput_1.getString(12);
							if (tmpContent_tDBInput_1 != null) {
								if (talendToDBList_tDBInput_1.contains(
										rsmd_tDBInput_1.getColumnTypeName(12).toUpperCase(java.util.Locale.ENGLISH))) {
									row1.DRIVER_SEX = FormatterUtils.formatUnwithE(tmpContent_tDBInput_1);
								} else {
									row1.DRIVER_SEX = tmpContent_tDBInput_1;
								}
							} else {
								row1.DRIVER_SEX = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 13) {
							row1.DRIVER_LICENSE_STATUS = null;
						} else {

							tmpContent_tDBInput_1 = rs_tDBInput_1.getString(13);
							if (tmpContent_tDBInput_1 != null) {
								if (talendToDBList_tDBInput_1.contains(
										rsmd_tDBInput_1.getColumnTypeName(13).toUpperCase(java.util.Locale.ENGLISH))) {
									row1.DRIVER_LICENSE_STATUS = FormatterUtils.formatUnwithE(tmpContent_tDBInput_1);
								} else {
									row1.DRIVER_LICENSE_STATUS = tmpContent_tDBInput_1;
								}
							} else {
								row1.DRIVER_LICENSE_STATUS = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 14) {
							row1.DRIVER_LICENSE_JURISDICTION = null;
						} else {

							tmpContent_tDBInput_1 = rs_tDBInput_1.getString(14);
							if (tmpContent_tDBInput_1 != null) {
								if (talendToDBList_tDBInput_1.contains(
										rsmd_tDBInput_1.getColumnTypeName(14).toUpperCase(java.util.Locale.ENGLISH))) {
									row1.DRIVER_LICENSE_JURISDICTION = FormatterUtils
											.formatUnwithE(tmpContent_tDBInput_1);
								} else {
									row1.DRIVER_LICENSE_JURISDICTION = tmpContent_tDBInput_1;
								}
							} else {
								row1.DRIVER_LICENSE_JURISDICTION = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 15) {
							row1.PRE_CRASH = null;
						} else {

							tmpContent_tDBInput_1 = rs_tDBInput_1.getString(15);
							if (tmpContent_tDBInput_1 != null) {
								if (talendToDBList_tDBInput_1.contains(
										rsmd_tDBInput_1.getColumnTypeName(15).toUpperCase(java.util.Locale.ENGLISH))) {
									row1.PRE_CRASH = FormatterUtils.formatUnwithE(tmpContent_tDBInput_1);
								} else {
									row1.PRE_CRASH = tmpContent_tDBInput_1;
								}
							} else {
								row1.PRE_CRASH = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 16) {
							row1.POINT_OF_IMPACT = null;
						} else {

							tmpContent_tDBInput_1 = rs_tDBInput_1.getString(16);
							if (tmpContent_tDBInput_1 != null) {
								if (talendToDBList_tDBInput_1.contains(
										rsmd_tDBInput_1.getColumnTypeName(16).toUpperCase(java.util.Locale.ENGLISH))) {
									row1.POINT_OF_IMPACT = FormatterUtils.formatUnwithE(tmpContent_tDBInput_1);
								} else {
									row1.POINT_OF_IMPACT = tmpContent_tDBInput_1;
								}
							} else {
								row1.POINT_OF_IMPACT = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 17) {
							row1.VEHICLE_DAMAGE = null;
						} else {

							tmpContent_tDBInput_1 = rs_tDBInput_1.getString(17);
							if (tmpContent_tDBInput_1 != null) {
								if (talendToDBList_tDBInput_1.contains(
										rsmd_tDBInput_1.getColumnTypeName(17).toUpperCase(java.util.Locale.ENGLISH))) {
									row1.VEHICLE_DAMAGE = FormatterUtils.formatUnwithE(tmpContent_tDBInput_1);
								} else {
									row1.VEHICLE_DAMAGE = tmpContent_tDBInput_1;
								}
							} else {
								row1.VEHICLE_DAMAGE = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 18) {
							row1.VEHICLE_DAMAGE_1 = null;
						} else {

							tmpContent_tDBInput_1 = rs_tDBInput_1.getString(18);
							if (tmpContent_tDBInput_1 != null) {
								if (talendToDBList_tDBInput_1.contains(
										rsmd_tDBInput_1.getColumnTypeName(18).toUpperCase(java.util.Locale.ENGLISH))) {
									row1.VEHICLE_DAMAGE_1 = FormatterUtils.formatUnwithE(tmpContent_tDBInput_1);
								} else {
									row1.VEHICLE_DAMAGE_1 = tmpContent_tDBInput_1;
								}
							} else {
								row1.VEHICLE_DAMAGE_1 = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 19) {
							row1.VEHICLE_DAMAGE_2 = null;
						} else {

							tmpContent_tDBInput_1 = rs_tDBInput_1.getString(19);
							if (tmpContent_tDBInput_1 != null) {
								if (talendToDBList_tDBInput_1.contains(
										rsmd_tDBInput_1.getColumnTypeName(19).toUpperCase(java.util.Locale.ENGLISH))) {
									row1.VEHICLE_DAMAGE_2 = FormatterUtils.formatUnwithE(tmpContent_tDBInput_1);
								} else {
									row1.VEHICLE_DAMAGE_2 = tmpContent_tDBInput_1;
								}
							} else {
								row1.VEHICLE_DAMAGE_2 = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 20) {
							row1.VEHICLE_DAMAGE_3 = null;
						} else {

							tmpContent_tDBInput_1 = rs_tDBInput_1.getString(20);
							if (tmpContent_tDBInput_1 != null) {
								if (talendToDBList_tDBInput_1.contains(
										rsmd_tDBInput_1.getColumnTypeName(20).toUpperCase(java.util.Locale.ENGLISH))) {
									row1.VEHICLE_DAMAGE_3 = FormatterUtils.formatUnwithE(tmpContent_tDBInput_1);
								} else {
									row1.VEHICLE_DAMAGE_3 = tmpContent_tDBInput_1;
								}
							} else {
								row1.VEHICLE_DAMAGE_3 = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 21) {
							row1.PUBLIC_PROPERTY_DAMAGE = null;
						} else {

							tmpContent_tDBInput_1 = rs_tDBInput_1.getString(21);
							if (tmpContent_tDBInput_1 != null) {
								if (talendToDBList_tDBInput_1.contains(
										rsmd_tDBInput_1.getColumnTypeName(21).toUpperCase(java.util.Locale.ENGLISH))) {
									row1.PUBLIC_PROPERTY_DAMAGE = FormatterUtils.formatUnwithE(tmpContent_tDBInput_1);
								} else {
									row1.PUBLIC_PROPERTY_DAMAGE = tmpContent_tDBInput_1;
								}
							} else {
								row1.PUBLIC_PROPERTY_DAMAGE = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 22) {
							row1.PUBLIC_PROPERTY_DAMAGE_TYPE = null;
						} else {

							tmpContent_tDBInput_1 = rs_tDBInput_1.getString(22);
							if (tmpContent_tDBInput_1 != null) {
								if (talendToDBList_tDBInput_1.contains(
										rsmd_tDBInput_1.getColumnTypeName(22).toUpperCase(java.util.Locale.ENGLISH))) {
									row1.PUBLIC_PROPERTY_DAMAGE_TYPE = FormatterUtils
											.formatUnwithE(tmpContent_tDBInput_1);
								} else {
									row1.PUBLIC_PROPERTY_DAMAGE_TYPE = tmpContent_tDBInput_1;
								}
							} else {
								row1.PUBLIC_PROPERTY_DAMAGE_TYPE = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 23) {
							row1.CONTRIBUTING_FACTOR_1 = null;
						} else {

							tmpContent_tDBInput_1 = rs_tDBInput_1.getString(23);
							if (tmpContent_tDBInput_1 != null) {
								if (talendToDBList_tDBInput_1.contains(
										rsmd_tDBInput_1.getColumnTypeName(23).toUpperCase(java.util.Locale.ENGLISH))) {
									row1.CONTRIBUTING_FACTOR_1 = FormatterUtils.formatUnwithE(tmpContent_tDBInput_1);
								} else {
									row1.CONTRIBUTING_FACTOR_1 = tmpContent_tDBInput_1;
								}
							} else {
								row1.CONTRIBUTING_FACTOR_1 = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 24) {
							row1.CONTRIBUTING_FACTOR_2 = null;
						} else {

							tmpContent_tDBInput_1 = rs_tDBInput_1.getString(24);
							if (tmpContent_tDBInput_1 != null) {
								if (talendToDBList_tDBInput_1.contains(
										rsmd_tDBInput_1.getColumnTypeName(24).toUpperCase(java.util.Locale.ENGLISH))) {
									row1.CONTRIBUTING_FACTOR_2 = FormatterUtils.formatUnwithE(tmpContent_tDBInput_1);
								} else {
									row1.CONTRIBUTING_FACTOR_2 = tmpContent_tDBInput_1;
								}
							} else {
								row1.CONTRIBUTING_FACTOR_2 = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 25) {
							row1.UNIQUE_ID = null;
						} else {

							row1.UNIQUE_ID = rs_tDBInput_1.getInt(25);
							if (rs_tDBInput_1.wasNull()) {
								row1.UNIQUE_ID = null;
							}
						}

						log.debug("tDBInput_1 - Retrieving the record " + nb_line_tDBInput_1 + ".");

						/**
						 * [tDBInput_1 begin ] stop
						 */

						/**
						 * [tDBInput_1 main ] start
						 */

						currentComponent = "tDBInput_1";

						tos_count_tDBInput_1++;

						/**
						 * [tDBInput_1 main ] stop
						 */

						/**
						 * [tDBInput_1 process_data_begin ] start
						 */

						currentComponent = "tDBInput_1";

						/**
						 * [tDBInput_1 process_data_begin ] stop
						 */

						/**
						 * [tMap_1 main ] start
						 */

						currentComponent = "tMap_1";

						if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

								, "row1", "tDBInput_1", "__TABLE__", "tMSSqlInput", "tMap_1", "tMap_1", "tMap"

						)) {
							talendJobLogProcess(globalMap);
						}

						if (log.isTraceEnabled()) {
							log.trace("row1 - " + (row1 == null ? "" : row1.toLogString()));
						}

						boolean hasCasePrimitiveKeyWithNull_tMap_1 = false;

						// ###############################
						// # Input tables (lookups)
						boolean rejectedInnerJoin_tMap_1 = false;
						boolean mainRowRejected_tMap_1 = false;

						// ###############################
						{ // start of Var scope

							// ###############################
							// # Vars tables

							Var__tMap_1__Struct Var = Var__tMap_1;// ###############################
							// ###############################
							// # Output tables

							State_Registration_Sk = null;
							Vehicle_type = null;
							Vehicle_Make = null;
							Vehicle_Model = null;
							Travel_Direction = null;
							Driver_License_Status = null;
							Driver_License_Jusridiction = null;
							PreCash = null;
							Point_Of_Impact = null;
							Public_propertyDamage = null;

// # Output table : 'State_Registration_Sk'
							count_State_Registration_Sk_tMap_1++;

							State_Registration_Sk_tmp.STATE_REGISTRATION = row1.STATE_REGISTRATION;
							State_Registration_Sk = State_Registration_Sk_tmp;
							log.debug("tMap_1 - Outputting the record " + count_State_Registration_Sk_tMap_1
									+ " of the output table 'State_Registration_Sk'.");

// # Output table : 'Vehicle_type'
							count_Vehicle_type_tMap_1++;

							Vehicle_type_tmp.VEHICLE_TYPE = row1.VEHICLE_TYPE;
							Vehicle_type = Vehicle_type_tmp;
							log.debug("tMap_1 - Outputting the record " + count_Vehicle_type_tMap_1
									+ " of the output table 'Vehicle_type'.");

// # Output table : 'Vehicle_Make'
							count_Vehicle_Make_tMap_1++;

							Vehicle_Make_tmp.VEHICLE_MAKE = row1.VEHICLE_MAKE;
							Vehicle_Make = Vehicle_Make_tmp;
							log.debug("tMap_1 - Outputting the record " + count_Vehicle_Make_tMap_1
									+ " of the output table 'Vehicle_Make'.");

// # Output table : 'Vehicle_Model'
							count_Vehicle_Model_tMap_1++;

							Vehicle_Model_tmp.VEHICLE_MODEL = row1.VEHICLE_MODEL;
							Vehicle_Model = Vehicle_Model_tmp;
							log.debug("tMap_1 - Outputting the record " + count_Vehicle_Model_tMap_1
									+ " of the output table 'Vehicle_Model'.");

// # Output table : 'Travel_Direction'
							count_Travel_Direction_tMap_1++;

							Travel_Direction_tmp.TRAVEL_DIRECTION = row1.TRAVEL_DIRECTION;
							Travel_Direction = Travel_Direction_tmp;
							log.debug("tMap_1 - Outputting the record " + count_Travel_Direction_tMap_1
									+ " of the output table 'Travel_Direction'.");

// # Output table : 'Driver_License_Status'
							count_Driver_License_Status_tMap_1++;

							Driver_License_Status_tmp.DRIVER_LICENSE_STATUS = row1.DRIVER_LICENSE_STATUS;
							Driver_License_Status = Driver_License_Status_tmp;
							log.debug("tMap_1 - Outputting the record " + count_Driver_License_Status_tMap_1
									+ " of the output table 'Driver_License_Status'.");

// # Output table : 'Driver_License_Jusridiction'
							count_Driver_License_Jusridiction_tMap_1++;

							Driver_License_Jusridiction_tmp.DRIVER_LICENSE_JURISDICTION = row1.DRIVER_LICENSE_JURISDICTION;
							Driver_License_Jusridiction = Driver_License_Jusridiction_tmp;
							log.debug("tMap_1 - Outputting the record " + count_Driver_License_Jusridiction_tMap_1
									+ " of the output table 'Driver_License_Jusridiction'.");

// # Output table : 'PreCash'
							count_PreCash_tMap_1++;

							PreCash_tmp.PRE_CRASH = row1.PRE_CRASH;
							PreCash = PreCash_tmp;
							log.debug("tMap_1 - Outputting the record " + count_PreCash_tMap_1
									+ " of the output table 'PreCash'.");

// # Output table : 'Point_Of_Impact'
							count_Point_Of_Impact_tMap_1++;

							Point_Of_Impact_tmp.POINT_OF_IMPACT = row1.POINT_OF_IMPACT;
							Point_Of_Impact = Point_Of_Impact_tmp;
							log.debug("tMap_1 - Outputting the record " + count_Point_Of_Impact_tMap_1
									+ " of the output table 'Point_Of_Impact'.");

// # Output table : 'Public_propertyDamage'
							count_Public_propertyDamage_tMap_1++;

							Public_propertyDamage_tmp.PUBLIC_PROPERTY_DAMAGE = row1.PUBLIC_PROPERTY_DAMAGE;
							Public_propertyDamage = Public_propertyDamage_tmp;
							log.debug("tMap_1 - Outputting the record " + count_Public_propertyDamage_tMap_1
									+ " of the output table 'Public_propertyDamage'.");

// ###############################

						} // end of Var scope

						rejectedInnerJoin_tMap_1 = false;

						tos_count_tMap_1++;

						/**
						 * [tMap_1 main ] stop
						 */

						/**
						 * [tMap_1 process_data_begin ] start
						 */

						currentComponent = "tMap_1";

						/**
						 * [tMap_1 process_data_begin ] stop
						 */
// Start of branch "State_Registration_Sk"
						if (State_Registration_Sk != null) {

							/**
							 * [tUniqRow_1 main ] start
							 */

							currentComponent = "tUniqRow_1";

							if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

									, "State_Registration_Sk", "tMap_1", "tMap_1", "tMap", "tUniqRow_1", "tUniqRow_1",
									"tUniqRow"

							)) {
								talendJobLogProcess(globalMap);
							}

							if (log.isTraceEnabled()) {
								log.trace("State_Registration_Sk - "
										+ (State_Registration_Sk == null ? "" : State_Registration_Sk.toLogString()));
							}

							row2 = null;
							if (State_Registration_Sk.STATE_REGISTRATION == null) {
								finder_tUniqRow_1.STATE_REGISTRATION = null;
							} else {
								finder_tUniqRow_1.STATE_REGISTRATION = State_Registration_Sk.STATE_REGISTRATION
										.toLowerCase();
							}
							finder_tUniqRow_1.hashCodeDirty = true;
							if (!keystUniqRow_1.contains(finder_tUniqRow_1)) {
								KeyStruct_tUniqRow_1 new_tUniqRow_1 = new KeyStruct_tUniqRow_1();

								if (State_Registration_Sk.STATE_REGISTRATION == null) {
									new_tUniqRow_1.STATE_REGISTRATION = null;
								} else {
									new_tUniqRow_1.STATE_REGISTRATION = State_Registration_Sk.STATE_REGISTRATION
											.toLowerCase();
								}

								keystUniqRow_1.add(new_tUniqRow_1);
								if (row2 == null) {

									log.trace("tUniqRow_1 - Writing the unique record " + (nb_uniques_tUniqRow_1 + 1)
											+ " into row2.");

									row2 = new row2Struct();
								}
								row2.STATE_REGISTRATION = State_Registration_Sk.STATE_REGISTRATION;
								nb_uniques_tUniqRow_1++;
							} else {
								nb_duplicates_tUniqRow_1++;
							}

							tos_count_tUniqRow_1++;

							/**
							 * [tUniqRow_1 main ] stop
							 */

							/**
							 * [tUniqRow_1 process_data_begin ] start
							 */

							currentComponent = "tUniqRow_1";

							/**
							 * [tUniqRow_1 process_data_begin ] stop
							 */
// Start of branch "row2"
							if (row2 != null) {

								/**
								 * [tMap_2 main ] start
								 */

								currentComponent = "tMap_2";

								if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

										, "row2", "tUniqRow_1", "tUniqRow_1", "tUniqRow", "tMap_2", "tMap_2", "tMap"

								)) {
									talendJobLogProcess(globalMap);
								}

								if (log.isTraceEnabled()) {
									log.trace("row2 - " + (row2 == null ? "" : row2.toLogString()));
								}

								boolean hasCasePrimitiveKeyWithNull_tMap_2 = false;

								// ###############################
								// # Input tables (lookups)
								boolean rejectedInnerJoin_tMap_2 = false;
								boolean mainRowRejected_tMap_2 = false;

								// ###############################
								{ // start of Var scope

									// ###############################
									// # Vars tables

									Var__tMap_2__Struct Var = Var__tMap_2;// ###############################
									// ###############################
									// # Output tables

									State_Reg2 = null;

// # Output table : 'State_Reg2'
									count_State_Reg2_tMap_2++;

									State_Reg2_tmp.STATE_REGISTRATION_SK = row2.STATE_REGISTRATION.equals(
											"NoValueProvided") ? new Integer("-99") : Numeric.sequence("s1", 1, 1);
									State_Reg2_tmp.STATE_REGISTRATION = row2.STATE_REGISTRATION;
									State_Reg2_tmp.DI_PID = "MVC_LOAD";
									State_Reg2_tmp.DI_Create_Date = TalendDate.getCurrentDate();
									State_Reg2 = State_Reg2_tmp;
									log.debug("tMap_2 - Outputting the record " + count_State_Reg2_tMap_2
											+ " of the output table 'State_Reg2'.");

// ###############################

								} // end of Var scope

								rejectedInnerJoin_tMap_2 = false;

								tos_count_tMap_2++;

								/**
								 * [tMap_2 main ] stop
								 */

								/**
								 * [tMap_2 process_data_begin ] start
								 */

								currentComponent = "tMap_2";

								/**
								 * [tMap_2 process_data_begin ] stop
								 */
// Start of branch "State_Reg2"
								if (State_Reg2 != null) {

									/**
									 * [tDBOutput_1 main ] start
									 */

									currentComponent = "tDBOutput_1";

									if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

											, "State_Reg2", "tMap_2", "tMap_2", "tMap", "tDBOutput_1", "__TABLE__",
											"tMSSqlOutput"

									)) {
										talendJobLogProcess(globalMap);
									}

									if (log.isTraceEnabled()) {
										log.trace(
												"State_Reg2 - " + (State_Reg2 == null ? "" : State_Reg2.toLogString()));
									}

									whetherReject_tDBOutput_1 = false;
									if (State_Reg2.STATE_REGISTRATION_SK == null) {
										pstmt_tDBOutput_1.setNull(1, java.sql.Types.INTEGER);
									} else {
										pstmt_tDBOutput_1.setInt(1, State_Reg2.STATE_REGISTRATION_SK);
									}

									if (State_Reg2.STATE_REGISTRATION == null) {
										pstmt_tDBOutput_1.setNull(2, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_1.setString(2, State_Reg2.STATE_REGISTRATION);
									}

									if (State_Reg2.DI_PID == null) {
										pstmt_tDBOutput_1.setNull(3, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_1.setString(3, State_Reg2.DI_PID);
									}

									if (State_Reg2.DI_Create_Date != null) {
										pstmt_tDBOutput_1.setTimestamp(4,
												new java.sql.Timestamp(State_Reg2.DI_Create_Date.getTime()));
									} else {
										pstmt_tDBOutput_1.setNull(4, java.sql.Types.TIMESTAMP);
									}

									pstmt_tDBOutput_1.addBatch();
									nb_line_tDBOutput_1++;

									if (log.isDebugEnabled())
										log.debug("tDBOutput_1 - " + ("Adding the record ") + (nb_line_tDBOutput_1)
												+ (" to the ") + ("INSERT") + (" batch."));
									batchSizeCounter_tDBOutput_1++;

									////////// batch execute by batch size///////
									class LimitBytesHelper_tDBOutput_1 {
										public int limitBytePart1(int counter,
												java.sql.PreparedStatement pstmt_tDBOutput_1) throws Exception {
											try {

												if (log.isDebugEnabled())
													log.debug("tDBOutput_1 - " + ("Executing the ") + ("INSERT")
															+ (" batch."));
												for (int countEach_tDBOutput_1 : pstmt_tDBOutput_1.executeBatch()) {
													if (countEach_tDBOutput_1 == -2 || countEach_tDBOutput_1 == -3) {
														break;
													}
													counter += countEach_tDBOutput_1;
												}

												if (log.isDebugEnabled())
													log.debug("tDBOutput_1 - " + ("The ") + ("INSERT")
															+ (" batch execution has succeeded."));
											} catch (java.sql.BatchUpdateException e) {
												globalMap.put("tDBOutput_1_ERROR_MESSAGE", e.getMessage());

												int countSum_tDBOutput_1 = 0;
												for (int countEach_tDBOutput_1 : e.getUpdateCounts()) {
													counter += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
												}

												log.error("tDBOutput_1 - " + (e.getMessage()));
												System.err.println(e.getMessage());

											}
											return counter;
										}

										public int limitBytePart2(int counter,
												java.sql.PreparedStatement pstmt_tDBOutput_1) throws Exception {
											try {

												if (log.isDebugEnabled())
													log.debug("tDBOutput_1 - " + ("Executing the ") + ("INSERT")
															+ (" batch."));
												for (int countEach_tDBOutput_1 : pstmt_tDBOutput_1.executeBatch()) {
													if (countEach_tDBOutput_1 == -2 || countEach_tDBOutput_1 == -3) {
														break;
													}
													counter += countEach_tDBOutput_1;
												}

												if (log.isDebugEnabled())
													log.debug("tDBOutput_1 - " + ("The ") + ("INSERT")
															+ (" batch execution has succeeded."));
											} catch (java.sql.BatchUpdateException e) {
												globalMap.put("tDBOutput_1_ERROR_MESSAGE", e.getMessage());

												for (int countEach_tDBOutput_1 : e.getUpdateCounts()) {
													counter += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
												}

												log.error("tDBOutput_1 - " + (e.getMessage()));
												System.err.println(e.getMessage());

											}
											return counter;
										}
									}
									if ((batchSize_tDBOutput_1 > 0)
											&& (batchSize_tDBOutput_1 <= batchSizeCounter_tDBOutput_1)) {

										insertedCount_tDBOutput_1 = new LimitBytesHelper_tDBOutput_1()
												.limitBytePart1(insertedCount_tDBOutput_1, pstmt_tDBOutput_1);
										rowsToCommitCount_tDBOutput_1 = insertedCount_tDBOutput_1;

										batchSizeCounter_tDBOutput_1 = 0;
									}

									//////////// commit every////////////

									commitCounter_tDBOutput_1++;
									if (commitEvery_tDBOutput_1 <= commitCounter_tDBOutput_1) {
										if ((batchSize_tDBOutput_1 > 0) && (batchSizeCounter_tDBOutput_1 > 0)) {

											insertedCount_tDBOutput_1 = new LimitBytesHelper_tDBOutput_1()
													.limitBytePart1(insertedCount_tDBOutput_1, pstmt_tDBOutput_1);

											batchSizeCounter_tDBOutput_1 = 0;
										}
										if (rowsToCommitCount_tDBOutput_1 != 0) {

											if (log.isDebugEnabled())
												log.debug("tDBOutput_1 - " + ("Connection starting to commit ")
														+ (rowsToCommitCount_tDBOutput_1) + (" record(s)."));
										}
										conn_tDBOutput_1.commit();
										if (rowsToCommitCount_tDBOutput_1 != 0) {

											if (log.isDebugEnabled())
												log.debug("tDBOutput_1 - " + ("Connection commit has succeeded."));
											rowsToCommitCount_tDBOutput_1 = 0;
										}
										commitCounter_tDBOutput_1 = 0;
									}

									tos_count_tDBOutput_1++;

									/**
									 * [tDBOutput_1 main ] stop
									 */

									/**
									 * [tDBOutput_1 process_data_begin ] start
									 */

									currentComponent = "tDBOutput_1";

									/**
									 * [tDBOutput_1 process_data_begin ] stop
									 */

									/**
									 * [tDBOutput_1 process_data_end ] start
									 */

									currentComponent = "tDBOutput_1";

									/**
									 * [tDBOutput_1 process_data_end ] stop
									 */

								} // End of branch "State_Reg2"

								/**
								 * [tMap_2 process_data_end ] start
								 */

								currentComponent = "tMap_2";

								/**
								 * [tMap_2 process_data_end ] stop
								 */

							} // End of branch "row2"

							/**
							 * [tUniqRow_1 process_data_end ] start
							 */

							currentComponent = "tUniqRow_1";

							/**
							 * [tUniqRow_1 process_data_end ] stop
							 */

						} // End of branch "State_Registration_Sk"

// Start of branch "Vehicle_type"
						if (Vehicle_type != null) {

							/**
							 * [tUniqRow_2 main ] start
							 */

							currentComponent = "tUniqRow_2";

							if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

									, "Vehicle_type", "tMap_1", "tMap_1", "tMap", "tUniqRow_2", "tUniqRow_2", "tUniqRow"

							)) {
								talendJobLogProcess(globalMap);
							}

							if (log.isTraceEnabled()) {
								log.trace("Vehicle_type - " + (Vehicle_type == null ? "" : Vehicle_type.toLogString()));
							}

							row3 = null;
							if (Vehicle_type.VEHICLE_TYPE == null) {
								finder_tUniqRow_2.VEHICLE_TYPE = null;
							} else {
								finder_tUniqRow_2.VEHICLE_TYPE = Vehicle_type.VEHICLE_TYPE.toLowerCase();
							}
							finder_tUniqRow_2.hashCodeDirty = true;
							if (!keystUniqRow_2.contains(finder_tUniqRow_2)) {
								KeyStruct_tUniqRow_2 new_tUniqRow_2 = new KeyStruct_tUniqRow_2();

								if (Vehicle_type.VEHICLE_TYPE == null) {
									new_tUniqRow_2.VEHICLE_TYPE = null;
								} else {
									new_tUniqRow_2.VEHICLE_TYPE = Vehicle_type.VEHICLE_TYPE.toLowerCase();
								}

								keystUniqRow_2.add(new_tUniqRow_2);
								if (row3 == null) {

									log.trace("tUniqRow_2 - Writing the unique record " + (nb_uniques_tUniqRow_2 + 1)
											+ " into row3.");

									row3 = new row3Struct();
								}
								row3.VEHICLE_TYPE = Vehicle_type.VEHICLE_TYPE;
								nb_uniques_tUniqRow_2++;
							} else {
								nb_duplicates_tUniqRow_2++;
							}

							tos_count_tUniqRow_2++;

							/**
							 * [tUniqRow_2 main ] stop
							 */

							/**
							 * [tUniqRow_2 process_data_begin ] start
							 */

							currentComponent = "tUniqRow_2";

							/**
							 * [tUniqRow_2 process_data_begin ] stop
							 */
// Start of branch "row3"
							if (row3 != null) {

								/**
								 * [tMap_3 main ] start
								 */

								currentComponent = "tMap_3";

								if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

										, "row3", "tUniqRow_2", "tUniqRow_2", "tUniqRow", "tMap_3", "tMap_3", "tMap"

								)) {
									talendJobLogProcess(globalMap);
								}

								if (log.isTraceEnabled()) {
									log.trace("row3 - " + (row3 == null ? "" : row3.toLogString()));
								}

								boolean hasCasePrimitiveKeyWithNull_tMap_3 = false;

								// ###############################
								// # Input tables (lookups)
								boolean rejectedInnerJoin_tMap_3 = false;
								boolean mainRowRejected_tMap_3 = false;

								// ###############################
								{ // start of Var scope

									// ###############################
									// # Vars tables

									Var__tMap_3__Struct Var = Var__tMap_3;// ###############################
									// ###############################
									// # Output tables

									Vehicle_Type2 = null;

// # Output table : 'Vehicle_Type2'
									count_Vehicle_Type2_tMap_3++;

									Vehicle_Type2_tmp.VEHICLE_TYPE_SK = null;
									Vehicle_Type2_tmp.VEHICLE_TYPE = row3.VEHICLE_TYPE;
									Vehicle_Type2_tmp.DI_PID = "MVC_LOAD";
									Vehicle_Type2_tmp.DI_Create_Date = TalendDate.getCurrentDate();
									Vehicle_Type2 = Vehicle_Type2_tmp;
									log.debug("tMap_3 - Outputting the record " + count_Vehicle_Type2_tMap_3
											+ " of the output table 'Vehicle_Type2'.");

// ###############################

								} // end of Var scope

								rejectedInnerJoin_tMap_3 = false;

								tos_count_tMap_3++;

								/**
								 * [tMap_3 main ] stop
								 */

								/**
								 * [tMap_3 process_data_begin ] start
								 */

								currentComponent = "tMap_3";

								/**
								 * [tMap_3 process_data_begin ] stop
								 */
// Start of branch "Vehicle_Type2"
								if (Vehicle_Type2 != null) {

									/**
									 * [tDBOutput_2 main ] start
									 */

									currentComponent = "tDBOutput_2";

									if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

											, "Vehicle_Type2", "tMap_3", "tMap_3", "tMap", "tDBOutput_2", "__TABLE__",
											"tMSSqlOutput"

									)) {
										talendJobLogProcess(globalMap);
									}

									if (log.isTraceEnabled()) {
										log.trace("Vehicle_Type2 - "
												+ (Vehicle_Type2 == null ? "" : Vehicle_Type2.toLogString()));
									}

									whetherReject_tDBOutput_2 = false;
									if (Vehicle_Type2.VEHICLE_TYPE_SK == null) {
										pstmt_tDBOutput_2.setNull(1, java.sql.Types.INTEGER);
									} else {
										pstmt_tDBOutput_2.setInt(1, Vehicle_Type2.VEHICLE_TYPE_SK);
									}

									if (Vehicle_Type2.VEHICLE_TYPE == null) {
										pstmt_tDBOutput_2.setNull(2, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_2.setString(2, Vehicle_Type2.VEHICLE_TYPE);
									}

									if (Vehicle_Type2.DI_PID == null) {
										pstmt_tDBOutput_2.setNull(3, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_2.setString(3, Vehicle_Type2.DI_PID);
									}

									if (Vehicle_Type2.DI_Create_Date != null) {
										pstmt_tDBOutput_2.setTimestamp(4,
												new java.sql.Timestamp(Vehicle_Type2.DI_Create_Date.getTime()));
									} else {
										pstmt_tDBOutput_2.setNull(4, java.sql.Types.TIMESTAMP);
									}

									pstmt_tDBOutput_2.addBatch();
									nb_line_tDBOutput_2++;

									if (log.isDebugEnabled())
										log.debug("tDBOutput_2 - " + ("Adding the record ") + (nb_line_tDBOutput_2)
												+ (" to the ") + ("INSERT") + (" batch."));
									batchSizeCounter_tDBOutput_2++;

									////////// batch execute by batch size///////
									class LimitBytesHelper_tDBOutput_2 {
										public int limitBytePart1(int counter,
												java.sql.PreparedStatement pstmt_tDBOutput_2) throws Exception {
											try {

												if (log.isDebugEnabled())
													log.debug("tDBOutput_2 - " + ("Executing the ") + ("INSERT")
															+ (" batch."));
												for (int countEach_tDBOutput_2 : pstmt_tDBOutput_2.executeBatch()) {
													if (countEach_tDBOutput_2 == -2 || countEach_tDBOutput_2 == -3) {
														break;
													}
													counter += countEach_tDBOutput_2;
												}

												if (log.isDebugEnabled())
													log.debug("tDBOutput_2 - " + ("The ") + ("INSERT")
															+ (" batch execution has succeeded."));
											} catch (java.sql.BatchUpdateException e) {
												globalMap.put("tDBOutput_2_ERROR_MESSAGE", e.getMessage());

												int countSum_tDBOutput_2 = 0;
												for (int countEach_tDBOutput_2 : e.getUpdateCounts()) {
													counter += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
												}

												log.error("tDBOutput_2 - " + (e.getMessage()));
												System.err.println(e.getMessage());

											}
											return counter;
										}

										public int limitBytePart2(int counter,
												java.sql.PreparedStatement pstmt_tDBOutput_2) throws Exception {
											try {

												if (log.isDebugEnabled())
													log.debug("tDBOutput_2 - " + ("Executing the ") + ("INSERT")
															+ (" batch."));
												for (int countEach_tDBOutput_2 : pstmt_tDBOutput_2.executeBatch()) {
													if (countEach_tDBOutput_2 == -2 || countEach_tDBOutput_2 == -3) {
														break;
													}
													counter += countEach_tDBOutput_2;
												}

												if (log.isDebugEnabled())
													log.debug("tDBOutput_2 - " + ("The ") + ("INSERT")
															+ (" batch execution has succeeded."));
											} catch (java.sql.BatchUpdateException e) {
												globalMap.put("tDBOutput_2_ERROR_MESSAGE", e.getMessage());

												for (int countEach_tDBOutput_2 : e.getUpdateCounts()) {
													counter += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
												}

												log.error("tDBOutput_2 - " + (e.getMessage()));
												System.err.println(e.getMessage());

											}
											return counter;
										}
									}
									if ((batchSize_tDBOutput_2 > 0)
											&& (batchSize_tDBOutput_2 <= batchSizeCounter_tDBOutput_2)) {

										insertedCount_tDBOutput_2 = new LimitBytesHelper_tDBOutput_2()
												.limitBytePart1(insertedCount_tDBOutput_2, pstmt_tDBOutput_2);
										rowsToCommitCount_tDBOutput_2 = insertedCount_tDBOutput_2;

										batchSizeCounter_tDBOutput_2 = 0;
									}

									//////////// commit every////////////

									commitCounter_tDBOutput_2++;
									if (commitEvery_tDBOutput_2 <= commitCounter_tDBOutput_2) {
										if ((batchSize_tDBOutput_2 > 0) && (batchSizeCounter_tDBOutput_2 > 0)) {

											insertedCount_tDBOutput_2 = new LimitBytesHelper_tDBOutput_2()
													.limitBytePart1(insertedCount_tDBOutput_2, pstmt_tDBOutput_2);

											batchSizeCounter_tDBOutput_2 = 0;
										}
										if (rowsToCommitCount_tDBOutput_2 != 0) {

											if (log.isDebugEnabled())
												log.debug("tDBOutput_2 - " + ("Connection starting to commit ")
														+ (rowsToCommitCount_tDBOutput_2) + (" record(s)."));
										}
										conn_tDBOutput_2.commit();
										if (rowsToCommitCount_tDBOutput_2 != 0) {

											if (log.isDebugEnabled())
												log.debug("tDBOutput_2 - " + ("Connection commit has succeeded."));
											rowsToCommitCount_tDBOutput_2 = 0;
										}
										commitCounter_tDBOutput_2 = 0;
									}

									tos_count_tDBOutput_2++;

									/**
									 * [tDBOutput_2 main ] stop
									 */

									/**
									 * [tDBOutput_2 process_data_begin ] start
									 */

									currentComponent = "tDBOutput_2";

									/**
									 * [tDBOutput_2 process_data_begin ] stop
									 */

									/**
									 * [tDBOutput_2 process_data_end ] start
									 */

									currentComponent = "tDBOutput_2";

									/**
									 * [tDBOutput_2 process_data_end ] stop
									 */

								} // End of branch "Vehicle_Type2"

								/**
								 * [tMap_3 process_data_end ] start
								 */

								currentComponent = "tMap_3";

								/**
								 * [tMap_3 process_data_end ] stop
								 */

							} // End of branch "row3"

							/**
							 * [tUniqRow_2 process_data_end ] start
							 */

							currentComponent = "tUniqRow_2";

							/**
							 * [tUniqRow_2 process_data_end ] stop
							 */

						} // End of branch "Vehicle_type"

// Start of branch "Vehicle_Make"
						if (Vehicle_Make != null) {

							/**
							 * [tUniqRow_3 main ] start
							 */

							currentComponent = "tUniqRow_3";

							if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

									, "Vehicle_Make", "tMap_1", "tMap_1", "tMap", "tUniqRow_3", "tUniqRow_3", "tUniqRow"

							)) {
								talendJobLogProcess(globalMap);
							}

							if (log.isTraceEnabled()) {
								log.trace("Vehicle_Make - " + (Vehicle_Make == null ? "" : Vehicle_Make.toLogString()));
							}

							row4 = null;
							if (Vehicle_Make.VEHICLE_MAKE == null) {
								finder_tUniqRow_3.VEHICLE_MAKE = null;
							} else {
								finder_tUniqRow_3.VEHICLE_MAKE = Vehicle_Make.VEHICLE_MAKE.toLowerCase();
							}
							finder_tUniqRow_3.hashCodeDirty = true;
							if (!keystUniqRow_3.contains(finder_tUniqRow_3)) {
								KeyStruct_tUniqRow_3 new_tUniqRow_3 = new KeyStruct_tUniqRow_3();

								if (Vehicle_Make.VEHICLE_MAKE == null) {
									new_tUniqRow_3.VEHICLE_MAKE = null;
								} else {
									new_tUniqRow_3.VEHICLE_MAKE = Vehicle_Make.VEHICLE_MAKE.toLowerCase();
								}

								keystUniqRow_3.add(new_tUniqRow_3);
								if (row4 == null) {

									log.trace("tUniqRow_3 - Writing the unique record " + (nb_uniques_tUniqRow_3 + 1)
											+ " into row4.");

									row4 = new row4Struct();
								}
								row4.VEHICLE_MAKE = Vehicle_Make.VEHICLE_MAKE;
								nb_uniques_tUniqRow_3++;
							} else {
								nb_duplicates_tUniqRow_3++;
							}

							tos_count_tUniqRow_3++;

							/**
							 * [tUniqRow_3 main ] stop
							 */

							/**
							 * [tUniqRow_3 process_data_begin ] start
							 */

							currentComponent = "tUniqRow_3";

							/**
							 * [tUniqRow_3 process_data_begin ] stop
							 */
// Start of branch "row4"
							if (row4 != null) {

								/**
								 * [tMap_4 main ] start
								 */

								currentComponent = "tMap_4";

								if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

										, "row4", "tUniqRow_3", "tUniqRow_3", "tUniqRow", "tMap_4", "tMap_4", "tMap"

								)) {
									talendJobLogProcess(globalMap);
								}

								if (log.isTraceEnabled()) {
									log.trace("row4 - " + (row4 == null ? "" : row4.toLogString()));
								}

								boolean hasCasePrimitiveKeyWithNull_tMap_4 = false;

								// ###############################
								// # Input tables (lookups)
								boolean rejectedInnerJoin_tMap_4 = false;
								boolean mainRowRejected_tMap_4 = false;

								// ###############################
								{ // start of Var scope

									// ###############################
									// # Vars tables

									Var__tMap_4__Struct Var = Var__tMap_4;// ###############################
									// ###############################
									// # Output tables

									Vehicle_Make2 = null;

// # Output table : 'Vehicle_Make2'
									count_Vehicle_Make2_tMap_4++;

									Vehicle_Make2_tmp.VEHICLE_MAKE_SK = 0;
									Vehicle_Make2_tmp.VEHICLE_MAKE = row4.VEHICLE_MAKE;
									Vehicle_Make2_tmp.DI_PID = "MVC_LOAD";
									Vehicle_Make2_tmp.DI_Create_Date = TalendDate.getCurrentDate();
									Vehicle_Make2 = Vehicle_Make2_tmp;
									log.debug("tMap_4 - Outputting the record " + count_Vehicle_Make2_tMap_4
											+ " of the output table 'Vehicle_Make2'.");

// ###############################

								} // end of Var scope

								rejectedInnerJoin_tMap_4 = false;

								tos_count_tMap_4++;

								/**
								 * [tMap_4 main ] stop
								 */

								/**
								 * [tMap_4 process_data_begin ] start
								 */

								currentComponent = "tMap_4";

								/**
								 * [tMap_4 process_data_begin ] stop
								 */
// Start of branch "Vehicle_Make2"
								if (Vehicle_Make2 != null) {

									/**
									 * [tDBOutput_3 main ] start
									 */

									currentComponent = "tDBOutput_3";

									if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

											, "Vehicle_Make2", "tMap_4", "tMap_4", "tMap", "tDBOutput_3", "__TABLE__",
											"tMSSqlOutput"

									)) {
										talendJobLogProcess(globalMap);
									}

									if (log.isTraceEnabled()) {
										log.trace("Vehicle_Make2 - "
												+ (Vehicle_Make2 == null ? "" : Vehicle_Make2.toLogString()));
									}

									whetherReject_tDBOutput_3 = false;
									pstmt_tDBOutput_3.setInt(1, Vehicle_Make2.VEHICLE_MAKE_SK);

									if (Vehicle_Make2.VEHICLE_MAKE == null) {
										pstmt_tDBOutput_3.setNull(2, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_3.setString(2, Vehicle_Make2.VEHICLE_MAKE);
									}

									if (Vehicle_Make2.DI_PID == null) {
										pstmt_tDBOutput_3.setNull(3, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_3.setString(3, Vehicle_Make2.DI_PID);
									}

									if (Vehicle_Make2.DI_Create_Date != null) {
										pstmt_tDBOutput_3.setTimestamp(4,
												new java.sql.Timestamp(Vehicle_Make2.DI_Create_Date.getTime()));
									} else {
										pstmt_tDBOutput_3.setNull(4, java.sql.Types.TIMESTAMP);
									}

									pstmt_tDBOutput_3.addBatch();
									nb_line_tDBOutput_3++;

									if (log.isDebugEnabled())
										log.debug("tDBOutput_3 - " + ("Adding the record ") + (nb_line_tDBOutput_3)
												+ (" to the ") + ("INSERT") + (" batch."));
									batchSizeCounter_tDBOutput_3++;

									////////// batch execute by batch size///////
									class LimitBytesHelper_tDBOutput_3 {
										public int limitBytePart1(int counter,
												java.sql.PreparedStatement pstmt_tDBOutput_3) throws Exception {
											try {

												if (log.isDebugEnabled())
													log.debug("tDBOutput_3 - " + ("Executing the ") + ("INSERT")
															+ (" batch."));
												for (int countEach_tDBOutput_3 : pstmt_tDBOutput_3.executeBatch()) {
													if (countEach_tDBOutput_3 == -2 || countEach_tDBOutput_3 == -3) {
														break;
													}
													counter += countEach_tDBOutput_3;
												}

												if (log.isDebugEnabled())
													log.debug("tDBOutput_3 - " + ("The ") + ("INSERT")
															+ (" batch execution has succeeded."));
											} catch (java.sql.BatchUpdateException e) {
												globalMap.put("tDBOutput_3_ERROR_MESSAGE", e.getMessage());

												int countSum_tDBOutput_3 = 0;
												for (int countEach_tDBOutput_3 : e.getUpdateCounts()) {
													counter += (countEach_tDBOutput_3 < 0 ? 0 : countEach_tDBOutput_3);
												}

												log.error("tDBOutput_3 - " + (e.getMessage()));
												System.err.println(e.getMessage());

											}
											return counter;
										}

										public int limitBytePart2(int counter,
												java.sql.PreparedStatement pstmt_tDBOutput_3) throws Exception {
											try {

												if (log.isDebugEnabled())
													log.debug("tDBOutput_3 - " + ("Executing the ") + ("INSERT")
															+ (" batch."));
												for (int countEach_tDBOutput_3 : pstmt_tDBOutput_3.executeBatch()) {
													if (countEach_tDBOutput_3 == -2 || countEach_tDBOutput_3 == -3) {
														break;
													}
													counter += countEach_tDBOutput_3;
												}

												if (log.isDebugEnabled())
													log.debug("tDBOutput_3 - " + ("The ") + ("INSERT")
															+ (" batch execution has succeeded."));
											} catch (java.sql.BatchUpdateException e) {
												globalMap.put("tDBOutput_3_ERROR_MESSAGE", e.getMessage());

												for (int countEach_tDBOutput_3 : e.getUpdateCounts()) {
													counter += (countEach_tDBOutput_3 < 0 ? 0 : countEach_tDBOutput_3);
												}

												log.error("tDBOutput_3 - " + (e.getMessage()));
												System.err.println(e.getMessage());

											}
											return counter;
										}
									}
									if ((batchSize_tDBOutput_3 > 0)
											&& (batchSize_tDBOutput_3 <= batchSizeCounter_tDBOutput_3)) {

										insertedCount_tDBOutput_3 = new LimitBytesHelper_tDBOutput_3()
												.limitBytePart1(insertedCount_tDBOutput_3, pstmt_tDBOutput_3);
										rowsToCommitCount_tDBOutput_3 = insertedCount_tDBOutput_3;

										batchSizeCounter_tDBOutput_3 = 0;
									}

									//////////// commit every////////////

									commitCounter_tDBOutput_3++;
									if (commitEvery_tDBOutput_3 <= commitCounter_tDBOutput_3) {
										if ((batchSize_tDBOutput_3 > 0) && (batchSizeCounter_tDBOutput_3 > 0)) {

											insertedCount_tDBOutput_3 = new LimitBytesHelper_tDBOutput_3()
													.limitBytePart1(insertedCount_tDBOutput_3, pstmt_tDBOutput_3);

											batchSizeCounter_tDBOutput_3 = 0;
										}
										if (rowsToCommitCount_tDBOutput_3 != 0) {

											if (log.isDebugEnabled())
												log.debug("tDBOutput_3 - " + ("Connection starting to commit ")
														+ (rowsToCommitCount_tDBOutput_3) + (" record(s)."));
										}
										conn_tDBOutput_3.commit();
										if (rowsToCommitCount_tDBOutput_3 != 0) {

											if (log.isDebugEnabled())
												log.debug("tDBOutput_3 - " + ("Connection commit has succeeded."));
											rowsToCommitCount_tDBOutput_3 = 0;
										}
										commitCounter_tDBOutput_3 = 0;
									}

									tos_count_tDBOutput_3++;

									/**
									 * [tDBOutput_3 main ] stop
									 */

									/**
									 * [tDBOutput_3 process_data_begin ] start
									 */

									currentComponent = "tDBOutput_3";

									/**
									 * [tDBOutput_3 process_data_begin ] stop
									 */

									/**
									 * [tDBOutput_3 process_data_end ] start
									 */

									currentComponent = "tDBOutput_3";

									/**
									 * [tDBOutput_3 process_data_end ] stop
									 */

								} // End of branch "Vehicle_Make2"

								/**
								 * [tMap_4 process_data_end ] start
								 */

								currentComponent = "tMap_4";

								/**
								 * [tMap_4 process_data_end ] stop
								 */

							} // End of branch "row4"

							/**
							 * [tUniqRow_3 process_data_end ] start
							 */

							currentComponent = "tUniqRow_3";

							/**
							 * [tUniqRow_3 process_data_end ] stop
							 */

						} // End of branch "Vehicle_Make"

// Start of branch "Vehicle_Model"
						if (Vehicle_Model != null) {

							/**
							 * [tUniqRow_4 main ] start
							 */

							currentComponent = "tUniqRow_4";

							if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

									, "Vehicle_Model", "tMap_1", "tMap_1", "tMap", "tUniqRow_4", "tUniqRow_4",
									"tUniqRow"

							)) {
								talendJobLogProcess(globalMap);
							}

							if (log.isTraceEnabled()) {
								log.trace("Vehicle_Model - "
										+ (Vehicle_Model == null ? "" : Vehicle_Model.toLogString()));
							}

							row5.VEHICLE_MODEL = Vehicle_Model.VEHICLE_MODEL;

							tos_count_tUniqRow_4++;

							/**
							 * [tUniqRow_4 main ] stop
							 */

							/**
							 * [tUniqRow_4 process_data_begin ] start
							 */

							currentComponent = "tUniqRow_4";

							/**
							 * [tUniqRow_4 process_data_begin ] stop
							 */
// Start of branch "row5"
							if (row5 != null) {

								/**
								 * [tMap_5 main ] start
								 */

								currentComponent = "tMap_5";

								if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

										, "row5", "tUniqRow_4", "tUniqRow_4", "tUniqRow", "tMap_5", "tMap_5", "tMap"

								)) {
									talendJobLogProcess(globalMap);
								}

								if (log.isTraceEnabled()) {
									log.trace("row5 - " + (row5 == null ? "" : row5.toLogString()));
								}

								boolean hasCasePrimitiveKeyWithNull_tMap_5 = false;

								// ###############################
								// # Input tables (lookups)
								boolean rejectedInnerJoin_tMap_5 = false;
								boolean mainRowRejected_tMap_5 = false;

								// ###############################
								{ // start of Var scope

									// ###############################
									// # Vars tables

									Var__tMap_5__Struct Var = Var__tMap_5;// ###############################
									// ###############################
									// # Output tables

									Vehicle_Model1 = null;

// # Output table : 'Vehicle_Model1'
									count_Vehicle_Model1_tMap_5++;

									Vehicle_Model1_tmp.VEHICLE_MODEL_SK = 0;
									Vehicle_Model1_tmp.VEHICLE_MODEL = row5.VEHICLE_MODEL;
									Vehicle_Model1_tmp.DI_PID = "MVC_LOAD";
									Vehicle_Model1_tmp.DI_Create_Date = TalendDate.getCurrentDate();
									Vehicle_Model1 = Vehicle_Model1_tmp;
									log.debug("tMap_5 - Outputting the record " + count_Vehicle_Model1_tMap_5
											+ " of the output table 'Vehicle_Model1'.");

// ###############################

								} // end of Var scope

								rejectedInnerJoin_tMap_5 = false;

								tos_count_tMap_5++;

								/**
								 * [tMap_5 main ] stop
								 */

								/**
								 * [tMap_5 process_data_begin ] start
								 */

								currentComponent = "tMap_5";

								/**
								 * [tMap_5 process_data_begin ] stop
								 */
// Start of branch "Vehicle_Model1"
								if (Vehicle_Model1 != null) {

									/**
									 * [tDBOutput_4 main ] start
									 */

									currentComponent = "tDBOutput_4";

									if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

											, "Vehicle_Model1", "tMap_5", "tMap_5", "tMap", "tDBOutput_4", "__TABLE__",
											"tMSSqlOutput"

									)) {
										talendJobLogProcess(globalMap);
									}

									if (log.isTraceEnabled()) {
										log.trace("Vehicle_Model1 - "
												+ (Vehicle_Model1 == null ? "" : Vehicle_Model1.toLogString()));
									}

									whetherReject_tDBOutput_4 = false;
									pstmt_tDBOutput_4.setInt(1, Vehicle_Model1.VEHICLE_MODEL_SK);

									if (Vehicle_Model1.VEHICLE_MODEL == null) {
										pstmt_tDBOutput_4.setNull(2, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_4.setString(2, Vehicle_Model1.VEHICLE_MODEL);
									}

									if (Vehicle_Model1.DI_PID == null) {
										pstmt_tDBOutput_4.setNull(3, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_4.setString(3, Vehicle_Model1.DI_PID);
									}

									if (Vehicle_Model1.DI_Create_Date != null) {
										pstmt_tDBOutput_4.setTimestamp(4,
												new java.sql.Timestamp(Vehicle_Model1.DI_Create_Date.getTime()));
									} else {
										pstmt_tDBOutput_4.setNull(4, java.sql.Types.TIMESTAMP);
									}

									pstmt_tDBOutput_4.addBatch();
									nb_line_tDBOutput_4++;

									if (log.isDebugEnabled())
										log.debug("tDBOutput_4 - " + ("Adding the record ") + (nb_line_tDBOutput_4)
												+ (" to the ") + ("INSERT") + (" batch."));
									batchSizeCounter_tDBOutput_4++;

									////////// batch execute by batch size///////
									class LimitBytesHelper_tDBOutput_4 {
										public int limitBytePart1(int counter,
												java.sql.PreparedStatement pstmt_tDBOutput_4) throws Exception {
											try {

												if (log.isDebugEnabled())
													log.debug("tDBOutput_4 - " + ("Executing the ") + ("INSERT")
															+ (" batch."));
												for (int countEach_tDBOutput_4 : pstmt_tDBOutput_4.executeBatch()) {
													if (countEach_tDBOutput_4 == -2 || countEach_tDBOutput_4 == -3) {
														break;
													}
													counter += countEach_tDBOutput_4;
												}

												if (log.isDebugEnabled())
													log.debug("tDBOutput_4 - " + ("The ") + ("INSERT")
															+ (" batch execution has succeeded."));
											} catch (java.sql.BatchUpdateException e) {
												globalMap.put("tDBOutput_4_ERROR_MESSAGE", e.getMessage());

												int countSum_tDBOutput_4 = 0;
												for (int countEach_tDBOutput_4 : e.getUpdateCounts()) {
													counter += (countEach_tDBOutput_4 < 0 ? 0 : countEach_tDBOutput_4);
												}

												log.error("tDBOutput_4 - " + (e.getMessage()));
												System.err.println(e.getMessage());

											}
											return counter;
										}

										public int limitBytePart2(int counter,
												java.sql.PreparedStatement pstmt_tDBOutput_4) throws Exception {
											try {

												if (log.isDebugEnabled())
													log.debug("tDBOutput_4 - " + ("Executing the ") + ("INSERT")
															+ (" batch."));
												for (int countEach_tDBOutput_4 : pstmt_tDBOutput_4.executeBatch()) {
													if (countEach_tDBOutput_4 == -2 || countEach_tDBOutput_4 == -3) {
														break;
													}
													counter += countEach_tDBOutput_4;
												}

												if (log.isDebugEnabled())
													log.debug("tDBOutput_4 - " + ("The ") + ("INSERT")
															+ (" batch execution has succeeded."));
											} catch (java.sql.BatchUpdateException e) {
												globalMap.put("tDBOutput_4_ERROR_MESSAGE", e.getMessage());

												for (int countEach_tDBOutput_4 : e.getUpdateCounts()) {
													counter += (countEach_tDBOutput_4 < 0 ? 0 : countEach_tDBOutput_4);
												}

												log.error("tDBOutput_4 - " + (e.getMessage()));
												System.err.println(e.getMessage());

											}
											return counter;
										}
									}
									if ((batchSize_tDBOutput_4 > 0)
											&& (batchSize_tDBOutput_4 <= batchSizeCounter_tDBOutput_4)) {

										insertedCount_tDBOutput_4 = new LimitBytesHelper_tDBOutput_4()
												.limitBytePart1(insertedCount_tDBOutput_4, pstmt_tDBOutput_4);
										rowsToCommitCount_tDBOutput_4 = insertedCount_tDBOutput_4;

										batchSizeCounter_tDBOutput_4 = 0;
									}

									//////////// commit every////////////

									commitCounter_tDBOutput_4++;
									if (commitEvery_tDBOutput_4 <= commitCounter_tDBOutput_4) {
										if ((batchSize_tDBOutput_4 > 0) && (batchSizeCounter_tDBOutput_4 > 0)) {

											insertedCount_tDBOutput_4 = new LimitBytesHelper_tDBOutput_4()
													.limitBytePart1(insertedCount_tDBOutput_4, pstmt_tDBOutput_4);

											batchSizeCounter_tDBOutput_4 = 0;
										}
										if (rowsToCommitCount_tDBOutput_4 != 0) {

											if (log.isDebugEnabled())
												log.debug("tDBOutput_4 - " + ("Connection starting to commit ")
														+ (rowsToCommitCount_tDBOutput_4) + (" record(s)."));
										}
										conn_tDBOutput_4.commit();
										if (rowsToCommitCount_tDBOutput_4 != 0) {

											if (log.isDebugEnabled())
												log.debug("tDBOutput_4 - " + ("Connection commit has succeeded."));
											rowsToCommitCount_tDBOutput_4 = 0;
										}
										commitCounter_tDBOutput_4 = 0;
									}

									tos_count_tDBOutput_4++;

									/**
									 * [tDBOutput_4 main ] stop
									 */

									/**
									 * [tDBOutput_4 process_data_begin ] start
									 */

									currentComponent = "tDBOutput_4";

									/**
									 * [tDBOutput_4 process_data_begin ] stop
									 */

									/**
									 * [tDBOutput_4 process_data_end ] start
									 */

									currentComponent = "tDBOutput_4";

									/**
									 * [tDBOutput_4 process_data_end ] stop
									 */

								} // End of branch "Vehicle_Model1"

								/**
								 * [tMap_5 process_data_end ] start
								 */

								currentComponent = "tMap_5";

								/**
								 * [tMap_5 process_data_end ] stop
								 */

							} // End of branch "row5"

							/**
							 * [tUniqRow_4 process_data_end ] start
							 */

							currentComponent = "tUniqRow_4";

							/**
							 * [tUniqRow_4 process_data_end ] stop
							 */

						} // End of branch "Vehicle_Model"

// Start of branch "Travel_Direction"
						if (Travel_Direction != null) {

							/**
							 * [tUniqRow_5 main ] start
							 */

							currentComponent = "tUniqRow_5";

							if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

									, "Travel_Direction", "tMap_1", "tMap_1", "tMap", "tUniqRow_5", "tUniqRow_5",
									"tUniqRow"

							)) {
								talendJobLogProcess(globalMap);
							}

							if (log.isTraceEnabled()) {
								log.trace("Travel_Direction - "
										+ (Travel_Direction == null ? "" : Travel_Direction.toLogString()));
							}

							row6.TRAVEL_DIRECTION = Travel_Direction.TRAVEL_DIRECTION;

							tos_count_tUniqRow_5++;

							/**
							 * [tUniqRow_5 main ] stop
							 */

							/**
							 * [tUniqRow_5 process_data_begin ] start
							 */

							currentComponent = "tUniqRow_5";

							/**
							 * [tUniqRow_5 process_data_begin ] stop
							 */
// Start of branch "row6"
							if (row6 != null) {

								/**
								 * [tMap_6 main ] start
								 */

								currentComponent = "tMap_6";

								if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

										, "row6", "tUniqRow_5", "tUniqRow_5", "tUniqRow", "tMap_6", "tMap_6", "tMap"

								)) {
									talendJobLogProcess(globalMap);
								}

								if (log.isTraceEnabled()) {
									log.trace("row6 - " + (row6 == null ? "" : row6.toLogString()));
								}

								boolean hasCasePrimitiveKeyWithNull_tMap_6 = false;

								// ###############################
								// # Input tables (lookups)
								boolean rejectedInnerJoin_tMap_6 = false;
								boolean mainRowRejected_tMap_6 = false;

								// ###############################
								{ // start of Var scope

									// ###############################
									// # Vars tables

									Var__tMap_6__Struct Var = Var__tMap_6;// ###############################
									// ###############################
									// # Output tables

									Travel_Direction_Loadd = null;

// # Output table : 'Travel_Direction_Loadd'
									count_Travel_Direction_Loadd_tMap_6++;

									Travel_Direction_Loadd_tmp.TRAVEL_DIRECTION_SK = 0;
									Travel_Direction_Loadd_tmp.TRAVEL_DIRECTION = null;
									Travel_Direction_Loadd_tmp.DI_PID = "MVC_LOAD";
									Travel_Direction_Loadd_tmp.DI_Create_Date = TalendDate.getCurrentDate();
									Travel_Direction_Loadd = Travel_Direction_Loadd_tmp;
									log.debug("tMap_6 - Outputting the record " + count_Travel_Direction_Loadd_tMap_6
											+ " of the output table 'Travel_Direction_Loadd'.");

// ###############################

								} // end of Var scope

								rejectedInnerJoin_tMap_6 = false;

								tos_count_tMap_6++;

								/**
								 * [tMap_6 main ] stop
								 */

								/**
								 * [tMap_6 process_data_begin ] start
								 */

								currentComponent = "tMap_6";

								/**
								 * [tMap_6 process_data_begin ] stop
								 */
// Start of branch "Travel_Direction_Loadd"
								if (Travel_Direction_Loadd != null) {

									/**
									 * [tDBOutput_5 main ] start
									 */

									currentComponent = "tDBOutput_5";

									if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

											, "Travel_Direction_Loadd", "tMap_6", "tMap_6", "tMap", "tDBOutput_5",
											"__TABLE__", "tMSSqlOutput"

									)) {
										talendJobLogProcess(globalMap);
									}

									if (log.isTraceEnabled()) {
										log.trace("Travel_Direction_Loadd - " + (Travel_Direction_Loadd == null ? ""
												: Travel_Direction_Loadd.toLogString()));
									}

									whetherReject_tDBOutput_5 = false;
									pstmt_tDBOutput_5.setInt(1, Travel_Direction_Loadd.TRAVEL_DIRECTION_SK);

									if (Travel_Direction_Loadd.TRAVEL_DIRECTION == null) {
										pstmt_tDBOutput_5.setNull(2, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_5.setString(2, Travel_Direction_Loadd.TRAVEL_DIRECTION);
									}

									if (Travel_Direction_Loadd.DI_PID == null) {
										pstmt_tDBOutput_5.setNull(3, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_5.setString(3, Travel_Direction_Loadd.DI_PID);
									}

									if (Travel_Direction_Loadd.DI_Create_Date != null) {
										pstmt_tDBOutput_5.setTimestamp(4, new java.sql.Timestamp(
												Travel_Direction_Loadd.DI_Create_Date.getTime()));
									} else {
										pstmt_tDBOutput_5.setNull(4, java.sql.Types.TIMESTAMP);
									}

									pstmt_tDBOutput_5.addBatch();
									nb_line_tDBOutput_5++;

									if (log.isDebugEnabled())
										log.debug("tDBOutput_5 - " + ("Adding the record ") + (nb_line_tDBOutput_5)
												+ (" to the ") + ("INSERT") + (" batch."));
									batchSizeCounter_tDBOutput_5++;

									////////// batch execute by batch size///////
									class LimitBytesHelper_tDBOutput_5 {
										public int limitBytePart1(int counter,
												java.sql.PreparedStatement pstmt_tDBOutput_5) throws Exception {
											try {

												if (log.isDebugEnabled())
													log.debug("tDBOutput_5 - " + ("Executing the ") + ("INSERT")
															+ (" batch."));
												for (int countEach_tDBOutput_5 : pstmt_tDBOutput_5.executeBatch()) {
													if (countEach_tDBOutput_5 == -2 || countEach_tDBOutput_5 == -3) {
														break;
													}
													counter += countEach_tDBOutput_5;
												}

												if (log.isDebugEnabled())
													log.debug("tDBOutput_5 - " + ("The ") + ("INSERT")
															+ (" batch execution has succeeded."));
											} catch (java.sql.BatchUpdateException e) {
												globalMap.put("tDBOutput_5_ERROR_MESSAGE", e.getMessage());

												int countSum_tDBOutput_5 = 0;
												for (int countEach_tDBOutput_5 : e.getUpdateCounts()) {
													counter += (countEach_tDBOutput_5 < 0 ? 0 : countEach_tDBOutput_5);
												}

												log.error("tDBOutput_5 - " + (e.getMessage()));
												System.err.println(e.getMessage());

											}
											return counter;
										}

										public int limitBytePart2(int counter,
												java.sql.PreparedStatement pstmt_tDBOutput_5) throws Exception {
											try {

												if (log.isDebugEnabled())
													log.debug("tDBOutput_5 - " + ("Executing the ") + ("INSERT")
															+ (" batch."));
												for (int countEach_tDBOutput_5 : pstmt_tDBOutput_5.executeBatch()) {
													if (countEach_tDBOutput_5 == -2 || countEach_tDBOutput_5 == -3) {
														break;
													}
													counter += countEach_tDBOutput_5;
												}

												if (log.isDebugEnabled())
													log.debug("tDBOutput_5 - " + ("The ") + ("INSERT")
															+ (" batch execution has succeeded."));
											} catch (java.sql.BatchUpdateException e) {
												globalMap.put("tDBOutput_5_ERROR_MESSAGE", e.getMessage());

												for (int countEach_tDBOutput_5 : e.getUpdateCounts()) {
													counter += (countEach_tDBOutput_5 < 0 ? 0 : countEach_tDBOutput_5);
												}

												log.error("tDBOutput_5 - " + (e.getMessage()));
												System.err.println(e.getMessage());

											}
											return counter;
										}
									}
									if ((batchSize_tDBOutput_5 > 0)
											&& (batchSize_tDBOutput_5 <= batchSizeCounter_tDBOutput_5)) {

										insertedCount_tDBOutput_5 = new LimitBytesHelper_tDBOutput_5()
												.limitBytePart1(insertedCount_tDBOutput_5, pstmt_tDBOutput_5);
										rowsToCommitCount_tDBOutput_5 = insertedCount_tDBOutput_5;

										batchSizeCounter_tDBOutput_5 = 0;
									}

									//////////// commit every////////////

									commitCounter_tDBOutput_5++;
									if (commitEvery_tDBOutput_5 <= commitCounter_tDBOutput_5) {
										if ((batchSize_tDBOutput_5 > 0) && (batchSizeCounter_tDBOutput_5 > 0)) {

											insertedCount_tDBOutput_5 = new LimitBytesHelper_tDBOutput_5()
													.limitBytePart1(insertedCount_tDBOutput_5, pstmt_tDBOutput_5);

											batchSizeCounter_tDBOutput_5 = 0;
										}
										if (rowsToCommitCount_tDBOutput_5 != 0) {

											if (log.isDebugEnabled())
												log.debug("tDBOutput_5 - " + ("Connection starting to commit ")
														+ (rowsToCommitCount_tDBOutput_5) + (" record(s)."));
										}
										conn_tDBOutput_5.commit();
										if (rowsToCommitCount_tDBOutput_5 != 0) {

											if (log.isDebugEnabled())
												log.debug("tDBOutput_5 - " + ("Connection commit has succeeded."));
											rowsToCommitCount_tDBOutput_5 = 0;
										}
										commitCounter_tDBOutput_5 = 0;
									}

									tos_count_tDBOutput_5++;

									/**
									 * [tDBOutput_5 main ] stop
									 */

									/**
									 * [tDBOutput_5 process_data_begin ] start
									 */

									currentComponent = "tDBOutput_5";

									/**
									 * [tDBOutput_5 process_data_begin ] stop
									 */

									/**
									 * [tDBOutput_5 process_data_end ] start
									 */

									currentComponent = "tDBOutput_5";

									/**
									 * [tDBOutput_5 process_data_end ] stop
									 */

								} // End of branch "Travel_Direction_Loadd"

								/**
								 * [tMap_6 process_data_end ] start
								 */

								currentComponent = "tMap_6";

								/**
								 * [tMap_6 process_data_end ] stop
								 */

							} // End of branch "row6"

							/**
							 * [tUniqRow_5 process_data_end ] start
							 */

							currentComponent = "tUniqRow_5";

							/**
							 * [tUniqRow_5 process_data_end ] stop
							 */

						} // End of branch "Travel_Direction"

// Start of branch "Driver_License_Status"
						if (Driver_License_Status != null) {

							/**
							 * [tUniqRow_6 main ] start
							 */

							currentComponent = "tUniqRow_6";

							if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

									, "Driver_License_Status", "tMap_1", "tMap_1", "tMap", "tUniqRow_6", "tUniqRow_6",
									"tUniqRow"

							)) {
								talendJobLogProcess(globalMap);
							}

							if (log.isTraceEnabled()) {
								log.trace("Driver_License_Status - "
										+ (Driver_License_Status == null ? "" : Driver_License_Status.toLogString()));
							}

							row7.DRIVER_LICENSE_STATUS = Driver_License_Status.DRIVER_LICENSE_STATUS;

							tos_count_tUniqRow_6++;

							/**
							 * [tUniqRow_6 main ] stop
							 */

							/**
							 * [tUniqRow_6 process_data_begin ] start
							 */

							currentComponent = "tUniqRow_6";

							/**
							 * [tUniqRow_6 process_data_begin ] stop
							 */
// Start of branch "row7"
							if (row7 != null) {

								/**
								 * [tMap_7 main ] start
								 */

								currentComponent = "tMap_7";

								if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

										, "row7", "tUniqRow_6", "tUniqRow_6", "tUniqRow", "tMap_7", "tMap_7", "tMap"

								)) {
									talendJobLogProcess(globalMap);
								}

								if (log.isTraceEnabled()) {
									log.trace("row7 - " + (row7 == null ? "" : row7.toLogString()));
								}

								boolean hasCasePrimitiveKeyWithNull_tMap_7 = false;

								// ###############################
								// # Input tables (lookups)
								boolean rejectedInnerJoin_tMap_7 = false;
								boolean mainRowRejected_tMap_7 = false;

								// ###############################
								{ // start of Var scope

									// ###############################
									// # Vars tables

									Var__tMap_7__Struct Var = Var__tMap_7;// ###############################
									// ###############################
									// # Output tables

									Driver_License_Status_2 = null;

// # Output table : 'Driver_License_Status_2'
									count_Driver_License_Status_2_tMap_7++;

									Driver_License_Status_2_tmp.DRIVER_LICENSE_STATUS_SK = 0;
									Driver_License_Status_2_tmp.DRIVER_LICENSE_STATUS = row7.DRIVER_LICENSE_STATUS;
									Driver_License_Status_2_tmp.DI_PID = "MVC_LOAD";
									Driver_License_Status_2_tmp.DI_Create_Date = TalendDate.getCurrentDate();
									Driver_License_Status_2 = Driver_License_Status_2_tmp;
									log.debug("tMap_7 - Outputting the record " + count_Driver_License_Status_2_tMap_7
											+ " of the output table 'Driver_License_Status_2'.");

// ###############################

								} // end of Var scope

								rejectedInnerJoin_tMap_7 = false;

								tos_count_tMap_7++;

								/**
								 * [tMap_7 main ] stop
								 */

								/**
								 * [tMap_7 process_data_begin ] start
								 */

								currentComponent = "tMap_7";

								/**
								 * [tMap_7 process_data_begin ] stop
								 */
// Start of branch "Driver_License_Status_2"
								if (Driver_License_Status_2 != null) {

									/**
									 * [tDBOutput_6 main ] start
									 */

									currentComponent = "tDBOutput_6";

									if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

											, "Driver_License_Status_2", "tMap_7", "tMap_7", "tMap", "tDBOutput_6",
											"__TABLE__", "tMSSqlOutput"

									)) {
										talendJobLogProcess(globalMap);
									}

									if (log.isTraceEnabled()) {
										log.trace("Driver_License_Status_2 - " + (Driver_License_Status_2 == null ? ""
												: Driver_License_Status_2.toLogString()));
									}

									whetherReject_tDBOutput_6 = false;
									pstmt_tDBOutput_6.setInt(1, Driver_License_Status_2.DRIVER_LICENSE_STATUS_SK);

									if (Driver_License_Status_2.DRIVER_LICENSE_STATUS == null) {
										pstmt_tDBOutput_6.setNull(2, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_6.setString(2, Driver_License_Status_2.DRIVER_LICENSE_STATUS);
									}

									if (Driver_License_Status_2.DI_PID == null) {
										pstmt_tDBOutput_6.setNull(3, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_6.setString(3, Driver_License_Status_2.DI_PID);
									}

									if (Driver_License_Status_2.DI_Create_Date != null) {
										pstmt_tDBOutput_6.setTimestamp(4, new java.sql.Timestamp(
												Driver_License_Status_2.DI_Create_Date.getTime()));
									} else {
										pstmt_tDBOutput_6.setNull(4, java.sql.Types.TIMESTAMP);
									}

									pstmt_tDBOutput_6.addBatch();
									nb_line_tDBOutput_6++;

									if (log.isDebugEnabled())
										log.debug("tDBOutput_6 - " + ("Adding the record ") + (nb_line_tDBOutput_6)
												+ (" to the ") + ("INSERT") + (" batch."));
									batchSizeCounter_tDBOutput_6++;

									////////// batch execute by batch size///////
									class LimitBytesHelper_tDBOutput_6 {
										public int limitBytePart1(int counter,
												java.sql.PreparedStatement pstmt_tDBOutput_6) throws Exception {
											try {

												if (log.isDebugEnabled())
													log.debug("tDBOutput_6 - " + ("Executing the ") + ("INSERT")
															+ (" batch."));
												for (int countEach_tDBOutput_6 : pstmt_tDBOutput_6.executeBatch()) {
													if (countEach_tDBOutput_6 == -2 || countEach_tDBOutput_6 == -3) {
														break;
													}
													counter += countEach_tDBOutput_6;
												}

												if (log.isDebugEnabled())
													log.debug("tDBOutput_6 - " + ("The ") + ("INSERT")
															+ (" batch execution has succeeded."));
											} catch (java.sql.BatchUpdateException e) {
												globalMap.put("tDBOutput_6_ERROR_MESSAGE", e.getMessage());

												int countSum_tDBOutput_6 = 0;
												for (int countEach_tDBOutput_6 : e.getUpdateCounts()) {
													counter += (countEach_tDBOutput_6 < 0 ? 0 : countEach_tDBOutput_6);
												}

												log.error("tDBOutput_6 - " + (e.getMessage()));
												System.err.println(e.getMessage());

											}
											return counter;
										}

										public int limitBytePart2(int counter,
												java.sql.PreparedStatement pstmt_tDBOutput_6) throws Exception {
											try {

												if (log.isDebugEnabled())
													log.debug("tDBOutput_6 - " + ("Executing the ") + ("INSERT")
															+ (" batch."));
												for (int countEach_tDBOutput_6 : pstmt_tDBOutput_6.executeBatch()) {
													if (countEach_tDBOutput_6 == -2 || countEach_tDBOutput_6 == -3) {
														break;
													}
													counter += countEach_tDBOutput_6;
												}

												if (log.isDebugEnabled())
													log.debug("tDBOutput_6 - " + ("The ") + ("INSERT")
															+ (" batch execution has succeeded."));
											} catch (java.sql.BatchUpdateException e) {
												globalMap.put("tDBOutput_6_ERROR_MESSAGE", e.getMessage());

												for (int countEach_tDBOutput_6 : e.getUpdateCounts()) {
													counter += (countEach_tDBOutput_6 < 0 ? 0 : countEach_tDBOutput_6);
												}

												log.error("tDBOutput_6 - " + (e.getMessage()));
												System.err.println(e.getMessage());

											}
											return counter;
										}
									}
									if ((batchSize_tDBOutput_6 > 0)
											&& (batchSize_tDBOutput_6 <= batchSizeCounter_tDBOutput_6)) {

										insertedCount_tDBOutput_6 = new LimitBytesHelper_tDBOutput_6()
												.limitBytePart1(insertedCount_tDBOutput_6, pstmt_tDBOutput_6);
										rowsToCommitCount_tDBOutput_6 = insertedCount_tDBOutput_6;

										batchSizeCounter_tDBOutput_6 = 0;
									}

									//////////// commit every////////////

									commitCounter_tDBOutput_6++;
									if (commitEvery_tDBOutput_6 <= commitCounter_tDBOutput_6) {
										if ((batchSize_tDBOutput_6 > 0) && (batchSizeCounter_tDBOutput_6 > 0)) {

											insertedCount_tDBOutput_6 = new LimitBytesHelper_tDBOutput_6()
													.limitBytePart1(insertedCount_tDBOutput_6, pstmt_tDBOutput_6);

											batchSizeCounter_tDBOutput_6 = 0;
										}
										if (rowsToCommitCount_tDBOutput_6 != 0) {

											if (log.isDebugEnabled())
												log.debug("tDBOutput_6 - " + ("Connection starting to commit ")
														+ (rowsToCommitCount_tDBOutput_6) + (" record(s)."));
										}
										conn_tDBOutput_6.commit();
										if (rowsToCommitCount_tDBOutput_6 != 0) {

											if (log.isDebugEnabled())
												log.debug("tDBOutput_6 - " + ("Connection commit has succeeded."));
											rowsToCommitCount_tDBOutput_6 = 0;
										}
										commitCounter_tDBOutput_6 = 0;
									}

									tos_count_tDBOutput_6++;

									/**
									 * [tDBOutput_6 main ] stop
									 */

									/**
									 * [tDBOutput_6 process_data_begin ] start
									 */

									currentComponent = "tDBOutput_6";

									/**
									 * [tDBOutput_6 process_data_begin ] stop
									 */

									/**
									 * [tDBOutput_6 process_data_end ] start
									 */

									currentComponent = "tDBOutput_6";

									/**
									 * [tDBOutput_6 process_data_end ] stop
									 */

								} // End of branch "Driver_License_Status_2"

								/**
								 * [tMap_7 process_data_end ] start
								 */

								currentComponent = "tMap_7";

								/**
								 * [tMap_7 process_data_end ] stop
								 */

							} // End of branch "row7"

							/**
							 * [tUniqRow_6 process_data_end ] start
							 */

							currentComponent = "tUniqRow_6";

							/**
							 * [tUniqRow_6 process_data_end ] stop
							 */

						} // End of branch "Driver_License_Status"

// Start of branch "Driver_License_Jusridiction"
						if (Driver_License_Jusridiction != null) {

							/**
							 * [tUniqRow_7 main ] start
							 */

							currentComponent = "tUniqRow_7";

							if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

									, "Driver_License_Jusridiction", "tMap_1", "tMap_1", "tMap", "tUniqRow_7",
									"tUniqRow_7", "tUniqRow"

							)) {
								talendJobLogProcess(globalMap);
							}

							if (log.isTraceEnabled()) {
								log.trace("Driver_License_Jusridiction - " + (Driver_License_Jusridiction == null ? ""
										: Driver_License_Jusridiction.toLogString()));
							}

							row8.DRIVER_LICENSE_JURISDICTION = Driver_License_Jusridiction.DRIVER_LICENSE_JURISDICTION;

							tos_count_tUniqRow_7++;

							/**
							 * [tUniqRow_7 main ] stop
							 */

							/**
							 * [tUniqRow_7 process_data_begin ] start
							 */

							currentComponent = "tUniqRow_7";

							/**
							 * [tUniqRow_7 process_data_begin ] stop
							 */
// Start of branch "row8"
							if (row8 != null) {

								/**
								 * [tMap_8 main ] start
								 */

								currentComponent = "tMap_8";

								if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

										, "row8", "tUniqRow_7", "tUniqRow_7", "tUniqRow", "tMap_8", "tMap_8", "tMap"

								)) {
									talendJobLogProcess(globalMap);
								}

								if (log.isTraceEnabled()) {
									log.trace("row8 - " + (row8 == null ? "" : row8.toLogString()));
								}

								boolean hasCasePrimitiveKeyWithNull_tMap_8 = false;

								// ###############################
								// # Input tables (lookups)
								boolean rejectedInnerJoin_tMap_8 = false;
								boolean mainRowRejected_tMap_8 = false;

								// ###############################
								{ // start of Var scope

									// ###############################
									// # Vars tables

									Var__tMap_8__Struct Var = Var__tMap_8;// ###############################
									// ###############################
									// # Output tables

									Jurisdiv = null;

// # Output table : 'Jurisdiv'
									count_Jurisdiv_tMap_8++;

									Jurisdiv_tmp.DRIVER_LICENSE_JURISDICTION_SK = 0;
									Jurisdiv_tmp.DRIVER_LICENSE_JURISDICTION = row8.DRIVER_LICENSE_JURISDICTION;
									Jurisdiv_tmp.DI_PID = "MVC_LOAD";
									Jurisdiv_tmp.DI_Create_Date = TalendDate.getCurrentDate();
									Jurisdiv = Jurisdiv_tmp;
									log.debug("tMap_8 - Outputting the record " + count_Jurisdiv_tMap_8
											+ " of the output table 'Jurisdiv'.");

// ###############################

								} // end of Var scope

								rejectedInnerJoin_tMap_8 = false;

								tos_count_tMap_8++;

								/**
								 * [tMap_8 main ] stop
								 */

								/**
								 * [tMap_8 process_data_begin ] start
								 */

								currentComponent = "tMap_8";

								/**
								 * [tMap_8 process_data_begin ] stop
								 */
// Start of branch "Jurisdiv"
								if (Jurisdiv != null) {

									/**
									 * [tDBOutput_7 main ] start
									 */

									currentComponent = "tDBOutput_7";

									if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

											, "Jurisdiv", "tMap_8", "tMap_8", "tMap", "tDBOutput_7", "__TABLE__",
											"tMSSqlOutput"

									)) {
										talendJobLogProcess(globalMap);
									}

									if (log.isTraceEnabled()) {
										log.trace("Jurisdiv - " + (Jurisdiv == null ? "" : Jurisdiv.toLogString()));
									}

									whetherReject_tDBOutput_7 = false;
									pstmt_tDBOutput_7.setInt(1, Jurisdiv.DRIVER_LICENSE_JURISDICTION_SK);

									if (Jurisdiv.DRIVER_LICENSE_JURISDICTION == null) {
										pstmt_tDBOutput_7.setNull(2, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_7.setString(2, Jurisdiv.DRIVER_LICENSE_JURISDICTION);
									}

									if (Jurisdiv.DI_PID == null) {
										pstmt_tDBOutput_7.setNull(3, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_7.setString(3, Jurisdiv.DI_PID);
									}

									if (Jurisdiv.DI_Create_Date != null) {
										pstmt_tDBOutput_7.setTimestamp(4,
												new java.sql.Timestamp(Jurisdiv.DI_Create_Date.getTime()));
									} else {
										pstmt_tDBOutput_7.setNull(4, java.sql.Types.TIMESTAMP);
									}

									pstmt_tDBOutput_7.addBatch();
									nb_line_tDBOutput_7++;

									if (log.isDebugEnabled())
										log.debug("tDBOutput_7 - " + ("Adding the record ") + (nb_line_tDBOutput_7)
												+ (" to the ") + ("INSERT") + (" batch."));
									batchSizeCounter_tDBOutput_7++;

									////////// batch execute by batch size///////
									class LimitBytesHelper_tDBOutput_7 {
										public int limitBytePart1(int counter,
												java.sql.PreparedStatement pstmt_tDBOutput_7) throws Exception {
											try {

												if (log.isDebugEnabled())
													log.debug("tDBOutput_7 - " + ("Executing the ") + ("INSERT")
															+ (" batch."));
												for (int countEach_tDBOutput_7 : pstmt_tDBOutput_7.executeBatch()) {
													if (countEach_tDBOutput_7 == -2 || countEach_tDBOutput_7 == -3) {
														break;
													}
													counter += countEach_tDBOutput_7;
												}

												if (log.isDebugEnabled())
													log.debug("tDBOutput_7 - " + ("The ") + ("INSERT")
															+ (" batch execution has succeeded."));
											} catch (java.sql.BatchUpdateException e) {
												globalMap.put("tDBOutput_7_ERROR_MESSAGE", e.getMessage());

												int countSum_tDBOutput_7 = 0;
												for (int countEach_tDBOutput_7 : e.getUpdateCounts()) {
													counter += (countEach_tDBOutput_7 < 0 ? 0 : countEach_tDBOutput_7);
												}

												log.error("tDBOutput_7 - " + (e.getMessage()));
												System.err.println(e.getMessage());

											}
											return counter;
										}

										public int limitBytePart2(int counter,
												java.sql.PreparedStatement pstmt_tDBOutput_7) throws Exception {
											try {

												if (log.isDebugEnabled())
													log.debug("tDBOutput_7 - " + ("Executing the ") + ("INSERT")
															+ (" batch."));
												for (int countEach_tDBOutput_7 : pstmt_tDBOutput_7.executeBatch()) {
													if (countEach_tDBOutput_7 == -2 || countEach_tDBOutput_7 == -3) {
														break;
													}
													counter += countEach_tDBOutput_7;
												}

												if (log.isDebugEnabled())
													log.debug("tDBOutput_7 - " + ("The ") + ("INSERT")
															+ (" batch execution has succeeded."));
											} catch (java.sql.BatchUpdateException e) {
												globalMap.put("tDBOutput_7_ERROR_MESSAGE", e.getMessage());

												for (int countEach_tDBOutput_7 : e.getUpdateCounts()) {
													counter += (countEach_tDBOutput_7 < 0 ? 0 : countEach_tDBOutput_7);
												}

												log.error("tDBOutput_7 - " + (e.getMessage()));
												System.err.println(e.getMessage());

											}
											return counter;
										}
									}
									if ((batchSize_tDBOutput_7 > 0)
											&& (batchSize_tDBOutput_7 <= batchSizeCounter_tDBOutput_7)) {

										insertedCount_tDBOutput_7 = new LimitBytesHelper_tDBOutput_7()
												.limitBytePart1(insertedCount_tDBOutput_7, pstmt_tDBOutput_7);
										rowsToCommitCount_tDBOutput_7 = insertedCount_tDBOutput_7;

										batchSizeCounter_tDBOutput_7 = 0;
									}

									//////////// commit every////////////

									commitCounter_tDBOutput_7++;
									if (commitEvery_tDBOutput_7 <= commitCounter_tDBOutput_7) {
										if ((batchSize_tDBOutput_7 > 0) && (batchSizeCounter_tDBOutput_7 > 0)) {

											insertedCount_tDBOutput_7 = new LimitBytesHelper_tDBOutput_7()
													.limitBytePart1(insertedCount_tDBOutput_7, pstmt_tDBOutput_7);

											batchSizeCounter_tDBOutput_7 = 0;
										}
										if (rowsToCommitCount_tDBOutput_7 != 0) {

											if (log.isDebugEnabled())
												log.debug("tDBOutput_7 - " + ("Connection starting to commit ")
														+ (rowsToCommitCount_tDBOutput_7) + (" record(s)."));
										}
										conn_tDBOutput_7.commit();
										if (rowsToCommitCount_tDBOutput_7 != 0) {

											if (log.isDebugEnabled())
												log.debug("tDBOutput_7 - " + ("Connection commit has succeeded."));
											rowsToCommitCount_tDBOutput_7 = 0;
										}
										commitCounter_tDBOutput_7 = 0;
									}

									tos_count_tDBOutput_7++;

									/**
									 * [tDBOutput_7 main ] stop
									 */

									/**
									 * [tDBOutput_7 process_data_begin ] start
									 */

									currentComponent = "tDBOutput_7";

									/**
									 * [tDBOutput_7 process_data_begin ] stop
									 */

									/**
									 * [tDBOutput_7 process_data_end ] start
									 */

									currentComponent = "tDBOutput_7";

									/**
									 * [tDBOutput_7 process_data_end ] stop
									 */

								} // End of branch "Jurisdiv"

								/**
								 * [tMap_8 process_data_end ] start
								 */

								currentComponent = "tMap_8";

								/**
								 * [tMap_8 process_data_end ] stop
								 */

							} // End of branch "row8"

							/**
							 * [tUniqRow_7 process_data_end ] start
							 */

							currentComponent = "tUniqRow_7";

							/**
							 * [tUniqRow_7 process_data_end ] stop
							 */

						} // End of branch "Driver_License_Jusridiction"

// Start of branch "PreCash"
						if (PreCash != null) {

							/**
							 * [tUniqRow_8 main ] start
							 */

							currentComponent = "tUniqRow_8";

							if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

									, "PreCash", "tMap_1", "tMap_1", "tMap", "tUniqRow_8", "tUniqRow_8", "tUniqRow"

							)) {
								talendJobLogProcess(globalMap);
							}

							if (log.isTraceEnabled()) {
								log.trace("PreCash - " + (PreCash == null ? "" : PreCash.toLogString()));
							}

							row9.PRE_CRASH = PreCash.PRE_CRASH;

							tos_count_tUniqRow_8++;

							/**
							 * [tUniqRow_8 main ] stop
							 */

							/**
							 * [tUniqRow_8 process_data_begin ] start
							 */

							currentComponent = "tUniqRow_8";

							/**
							 * [tUniqRow_8 process_data_begin ] stop
							 */
// Start of branch "row9"
							if (row9 != null) {

								/**
								 * [tMap_9 main ] start
								 */

								currentComponent = "tMap_9";

								if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

										, "row9", "tUniqRow_8", "tUniqRow_8", "tUniqRow", "tMap_9", "tMap_9", "tMap"

								)) {
									talendJobLogProcess(globalMap);
								}

								if (log.isTraceEnabled()) {
									log.trace("row9 - " + (row9 == null ? "" : row9.toLogString()));
								}

								boolean hasCasePrimitiveKeyWithNull_tMap_9 = false;

								// ###############################
								// # Input tables (lookups)
								boolean rejectedInnerJoin_tMap_9 = false;
								boolean mainRowRejected_tMap_9 = false;

								// ###############################
								{ // start of Var scope

									// ###############################
									// # Vars tables

									Var__tMap_9__Struct Var = Var__tMap_9;// ###############################
									// ###############################
									// # Output tables

									PreCash22 = null;

// # Output table : 'PreCash22'
									count_PreCash22_tMap_9++;

									PreCash22_tmp.PRE_CRASH_SK = 0;
									PreCash22_tmp.PRE_CRASH = row9.PRE_CRASH;
									PreCash22_tmp.DI_PID = "MVC_LOAD";
									PreCash22_tmp.DI_Create_Date = TalendDate.getCurrentDate();
									PreCash22 = PreCash22_tmp;
									log.debug("tMap_9 - Outputting the record " + count_PreCash22_tMap_9
											+ " of the output table 'PreCash22'.");

// ###############################

								} // end of Var scope

								rejectedInnerJoin_tMap_9 = false;

								tos_count_tMap_9++;

								/**
								 * [tMap_9 main ] stop
								 */

								/**
								 * [tMap_9 process_data_begin ] start
								 */

								currentComponent = "tMap_9";

								/**
								 * [tMap_9 process_data_begin ] stop
								 */
// Start of branch "PreCash22"
								if (PreCash22 != null) {

									/**
									 * [tDBOutput_8 main ] start
									 */

									currentComponent = "tDBOutput_8";

									if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

											, "PreCash22", "tMap_9", "tMap_9", "tMap", "tDBOutput_8", "__TABLE__",
											"tMSSqlOutput"

									)) {
										talendJobLogProcess(globalMap);
									}

									if (log.isTraceEnabled()) {
										log.trace("PreCash22 - " + (PreCash22 == null ? "" : PreCash22.toLogString()));
									}

									whetherReject_tDBOutput_8 = false;
									pstmt_tDBOutput_8.setInt(1, PreCash22.PRE_CRASH_SK);

									if (PreCash22.PRE_CRASH == null) {
										pstmt_tDBOutput_8.setNull(2, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_8.setString(2, PreCash22.PRE_CRASH);
									}

									if (PreCash22.DI_PID == null) {
										pstmt_tDBOutput_8.setNull(3, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_8.setString(3, PreCash22.DI_PID);
									}

									if (PreCash22.DI_Create_Date != null) {
										pstmt_tDBOutput_8.setTimestamp(4,
												new java.sql.Timestamp(PreCash22.DI_Create_Date.getTime()));
									} else {
										pstmt_tDBOutput_8.setNull(4, java.sql.Types.TIMESTAMP);
									}

									pstmt_tDBOutput_8.addBatch();
									nb_line_tDBOutput_8++;

									if (log.isDebugEnabled())
										log.debug("tDBOutput_8 - " + ("Adding the record ") + (nb_line_tDBOutput_8)
												+ (" to the ") + ("INSERT") + (" batch."));
									batchSizeCounter_tDBOutput_8++;

									////////// batch execute by batch size///////
									class LimitBytesHelper_tDBOutput_8 {
										public int limitBytePart1(int counter,
												java.sql.PreparedStatement pstmt_tDBOutput_8) throws Exception {
											try {

												if (log.isDebugEnabled())
													log.debug("tDBOutput_8 - " + ("Executing the ") + ("INSERT")
															+ (" batch."));
												for (int countEach_tDBOutput_8 : pstmt_tDBOutput_8.executeBatch()) {
													if (countEach_tDBOutput_8 == -2 || countEach_tDBOutput_8 == -3) {
														break;
													}
													counter += countEach_tDBOutput_8;
												}

												if (log.isDebugEnabled())
													log.debug("tDBOutput_8 - " + ("The ") + ("INSERT")
															+ (" batch execution has succeeded."));
											} catch (java.sql.BatchUpdateException e) {
												globalMap.put("tDBOutput_8_ERROR_MESSAGE", e.getMessage());

												int countSum_tDBOutput_8 = 0;
												for (int countEach_tDBOutput_8 : e.getUpdateCounts()) {
													counter += (countEach_tDBOutput_8 < 0 ? 0 : countEach_tDBOutput_8);
												}

												log.error("tDBOutput_8 - " + (e.getMessage()));
												System.err.println(e.getMessage());

											}
											return counter;
										}

										public int limitBytePart2(int counter,
												java.sql.PreparedStatement pstmt_tDBOutput_8) throws Exception {
											try {

												if (log.isDebugEnabled())
													log.debug("tDBOutput_8 - " + ("Executing the ") + ("INSERT")
															+ (" batch."));
												for (int countEach_tDBOutput_8 : pstmt_tDBOutput_8.executeBatch()) {
													if (countEach_tDBOutput_8 == -2 || countEach_tDBOutput_8 == -3) {
														break;
													}
													counter += countEach_tDBOutput_8;
												}

												if (log.isDebugEnabled())
													log.debug("tDBOutput_8 - " + ("The ") + ("INSERT")
															+ (" batch execution has succeeded."));
											} catch (java.sql.BatchUpdateException e) {
												globalMap.put("tDBOutput_8_ERROR_MESSAGE", e.getMessage());

												for (int countEach_tDBOutput_8 : e.getUpdateCounts()) {
													counter += (countEach_tDBOutput_8 < 0 ? 0 : countEach_tDBOutput_8);
												}

												log.error("tDBOutput_8 - " + (e.getMessage()));
												System.err.println(e.getMessage());

											}
											return counter;
										}
									}
									if ((batchSize_tDBOutput_8 > 0)
											&& (batchSize_tDBOutput_8 <= batchSizeCounter_tDBOutput_8)) {

										insertedCount_tDBOutput_8 = new LimitBytesHelper_tDBOutput_8()
												.limitBytePart1(insertedCount_tDBOutput_8, pstmt_tDBOutput_8);
										rowsToCommitCount_tDBOutput_8 = insertedCount_tDBOutput_8;

										batchSizeCounter_tDBOutput_8 = 0;
									}

									//////////// commit every////////////

									commitCounter_tDBOutput_8++;
									if (commitEvery_tDBOutput_8 <= commitCounter_tDBOutput_8) {
										if ((batchSize_tDBOutput_8 > 0) && (batchSizeCounter_tDBOutput_8 > 0)) {

											insertedCount_tDBOutput_8 = new LimitBytesHelper_tDBOutput_8()
													.limitBytePart1(insertedCount_tDBOutput_8, pstmt_tDBOutput_8);

											batchSizeCounter_tDBOutput_8 = 0;
										}
										if (rowsToCommitCount_tDBOutput_8 != 0) {

											if (log.isDebugEnabled())
												log.debug("tDBOutput_8 - " + ("Connection starting to commit ")
														+ (rowsToCommitCount_tDBOutput_8) + (" record(s)."));
										}
										conn_tDBOutput_8.commit();
										if (rowsToCommitCount_tDBOutput_8 != 0) {

											if (log.isDebugEnabled())
												log.debug("tDBOutput_8 - " + ("Connection commit has succeeded."));
											rowsToCommitCount_tDBOutput_8 = 0;
										}
										commitCounter_tDBOutput_8 = 0;
									}

									tos_count_tDBOutput_8++;

									/**
									 * [tDBOutput_8 main ] stop
									 */

									/**
									 * [tDBOutput_8 process_data_begin ] start
									 */

									currentComponent = "tDBOutput_8";

									/**
									 * [tDBOutput_8 process_data_begin ] stop
									 */

									/**
									 * [tDBOutput_8 process_data_end ] start
									 */

									currentComponent = "tDBOutput_8";

									/**
									 * [tDBOutput_8 process_data_end ] stop
									 */

								} // End of branch "PreCash22"

								/**
								 * [tMap_9 process_data_end ] start
								 */

								currentComponent = "tMap_9";

								/**
								 * [tMap_9 process_data_end ] stop
								 */

							} // End of branch "row9"

							/**
							 * [tUniqRow_8 process_data_end ] start
							 */

							currentComponent = "tUniqRow_8";

							/**
							 * [tUniqRow_8 process_data_end ] stop
							 */

						} // End of branch "PreCash"

// Start of branch "Point_Of_Impact"
						if (Point_Of_Impact != null) {

							/**
							 * [tUniqRow_9 main ] start
							 */

							currentComponent = "tUniqRow_9";

							if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

									, "Point_Of_Impact", "tMap_1", "tMap_1", "tMap", "tUniqRow_9", "tUniqRow_9",
									"tUniqRow"

							)) {
								talendJobLogProcess(globalMap);
							}

							if (log.isTraceEnabled()) {
								log.trace("Point_Of_Impact - "
										+ (Point_Of_Impact == null ? "" : Point_Of_Impact.toLogString()));
							}

							row10.POINT_OF_IMPACT = Point_Of_Impact.POINT_OF_IMPACT;

							tos_count_tUniqRow_9++;

							/**
							 * [tUniqRow_9 main ] stop
							 */

							/**
							 * [tUniqRow_9 process_data_begin ] start
							 */

							currentComponent = "tUniqRow_9";

							/**
							 * [tUniqRow_9 process_data_begin ] stop
							 */
// Start of branch "row10"
							if (row10 != null) {

								/**
								 * [tMap_10 main ] start
								 */

								currentComponent = "tMap_10";

								if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

										, "row10", "tUniqRow_9", "tUniqRow_9", "tUniqRow", "tMap_10", "tMap_10", "tMap"

								)) {
									talendJobLogProcess(globalMap);
								}

								if (log.isTraceEnabled()) {
									log.trace("row10 - " + (row10 == null ? "" : row10.toLogString()));
								}

								boolean hasCasePrimitiveKeyWithNull_tMap_10 = false;

								// ###############################
								// # Input tables (lookups)
								boolean rejectedInnerJoin_tMap_10 = false;
								boolean mainRowRejected_tMap_10 = false;

								// ###############################
								{ // start of Var scope

									// ###############################
									// # Vars tables

									Var__tMap_10__Struct Var = Var__tMap_10;// ###############################
									// ###############################
									// # Output tables

									PointOFImpact2 = null;

// # Output table : 'PointOFImpact2'
									count_PointOFImpact2_tMap_10++;

									PointOFImpact2_tmp.POINT_OF_IMPACT_SK = 0;
									PointOFImpact2_tmp.POINT_OF_IMPACT = row10.POINT_OF_IMPACT;
									PointOFImpact2_tmp.DI_PID = "MVC_LOAD";
									PointOFImpact2_tmp.DI_Create_Date = TalendDate.getCurrentDate();
									PointOFImpact2 = PointOFImpact2_tmp;
									log.debug("tMap_10 - Outputting the record " + count_PointOFImpact2_tMap_10
											+ " of the output table 'PointOFImpact2'.");

// ###############################

								} // end of Var scope

								rejectedInnerJoin_tMap_10 = false;

								tos_count_tMap_10++;

								/**
								 * [tMap_10 main ] stop
								 */

								/**
								 * [tMap_10 process_data_begin ] start
								 */

								currentComponent = "tMap_10";

								/**
								 * [tMap_10 process_data_begin ] stop
								 */
// Start of branch "PointOFImpact2"
								if (PointOFImpact2 != null) {

									/**
									 * [tDBOutput_9 main ] start
									 */

									currentComponent = "tDBOutput_9";

									if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

											, "PointOFImpact2", "tMap_10", "tMap_10", "tMap", "tDBOutput_9",
											"__TABLE__", "tMSSqlOutput"

									)) {
										talendJobLogProcess(globalMap);
									}

									if (log.isTraceEnabled()) {
										log.trace("PointOFImpact2 - "
												+ (PointOFImpact2 == null ? "" : PointOFImpact2.toLogString()));
									}

									whetherReject_tDBOutput_9 = false;
									pstmt_tDBOutput_9.setInt(1, PointOFImpact2.POINT_OF_IMPACT_SK);

									if (PointOFImpact2.POINT_OF_IMPACT == null) {
										pstmt_tDBOutput_9.setNull(2, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_9.setString(2, PointOFImpact2.POINT_OF_IMPACT);
									}

									if (PointOFImpact2.DI_PID == null) {
										pstmt_tDBOutput_9.setNull(3, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_9.setString(3, PointOFImpact2.DI_PID);
									}

									if (PointOFImpact2.DI_Create_Date != null) {
										pstmt_tDBOutput_9.setTimestamp(4,
												new java.sql.Timestamp(PointOFImpact2.DI_Create_Date.getTime()));
									} else {
										pstmt_tDBOutput_9.setNull(4, java.sql.Types.TIMESTAMP);
									}

									pstmt_tDBOutput_9.addBatch();
									nb_line_tDBOutput_9++;

									if (log.isDebugEnabled())
										log.debug("tDBOutput_9 - " + ("Adding the record ") + (nb_line_tDBOutput_9)
												+ (" to the ") + ("INSERT") + (" batch."));
									batchSizeCounter_tDBOutput_9++;

									////////// batch execute by batch size///////
									class LimitBytesHelper_tDBOutput_9 {
										public int limitBytePart1(int counter,
												java.sql.PreparedStatement pstmt_tDBOutput_9) throws Exception {
											try {

												if (log.isDebugEnabled())
													log.debug("tDBOutput_9 - " + ("Executing the ") + ("INSERT")
															+ (" batch."));
												for (int countEach_tDBOutput_9 : pstmt_tDBOutput_9.executeBatch()) {
													if (countEach_tDBOutput_9 == -2 || countEach_tDBOutput_9 == -3) {
														break;
													}
													counter += countEach_tDBOutput_9;
												}

												if (log.isDebugEnabled())
													log.debug("tDBOutput_9 - " + ("The ") + ("INSERT")
															+ (" batch execution has succeeded."));
											} catch (java.sql.BatchUpdateException e) {
												globalMap.put("tDBOutput_9_ERROR_MESSAGE", e.getMessage());

												int countSum_tDBOutput_9 = 0;
												for (int countEach_tDBOutput_9 : e.getUpdateCounts()) {
													counter += (countEach_tDBOutput_9 < 0 ? 0 : countEach_tDBOutput_9);
												}

												log.error("tDBOutput_9 - " + (e.getMessage()));
												System.err.println(e.getMessage());

											}
											return counter;
										}

										public int limitBytePart2(int counter,
												java.sql.PreparedStatement pstmt_tDBOutput_9) throws Exception {
											try {

												if (log.isDebugEnabled())
													log.debug("tDBOutput_9 - " + ("Executing the ") + ("INSERT")
															+ (" batch."));
												for (int countEach_tDBOutput_9 : pstmt_tDBOutput_9.executeBatch()) {
													if (countEach_tDBOutput_9 == -2 || countEach_tDBOutput_9 == -3) {
														break;
													}
													counter += countEach_tDBOutput_9;
												}

												if (log.isDebugEnabled())
													log.debug("tDBOutput_9 - " + ("The ") + ("INSERT")
															+ (" batch execution has succeeded."));
											} catch (java.sql.BatchUpdateException e) {
												globalMap.put("tDBOutput_9_ERROR_MESSAGE", e.getMessage());

												for (int countEach_tDBOutput_9 : e.getUpdateCounts()) {
													counter += (countEach_tDBOutput_9 < 0 ? 0 : countEach_tDBOutput_9);
												}

												log.error("tDBOutput_9 - " + (e.getMessage()));
												System.err.println(e.getMessage());

											}
											return counter;
										}
									}
									if ((batchSize_tDBOutput_9 > 0)
											&& (batchSize_tDBOutput_9 <= batchSizeCounter_tDBOutput_9)) {

										insertedCount_tDBOutput_9 = new LimitBytesHelper_tDBOutput_9()
												.limitBytePart1(insertedCount_tDBOutput_9, pstmt_tDBOutput_9);
										rowsToCommitCount_tDBOutput_9 = insertedCount_tDBOutput_9;

										batchSizeCounter_tDBOutput_9 = 0;
									}

									//////////// commit every////////////

									commitCounter_tDBOutput_9++;
									if (commitEvery_tDBOutput_9 <= commitCounter_tDBOutput_9) {
										if ((batchSize_tDBOutput_9 > 0) && (batchSizeCounter_tDBOutput_9 > 0)) {

											insertedCount_tDBOutput_9 = new LimitBytesHelper_tDBOutput_9()
													.limitBytePart1(insertedCount_tDBOutput_9, pstmt_tDBOutput_9);

											batchSizeCounter_tDBOutput_9 = 0;
										}
										if (rowsToCommitCount_tDBOutput_9 != 0) {

											if (log.isDebugEnabled())
												log.debug("tDBOutput_9 - " + ("Connection starting to commit ")
														+ (rowsToCommitCount_tDBOutput_9) + (" record(s)."));
										}
										conn_tDBOutput_9.commit();
										if (rowsToCommitCount_tDBOutput_9 != 0) {

											if (log.isDebugEnabled())
												log.debug("tDBOutput_9 - " + ("Connection commit has succeeded."));
											rowsToCommitCount_tDBOutput_9 = 0;
										}
										commitCounter_tDBOutput_9 = 0;
									}

									tos_count_tDBOutput_9++;

									/**
									 * [tDBOutput_9 main ] stop
									 */

									/**
									 * [tDBOutput_9 process_data_begin ] start
									 */

									currentComponent = "tDBOutput_9";

									/**
									 * [tDBOutput_9 process_data_begin ] stop
									 */

									/**
									 * [tDBOutput_9 process_data_end ] start
									 */

									currentComponent = "tDBOutput_9";

									/**
									 * [tDBOutput_9 process_data_end ] stop
									 */

								} // End of branch "PointOFImpact2"

								/**
								 * [tMap_10 process_data_end ] start
								 */

								currentComponent = "tMap_10";

								/**
								 * [tMap_10 process_data_end ] stop
								 */

							} // End of branch "row10"

							/**
							 * [tUniqRow_9 process_data_end ] start
							 */

							currentComponent = "tUniqRow_9";

							/**
							 * [tUniqRow_9 process_data_end ] stop
							 */

						} // End of branch "Point_Of_Impact"

// Start of branch "Public_propertyDamage"
						if (Public_propertyDamage != null) {

							/**
							 * [tUniqRow_10 main ] start
							 */

							currentComponent = "tUniqRow_10";

							if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

									, "Public_propertyDamage", "tMap_1", "tMap_1", "tMap", "tUniqRow_10", "tUniqRow_10",
									"tUniqRow"

							)) {
								talendJobLogProcess(globalMap);
							}

							if (log.isTraceEnabled()) {
								log.trace("Public_propertyDamage - "
										+ (Public_propertyDamage == null ? "" : Public_propertyDamage.toLogString()));
							}

							row11.PUBLIC_PROPERTY_DAMAGE = Public_propertyDamage.PUBLIC_PROPERTY_DAMAGE;

							tos_count_tUniqRow_10++;

							/**
							 * [tUniqRow_10 main ] stop
							 */

							/**
							 * [tUniqRow_10 process_data_begin ] start
							 */

							currentComponent = "tUniqRow_10";

							/**
							 * [tUniqRow_10 process_data_begin ] stop
							 */
// Start of branch "row11"
							if (row11 != null) {

								/**
								 * [tMap_11 main ] start
								 */

								currentComponent = "tMap_11";

								if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

										, "row11", "tUniqRow_10", "tUniqRow_10", "tUniqRow", "tMap_11", "tMap_11",
										"tMap"

								)) {
									talendJobLogProcess(globalMap);
								}

								if (log.isTraceEnabled()) {
									log.trace("row11 - " + (row11 == null ? "" : row11.toLogString()));
								}

								boolean hasCasePrimitiveKeyWithNull_tMap_11 = false;

								// ###############################
								// # Input tables (lookups)
								boolean rejectedInnerJoin_tMap_11 = false;
								boolean mainRowRejected_tMap_11 = false;

								// ###############################
								{ // start of Var scope

									// ###############################
									// # Vars tables

									Var__tMap_11__Struct Var = Var__tMap_11;// ###############################
									// ###############################
									// # Output tables

									PublicPropertyDamage2 = null;

// # Output table : 'PublicPropertyDamage2'
									count_PublicPropertyDamage2_tMap_11++;

									PublicPropertyDamage2_tmp.PUBLIC_PROPERTY_DAMAGE_SK = 0;
									PublicPropertyDamage2_tmp.PUBLIC_PROPERTY_DAMAGE = row11.PUBLIC_PROPERTY_DAMAGE;
									PublicPropertyDamage2_tmp.DI_PID = "MVC_LOAD";
									PublicPropertyDamage2_tmp.DI_Create_Date = TalendDate.getCurrentDate();
									PublicPropertyDamage2 = PublicPropertyDamage2_tmp;
									log.debug("tMap_11 - Outputting the record " + count_PublicPropertyDamage2_tMap_11
											+ " of the output table 'PublicPropertyDamage2'.");

// ###############################

								} // end of Var scope

								rejectedInnerJoin_tMap_11 = false;

								tos_count_tMap_11++;

								/**
								 * [tMap_11 main ] stop
								 */

								/**
								 * [tMap_11 process_data_begin ] start
								 */

								currentComponent = "tMap_11";

								/**
								 * [tMap_11 process_data_begin ] stop
								 */
// Start of branch "PublicPropertyDamage2"
								if (PublicPropertyDamage2 != null) {

									/**
									 * [tDBOutput_10 main ] start
									 */

									currentComponent = "tDBOutput_10";

									if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

											, "PublicPropertyDamage2", "tMap_11", "tMap_11", "tMap", "tDBOutput_10",
											"__TABLE__", "tMSSqlOutput"

									)) {
										talendJobLogProcess(globalMap);
									}

									if (log.isTraceEnabled()) {
										log.trace("PublicPropertyDamage2 - " + (PublicPropertyDamage2 == null ? ""
												: PublicPropertyDamage2.toLogString()));
									}

									whetherReject_tDBOutput_10 = false;
									pstmt_tDBOutput_10.setInt(1, PublicPropertyDamage2.PUBLIC_PROPERTY_DAMAGE_SK);

									if (PublicPropertyDamage2.PUBLIC_PROPERTY_DAMAGE == null) {
										pstmt_tDBOutput_10.setNull(2, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_10.setString(2, PublicPropertyDamage2.PUBLIC_PROPERTY_DAMAGE);
									}

									if (PublicPropertyDamage2.DI_PID == null) {
										pstmt_tDBOutput_10.setNull(3, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_10.setString(3, PublicPropertyDamage2.DI_PID);
									}

									if (PublicPropertyDamage2.DI_Create_Date != null) {
										pstmt_tDBOutput_10.setTimestamp(4,
												new java.sql.Timestamp(PublicPropertyDamage2.DI_Create_Date.getTime()));
									} else {
										pstmt_tDBOutput_10.setNull(4, java.sql.Types.TIMESTAMP);
									}

									pstmt_tDBOutput_10.addBatch();
									nb_line_tDBOutput_10++;

									if (log.isDebugEnabled())
										log.debug("tDBOutput_10 - " + ("Adding the record ") + (nb_line_tDBOutput_10)
												+ (" to the ") + ("INSERT") + (" batch."));
									batchSizeCounter_tDBOutput_10++;

									////////// batch execute by batch size///////
									class LimitBytesHelper_tDBOutput_10 {
										public int limitBytePart1(int counter,
												java.sql.PreparedStatement pstmt_tDBOutput_10) throws Exception {
											try {

												if (log.isDebugEnabled())
													log.debug("tDBOutput_10 - " + ("Executing the ") + ("INSERT")
															+ (" batch."));
												for (int countEach_tDBOutput_10 : pstmt_tDBOutput_10.executeBatch()) {
													if (countEach_tDBOutput_10 == -2 || countEach_tDBOutput_10 == -3) {
														break;
													}
													counter += countEach_tDBOutput_10;
												}

												if (log.isDebugEnabled())
													log.debug("tDBOutput_10 - " + ("The ") + ("INSERT")
															+ (" batch execution has succeeded."));
											} catch (java.sql.BatchUpdateException e) {
												globalMap.put("tDBOutput_10_ERROR_MESSAGE", e.getMessage());

												int countSum_tDBOutput_10 = 0;
												for (int countEach_tDBOutput_10 : e.getUpdateCounts()) {
													counter += (countEach_tDBOutput_10 < 0 ? 0
															: countEach_tDBOutput_10);
												}

												log.error("tDBOutput_10 - " + (e.getMessage()));
												System.err.println(e.getMessage());

											}
											return counter;
										}

										public int limitBytePart2(int counter,
												java.sql.PreparedStatement pstmt_tDBOutput_10) throws Exception {
											try {

												if (log.isDebugEnabled())
													log.debug("tDBOutput_10 - " + ("Executing the ") + ("INSERT")
															+ (" batch."));
												for (int countEach_tDBOutput_10 : pstmt_tDBOutput_10.executeBatch()) {
													if (countEach_tDBOutput_10 == -2 || countEach_tDBOutput_10 == -3) {
														break;
													}
													counter += countEach_tDBOutput_10;
												}

												if (log.isDebugEnabled())
													log.debug("tDBOutput_10 - " + ("The ") + ("INSERT")
															+ (" batch execution has succeeded."));
											} catch (java.sql.BatchUpdateException e) {
												globalMap.put("tDBOutput_10_ERROR_MESSAGE", e.getMessage());

												for (int countEach_tDBOutput_10 : e.getUpdateCounts()) {
													counter += (countEach_tDBOutput_10 < 0 ? 0
															: countEach_tDBOutput_10);
												}

												log.error("tDBOutput_10 - " + (e.getMessage()));
												System.err.println(e.getMessage());

											}
											return counter;
										}
									}
									if ((batchSize_tDBOutput_10 > 0)
											&& (batchSize_tDBOutput_10 <= batchSizeCounter_tDBOutput_10)) {

										insertedCount_tDBOutput_10 = new LimitBytesHelper_tDBOutput_10()
												.limitBytePart1(insertedCount_tDBOutput_10, pstmt_tDBOutput_10);
										rowsToCommitCount_tDBOutput_10 = insertedCount_tDBOutput_10;

										batchSizeCounter_tDBOutput_10 = 0;
									}

									//////////// commit every////////////

									commitCounter_tDBOutput_10++;
									if (commitEvery_tDBOutput_10 <= commitCounter_tDBOutput_10) {
										if ((batchSize_tDBOutput_10 > 0) && (batchSizeCounter_tDBOutput_10 > 0)) {

											insertedCount_tDBOutput_10 = new LimitBytesHelper_tDBOutput_10()
													.limitBytePart1(insertedCount_tDBOutput_10, pstmt_tDBOutput_10);

											batchSizeCounter_tDBOutput_10 = 0;
										}
										if (rowsToCommitCount_tDBOutput_10 != 0) {

											if (log.isDebugEnabled())
												log.debug("tDBOutput_10 - " + ("Connection starting to commit ")
														+ (rowsToCommitCount_tDBOutput_10) + (" record(s)."));
										}
										conn_tDBOutput_10.commit();
										if (rowsToCommitCount_tDBOutput_10 != 0) {

											if (log.isDebugEnabled())
												log.debug("tDBOutput_10 - " + ("Connection commit has succeeded."));
											rowsToCommitCount_tDBOutput_10 = 0;
										}
										commitCounter_tDBOutput_10 = 0;
									}

									tos_count_tDBOutput_10++;

									/**
									 * [tDBOutput_10 main ] stop
									 */

									/**
									 * [tDBOutput_10 process_data_begin ] start
									 */

									currentComponent = "tDBOutput_10";

									/**
									 * [tDBOutput_10 process_data_begin ] stop
									 */

									/**
									 * [tDBOutput_10 process_data_end ] start
									 */

									currentComponent = "tDBOutput_10";

									/**
									 * [tDBOutput_10 process_data_end ] stop
									 */

								} // End of branch "PublicPropertyDamage2"

								/**
								 * [tMap_11 process_data_end ] start
								 */

								currentComponent = "tMap_11";

								/**
								 * [tMap_11 process_data_end ] stop
								 */

							} // End of branch "row11"

							/**
							 * [tUniqRow_10 process_data_end ] start
							 */

							currentComponent = "tUniqRow_10";

							/**
							 * [tUniqRow_10 process_data_end ] stop
							 */

						} // End of branch "Public_propertyDamage"

						/**
						 * [tMap_1 process_data_end ] start
						 */

						currentComponent = "tMap_1";

						/**
						 * [tMap_1 process_data_end ] stop
						 */

						/**
						 * [tDBInput_1 process_data_end ] start
						 */

						currentComponent = "tDBInput_1";

						/**
						 * [tDBInput_1 process_data_end ] stop
						 */

						/**
						 * [tDBInput_1 end ] start
						 */

						currentComponent = "tDBInput_1";

					}
				} finally {
					if (rs_tDBInput_1 != null) {
						rs_tDBInput_1.close();
					}
					if (stmt_tDBInput_1 != null) {
						stmt_tDBInput_1.close();
					}
					if (conn_tDBInput_1 != null && !conn_tDBInput_1.isClosed()) {

						log.debug("tDBInput_1 - Closing the connection to the database.");

						conn_tDBInput_1.close();

						if ("com.mysql.cj.jdbc.Driver".equals((String) globalMap.get("driverClass_"))
								&& routines.system.BundleUtils.inOSGi()) {
							Class.forName("com.mysql.cj.jdbc.AbandonedConnectionCleanupThread")
									.getMethod("checkedShutdown").invoke(null, (Object[]) null);
						}

						log.debug("tDBInput_1 - Connection to the database closed.");

					}
				}
				globalMap.put("tDBInput_1_NB_LINE", nb_line_tDBInput_1);
				log.debug("tDBInput_1 - Retrieved records count: " + nb_line_tDBInput_1 + " .");

				if (log.isDebugEnabled())
					log.debug("tDBInput_1 - " + ("Done."));

				ok_Hash.put("tDBInput_1", true);
				end_Hash.put("tDBInput_1", System.currentTimeMillis());

				/**
				 * [tDBInput_1 end ] stop
				 */

				/**
				 * [tMap_1 end ] start
				 */

				currentComponent = "tMap_1";

// ###############################
// # Lookup hashes releasing
// ###############################      
				log.debug("tMap_1 - Written records count in the table 'State_Registration_Sk': "
						+ count_State_Registration_Sk_tMap_1 + ".");
				log.debug("tMap_1 - Written records count in the table 'Vehicle_type': " + count_Vehicle_type_tMap_1
						+ ".");
				log.debug("tMap_1 - Written records count in the table 'Vehicle_Make': " + count_Vehicle_Make_tMap_1
						+ ".");
				log.debug("tMap_1 - Written records count in the table 'Vehicle_Model': " + count_Vehicle_Model_tMap_1
						+ ".");
				log.debug("tMap_1 - Written records count in the table 'Travel_Direction': "
						+ count_Travel_Direction_tMap_1 + ".");
				log.debug("tMap_1 - Written records count in the table 'Driver_License_Status': "
						+ count_Driver_License_Status_tMap_1 + ".");
				log.debug("tMap_1 - Written records count in the table 'Driver_License_Jusridiction': "
						+ count_Driver_License_Jusridiction_tMap_1 + ".");
				log.debug("tMap_1 - Written records count in the table 'PreCash': " + count_PreCash_tMap_1 + ".");
				log.debug("tMap_1 - Written records count in the table 'Point_Of_Impact': "
						+ count_Point_Of_Impact_tMap_1 + ".");
				log.debug("tMap_1 - Written records count in the table 'Public_propertyDamage': "
						+ count_Public_propertyDamage_tMap_1 + ".");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "row1", 2, 0,
						"tDBInput_1", "__TABLE__", "tMSSqlInput", "tMap_1", "tMap_1", "tMap", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tMap_1 - " + ("Done."));

				ok_Hash.put("tMap_1", true);
				end_Hash.put("tMap_1", System.currentTimeMillis());

				/**
				 * [tMap_1 end ] stop
				 */

				/**
				 * [tUniqRow_1 end ] start
				 */

				currentComponent = "tUniqRow_1";

				globalMap.put("tUniqRow_1_NB_UNIQUES", nb_uniques_tUniqRow_1);
				globalMap.put("tUniqRow_1_NB_DUPLICATES", nb_duplicates_tUniqRow_1);
				log.info("tUniqRow_1 - Unique records count: " + (nb_uniques_tUniqRow_1) + " .");
				log.info("tUniqRow_1 - Duplicate records count: " + (nb_duplicates_tUniqRow_1) + " .");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "State_Registration_Sk",
						2, 0, "tMap_1", "tMap_1", "tMap", "tUniqRow_1", "tUniqRow_1", "tUniqRow", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tUniqRow_1 - " + ("Done."));

				ok_Hash.put("tUniqRow_1", true);
				end_Hash.put("tUniqRow_1", System.currentTimeMillis());

				/**
				 * [tUniqRow_1 end ] stop
				 */

				/**
				 * [tMap_2 end ] start
				 */

				currentComponent = "tMap_2";

// ###############################
// # Lookup hashes releasing
// ###############################      
				log.debug("tMap_2 - Written records count in the table 'State_Reg2': " + count_State_Reg2_tMap_2 + ".");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "row2", 2, 0,
						"tUniqRow_1", "tUniqRow_1", "tUniqRow", "tMap_2", "tMap_2", "tMap", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tMap_2 - " + ("Done."));

				ok_Hash.put("tMap_2", true);
				end_Hash.put("tMap_2", System.currentTimeMillis());

				/**
				 * [tMap_2 end ] stop
				 */

				/**
				 * [tDBOutput_1 end ] start
				 */

				currentComponent = "tDBOutput_1";

				try {
					int countSum_tDBOutput_1 = 0;
					if (pstmt_tDBOutput_1 != null && batchSizeCounter_tDBOutput_1 > 0) {

						if (log.isDebugEnabled())
							log.debug("tDBOutput_1 - " + ("Executing the ") + ("INSERT") + (" batch."));
						for (int countEach_tDBOutput_1 : pstmt_tDBOutput_1.executeBatch()) {
							if (countEach_tDBOutput_1 == -2 || countEach_tDBOutput_1 == -3) {
								break;
							}
							countSum_tDBOutput_1 += countEach_tDBOutput_1;
						}
						rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;

						if (log.isDebugEnabled())
							log.debug("tDBOutput_1 - " + ("The ") + ("INSERT") + (" batch execution has succeeded."));
					}

					insertedCount_tDBOutput_1 += countSum_tDBOutput_1;

				} catch (java.sql.BatchUpdateException e) {
					globalMap.put("tDBOutput_1_ERROR_MESSAGE", e.getMessage());

					int countSum_tDBOutput_1 = 0;
					for (int countEach_tDBOutput_1 : e.getUpdateCounts()) {
						countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
					}
					rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;

					insertedCount_tDBOutput_1 += countSum_tDBOutput_1;

					log.error("tDBOutput_1 - " + (e.getMessage()));
					System.err.println(e.getMessage());

				}
				if (pstmt_tDBOutput_1 != null) {

					pstmt_tDBOutput_1.close();
					resourceMap.remove("pstmt_tDBOutput_1");

				}
				resourceMap.put("statementClosed_tDBOutput_1", true);
				if (rowsToCommitCount_tDBOutput_1 != 0) {

					if (log.isDebugEnabled())
						log.debug("tDBOutput_1 - " + ("Connection starting to commit ")
								+ (rowsToCommitCount_tDBOutput_1) + (" record(s)."));
				}
				conn_tDBOutput_1.commit();
				if (rowsToCommitCount_tDBOutput_1 != 0) {

					if (log.isDebugEnabled())
						log.debug("tDBOutput_1 - " + ("Connection commit has succeeded."));
					rowsToCommitCount_tDBOutput_1 = 0;
				}
				commitCounter_tDBOutput_1 = 0;
				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Closing the connection to the database."));
				conn_tDBOutput_1.close();
				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Connection to the database has closed."));
				resourceMap.put("finish_tDBOutput_1", true);

				nb_line_deleted_tDBOutput_1 = nb_line_deleted_tDBOutput_1 + deletedCount_tDBOutput_1;
				nb_line_update_tDBOutput_1 = nb_line_update_tDBOutput_1 + updatedCount_tDBOutput_1;
				nb_line_inserted_tDBOutput_1 = nb_line_inserted_tDBOutput_1 + insertedCount_tDBOutput_1;
				nb_line_rejected_tDBOutput_1 = nb_line_rejected_tDBOutput_1 + rejectedCount_tDBOutput_1;

				globalMap.put("tDBOutput_1_NB_LINE", nb_line_tDBOutput_1);
				globalMap.put("tDBOutput_1_NB_LINE_UPDATED", nb_line_update_tDBOutput_1);
				globalMap.put("tDBOutput_1_NB_LINE_INSERTED", nb_line_inserted_tDBOutput_1);
				globalMap.put("tDBOutput_1_NB_LINE_DELETED", nb_line_deleted_tDBOutput_1);
				globalMap.put("tDBOutput_1_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_1);

				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Has ") + ("inserted") + (" ") + (nb_line_inserted_tDBOutput_1)
							+ (" record(s)."));

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "State_Reg2", 2, 0,
						"tMap_2", "tMap_2", "tMap", "tDBOutput_1", "__TABLE__", "tMSSqlOutput", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Done."));

				ok_Hash.put("tDBOutput_1", true);
				end_Hash.put("tDBOutput_1", System.currentTimeMillis());

				/**
				 * [tDBOutput_1 end ] stop
				 */

				/**
				 * [tUniqRow_2 end ] start
				 */

				currentComponent = "tUniqRow_2";

				globalMap.put("tUniqRow_2_NB_UNIQUES", nb_uniques_tUniqRow_2);
				globalMap.put("tUniqRow_2_NB_DUPLICATES", nb_duplicates_tUniqRow_2);
				log.info("tUniqRow_2 - Unique records count: " + (nb_uniques_tUniqRow_2) + " .");
				log.info("tUniqRow_2 - Duplicate records count: " + (nb_duplicates_tUniqRow_2) + " .");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "Vehicle_type", 2, 0,
						"tMap_1", "tMap_1", "tMap", "tUniqRow_2", "tUniqRow_2", "tUniqRow", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tUniqRow_2 - " + ("Done."));

				ok_Hash.put("tUniqRow_2", true);
				end_Hash.put("tUniqRow_2", System.currentTimeMillis());

				/**
				 * [tUniqRow_2 end ] stop
				 */

				/**
				 * [tMap_3 end ] start
				 */

				currentComponent = "tMap_3";

// ###############################
// # Lookup hashes releasing
// ###############################      
				log.debug("tMap_3 - Written records count in the table 'Vehicle_Type2': " + count_Vehicle_Type2_tMap_3
						+ ".");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "row3", 2, 0,
						"tUniqRow_2", "tUniqRow_2", "tUniqRow", "tMap_3", "tMap_3", "tMap", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tMap_3 - " + ("Done."));

				ok_Hash.put("tMap_3", true);
				end_Hash.put("tMap_3", System.currentTimeMillis());

				/**
				 * [tMap_3 end ] stop
				 */

				/**
				 * [tDBOutput_2 end ] start
				 */

				currentComponent = "tDBOutput_2";

				try {
					int countSum_tDBOutput_2 = 0;
					if (pstmt_tDBOutput_2 != null && batchSizeCounter_tDBOutput_2 > 0) {

						if (log.isDebugEnabled())
							log.debug("tDBOutput_2 - " + ("Executing the ") + ("INSERT") + (" batch."));
						for (int countEach_tDBOutput_2 : pstmt_tDBOutput_2.executeBatch()) {
							if (countEach_tDBOutput_2 == -2 || countEach_tDBOutput_2 == -3) {
								break;
							}
							countSum_tDBOutput_2 += countEach_tDBOutput_2;
						}
						rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;

						if (log.isDebugEnabled())
							log.debug("tDBOutput_2 - " + ("The ") + ("INSERT") + (" batch execution has succeeded."));
					}

					insertedCount_tDBOutput_2 += countSum_tDBOutput_2;

				} catch (java.sql.BatchUpdateException e) {
					globalMap.put("tDBOutput_2_ERROR_MESSAGE", e.getMessage());

					int countSum_tDBOutput_2 = 0;
					for (int countEach_tDBOutput_2 : e.getUpdateCounts()) {
						countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
					}
					rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;

					insertedCount_tDBOutput_2 += countSum_tDBOutput_2;

					log.error("tDBOutput_2 - " + (e.getMessage()));
					System.err.println(e.getMessage());

				}
				if (pstmt_tDBOutput_2 != null) {

					pstmt_tDBOutput_2.close();
					resourceMap.remove("pstmt_tDBOutput_2");

				}
				resourceMap.put("statementClosed_tDBOutput_2", true);
				if (rowsToCommitCount_tDBOutput_2 != 0) {

					if (log.isDebugEnabled())
						log.debug("tDBOutput_2 - " + ("Connection starting to commit ")
								+ (rowsToCommitCount_tDBOutput_2) + (" record(s)."));
				}
				conn_tDBOutput_2.commit();
				if (rowsToCommitCount_tDBOutput_2 != 0) {

					if (log.isDebugEnabled())
						log.debug("tDBOutput_2 - " + ("Connection commit has succeeded."));
					rowsToCommitCount_tDBOutput_2 = 0;
				}
				commitCounter_tDBOutput_2 = 0;
				if (log.isDebugEnabled())
					log.debug("tDBOutput_2 - " + ("Closing the connection to the database."));
				conn_tDBOutput_2.close();
				if (log.isDebugEnabled())
					log.debug("tDBOutput_2 - " + ("Connection to the database has closed."));
				resourceMap.put("finish_tDBOutput_2", true);

				nb_line_deleted_tDBOutput_2 = nb_line_deleted_tDBOutput_2 + deletedCount_tDBOutput_2;
				nb_line_update_tDBOutput_2 = nb_line_update_tDBOutput_2 + updatedCount_tDBOutput_2;
				nb_line_inserted_tDBOutput_2 = nb_line_inserted_tDBOutput_2 + insertedCount_tDBOutput_2;
				nb_line_rejected_tDBOutput_2 = nb_line_rejected_tDBOutput_2 + rejectedCount_tDBOutput_2;

				globalMap.put("tDBOutput_2_NB_LINE", nb_line_tDBOutput_2);
				globalMap.put("tDBOutput_2_NB_LINE_UPDATED", nb_line_update_tDBOutput_2);
				globalMap.put("tDBOutput_2_NB_LINE_INSERTED", nb_line_inserted_tDBOutput_2);
				globalMap.put("tDBOutput_2_NB_LINE_DELETED", nb_line_deleted_tDBOutput_2);
				globalMap.put("tDBOutput_2_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_2);

				if (log.isDebugEnabled())
					log.debug("tDBOutput_2 - " + ("Has ") + ("inserted") + (" ") + (nb_line_inserted_tDBOutput_2)
							+ (" record(s)."));

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "Vehicle_Type2", 2, 0,
						"tMap_3", "tMap_3", "tMap", "tDBOutput_2", "__TABLE__", "tMSSqlOutput", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tDBOutput_2 - " + ("Done."));

				ok_Hash.put("tDBOutput_2", true);
				end_Hash.put("tDBOutput_2", System.currentTimeMillis());

				/**
				 * [tDBOutput_2 end ] stop
				 */

				/**
				 * [tUniqRow_3 end ] start
				 */

				currentComponent = "tUniqRow_3";

				globalMap.put("tUniqRow_3_NB_UNIQUES", nb_uniques_tUniqRow_3);
				globalMap.put("tUniqRow_3_NB_DUPLICATES", nb_duplicates_tUniqRow_3);
				log.info("tUniqRow_3 - Unique records count: " + (nb_uniques_tUniqRow_3) + " .");
				log.info("tUniqRow_3 - Duplicate records count: " + (nb_duplicates_tUniqRow_3) + " .");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "Vehicle_Make", 2, 0,
						"tMap_1", "tMap_1", "tMap", "tUniqRow_3", "tUniqRow_3", "tUniqRow", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tUniqRow_3 - " + ("Done."));

				ok_Hash.put("tUniqRow_3", true);
				end_Hash.put("tUniqRow_3", System.currentTimeMillis());

				/**
				 * [tUniqRow_3 end ] stop
				 */

				/**
				 * [tMap_4 end ] start
				 */

				currentComponent = "tMap_4";

// ###############################
// # Lookup hashes releasing
// ###############################      
				log.debug("tMap_4 - Written records count in the table 'Vehicle_Make2': " + count_Vehicle_Make2_tMap_4
						+ ".");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "row4", 2, 0,
						"tUniqRow_3", "tUniqRow_3", "tUniqRow", "tMap_4", "tMap_4", "tMap", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tMap_4 - " + ("Done."));

				ok_Hash.put("tMap_4", true);
				end_Hash.put("tMap_4", System.currentTimeMillis());

				/**
				 * [tMap_4 end ] stop
				 */

				/**
				 * [tDBOutput_3 end ] start
				 */

				currentComponent = "tDBOutput_3";

				try {
					int countSum_tDBOutput_3 = 0;
					if (pstmt_tDBOutput_3 != null && batchSizeCounter_tDBOutput_3 > 0) {

						if (log.isDebugEnabled())
							log.debug("tDBOutput_3 - " + ("Executing the ") + ("INSERT") + (" batch."));
						for (int countEach_tDBOutput_3 : pstmt_tDBOutput_3.executeBatch()) {
							if (countEach_tDBOutput_3 == -2 || countEach_tDBOutput_3 == -3) {
								break;
							}
							countSum_tDBOutput_3 += countEach_tDBOutput_3;
						}
						rowsToCommitCount_tDBOutput_3 += countSum_tDBOutput_3;

						if (log.isDebugEnabled())
							log.debug("tDBOutput_3 - " + ("The ") + ("INSERT") + (" batch execution has succeeded."));
					}

					insertedCount_tDBOutput_3 += countSum_tDBOutput_3;

				} catch (java.sql.BatchUpdateException e) {
					globalMap.put("tDBOutput_3_ERROR_MESSAGE", e.getMessage());

					int countSum_tDBOutput_3 = 0;
					for (int countEach_tDBOutput_3 : e.getUpdateCounts()) {
						countSum_tDBOutput_3 += (countEach_tDBOutput_3 < 0 ? 0 : countEach_tDBOutput_3);
					}
					rowsToCommitCount_tDBOutput_3 += countSum_tDBOutput_3;

					insertedCount_tDBOutput_3 += countSum_tDBOutput_3;

					log.error("tDBOutput_3 - " + (e.getMessage()));
					System.err.println(e.getMessage());

				}
				if (pstmt_tDBOutput_3 != null) {

					pstmt_tDBOutput_3.close();
					resourceMap.remove("pstmt_tDBOutput_3");

				}
				resourceMap.put("statementClosed_tDBOutput_3", true);
				if (rowsToCommitCount_tDBOutput_3 != 0) {

					if (log.isDebugEnabled())
						log.debug("tDBOutput_3 - " + ("Connection starting to commit ")
								+ (rowsToCommitCount_tDBOutput_3) + (" record(s)."));
				}
				conn_tDBOutput_3.commit();
				if (rowsToCommitCount_tDBOutput_3 != 0) {

					if (log.isDebugEnabled())
						log.debug("tDBOutput_3 - " + ("Connection commit has succeeded."));
					rowsToCommitCount_tDBOutput_3 = 0;
				}
				commitCounter_tDBOutput_3 = 0;
				if (log.isDebugEnabled())
					log.debug("tDBOutput_3 - " + ("Closing the connection to the database."));
				conn_tDBOutput_3.close();
				if (log.isDebugEnabled())
					log.debug("tDBOutput_3 - " + ("Connection to the database has closed."));
				resourceMap.put("finish_tDBOutput_3", true);

				nb_line_deleted_tDBOutput_3 = nb_line_deleted_tDBOutput_3 + deletedCount_tDBOutput_3;
				nb_line_update_tDBOutput_3 = nb_line_update_tDBOutput_3 + updatedCount_tDBOutput_3;
				nb_line_inserted_tDBOutput_3 = nb_line_inserted_tDBOutput_3 + insertedCount_tDBOutput_3;
				nb_line_rejected_tDBOutput_3 = nb_line_rejected_tDBOutput_3 + rejectedCount_tDBOutput_3;

				globalMap.put("tDBOutput_3_NB_LINE", nb_line_tDBOutput_3);
				globalMap.put("tDBOutput_3_NB_LINE_UPDATED", nb_line_update_tDBOutput_3);
				globalMap.put("tDBOutput_3_NB_LINE_INSERTED", nb_line_inserted_tDBOutput_3);
				globalMap.put("tDBOutput_3_NB_LINE_DELETED", nb_line_deleted_tDBOutput_3);
				globalMap.put("tDBOutput_3_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_3);

				if (log.isDebugEnabled())
					log.debug("tDBOutput_3 - " + ("Has ") + ("inserted") + (" ") + (nb_line_inserted_tDBOutput_3)
							+ (" record(s)."));

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "Vehicle_Make2", 2, 0,
						"tMap_4", "tMap_4", "tMap", "tDBOutput_3", "__TABLE__", "tMSSqlOutput", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tDBOutput_3 - " + ("Done."));

				ok_Hash.put("tDBOutput_3", true);
				end_Hash.put("tDBOutput_3", System.currentTimeMillis());

				/**
				 * [tDBOutput_3 end ] stop
				 */

				/**
				 * [tUniqRow_4 end ] start
				 */

				currentComponent = "tUniqRow_4";

				globalMap.put("tUniqRow_4_NB_UNIQUES", nb_uniques_tUniqRow_4);
				globalMap.put("tUniqRow_4_NB_DUPLICATES", nb_duplicates_tUniqRow_4);
				log.info("tUniqRow_4 - Unique records count: " + (nb_uniques_tUniqRow_4) + " .");
				log.info("tUniqRow_4 - Duplicate records count: " + (nb_duplicates_tUniqRow_4) + " .");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "Vehicle_Model", 2, 0,
						"tMap_1", "tMap_1", "tMap", "tUniqRow_4", "tUniqRow_4", "tUniqRow", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tUniqRow_4 - " + ("Done."));

				ok_Hash.put("tUniqRow_4", true);
				end_Hash.put("tUniqRow_4", System.currentTimeMillis());

				/**
				 * [tUniqRow_4 end ] stop
				 */

				/**
				 * [tMap_5 end ] start
				 */

				currentComponent = "tMap_5";

// ###############################
// # Lookup hashes releasing
// ###############################      
				log.debug("tMap_5 - Written records count in the table 'Vehicle_Model1': " + count_Vehicle_Model1_tMap_5
						+ ".");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "row5", 2, 0,
						"tUniqRow_4", "tUniqRow_4", "tUniqRow", "tMap_5", "tMap_5", "tMap", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tMap_5 - " + ("Done."));

				ok_Hash.put("tMap_5", true);
				end_Hash.put("tMap_5", System.currentTimeMillis());

				/**
				 * [tMap_5 end ] stop
				 */

				/**
				 * [tDBOutput_4 end ] start
				 */

				currentComponent = "tDBOutput_4";

				try {
					int countSum_tDBOutput_4 = 0;
					if (pstmt_tDBOutput_4 != null && batchSizeCounter_tDBOutput_4 > 0) {

						if (log.isDebugEnabled())
							log.debug("tDBOutput_4 - " + ("Executing the ") + ("INSERT") + (" batch."));
						for (int countEach_tDBOutput_4 : pstmt_tDBOutput_4.executeBatch()) {
							if (countEach_tDBOutput_4 == -2 || countEach_tDBOutput_4 == -3) {
								break;
							}
							countSum_tDBOutput_4 += countEach_tDBOutput_4;
						}
						rowsToCommitCount_tDBOutput_4 += countSum_tDBOutput_4;

						if (log.isDebugEnabled())
							log.debug("tDBOutput_4 - " + ("The ") + ("INSERT") + (" batch execution has succeeded."));
					}

					insertedCount_tDBOutput_4 += countSum_tDBOutput_4;

				} catch (java.sql.BatchUpdateException e) {
					globalMap.put("tDBOutput_4_ERROR_MESSAGE", e.getMessage());

					int countSum_tDBOutput_4 = 0;
					for (int countEach_tDBOutput_4 : e.getUpdateCounts()) {
						countSum_tDBOutput_4 += (countEach_tDBOutput_4 < 0 ? 0 : countEach_tDBOutput_4);
					}
					rowsToCommitCount_tDBOutput_4 += countSum_tDBOutput_4;

					insertedCount_tDBOutput_4 += countSum_tDBOutput_4;

					log.error("tDBOutput_4 - " + (e.getMessage()));
					System.err.println(e.getMessage());

				}
				if (pstmt_tDBOutput_4 != null) {

					pstmt_tDBOutput_4.close();
					resourceMap.remove("pstmt_tDBOutput_4");

				}
				resourceMap.put("statementClosed_tDBOutput_4", true);
				if (rowsToCommitCount_tDBOutput_4 != 0) {

					if (log.isDebugEnabled())
						log.debug("tDBOutput_4 - " + ("Connection starting to commit ")
								+ (rowsToCommitCount_tDBOutput_4) + (" record(s)."));
				}
				conn_tDBOutput_4.commit();
				if (rowsToCommitCount_tDBOutput_4 != 0) {

					if (log.isDebugEnabled())
						log.debug("tDBOutput_4 - " + ("Connection commit has succeeded."));
					rowsToCommitCount_tDBOutput_4 = 0;
				}
				commitCounter_tDBOutput_4 = 0;
				if (log.isDebugEnabled())
					log.debug("tDBOutput_4 - " + ("Closing the connection to the database."));
				conn_tDBOutput_4.close();
				if (log.isDebugEnabled())
					log.debug("tDBOutput_4 - " + ("Connection to the database has closed."));
				resourceMap.put("finish_tDBOutput_4", true);

				nb_line_deleted_tDBOutput_4 = nb_line_deleted_tDBOutput_4 + deletedCount_tDBOutput_4;
				nb_line_update_tDBOutput_4 = nb_line_update_tDBOutput_4 + updatedCount_tDBOutput_4;
				nb_line_inserted_tDBOutput_4 = nb_line_inserted_tDBOutput_4 + insertedCount_tDBOutput_4;
				nb_line_rejected_tDBOutput_4 = nb_line_rejected_tDBOutput_4 + rejectedCount_tDBOutput_4;

				globalMap.put("tDBOutput_4_NB_LINE", nb_line_tDBOutput_4);
				globalMap.put("tDBOutput_4_NB_LINE_UPDATED", nb_line_update_tDBOutput_4);
				globalMap.put("tDBOutput_4_NB_LINE_INSERTED", nb_line_inserted_tDBOutput_4);
				globalMap.put("tDBOutput_4_NB_LINE_DELETED", nb_line_deleted_tDBOutput_4);
				globalMap.put("tDBOutput_4_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_4);

				if (log.isDebugEnabled())
					log.debug("tDBOutput_4 - " + ("Has ") + ("inserted") + (" ") + (nb_line_inserted_tDBOutput_4)
							+ (" record(s)."));

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "Vehicle_Model1", 2, 0,
						"tMap_5", "tMap_5", "tMap", "tDBOutput_4", "__TABLE__", "tMSSqlOutput", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tDBOutput_4 - " + ("Done."));

				ok_Hash.put("tDBOutput_4", true);
				end_Hash.put("tDBOutput_4", System.currentTimeMillis());

				/**
				 * [tDBOutput_4 end ] stop
				 */

				/**
				 * [tUniqRow_5 end ] start
				 */

				currentComponent = "tUniqRow_5";

				globalMap.put("tUniqRow_5_NB_UNIQUES", nb_uniques_tUniqRow_5);
				globalMap.put("tUniqRow_5_NB_DUPLICATES", nb_duplicates_tUniqRow_5);
				log.info("tUniqRow_5 - Unique records count: " + (nb_uniques_tUniqRow_5) + " .");
				log.info("tUniqRow_5 - Duplicate records count: " + (nb_duplicates_tUniqRow_5) + " .");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "Travel_Direction", 2, 0,
						"tMap_1", "tMap_1", "tMap", "tUniqRow_5", "tUniqRow_5", "tUniqRow", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tUniqRow_5 - " + ("Done."));

				ok_Hash.put("tUniqRow_5", true);
				end_Hash.put("tUniqRow_5", System.currentTimeMillis());

				/**
				 * [tUniqRow_5 end ] stop
				 */

				/**
				 * [tMap_6 end ] start
				 */

				currentComponent = "tMap_6";

// ###############################
// # Lookup hashes releasing
// ###############################      
				log.debug("tMap_6 - Written records count in the table 'Travel_Direction_Loadd': "
						+ count_Travel_Direction_Loadd_tMap_6 + ".");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "row6", 2, 0,
						"tUniqRow_5", "tUniqRow_5", "tUniqRow", "tMap_6", "tMap_6", "tMap", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tMap_6 - " + ("Done."));

				ok_Hash.put("tMap_6", true);
				end_Hash.put("tMap_6", System.currentTimeMillis());

				/**
				 * [tMap_6 end ] stop
				 */

				/**
				 * [tDBOutput_5 end ] start
				 */

				currentComponent = "tDBOutput_5";

				try {
					int countSum_tDBOutput_5 = 0;
					if (pstmt_tDBOutput_5 != null && batchSizeCounter_tDBOutput_5 > 0) {

						if (log.isDebugEnabled())
							log.debug("tDBOutput_5 - " + ("Executing the ") + ("INSERT") + (" batch."));
						for (int countEach_tDBOutput_5 : pstmt_tDBOutput_5.executeBatch()) {
							if (countEach_tDBOutput_5 == -2 || countEach_tDBOutput_5 == -3) {
								break;
							}
							countSum_tDBOutput_5 += countEach_tDBOutput_5;
						}
						rowsToCommitCount_tDBOutput_5 += countSum_tDBOutput_5;

						if (log.isDebugEnabled())
							log.debug("tDBOutput_5 - " + ("The ") + ("INSERT") + (" batch execution has succeeded."));
					}

					insertedCount_tDBOutput_5 += countSum_tDBOutput_5;

				} catch (java.sql.BatchUpdateException e) {
					globalMap.put("tDBOutput_5_ERROR_MESSAGE", e.getMessage());

					int countSum_tDBOutput_5 = 0;
					for (int countEach_tDBOutput_5 : e.getUpdateCounts()) {
						countSum_tDBOutput_5 += (countEach_tDBOutput_5 < 0 ? 0 : countEach_tDBOutput_5);
					}
					rowsToCommitCount_tDBOutput_5 += countSum_tDBOutput_5;

					insertedCount_tDBOutput_5 += countSum_tDBOutput_5;

					log.error("tDBOutput_5 - " + (e.getMessage()));
					System.err.println(e.getMessage());

				}
				if (pstmt_tDBOutput_5 != null) {

					pstmt_tDBOutput_5.close();
					resourceMap.remove("pstmt_tDBOutput_5");

				}
				resourceMap.put("statementClosed_tDBOutput_5", true);
				if (rowsToCommitCount_tDBOutput_5 != 0) {

					if (log.isDebugEnabled())
						log.debug("tDBOutput_5 - " + ("Connection starting to commit ")
								+ (rowsToCommitCount_tDBOutput_5) + (" record(s)."));
				}
				conn_tDBOutput_5.commit();
				if (rowsToCommitCount_tDBOutput_5 != 0) {

					if (log.isDebugEnabled())
						log.debug("tDBOutput_5 - " + ("Connection commit has succeeded."));
					rowsToCommitCount_tDBOutput_5 = 0;
				}
				commitCounter_tDBOutput_5 = 0;
				if (log.isDebugEnabled())
					log.debug("tDBOutput_5 - " + ("Closing the connection to the database."));
				conn_tDBOutput_5.close();
				if (log.isDebugEnabled())
					log.debug("tDBOutput_5 - " + ("Connection to the database has closed."));
				resourceMap.put("finish_tDBOutput_5", true);

				nb_line_deleted_tDBOutput_5 = nb_line_deleted_tDBOutput_5 + deletedCount_tDBOutput_5;
				nb_line_update_tDBOutput_5 = nb_line_update_tDBOutput_5 + updatedCount_tDBOutput_5;
				nb_line_inserted_tDBOutput_5 = nb_line_inserted_tDBOutput_5 + insertedCount_tDBOutput_5;
				nb_line_rejected_tDBOutput_5 = nb_line_rejected_tDBOutput_5 + rejectedCount_tDBOutput_5;

				globalMap.put("tDBOutput_5_NB_LINE", nb_line_tDBOutput_5);
				globalMap.put("tDBOutput_5_NB_LINE_UPDATED", nb_line_update_tDBOutput_5);
				globalMap.put("tDBOutput_5_NB_LINE_INSERTED", nb_line_inserted_tDBOutput_5);
				globalMap.put("tDBOutput_5_NB_LINE_DELETED", nb_line_deleted_tDBOutput_5);
				globalMap.put("tDBOutput_5_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_5);

				if (log.isDebugEnabled())
					log.debug("tDBOutput_5 - " + ("Has ") + ("inserted") + (" ") + (nb_line_inserted_tDBOutput_5)
							+ (" record(s)."));

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "Travel_Direction_Loadd",
						2, 0, "tMap_6", "tMap_6", "tMap", "tDBOutput_5", "__TABLE__", "tMSSqlOutput", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tDBOutput_5 - " + ("Done."));

				ok_Hash.put("tDBOutput_5", true);
				end_Hash.put("tDBOutput_5", System.currentTimeMillis());

				/**
				 * [tDBOutput_5 end ] stop
				 */

				/**
				 * [tUniqRow_6 end ] start
				 */

				currentComponent = "tUniqRow_6";

				globalMap.put("tUniqRow_6_NB_UNIQUES", nb_uniques_tUniqRow_6);
				globalMap.put("tUniqRow_6_NB_DUPLICATES", nb_duplicates_tUniqRow_6);
				log.info("tUniqRow_6 - Unique records count: " + (nb_uniques_tUniqRow_6) + " .");
				log.info("tUniqRow_6 - Duplicate records count: " + (nb_duplicates_tUniqRow_6) + " .");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "Driver_License_Status",
						2, 0, "tMap_1", "tMap_1", "tMap", "tUniqRow_6", "tUniqRow_6", "tUniqRow", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tUniqRow_6 - " + ("Done."));

				ok_Hash.put("tUniqRow_6", true);
				end_Hash.put("tUniqRow_6", System.currentTimeMillis());

				/**
				 * [tUniqRow_6 end ] stop
				 */

				/**
				 * [tMap_7 end ] start
				 */

				currentComponent = "tMap_7";

// ###############################
// # Lookup hashes releasing
// ###############################      
				log.debug("tMap_7 - Written records count in the table 'Driver_License_Status_2': "
						+ count_Driver_License_Status_2_tMap_7 + ".");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "row7", 2, 0,
						"tUniqRow_6", "tUniqRow_6", "tUniqRow", "tMap_7", "tMap_7", "tMap", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tMap_7 - " + ("Done."));

				ok_Hash.put("tMap_7", true);
				end_Hash.put("tMap_7", System.currentTimeMillis());

				/**
				 * [tMap_7 end ] stop
				 */

				/**
				 * [tDBOutput_6 end ] start
				 */

				currentComponent = "tDBOutput_6";

				try {
					int countSum_tDBOutput_6 = 0;
					if (pstmt_tDBOutput_6 != null && batchSizeCounter_tDBOutput_6 > 0) {

						if (log.isDebugEnabled())
							log.debug("tDBOutput_6 - " + ("Executing the ") + ("INSERT") + (" batch."));
						for (int countEach_tDBOutput_6 : pstmt_tDBOutput_6.executeBatch()) {
							if (countEach_tDBOutput_6 == -2 || countEach_tDBOutput_6 == -3) {
								break;
							}
							countSum_tDBOutput_6 += countEach_tDBOutput_6;
						}
						rowsToCommitCount_tDBOutput_6 += countSum_tDBOutput_6;

						if (log.isDebugEnabled())
							log.debug("tDBOutput_6 - " + ("The ") + ("INSERT") + (" batch execution has succeeded."));
					}

					insertedCount_tDBOutput_6 += countSum_tDBOutput_6;

				} catch (java.sql.BatchUpdateException e) {
					globalMap.put("tDBOutput_6_ERROR_MESSAGE", e.getMessage());

					int countSum_tDBOutput_6 = 0;
					for (int countEach_tDBOutput_6 : e.getUpdateCounts()) {
						countSum_tDBOutput_6 += (countEach_tDBOutput_6 < 0 ? 0 : countEach_tDBOutput_6);
					}
					rowsToCommitCount_tDBOutput_6 += countSum_tDBOutput_6;

					insertedCount_tDBOutput_6 += countSum_tDBOutput_6;

					log.error("tDBOutput_6 - " + (e.getMessage()));
					System.err.println(e.getMessage());

				}
				if (pstmt_tDBOutput_6 != null) {

					pstmt_tDBOutput_6.close();
					resourceMap.remove("pstmt_tDBOutput_6");

				}
				resourceMap.put("statementClosed_tDBOutput_6", true);
				if (rowsToCommitCount_tDBOutput_6 != 0) {

					if (log.isDebugEnabled())
						log.debug("tDBOutput_6 - " + ("Connection starting to commit ")
								+ (rowsToCommitCount_tDBOutput_6) + (" record(s)."));
				}
				conn_tDBOutput_6.commit();
				if (rowsToCommitCount_tDBOutput_6 != 0) {

					if (log.isDebugEnabled())
						log.debug("tDBOutput_6 - " + ("Connection commit has succeeded."));
					rowsToCommitCount_tDBOutput_6 = 0;
				}
				commitCounter_tDBOutput_6 = 0;
				if (log.isDebugEnabled())
					log.debug("tDBOutput_6 - " + ("Closing the connection to the database."));
				conn_tDBOutput_6.close();
				if (log.isDebugEnabled())
					log.debug("tDBOutput_6 - " + ("Connection to the database has closed."));
				resourceMap.put("finish_tDBOutput_6", true);

				nb_line_deleted_tDBOutput_6 = nb_line_deleted_tDBOutput_6 + deletedCount_tDBOutput_6;
				nb_line_update_tDBOutput_6 = nb_line_update_tDBOutput_6 + updatedCount_tDBOutput_6;
				nb_line_inserted_tDBOutput_6 = nb_line_inserted_tDBOutput_6 + insertedCount_tDBOutput_6;
				nb_line_rejected_tDBOutput_6 = nb_line_rejected_tDBOutput_6 + rejectedCount_tDBOutput_6;

				globalMap.put("tDBOutput_6_NB_LINE", nb_line_tDBOutput_6);
				globalMap.put("tDBOutput_6_NB_LINE_UPDATED", nb_line_update_tDBOutput_6);
				globalMap.put("tDBOutput_6_NB_LINE_INSERTED", nb_line_inserted_tDBOutput_6);
				globalMap.put("tDBOutput_6_NB_LINE_DELETED", nb_line_deleted_tDBOutput_6);
				globalMap.put("tDBOutput_6_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_6);

				if (log.isDebugEnabled())
					log.debug("tDBOutput_6 - " + ("Has ") + ("inserted") + (" ") + (nb_line_inserted_tDBOutput_6)
							+ (" record(s)."));

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId,
						"Driver_License_Status_2", 2, 0, "tMap_7", "tMap_7", "tMap", "tDBOutput_6", "__TABLE__",
						"tMSSqlOutput", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tDBOutput_6 - " + ("Done."));

				ok_Hash.put("tDBOutput_6", true);
				end_Hash.put("tDBOutput_6", System.currentTimeMillis());

				/**
				 * [tDBOutput_6 end ] stop
				 */

				/**
				 * [tUniqRow_7 end ] start
				 */

				currentComponent = "tUniqRow_7";

				globalMap.put("tUniqRow_7_NB_UNIQUES", nb_uniques_tUniqRow_7);
				globalMap.put("tUniqRow_7_NB_DUPLICATES", nb_duplicates_tUniqRow_7);
				log.info("tUniqRow_7 - Unique records count: " + (nb_uniques_tUniqRow_7) + " .");
				log.info("tUniqRow_7 - Duplicate records count: " + (nb_duplicates_tUniqRow_7) + " .");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId,
						"Driver_License_Jusridiction", 2, 0, "tMap_1", "tMap_1", "tMap", "tUniqRow_7", "tUniqRow_7",
						"tUniqRow", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tUniqRow_7 - " + ("Done."));

				ok_Hash.put("tUniqRow_7", true);
				end_Hash.put("tUniqRow_7", System.currentTimeMillis());

				/**
				 * [tUniqRow_7 end ] stop
				 */

				/**
				 * [tMap_8 end ] start
				 */

				currentComponent = "tMap_8";

// ###############################
// # Lookup hashes releasing
// ###############################      
				log.debug("tMap_8 - Written records count in the table 'Jurisdiv': " + count_Jurisdiv_tMap_8 + ".");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "row8", 2, 0,
						"tUniqRow_7", "tUniqRow_7", "tUniqRow", "tMap_8", "tMap_8", "tMap", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tMap_8 - " + ("Done."));

				ok_Hash.put("tMap_8", true);
				end_Hash.put("tMap_8", System.currentTimeMillis());

				/**
				 * [tMap_8 end ] stop
				 */

				/**
				 * [tDBOutput_7 end ] start
				 */

				currentComponent = "tDBOutput_7";

				try {
					int countSum_tDBOutput_7 = 0;
					if (pstmt_tDBOutput_7 != null && batchSizeCounter_tDBOutput_7 > 0) {

						if (log.isDebugEnabled())
							log.debug("tDBOutput_7 - " + ("Executing the ") + ("INSERT") + (" batch."));
						for (int countEach_tDBOutput_7 : pstmt_tDBOutput_7.executeBatch()) {
							if (countEach_tDBOutput_7 == -2 || countEach_tDBOutput_7 == -3) {
								break;
							}
							countSum_tDBOutput_7 += countEach_tDBOutput_7;
						}
						rowsToCommitCount_tDBOutput_7 += countSum_tDBOutput_7;

						if (log.isDebugEnabled())
							log.debug("tDBOutput_7 - " + ("The ") + ("INSERT") + (" batch execution has succeeded."));
					}

					insertedCount_tDBOutput_7 += countSum_tDBOutput_7;

				} catch (java.sql.BatchUpdateException e) {
					globalMap.put("tDBOutput_7_ERROR_MESSAGE", e.getMessage());

					int countSum_tDBOutput_7 = 0;
					for (int countEach_tDBOutput_7 : e.getUpdateCounts()) {
						countSum_tDBOutput_7 += (countEach_tDBOutput_7 < 0 ? 0 : countEach_tDBOutput_7);
					}
					rowsToCommitCount_tDBOutput_7 += countSum_tDBOutput_7;

					insertedCount_tDBOutput_7 += countSum_tDBOutput_7;

					log.error("tDBOutput_7 - " + (e.getMessage()));
					System.err.println(e.getMessage());

				}
				if (pstmt_tDBOutput_7 != null) {

					pstmt_tDBOutput_7.close();
					resourceMap.remove("pstmt_tDBOutput_7");

				}
				resourceMap.put("statementClosed_tDBOutput_7", true);
				if (rowsToCommitCount_tDBOutput_7 != 0) {

					if (log.isDebugEnabled())
						log.debug("tDBOutput_7 - " + ("Connection starting to commit ")
								+ (rowsToCommitCount_tDBOutput_7) + (" record(s)."));
				}
				conn_tDBOutput_7.commit();
				if (rowsToCommitCount_tDBOutput_7 != 0) {

					if (log.isDebugEnabled())
						log.debug("tDBOutput_7 - " + ("Connection commit has succeeded."));
					rowsToCommitCount_tDBOutput_7 = 0;
				}
				commitCounter_tDBOutput_7 = 0;
				if (log.isDebugEnabled())
					log.debug("tDBOutput_7 - " + ("Closing the connection to the database."));
				conn_tDBOutput_7.close();
				if (log.isDebugEnabled())
					log.debug("tDBOutput_7 - " + ("Connection to the database has closed."));
				resourceMap.put("finish_tDBOutput_7", true);

				nb_line_deleted_tDBOutput_7 = nb_line_deleted_tDBOutput_7 + deletedCount_tDBOutput_7;
				nb_line_update_tDBOutput_7 = nb_line_update_tDBOutput_7 + updatedCount_tDBOutput_7;
				nb_line_inserted_tDBOutput_7 = nb_line_inserted_tDBOutput_7 + insertedCount_tDBOutput_7;
				nb_line_rejected_tDBOutput_7 = nb_line_rejected_tDBOutput_7 + rejectedCount_tDBOutput_7;

				globalMap.put("tDBOutput_7_NB_LINE", nb_line_tDBOutput_7);
				globalMap.put("tDBOutput_7_NB_LINE_UPDATED", nb_line_update_tDBOutput_7);
				globalMap.put("tDBOutput_7_NB_LINE_INSERTED", nb_line_inserted_tDBOutput_7);
				globalMap.put("tDBOutput_7_NB_LINE_DELETED", nb_line_deleted_tDBOutput_7);
				globalMap.put("tDBOutput_7_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_7);

				if (log.isDebugEnabled())
					log.debug("tDBOutput_7 - " + ("Has ") + ("inserted") + (" ") + (nb_line_inserted_tDBOutput_7)
							+ (" record(s)."));

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "Jurisdiv", 2, 0,
						"tMap_8", "tMap_8", "tMap", "tDBOutput_7", "__TABLE__", "tMSSqlOutput", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tDBOutput_7 - " + ("Done."));

				ok_Hash.put("tDBOutput_7", true);
				end_Hash.put("tDBOutput_7", System.currentTimeMillis());

				/**
				 * [tDBOutput_7 end ] stop
				 */

				/**
				 * [tUniqRow_8 end ] start
				 */

				currentComponent = "tUniqRow_8";

				globalMap.put("tUniqRow_8_NB_UNIQUES", nb_uniques_tUniqRow_8);
				globalMap.put("tUniqRow_8_NB_DUPLICATES", nb_duplicates_tUniqRow_8);
				log.info("tUniqRow_8 - Unique records count: " + (nb_uniques_tUniqRow_8) + " .");
				log.info("tUniqRow_8 - Duplicate records count: " + (nb_duplicates_tUniqRow_8) + " .");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "PreCash", 2, 0,
						"tMap_1", "tMap_1", "tMap", "tUniqRow_8", "tUniqRow_8", "tUniqRow", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tUniqRow_8 - " + ("Done."));

				ok_Hash.put("tUniqRow_8", true);
				end_Hash.put("tUniqRow_8", System.currentTimeMillis());

				/**
				 * [tUniqRow_8 end ] stop
				 */

				/**
				 * [tMap_9 end ] start
				 */

				currentComponent = "tMap_9";

// ###############################
// # Lookup hashes releasing
// ###############################      
				log.debug("tMap_9 - Written records count in the table 'PreCash22': " + count_PreCash22_tMap_9 + ".");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "row9", 2, 0,
						"tUniqRow_8", "tUniqRow_8", "tUniqRow", "tMap_9", "tMap_9", "tMap", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tMap_9 - " + ("Done."));

				ok_Hash.put("tMap_9", true);
				end_Hash.put("tMap_9", System.currentTimeMillis());

				/**
				 * [tMap_9 end ] stop
				 */

				/**
				 * [tDBOutput_8 end ] start
				 */

				currentComponent = "tDBOutput_8";

				try {
					int countSum_tDBOutput_8 = 0;
					if (pstmt_tDBOutput_8 != null && batchSizeCounter_tDBOutput_8 > 0) {

						if (log.isDebugEnabled())
							log.debug("tDBOutput_8 - " + ("Executing the ") + ("INSERT") + (" batch."));
						for (int countEach_tDBOutput_8 : pstmt_tDBOutput_8.executeBatch()) {
							if (countEach_tDBOutput_8 == -2 || countEach_tDBOutput_8 == -3) {
								break;
							}
							countSum_tDBOutput_8 += countEach_tDBOutput_8;
						}
						rowsToCommitCount_tDBOutput_8 += countSum_tDBOutput_8;

						if (log.isDebugEnabled())
							log.debug("tDBOutput_8 - " + ("The ") + ("INSERT") + (" batch execution has succeeded."));
					}

					insertedCount_tDBOutput_8 += countSum_tDBOutput_8;

				} catch (java.sql.BatchUpdateException e) {
					globalMap.put("tDBOutput_8_ERROR_MESSAGE", e.getMessage());

					int countSum_tDBOutput_8 = 0;
					for (int countEach_tDBOutput_8 : e.getUpdateCounts()) {
						countSum_tDBOutput_8 += (countEach_tDBOutput_8 < 0 ? 0 : countEach_tDBOutput_8);
					}
					rowsToCommitCount_tDBOutput_8 += countSum_tDBOutput_8;

					insertedCount_tDBOutput_8 += countSum_tDBOutput_8;

					log.error("tDBOutput_8 - " + (e.getMessage()));
					System.err.println(e.getMessage());

				}
				if (pstmt_tDBOutput_8 != null) {

					pstmt_tDBOutput_8.close();
					resourceMap.remove("pstmt_tDBOutput_8");

				}
				resourceMap.put("statementClosed_tDBOutput_8", true);
				if (rowsToCommitCount_tDBOutput_8 != 0) {

					if (log.isDebugEnabled())
						log.debug("tDBOutput_8 - " + ("Connection starting to commit ")
								+ (rowsToCommitCount_tDBOutput_8) + (" record(s)."));
				}
				conn_tDBOutput_8.commit();
				if (rowsToCommitCount_tDBOutput_8 != 0) {

					if (log.isDebugEnabled())
						log.debug("tDBOutput_8 - " + ("Connection commit has succeeded."));
					rowsToCommitCount_tDBOutput_8 = 0;
				}
				commitCounter_tDBOutput_8 = 0;
				if (log.isDebugEnabled())
					log.debug("tDBOutput_8 - " + ("Closing the connection to the database."));
				conn_tDBOutput_8.close();
				if (log.isDebugEnabled())
					log.debug("tDBOutput_8 - " + ("Connection to the database has closed."));
				resourceMap.put("finish_tDBOutput_8", true);

				nb_line_deleted_tDBOutput_8 = nb_line_deleted_tDBOutput_8 + deletedCount_tDBOutput_8;
				nb_line_update_tDBOutput_8 = nb_line_update_tDBOutput_8 + updatedCount_tDBOutput_8;
				nb_line_inserted_tDBOutput_8 = nb_line_inserted_tDBOutput_8 + insertedCount_tDBOutput_8;
				nb_line_rejected_tDBOutput_8 = nb_line_rejected_tDBOutput_8 + rejectedCount_tDBOutput_8;

				globalMap.put("tDBOutput_8_NB_LINE", nb_line_tDBOutput_8);
				globalMap.put("tDBOutput_8_NB_LINE_UPDATED", nb_line_update_tDBOutput_8);
				globalMap.put("tDBOutput_8_NB_LINE_INSERTED", nb_line_inserted_tDBOutput_8);
				globalMap.put("tDBOutput_8_NB_LINE_DELETED", nb_line_deleted_tDBOutput_8);
				globalMap.put("tDBOutput_8_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_8);

				if (log.isDebugEnabled())
					log.debug("tDBOutput_8 - " + ("Has ") + ("inserted") + (" ") + (nb_line_inserted_tDBOutput_8)
							+ (" record(s)."));

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "PreCash22", 2, 0,
						"tMap_9", "tMap_9", "tMap", "tDBOutput_8", "__TABLE__", "tMSSqlOutput", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tDBOutput_8 - " + ("Done."));

				ok_Hash.put("tDBOutput_8", true);
				end_Hash.put("tDBOutput_8", System.currentTimeMillis());

				/**
				 * [tDBOutput_8 end ] stop
				 */

				/**
				 * [tUniqRow_9 end ] start
				 */

				currentComponent = "tUniqRow_9";

				globalMap.put("tUniqRow_9_NB_UNIQUES", nb_uniques_tUniqRow_9);
				globalMap.put("tUniqRow_9_NB_DUPLICATES", nb_duplicates_tUniqRow_9);
				log.info("tUniqRow_9 - Unique records count: " + (nb_uniques_tUniqRow_9) + " .");
				log.info("tUniqRow_9 - Duplicate records count: " + (nb_duplicates_tUniqRow_9) + " .");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "Point_Of_Impact", 2, 0,
						"tMap_1", "tMap_1", "tMap", "tUniqRow_9", "tUniqRow_9", "tUniqRow", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tUniqRow_9 - " + ("Done."));

				ok_Hash.put("tUniqRow_9", true);
				end_Hash.put("tUniqRow_9", System.currentTimeMillis());

				/**
				 * [tUniqRow_9 end ] stop
				 */

				/**
				 * [tMap_10 end ] start
				 */

				currentComponent = "tMap_10";

// ###############################
// # Lookup hashes releasing
// ###############################      
				log.debug("tMap_10 - Written records count in the table 'PointOFImpact2': "
						+ count_PointOFImpact2_tMap_10 + ".");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "row10", 2, 0,
						"tUniqRow_9", "tUniqRow_9", "tUniqRow", "tMap_10", "tMap_10", "tMap", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tMap_10 - " + ("Done."));

				ok_Hash.put("tMap_10", true);
				end_Hash.put("tMap_10", System.currentTimeMillis());

				/**
				 * [tMap_10 end ] stop
				 */

				/**
				 * [tDBOutput_9 end ] start
				 */

				currentComponent = "tDBOutput_9";

				try {
					int countSum_tDBOutput_9 = 0;
					if (pstmt_tDBOutput_9 != null && batchSizeCounter_tDBOutput_9 > 0) {

						if (log.isDebugEnabled())
							log.debug("tDBOutput_9 - " + ("Executing the ") + ("INSERT") + (" batch."));
						for (int countEach_tDBOutput_9 : pstmt_tDBOutput_9.executeBatch()) {
							if (countEach_tDBOutput_9 == -2 || countEach_tDBOutput_9 == -3) {
								break;
							}
							countSum_tDBOutput_9 += countEach_tDBOutput_9;
						}
						rowsToCommitCount_tDBOutput_9 += countSum_tDBOutput_9;

						if (log.isDebugEnabled())
							log.debug("tDBOutput_9 - " + ("The ") + ("INSERT") + (" batch execution has succeeded."));
					}

					insertedCount_tDBOutput_9 += countSum_tDBOutput_9;

				} catch (java.sql.BatchUpdateException e) {
					globalMap.put("tDBOutput_9_ERROR_MESSAGE", e.getMessage());

					int countSum_tDBOutput_9 = 0;
					for (int countEach_tDBOutput_9 : e.getUpdateCounts()) {
						countSum_tDBOutput_9 += (countEach_tDBOutput_9 < 0 ? 0 : countEach_tDBOutput_9);
					}
					rowsToCommitCount_tDBOutput_9 += countSum_tDBOutput_9;

					insertedCount_tDBOutput_9 += countSum_tDBOutput_9;

					log.error("tDBOutput_9 - " + (e.getMessage()));
					System.err.println(e.getMessage());

				}
				if (pstmt_tDBOutput_9 != null) {

					pstmt_tDBOutput_9.close();
					resourceMap.remove("pstmt_tDBOutput_9");

				}
				resourceMap.put("statementClosed_tDBOutput_9", true);
				if (rowsToCommitCount_tDBOutput_9 != 0) {

					if (log.isDebugEnabled())
						log.debug("tDBOutput_9 - " + ("Connection starting to commit ")
								+ (rowsToCommitCount_tDBOutput_9) + (" record(s)."));
				}
				conn_tDBOutput_9.commit();
				if (rowsToCommitCount_tDBOutput_9 != 0) {

					if (log.isDebugEnabled())
						log.debug("tDBOutput_9 - " + ("Connection commit has succeeded."));
					rowsToCommitCount_tDBOutput_9 = 0;
				}
				commitCounter_tDBOutput_9 = 0;
				if (log.isDebugEnabled())
					log.debug("tDBOutput_9 - " + ("Closing the connection to the database."));
				conn_tDBOutput_9.close();
				if (log.isDebugEnabled())
					log.debug("tDBOutput_9 - " + ("Connection to the database has closed."));
				resourceMap.put("finish_tDBOutput_9", true);

				nb_line_deleted_tDBOutput_9 = nb_line_deleted_tDBOutput_9 + deletedCount_tDBOutput_9;
				nb_line_update_tDBOutput_9 = nb_line_update_tDBOutput_9 + updatedCount_tDBOutput_9;
				nb_line_inserted_tDBOutput_9 = nb_line_inserted_tDBOutput_9 + insertedCount_tDBOutput_9;
				nb_line_rejected_tDBOutput_9 = nb_line_rejected_tDBOutput_9 + rejectedCount_tDBOutput_9;

				globalMap.put("tDBOutput_9_NB_LINE", nb_line_tDBOutput_9);
				globalMap.put("tDBOutput_9_NB_LINE_UPDATED", nb_line_update_tDBOutput_9);
				globalMap.put("tDBOutput_9_NB_LINE_INSERTED", nb_line_inserted_tDBOutput_9);
				globalMap.put("tDBOutput_9_NB_LINE_DELETED", nb_line_deleted_tDBOutput_9);
				globalMap.put("tDBOutput_9_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_9);

				if (log.isDebugEnabled())
					log.debug("tDBOutput_9 - " + ("Has ") + ("inserted") + (" ") + (nb_line_inserted_tDBOutput_9)
							+ (" record(s)."));

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "PointOFImpact2", 2, 0,
						"tMap_10", "tMap_10", "tMap", "tDBOutput_9", "__TABLE__", "tMSSqlOutput", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tDBOutput_9 - " + ("Done."));

				ok_Hash.put("tDBOutput_9", true);
				end_Hash.put("tDBOutput_9", System.currentTimeMillis());

				/**
				 * [tDBOutput_9 end ] stop
				 */

				/**
				 * [tUniqRow_10 end ] start
				 */

				currentComponent = "tUniqRow_10";

				globalMap.put("tUniqRow_10_NB_UNIQUES", nb_uniques_tUniqRow_10);
				globalMap.put("tUniqRow_10_NB_DUPLICATES", nb_duplicates_tUniqRow_10);
				log.info("tUniqRow_10 - Unique records count: " + (nb_uniques_tUniqRow_10) + " .");
				log.info("tUniqRow_10 - Duplicate records count: " + (nb_duplicates_tUniqRow_10) + " .");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "Public_propertyDamage",
						2, 0, "tMap_1", "tMap_1", "tMap", "tUniqRow_10", "tUniqRow_10", "tUniqRow", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tUniqRow_10 - " + ("Done."));

				ok_Hash.put("tUniqRow_10", true);
				end_Hash.put("tUniqRow_10", System.currentTimeMillis());

				/**
				 * [tUniqRow_10 end ] stop
				 */

				/**
				 * [tMap_11 end ] start
				 */

				currentComponent = "tMap_11";

// ###############################
// # Lookup hashes releasing
// ###############################      
				log.debug("tMap_11 - Written records count in the table 'PublicPropertyDamage2': "
						+ count_PublicPropertyDamage2_tMap_11 + ".");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "row11", 2, 0,
						"tUniqRow_10", "tUniqRow_10", "tUniqRow", "tMap_11", "tMap_11", "tMap", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tMap_11 - " + ("Done."));

				ok_Hash.put("tMap_11", true);
				end_Hash.put("tMap_11", System.currentTimeMillis());

				/**
				 * [tMap_11 end ] stop
				 */

				/**
				 * [tDBOutput_10 end ] start
				 */

				currentComponent = "tDBOutput_10";

				try {
					int countSum_tDBOutput_10 = 0;
					if (pstmt_tDBOutput_10 != null && batchSizeCounter_tDBOutput_10 > 0) {

						if (log.isDebugEnabled())
							log.debug("tDBOutput_10 - " + ("Executing the ") + ("INSERT") + (" batch."));
						for (int countEach_tDBOutput_10 : pstmt_tDBOutput_10.executeBatch()) {
							if (countEach_tDBOutput_10 == -2 || countEach_tDBOutput_10 == -3) {
								break;
							}
							countSum_tDBOutput_10 += countEach_tDBOutput_10;
						}
						rowsToCommitCount_tDBOutput_10 += countSum_tDBOutput_10;

						if (log.isDebugEnabled())
							log.debug("tDBOutput_10 - " + ("The ") + ("INSERT") + (" batch execution has succeeded."));
					}

					insertedCount_tDBOutput_10 += countSum_tDBOutput_10;

				} catch (java.sql.BatchUpdateException e) {
					globalMap.put("tDBOutput_10_ERROR_MESSAGE", e.getMessage());

					int countSum_tDBOutput_10 = 0;
					for (int countEach_tDBOutput_10 : e.getUpdateCounts()) {
						countSum_tDBOutput_10 += (countEach_tDBOutput_10 < 0 ? 0 : countEach_tDBOutput_10);
					}
					rowsToCommitCount_tDBOutput_10 += countSum_tDBOutput_10;

					insertedCount_tDBOutput_10 += countSum_tDBOutput_10;

					log.error("tDBOutput_10 - " + (e.getMessage()));
					System.err.println(e.getMessage());

				}
				if (pstmt_tDBOutput_10 != null) {

					pstmt_tDBOutput_10.close();
					resourceMap.remove("pstmt_tDBOutput_10");

				}
				resourceMap.put("statementClosed_tDBOutput_10", true);
				if (rowsToCommitCount_tDBOutput_10 != 0) {

					if (log.isDebugEnabled())
						log.debug("tDBOutput_10 - " + ("Connection starting to commit ")
								+ (rowsToCommitCount_tDBOutput_10) + (" record(s)."));
				}
				conn_tDBOutput_10.commit();
				if (rowsToCommitCount_tDBOutput_10 != 0) {

					if (log.isDebugEnabled())
						log.debug("tDBOutput_10 - " + ("Connection commit has succeeded."));
					rowsToCommitCount_tDBOutput_10 = 0;
				}
				commitCounter_tDBOutput_10 = 0;
				if (log.isDebugEnabled())
					log.debug("tDBOutput_10 - " + ("Closing the connection to the database."));
				conn_tDBOutput_10.close();
				if (log.isDebugEnabled())
					log.debug("tDBOutput_10 - " + ("Connection to the database has closed."));
				resourceMap.put("finish_tDBOutput_10", true);

				nb_line_deleted_tDBOutput_10 = nb_line_deleted_tDBOutput_10 + deletedCount_tDBOutput_10;
				nb_line_update_tDBOutput_10 = nb_line_update_tDBOutput_10 + updatedCount_tDBOutput_10;
				nb_line_inserted_tDBOutput_10 = nb_line_inserted_tDBOutput_10 + insertedCount_tDBOutput_10;
				nb_line_rejected_tDBOutput_10 = nb_line_rejected_tDBOutput_10 + rejectedCount_tDBOutput_10;

				globalMap.put("tDBOutput_10_NB_LINE", nb_line_tDBOutput_10);
				globalMap.put("tDBOutput_10_NB_LINE_UPDATED", nb_line_update_tDBOutput_10);
				globalMap.put("tDBOutput_10_NB_LINE_INSERTED", nb_line_inserted_tDBOutput_10);
				globalMap.put("tDBOutput_10_NB_LINE_DELETED", nb_line_deleted_tDBOutput_10);
				globalMap.put("tDBOutput_10_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_10);

				if (log.isDebugEnabled())
					log.debug("tDBOutput_10 - " + ("Has ") + ("inserted") + (" ") + (nb_line_inserted_tDBOutput_10)
							+ (" record(s)."));

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "PublicPropertyDamage2",
						2, 0, "tMap_11", "tMap_11", "tMap", "tDBOutput_10", "__TABLE__", "tMSSqlOutput", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tDBOutput_10 - " + ("Done."));

				ok_Hash.put("tDBOutput_10", true);
				end_Hash.put("tDBOutput_10", System.currentTimeMillis());

				/**
				 * [tDBOutput_10 end ] stop
				 */

			} // end the resume

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage(), e);
			}

			TalendException te = new TalendException(e, currentComponent, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [tDBInput_1 finally ] start
				 */

				currentComponent = "tDBInput_1";

				/**
				 * [tDBInput_1 finally ] stop
				 */

				/**
				 * [tMap_1 finally ] start
				 */

				currentComponent = "tMap_1";

				/**
				 * [tMap_1 finally ] stop
				 */

				/**
				 * [tUniqRow_1 finally ] start
				 */

				currentComponent = "tUniqRow_1";

				/**
				 * [tUniqRow_1 finally ] stop
				 */

				/**
				 * [tMap_2 finally ] start
				 */

				currentComponent = "tMap_2";

				/**
				 * [tMap_2 finally ] stop
				 */

				/**
				 * [tDBOutput_1 finally ] start
				 */

				currentComponent = "tDBOutput_1";

				try {
					if (resourceMap.get("statementClosed_tDBOutput_1") == null) {
						java.sql.PreparedStatement pstmtToClose_tDBOutput_1 = null;
						if ((pstmtToClose_tDBOutput_1 = (java.sql.PreparedStatement) resourceMap
								.remove("pstmt_tDBOutput_1")) != null) {
							pstmtToClose_tDBOutput_1.close();
						}
					}
				} finally {
					if (resourceMap.get("finish_tDBOutput_1") == null) {
						java.sql.Connection ctn_tDBOutput_1 = null;
						if ((ctn_tDBOutput_1 = (java.sql.Connection) resourceMap.get("conn_tDBOutput_1")) != null) {
							try {
								if (log.isDebugEnabled())
									log.debug("tDBOutput_1 - " + ("Closing the connection to the database."));
								ctn_tDBOutput_1.close();
								if (log.isDebugEnabled())
									log.debug("tDBOutput_1 - " + ("Connection to the database has closed."));
							} catch (java.sql.SQLException sqlEx_tDBOutput_1) {
								String errorMessage_tDBOutput_1 = "failed to close the connection in tDBOutput_1 :"
										+ sqlEx_tDBOutput_1.getMessage();
								log.error("tDBOutput_1 - " + (errorMessage_tDBOutput_1));
								System.err.println(errorMessage_tDBOutput_1);
							}
						}
					}
				}

				/**
				 * [tDBOutput_1 finally ] stop
				 */

				/**
				 * [tUniqRow_2 finally ] start
				 */

				currentComponent = "tUniqRow_2";

				/**
				 * [tUniqRow_2 finally ] stop
				 */

				/**
				 * [tMap_3 finally ] start
				 */

				currentComponent = "tMap_3";

				/**
				 * [tMap_3 finally ] stop
				 */

				/**
				 * [tDBOutput_2 finally ] start
				 */

				currentComponent = "tDBOutput_2";

				try {
					if (resourceMap.get("statementClosed_tDBOutput_2") == null) {
						java.sql.PreparedStatement pstmtToClose_tDBOutput_2 = null;
						if ((pstmtToClose_tDBOutput_2 = (java.sql.PreparedStatement) resourceMap
								.remove("pstmt_tDBOutput_2")) != null) {
							pstmtToClose_tDBOutput_2.close();
						}
					}
				} finally {
					if (resourceMap.get("finish_tDBOutput_2") == null) {
						java.sql.Connection ctn_tDBOutput_2 = null;
						if ((ctn_tDBOutput_2 = (java.sql.Connection) resourceMap.get("conn_tDBOutput_2")) != null) {
							try {
								if (log.isDebugEnabled())
									log.debug("tDBOutput_2 - " + ("Closing the connection to the database."));
								ctn_tDBOutput_2.close();
								if (log.isDebugEnabled())
									log.debug("tDBOutput_2 - " + ("Connection to the database has closed."));
							} catch (java.sql.SQLException sqlEx_tDBOutput_2) {
								String errorMessage_tDBOutput_2 = "failed to close the connection in tDBOutput_2 :"
										+ sqlEx_tDBOutput_2.getMessage();
								log.error("tDBOutput_2 - " + (errorMessage_tDBOutput_2));
								System.err.println(errorMessage_tDBOutput_2);
							}
						}
					}
				}

				/**
				 * [tDBOutput_2 finally ] stop
				 */

				/**
				 * [tUniqRow_3 finally ] start
				 */

				currentComponent = "tUniqRow_3";

				/**
				 * [tUniqRow_3 finally ] stop
				 */

				/**
				 * [tMap_4 finally ] start
				 */

				currentComponent = "tMap_4";

				/**
				 * [tMap_4 finally ] stop
				 */

				/**
				 * [tDBOutput_3 finally ] start
				 */

				currentComponent = "tDBOutput_3";

				try {
					if (resourceMap.get("statementClosed_tDBOutput_3") == null) {
						java.sql.PreparedStatement pstmtToClose_tDBOutput_3 = null;
						if ((pstmtToClose_tDBOutput_3 = (java.sql.PreparedStatement) resourceMap
								.remove("pstmt_tDBOutput_3")) != null) {
							pstmtToClose_tDBOutput_3.close();
						}
					}
				} finally {
					if (resourceMap.get("finish_tDBOutput_3") == null) {
						java.sql.Connection ctn_tDBOutput_3 = null;
						if ((ctn_tDBOutput_3 = (java.sql.Connection) resourceMap.get("conn_tDBOutput_3")) != null) {
							try {
								if (log.isDebugEnabled())
									log.debug("tDBOutput_3 - " + ("Closing the connection to the database."));
								ctn_tDBOutput_3.close();
								if (log.isDebugEnabled())
									log.debug("tDBOutput_3 - " + ("Connection to the database has closed."));
							} catch (java.sql.SQLException sqlEx_tDBOutput_3) {
								String errorMessage_tDBOutput_3 = "failed to close the connection in tDBOutput_3 :"
										+ sqlEx_tDBOutput_3.getMessage();
								log.error("tDBOutput_3 - " + (errorMessage_tDBOutput_3));
								System.err.println(errorMessage_tDBOutput_3);
							}
						}
					}
				}

				/**
				 * [tDBOutput_3 finally ] stop
				 */

				/**
				 * [tUniqRow_4 finally ] start
				 */

				currentComponent = "tUniqRow_4";

				/**
				 * [tUniqRow_4 finally ] stop
				 */

				/**
				 * [tMap_5 finally ] start
				 */

				currentComponent = "tMap_5";

				/**
				 * [tMap_5 finally ] stop
				 */

				/**
				 * [tDBOutput_4 finally ] start
				 */

				currentComponent = "tDBOutput_4";

				try {
					if (resourceMap.get("statementClosed_tDBOutput_4") == null) {
						java.sql.PreparedStatement pstmtToClose_tDBOutput_4 = null;
						if ((pstmtToClose_tDBOutput_4 = (java.sql.PreparedStatement) resourceMap
								.remove("pstmt_tDBOutput_4")) != null) {
							pstmtToClose_tDBOutput_4.close();
						}
					}
				} finally {
					if (resourceMap.get("finish_tDBOutput_4") == null) {
						java.sql.Connection ctn_tDBOutput_4 = null;
						if ((ctn_tDBOutput_4 = (java.sql.Connection) resourceMap.get("conn_tDBOutput_4")) != null) {
							try {
								if (log.isDebugEnabled())
									log.debug("tDBOutput_4 - " + ("Closing the connection to the database."));
								ctn_tDBOutput_4.close();
								if (log.isDebugEnabled())
									log.debug("tDBOutput_4 - " + ("Connection to the database has closed."));
							} catch (java.sql.SQLException sqlEx_tDBOutput_4) {
								String errorMessage_tDBOutput_4 = "failed to close the connection in tDBOutput_4 :"
										+ sqlEx_tDBOutput_4.getMessage();
								log.error("tDBOutput_4 - " + (errorMessage_tDBOutput_4));
								System.err.println(errorMessage_tDBOutput_4);
							}
						}
					}
				}

				/**
				 * [tDBOutput_4 finally ] stop
				 */

				/**
				 * [tUniqRow_5 finally ] start
				 */

				currentComponent = "tUniqRow_5";

				/**
				 * [tUniqRow_5 finally ] stop
				 */

				/**
				 * [tMap_6 finally ] start
				 */

				currentComponent = "tMap_6";

				/**
				 * [tMap_6 finally ] stop
				 */

				/**
				 * [tDBOutput_5 finally ] start
				 */

				currentComponent = "tDBOutput_5";

				try {
					if (resourceMap.get("statementClosed_tDBOutput_5") == null) {
						java.sql.PreparedStatement pstmtToClose_tDBOutput_5 = null;
						if ((pstmtToClose_tDBOutput_5 = (java.sql.PreparedStatement) resourceMap
								.remove("pstmt_tDBOutput_5")) != null) {
							pstmtToClose_tDBOutput_5.close();
						}
					}
				} finally {
					if (resourceMap.get("finish_tDBOutput_5") == null) {
						java.sql.Connection ctn_tDBOutput_5 = null;
						if ((ctn_tDBOutput_5 = (java.sql.Connection) resourceMap.get("conn_tDBOutput_5")) != null) {
							try {
								if (log.isDebugEnabled())
									log.debug("tDBOutput_5 - " + ("Closing the connection to the database."));
								ctn_tDBOutput_5.close();
								if (log.isDebugEnabled())
									log.debug("tDBOutput_5 - " + ("Connection to the database has closed."));
							} catch (java.sql.SQLException sqlEx_tDBOutput_5) {
								String errorMessage_tDBOutput_5 = "failed to close the connection in tDBOutput_5 :"
										+ sqlEx_tDBOutput_5.getMessage();
								log.error("tDBOutput_5 - " + (errorMessage_tDBOutput_5));
								System.err.println(errorMessage_tDBOutput_5);
							}
						}
					}
				}

				/**
				 * [tDBOutput_5 finally ] stop
				 */

				/**
				 * [tUniqRow_6 finally ] start
				 */

				currentComponent = "tUniqRow_6";

				/**
				 * [tUniqRow_6 finally ] stop
				 */

				/**
				 * [tMap_7 finally ] start
				 */

				currentComponent = "tMap_7";

				/**
				 * [tMap_7 finally ] stop
				 */

				/**
				 * [tDBOutput_6 finally ] start
				 */

				currentComponent = "tDBOutput_6";

				try {
					if (resourceMap.get("statementClosed_tDBOutput_6") == null) {
						java.sql.PreparedStatement pstmtToClose_tDBOutput_6 = null;
						if ((pstmtToClose_tDBOutput_6 = (java.sql.PreparedStatement) resourceMap
								.remove("pstmt_tDBOutput_6")) != null) {
							pstmtToClose_tDBOutput_6.close();
						}
					}
				} finally {
					if (resourceMap.get("finish_tDBOutput_6") == null) {
						java.sql.Connection ctn_tDBOutput_6 = null;
						if ((ctn_tDBOutput_6 = (java.sql.Connection) resourceMap.get("conn_tDBOutput_6")) != null) {
							try {
								if (log.isDebugEnabled())
									log.debug("tDBOutput_6 - " + ("Closing the connection to the database."));
								ctn_tDBOutput_6.close();
								if (log.isDebugEnabled())
									log.debug("tDBOutput_6 - " + ("Connection to the database has closed."));
							} catch (java.sql.SQLException sqlEx_tDBOutput_6) {
								String errorMessage_tDBOutput_6 = "failed to close the connection in tDBOutput_6 :"
										+ sqlEx_tDBOutput_6.getMessage();
								log.error("tDBOutput_6 - " + (errorMessage_tDBOutput_6));
								System.err.println(errorMessage_tDBOutput_6);
							}
						}
					}
				}

				/**
				 * [tDBOutput_6 finally ] stop
				 */

				/**
				 * [tUniqRow_7 finally ] start
				 */

				currentComponent = "tUniqRow_7";

				/**
				 * [tUniqRow_7 finally ] stop
				 */

				/**
				 * [tMap_8 finally ] start
				 */

				currentComponent = "tMap_8";

				/**
				 * [tMap_8 finally ] stop
				 */

				/**
				 * [tDBOutput_7 finally ] start
				 */

				currentComponent = "tDBOutput_7";

				try {
					if (resourceMap.get("statementClosed_tDBOutput_7") == null) {
						java.sql.PreparedStatement pstmtToClose_tDBOutput_7 = null;
						if ((pstmtToClose_tDBOutput_7 = (java.sql.PreparedStatement) resourceMap
								.remove("pstmt_tDBOutput_7")) != null) {
							pstmtToClose_tDBOutput_7.close();
						}
					}
				} finally {
					if (resourceMap.get("finish_tDBOutput_7") == null) {
						java.sql.Connection ctn_tDBOutput_7 = null;
						if ((ctn_tDBOutput_7 = (java.sql.Connection) resourceMap.get("conn_tDBOutput_7")) != null) {
							try {
								if (log.isDebugEnabled())
									log.debug("tDBOutput_7 - " + ("Closing the connection to the database."));
								ctn_tDBOutput_7.close();
								if (log.isDebugEnabled())
									log.debug("tDBOutput_7 - " + ("Connection to the database has closed."));
							} catch (java.sql.SQLException sqlEx_tDBOutput_7) {
								String errorMessage_tDBOutput_7 = "failed to close the connection in tDBOutput_7 :"
										+ sqlEx_tDBOutput_7.getMessage();
								log.error("tDBOutput_7 - " + (errorMessage_tDBOutput_7));
								System.err.println(errorMessage_tDBOutput_7);
							}
						}
					}
				}

				/**
				 * [tDBOutput_7 finally ] stop
				 */

				/**
				 * [tUniqRow_8 finally ] start
				 */

				currentComponent = "tUniqRow_8";

				/**
				 * [tUniqRow_8 finally ] stop
				 */

				/**
				 * [tMap_9 finally ] start
				 */

				currentComponent = "tMap_9";

				/**
				 * [tMap_9 finally ] stop
				 */

				/**
				 * [tDBOutput_8 finally ] start
				 */

				currentComponent = "tDBOutput_8";

				try {
					if (resourceMap.get("statementClosed_tDBOutput_8") == null) {
						java.sql.PreparedStatement pstmtToClose_tDBOutput_8 = null;
						if ((pstmtToClose_tDBOutput_8 = (java.sql.PreparedStatement) resourceMap
								.remove("pstmt_tDBOutput_8")) != null) {
							pstmtToClose_tDBOutput_8.close();
						}
					}
				} finally {
					if (resourceMap.get("finish_tDBOutput_8") == null) {
						java.sql.Connection ctn_tDBOutput_8 = null;
						if ((ctn_tDBOutput_8 = (java.sql.Connection) resourceMap.get("conn_tDBOutput_8")) != null) {
							try {
								if (log.isDebugEnabled())
									log.debug("tDBOutput_8 - " + ("Closing the connection to the database."));
								ctn_tDBOutput_8.close();
								if (log.isDebugEnabled())
									log.debug("tDBOutput_8 - " + ("Connection to the database has closed."));
							} catch (java.sql.SQLException sqlEx_tDBOutput_8) {
								String errorMessage_tDBOutput_8 = "failed to close the connection in tDBOutput_8 :"
										+ sqlEx_tDBOutput_8.getMessage();
								log.error("tDBOutput_8 - " + (errorMessage_tDBOutput_8));
								System.err.println(errorMessage_tDBOutput_8);
							}
						}
					}
				}

				/**
				 * [tDBOutput_8 finally ] stop
				 */

				/**
				 * [tUniqRow_9 finally ] start
				 */

				currentComponent = "tUniqRow_9";

				/**
				 * [tUniqRow_9 finally ] stop
				 */

				/**
				 * [tMap_10 finally ] start
				 */

				currentComponent = "tMap_10";

				/**
				 * [tMap_10 finally ] stop
				 */

				/**
				 * [tDBOutput_9 finally ] start
				 */

				currentComponent = "tDBOutput_9";

				try {
					if (resourceMap.get("statementClosed_tDBOutput_9") == null) {
						java.sql.PreparedStatement pstmtToClose_tDBOutput_9 = null;
						if ((pstmtToClose_tDBOutput_9 = (java.sql.PreparedStatement) resourceMap
								.remove("pstmt_tDBOutput_9")) != null) {
							pstmtToClose_tDBOutput_9.close();
						}
					}
				} finally {
					if (resourceMap.get("finish_tDBOutput_9") == null) {
						java.sql.Connection ctn_tDBOutput_9 = null;
						if ((ctn_tDBOutput_9 = (java.sql.Connection) resourceMap.get("conn_tDBOutput_9")) != null) {
							try {
								if (log.isDebugEnabled())
									log.debug("tDBOutput_9 - " + ("Closing the connection to the database."));
								ctn_tDBOutput_9.close();
								if (log.isDebugEnabled())
									log.debug("tDBOutput_9 - " + ("Connection to the database has closed."));
							} catch (java.sql.SQLException sqlEx_tDBOutput_9) {
								String errorMessage_tDBOutput_9 = "failed to close the connection in tDBOutput_9 :"
										+ sqlEx_tDBOutput_9.getMessage();
								log.error("tDBOutput_9 - " + (errorMessage_tDBOutput_9));
								System.err.println(errorMessage_tDBOutput_9);
							}
						}
					}
				}

				/**
				 * [tDBOutput_9 finally ] stop
				 */

				/**
				 * [tUniqRow_10 finally ] start
				 */

				currentComponent = "tUniqRow_10";

				/**
				 * [tUniqRow_10 finally ] stop
				 */

				/**
				 * [tMap_11 finally ] start
				 */

				currentComponent = "tMap_11";

				/**
				 * [tMap_11 finally ] stop
				 */

				/**
				 * [tDBOutput_10 finally ] start
				 */

				currentComponent = "tDBOutput_10";

				try {
					if (resourceMap.get("statementClosed_tDBOutput_10") == null) {
						java.sql.PreparedStatement pstmtToClose_tDBOutput_10 = null;
						if ((pstmtToClose_tDBOutput_10 = (java.sql.PreparedStatement) resourceMap
								.remove("pstmt_tDBOutput_10")) != null) {
							pstmtToClose_tDBOutput_10.close();
						}
					}
				} finally {
					if (resourceMap.get("finish_tDBOutput_10") == null) {
						java.sql.Connection ctn_tDBOutput_10 = null;
						if ((ctn_tDBOutput_10 = (java.sql.Connection) resourceMap.get("conn_tDBOutput_10")) != null) {
							try {
								if (log.isDebugEnabled())
									log.debug("tDBOutput_10 - " + ("Closing the connection to the database."));
								ctn_tDBOutput_10.close();
								if (log.isDebugEnabled())
									log.debug("tDBOutput_10 - " + ("Connection to the database has closed."));
							} catch (java.sql.SQLException sqlEx_tDBOutput_10) {
								String errorMessage_tDBOutput_10 = "failed to close the connection in tDBOutput_10 :"
										+ sqlEx_tDBOutput_10.getMessage();
								log.error("tDBOutput_10 - " + (errorMessage_tDBOutput_10));
								System.err.println(errorMessage_tDBOutput_10);
							}
						}
					}
				}

				/**
				 * [tDBOutput_10 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tDBInput_1_SUBPROCESS_STATE", 1);
	}

	public void talendJobLogProcess(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("talendJobLog_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				/**
				 * [talendJobLog begin ] start
				 */

				ok_Hash.put("talendJobLog", false);
				start_Hash.put("talendJobLog", System.currentTimeMillis());

				currentComponent = "talendJobLog";

				int tos_count_talendJobLog = 0;

				for (JobStructureCatcherUtils.JobStructureCatcherMessage jcm : talendJobLog.getMessages()) {
					org.talend.job.audit.JobContextBuilder builder_talendJobLog = org.talend.job.audit.JobContextBuilder
							.create().jobName(jcm.job_name).jobId(jcm.job_id).jobVersion(jcm.job_version)
							.custom("process_id", jcm.pid).custom("thread_id", jcm.tid).custom("pid", pid)
							.custom("father_pid", fatherPid).custom("root_pid", rootPid);
					org.talend.logging.audit.Context log_context_talendJobLog = null;

					if (jcm.log_type == JobStructureCatcherUtils.LogType.PERFORMANCE) {
						long timeMS = jcm.end_time - jcm.start_time;
						String duration = String.valueOf(timeMS);

						log_context_talendJobLog = builder_talendJobLog.sourceId(jcm.sourceId)
								.sourceLabel(jcm.sourceLabel).sourceConnectorType(jcm.sourceComponentName)
								.targetId(jcm.targetId).targetLabel(jcm.targetLabel)
								.targetConnectorType(jcm.targetComponentName).connectionName(jcm.current_connector)
								.rows(jcm.row_count).duration(duration).build();
						auditLogger_talendJobLog.flowExecution(log_context_talendJobLog);
					} else if (jcm.log_type == JobStructureCatcherUtils.LogType.JOBSTART) {
						log_context_talendJobLog = builder_talendJobLog.timestamp(jcm.moment).build();
						auditLogger_talendJobLog.jobstart(log_context_talendJobLog);
					} else if (jcm.log_type == JobStructureCatcherUtils.LogType.JOBEND) {
						long timeMS = jcm.end_time - jcm.start_time;
						String duration = String.valueOf(timeMS);

						log_context_talendJobLog = builder_talendJobLog.timestamp(jcm.moment).duration(duration)
								.status(jcm.status).build();
						auditLogger_talendJobLog.jobstop(log_context_talendJobLog);
					} else if (jcm.log_type == JobStructureCatcherUtils.LogType.RUNCOMPONENT) {
						log_context_talendJobLog = builder_talendJobLog.timestamp(jcm.moment)
								.connectorType(jcm.component_name).connectorId(jcm.component_id)
								.connectorLabel(jcm.component_label).build();
						auditLogger_talendJobLog.runcomponent(log_context_talendJobLog);
					} else if (jcm.log_type == JobStructureCatcherUtils.LogType.FLOWINPUT) {// log current component
																							// input line
						long timeMS = jcm.end_time - jcm.start_time;
						String duration = String.valueOf(timeMS);

						log_context_talendJobLog = builder_talendJobLog.connectorType(jcm.component_name)
								.connectorId(jcm.component_id).connectorLabel(jcm.component_label)
								.connectionName(jcm.current_connector).connectionType(jcm.current_connector_type)
								.rows(jcm.total_row_number).duration(duration).build();
						auditLogger_talendJobLog.flowInput(log_context_talendJobLog);
					} else if (jcm.log_type == JobStructureCatcherUtils.LogType.FLOWOUTPUT) {// log current component
																								// output/reject line
						long timeMS = jcm.end_time - jcm.start_time;
						String duration = String.valueOf(timeMS);

						log_context_talendJobLog = builder_talendJobLog.connectorType(jcm.component_name)
								.connectorId(jcm.component_id).connectorLabel(jcm.component_label)
								.connectionName(jcm.current_connector).connectionType(jcm.current_connector_type)
								.rows(jcm.total_row_number).duration(duration).build();
						auditLogger_talendJobLog.flowOutput(log_context_talendJobLog);
					}

				}

				/**
				 * [talendJobLog begin ] stop
				 */

				/**
				 * [talendJobLog main ] start
				 */

				currentComponent = "talendJobLog";

				tos_count_talendJobLog++;

				/**
				 * [talendJobLog main ] stop
				 */

				/**
				 * [talendJobLog process_data_begin ] start
				 */

				currentComponent = "talendJobLog";

				/**
				 * [talendJobLog process_data_begin ] stop
				 */

				/**
				 * [talendJobLog process_data_end ] start
				 */

				currentComponent = "talendJobLog";

				/**
				 * [talendJobLog process_data_end ] stop
				 */

				/**
				 * [talendJobLog end ] start
				 */

				currentComponent = "talendJobLog";

				ok_Hash.put("talendJobLog", true);
				end_Hash.put("talendJobLog", System.currentTimeMillis());

				/**
				 * [talendJobLog end ] stop
				 */
			} // end the resume

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage(), e);
			}

			TalendException te = new TalendException(e, currentComponent, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [talendJobLog finally ] start
				 */

				currentComponent = "talendJobLog";

				/**
				 * [talendJobLog finally ] stop
				 */
			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("talendJobLog_SUBPROCESS_STATE", 1);
	}

	public String resuming_logs_dir_path = null;
	public String resuming_checkpoint_path = null;
	public String parent_part_launcher = null;
	private String resumeEntryMethodName = null;
	private boolean globalResumeTicket = false;

	public boolean watch = false;
	// portStats is null, it means don't execute the statistics
	public Integer portStats = null;
	public int portTraces = 4334;
	public String clientHost;
	public String defaultClientHost = "localhost";
	public String contextStr = "Default";
	public boolean isDefaultContext = true;
	public String pid = "0";
	public String rootPid = null;
	public String fatherPid = null;
	public String fatherNode = null;
	public long startTime = 0;
	public boolean isChildJob = false;
	public String log4jLevel = "";

	private boolean enableLogStash;

	private boolean execStat = true;

	private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
		protected java.util.Map<String, String> initialValue() {
			java.util.Map<String, String> threadRunResultMap = new java.util.HashMap<String, String>();
			threadRunResultMap.put("errorCode", null);
			threadRunResultMap.put("status", "");
			return threadRunResultMap;
		};
	};

	protected PropertiesWithType context_param = new PropertiesWithType();
	public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

	public String status = "";

	public static void main(String[] args) {
		final Loading_Dimension_Part2 Loading_Dimension_Part2Class = new Loading_Dimension_Part2();

		int exitCode = Loading_Dimension_Part2Class.runJobInTOS(args);
		if (exitCode == 0) {
			log.info("TalendJob: 'Loading_Dimension_Part2' - Done.");
		}

		System.exit(exitCode);
	}

	public String[][] runJob(String[] args) {

		int exitCode = runJobInTOS(args);
		String[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };

		return bufferValue;
	}

	public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;

		return hastBufferOutput;
	}

	public int runJobInTOS(String[] args) {
		// reset status
		status = "";

		String lastStr = "";
		for (String arg : args) {
			if (arg.equalsIgnoreCase("--context_param")) {
				lastStr = arg;
			} else if (lastStr.equals("")) {
				evalParam(arg);
			} else {
				evalParam(lastStr + " " + arg);
				lastStr = "";
			}
		}
		enableLogStash = "true".equalsIgnoreCase(System.getProperty("audit.enabled"));

		if (!"".equals(log4jLevel)) {

			if ("trace".equalsIgnoreCase(log4jLevel)) {
				org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(),
						org.apache.logging.log4j.Level.TRACE);
			} else if ("debug".equalsIgnoreCase(log4jLevel)) {
				org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(),
						org.apache.logging.log4j.Level.DEBUG);
			} else if ("info".equalsIgnoreCase(log4jLevel)) {
				org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(),
						org.apache.logging.log4j.Level.INFO);
			} else if ("warn".equalsIgnoreCase(log4jLevel)) {
				org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(),
						org.apache.logging.log4j.Level.WARN);
			} else if ("error".equalsIgnoreCase(log4jLevel)) {
				org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(),
						org.apache.logging.log4j.Level.ERROR);
			} else if ("fatal".equalsIgnoreCase(log4jLevel)) {
				org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(),
						org.apache.logging.log4j.Level.FATAL);
			} else if ("off".equalsIgnoreCase(log4jLevel)) {
				org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(),
						org.apache.logging.log4j.Level.OFF);
			}
			org.apache.logging.log4j.core.config.Configurator
					.setLevel(org.apache.logging.log4j.LogManager.getRootLogger().getName(), log.getLevel());

		}
		log.info("TalendJob: 'Loading_Dimension_Part2' - Start.");

		if (enableLogStash) {
			java.util.Properties properties_talendJobLog = new java.util.Properties();
			properties_talendJobLog.setProperty("root.logger", "audit");
			properties_talendJobLog.setProperty("encoding", "UTF-8");
			properties_talendJobLog.setProperty("application.name", "Talend Studio");
			properties_talendJobLog.setProperty("service.name", "Talend Studio Job");
			properties_talendJobLog.setProperty("instance.name", "Talend Studio Job Instance");
			properties_talendJobLog.setProperty("propagate.appender.exceptions", "none");
			properties_talendJobLog.setProperty("log.appender", "file");
			properties_talendJobLog.setProperty("appender.file.path", "audit.json");
			properties_talendJobLog.setProperty("appender.file.maxsize", "52428800");
			properties_talendJobLog.setProperty("appender.file.maxbackup", "20");
			properties_talendJobLog.setProperty("host", "false");

			System.getProperties().stringPropertyNames().stream().filter(it -> it.startsWith("audit.logger."))
					.forEach(key -> properties_talendJobLog.setProperty(key.substring("audit.logger.".length()),
							System.getProperty(key)));

			org.apache.logging.log4j.core.config.Configurator
					.setLevel(properties_talendJobLog.getProperty("root.logger"), org.apache.logging.log4j.Level.DEBUG);

			auditLogger_talendJobLog = org.talend.job.audit.JobEventAuditLoggerFactory
					.createJobAuditLogger(properties_talendJobLog);
		}

		if (clientHost == null) {
			clientHost = defaultClientHost;
		}

		if (pid == null || "0".equals(pid)) {
			pid = TalendString.getAsciiRandomString(6);
		}

		if (rootPid == null) {
			rootPid = pid;
		}
		if (fatherPid == null) {
			fatherPid = pid;
		} else {
			isChildJob = true;
		}

		if (portStats != null) {
			// portStats = -1; //for testing
			if (portStats < 0 || portStats > 65535) {
				// issue:10869, the portStats is invalid, so this client socket can't open
				System.err.println("The statistics socket port " + portStats + " is invalid.");
				execStat = false;
			}
		} else {
			execStat = false;
		}
		boolean inOSGi = routines.system.BundleUtils.inOSGi();

		if (inOSGi) {
			java.util.Dictionary<String, Object> jobProperties = routines.system.BundleUtils.getJobProperties(jobName);

			if (jobProperties != null && jobProperties.get("context") != null) {
				contextStr = (String) jobProperties.get("context");
			}
		}

		try {
			// call job/subjob with an existing context, like: --context=production. if
			// without this parameter, there will use the default context instead.
			java.io.InputStream inContext = Loading_Dimension_Part2.class.getClassLoader().getResourceAsStream(
					"mvc_talend/loading_dimension_part2_0_1/contexts/" + contextStr + ".properties");
			if (inContext == null) {
				inContext = Loading_Dimension_Part2.class.getClassLoader()
						.getResourceAsStream("config/contexts/" + contextStr + ".properties");
			}
			if (inContext != null) {
				try {
					// defaultProps is in order to keep the original context value
					if (context != null && context.isEmpty()) {
						defaultProps.load(inContext);
						context = new ContextProperties(defaultProps);
					}
				} finally {
					inContext.close();
				}
			} else if (!isDefaultContext) {
				// print info and job continue to run, for case: context_param is not empty.
				System.err.println("Could not find the context " + contextStr);
			}

			if (!context_param.isEmpty()) {
				context.putAll(context_param);
				// set types for params from parentJobs
				for (Object key : context_param.keySet()) {
					String context_key = key.toString();
					String context_type = context_param.getContextType(context_key);
					context.setContextType(context_key, context_type);

				}
			}
			class ContextProcessing {
				private void processContext_0() {
				}

				public void processAllContext() {
					processContext_0();
				}
			}

			new ContextProcessing().processAllContext();
		} catch (java.io.IOException ie) {
			System.err.println("Could not load context " + contextStr);
			ie.printStackTrace();
		}

		// get context value from parent directly
		if (parentContextMap != null && !parentContextMap.isEmpty()) {
		}

		// Resume: init the resumeUtil
		resumeEntryMethodName = ResumeUtil.getResumeEntryMethodName(resuming_checkpoint_path);
		resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
		resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName, jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
		// Resume: jobStart
		resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "",
				"", "", "", "", resumeUtil.convertToJsonText(context, parametersToEncrypt));

		if (execStat) {
			try {
				runStat.openSocket(!isChildJob);
				runStat.setAllPID(rootPid, fatherPid, pid, jobName);
				runStat.startThreadStat(clientHost, portStats);
				runStat.updateStatOnJob(RunStat.JOBSTART, fatherNode);
			} catch (java.io.IOException ioException) {
				ioException.printStackTrace();
			}
		}

		java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
		globalMap.put("concurrentHashMap", concurrentHashMap);

		long startUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
		long endUsedMemory = 0;
		long end = 0;

		startTime = System.currentTimeMillis();

		this.globalResumeTicket = true;// to run tPreJob

		if (enableLogStash) {
			talendJobLog.addJobStartMessage();
			try {
				talendJobLogProcess(globalMap);
			} catch (java.lang.Exception e) {
				e.printStackTrace();
			}
		}

		this.globalResumeTicket = false;// to run others jobs

		try {
			errorCode = null;
			tDBInput_1Process(globalMap);
			if (!"failure".equals(status)) {
				status = "end";
			}
		} catch (TalendException e_tDBInput_1) {
			globalMap.put("tDBInput_1_SUBPROCESS_STATE", -1);

			e_tDBInput_1.printStackTrace();

		}

		this.globalResumeTicket = true;// to run tPostJob

		end = System.currentTimeMillis();

		if (watch) {
			System.out.println((end - startTime) + " milliseconds");
		}

		endUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
		if (false) {
			System.out.println((endUsedMemory - startUsedMemory)
					+ " bytes memory increase when running : Loading_Dimension_Part2");
		}
		if (enableLogStash) {
			talendJobLog.addJobEndMessage(startTime, end, status);
			try {
				talendJobLogProcess(globalMap);
			} catch (java.lang.Exception e) {
				e.printStackTrace();
			}
		}

		if (execStat) {
			runStat.updateStatOnJob(RunStat.JOBEND, fatherNode);
			runStat.stopThreadStat();
		}
		int returnCode = 0;

		if (errorCode == null) {
			returnCode = status != null && status.equals("failure") ? 1 : 0;
		} else {
			returnCode = errorCode.intValue();
		}
		resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "",
				"" + returnCode, "", "", "");

		return returnCode;

	}

	// only for OSGi env
	public void destroy() {

	}

	private java.util.Map<String, Object> getSharedConnections4REST() {
		java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();

		return connections;
	}

	private void evalParam(String arg) {
		if (arg.startsWith("--resuming_logs_dir_path")) {
			resuming_logs_dir_path = arg.substring(25);
		} else if (arg.startsWith("--resuming_checkpoint_path")) {
			resuming_checkpoint_path = arg.substring(27);
		} else if (arg.startsWith("--parent_part_launcher")) {
			parent_part_launcher = arg.substring(23);
		} else if (arg.startsWith("--watch")) {
			watch = true;
		} else if (arg.startsWith("--stat_port=")) {
			String portStatsStr = arg.substring(12);
			if (portStatsStr != null && !portStatsStr.equals("null")) {
				portStats = Integer.parseInt(portStatsStr);
			}
		} else if (arg.startsWith("--trace_port=")) {
			portTraces = Integer.parseInt(arg.substring(13));
		} else if (arg.startsWith("--client_host=")) {
			clientHost = arg.substring(14);
		} else if (arg.startsWith("--context=")) {
			contextStr = arg.substring(10);
			isDefaultContext = false;
		} else if (arg.startsWith("--father_pid=")) {
			fatherPid = arg.substring(13);
		} else if (arg.startsWith("--root_pid=")) {
			rootPid = arg.substring(11);
		} else if (arg.startsWith("--father_node=")) {
			fatherNode = arg.substring(14);
		} else if (arg.startsWith("--pid=")) {
			pid = arg.substring(6);
		} else if (arg.startsWith("--context_type")) {
			String keyValue = arg.substring(15);
			int index = -1;
			if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
				if (fatherPid == null) {
					context_param.setContextType(keyValue.substring(0, index),
							replaceEscapeChars(keyValue.substring(index + 1)));
				} else { // the subjob won't escape the especial chars
					context_param.setContextType(keyValue.substring(0, index), keyValue.substring(index + 1));
				}

			}

		} else if (arg.startsWith("--context_param")) {
			String keyValue = arg.substring(16);
			int index = -1;
			if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
				if (fatherPid == null) {
					context_param.put(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
				} else { // the subjob won't escape the especial chars
					context_param.put(keyValue.substring(0, index), keyValue.substring(index + 1));
				}
			}
		} else if (arg.startsWith("--log4jLevel=")) {
			log4jLevel = arg.substring(13);
		} else if (arg.startsWith("--audit.enabled") && arg.contains("=")) {// for trunjob call
			final int equal = arg.indexOf('=');
			final String key = arg.substring("--".length(), equal);
			System.setProperty(key, arg.substring(equal + 1));
		}
	}

	private static final String NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY = "<TALEND_NULL>";

	private final String[][] escapeChars = { { "\\\\", "\\" }, { "\\n", "\n" }, { "\\'", "\'" }, { "\\r", "\r" },
			{ "\\f", "\f" }, { "\\b", "\b" }, { "\\t", "\t" } };

	private String replaceEscapeChars(String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0], currIndex);
				if (index >= 0) {

					result.append(keyValue.substring(currIndex, index + strArray[0].length()).replace(strArray[0],
							strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left into the
			// result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
	}

	public Integer getErrorCode() {
		return errorCode;
	}

	public String getStatus() {
		return status;
	}

	ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 * 635561 characters generated by Talend Real-time Big Data Platform on the
 * April 20, 2023 at 11:29:28 PM EDT
 ************************************************************************************************/